# Project Guidelines: Spring Boot 3 + Apache Camel + Java 21

## Tech Stack Overview
- **Language:** Java 21 (LTS)
- **Framework:** Spring Boot 3.x
- **Integration Engine:** Apache Camel (Java DSL preferred)
- **Build Tool:** Maven (`./mvnw`) or Gradle (`./gradlew`)
- **Container/Deployment:** Docker / Kubernetes-ready microservice

---

## 1. Java 21 Language & Coding Standards

### Core Paradigms
- **Immutability First:** Use `record` for all Data Transfer Objects (DTOs), API request/response payloads, and intermediate exchange body objects. Never create standard POJOs for read-only data structures.
- **Pattern Matching:** Utilize Java 21 pattern matching for `switch` statements and `instanceof` checks. Always prefer exhaustive switch expressions over multi-branch `if-else` blocks.
- **Sealed Types:** Use `sealed interface` or `sealed class` hierarchies to model domain state, event types, or message payload variations. Combine with pattern matching in Camel Processors.
- **Text Blocks:** Use multi-line text blocks (`"""`) for raw JSON, XML, SQL, or Cypher queries inside routes and repositories. Avoid string concatenation (`+`).
- **Sequenced Collections:** Use Java 21 `SequencedCollection` interface methods (`getFirst()`, `getLast()`) instead of manual index offset calculations (`get(0)`).

### Asynchronous & Threading Model
- **Virtual Threads:** Leverage Java 21 Virtual Threads (`Project Loom`). Ensure all blocking I/O calls (HTTP, JPA/JDBC, File, JMS/Kafka) are routed through virtual thread executors rather than legacy platform thread pools.
- **Avoid Pinning:** Ensure legacy synchronized blocks (`synchronized(this)`) that wrap long-running I/O are refactored to `ReentrantLock` to prevent Virtual Thread pinning.

---

## 2. Spring Boot 3 Conventions

### Architecture & Beans
- **Dependency Injection:** Use **Constructor Injection** exclusively with `final` fields. Do NOT use `@Autowired` on fields.
- **Configuration Properties:** Use `@ConfigurationProperties` with immutable Records (`@Retention(RetentionPolicy.RUNTIME)` / `@ConfigurationPropertiesScan`).
- **Bean Naming:** Standard Camel processors, transformers, and aggregators must be registered as `@Component` or `@Bean` with clear, domain-driven names.

### Web & Actuator
- Expose Health Indicators for Camel Contexts (`camel.health.*`).
- Enable Spring Boot Actuator endpoints for route status and metric collection.

---

## 3. Apache Camel Best Practices (Java DSL)

### Route Design & Structure
- **Java DSL Exclusively:** Do NOT write XML route definitions. All routes must extend `RouteBuilder` and reside in dedicated Spring `@Component` classes.
- **Single Responsibility Routes:** One route builder class per functional domain or integration flow. Break large monolith routes into sub-routes using `direct:` or `seda:` endpoints.
- **Clean Route Pipelines:** Avoid heavy inline lambda processors inside route definitions (`.process(exchange -> { ... 30 lines of code ... })`). Extract business logic into separate, unit-testable Spring `@Component` beans and invoke via `.bean(MyService.class, "methodName")` or method references.

### Message Payloads & Exchanges
- **Strong Typing:** Unmarshal incoming messages early into Java 21 Records using `.unmarshal().json(MyRecord.class)` or Jackson adapters.
- **Header Safety:** Minimize custom exchange headers. Prefer structured bodies or typed properties over arbitrary string key-value header pollution.

### Concurrency & Performance
- **Virtual Thread Pools:** Configure Camel context to support virtual threads globally:
  ```properties
  camel.threads.virtual.enabled=true
  ```
- **SEDA & Parallel Processing:** When using `.split()`, `.multicast()`, or `.threads()`, specify `.executorService()` or rely on virtual thread-backed pools for concurrent I/O task distribution.

### Error Handling & Resilience
- **Explicit Exception Handling:** Every `RouteBuilder` MUST declare an explicit `onException(...)` block handling domain-specific and network errors.
- **Dead Letter Channel:** Configure a Dead Letter Channel (`deadLetterChannel(...)`) with retries, exponential backoff, and dead-letter queueing for unrecoverable processing failures.
- **Transaction & Saga Management:** Use `@Transactional` boundaries or Camel's Saga pattern (`.saga()`) when coordinating distributed updates across databases and messaging brokers.

---

## 4. Code Generation & Refactoring Rules for AI Assistants

When modifying, generating, or refactoring code in this repository, ALWAYS follow these strict directives:

1. **Check Compatibility:** Ensure Spring Boot 3 baseline dependencies (Jakarta EE 10 namespaces `jakarta.persistence.*`, `jakarta.servlet.*`, `jakarta.annotation.*`) are used instead of legacy `javax.*` packages.
2. **Preserve Route Semantics:** Do NOT alter Camel route URIs, endpoint schemes, or parameters without explicit user instructions.
3. **Refactor Inline Processors:** Automatically extract inline lambdas in Camel routes exceeding 5 lines into testable Spring Beans or helper methods.
4. **Enforce Immutability:** Convert mutable DTOs or plain classes holding exchange state into Java 21 `record` structures.
5. **Enforce Test Passing:** Always ensure new or refactored routes have corresponding Camel Testkit / `@SpringBootTest` verification specs.

---

## 5. Development Workflow & Commands

### Build & Verify
- **Clean Build & Test:**
  ```bash
  ./mvnw clean verify
  # or
  ./gradlew clean build
  ```
- **Run Camel Routes Locally:**
  ```bash
  ./mvnw spring-boot:run
  ```
- **Run Specific Camel Test:**
  ```bash
  ./mvnw test -Dtest=OrderRouteTest
  ```

### Code Format & Quality
- Run code formatters before committing changes (`mvn spotbugs:check`, `mvn checkstyle:check`, or corresponding Gradle tasks).
