package vf.vbps.dxl.microservicemetadata.backend.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.ToString;
import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;

@lombok.Generated
@Validated
@Data
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class Auth2Request {
	
	@JsonProperty("client_id")
	private String clientId;
	
	@JsonProperty("client_secret")
	private String clientSecret;

}
