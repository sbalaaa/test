package vf.vbps.dxl.microservicemetadata.backend.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@lombok.Generated
@Data
public class Auth2Response {
	
	@JsonProperty("access_token")
	private String accessToken;
	
	@JsonProperty("token_type")
	private String tokenType;

	@JsonProperty("expires_in")
	private String expiresIn;
	
	@JsonProperty("scope")
	private String scope;
}
