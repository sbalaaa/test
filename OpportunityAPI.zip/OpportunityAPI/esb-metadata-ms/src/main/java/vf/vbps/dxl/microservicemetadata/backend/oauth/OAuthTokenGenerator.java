package vf.vbps.dxl.microservicemetadata.backend.oauth;

import java.util.List;

import vf.vbps.dxl.microservicemetadata.backend.model.Auth2Response;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;
import vf.vbps.dxl.microservicemetadata.model.AccessCredentialRef;

public interface OAuthTokenGenerator {
	
	public AccessCredentialRef generateToken(MetaData metadata, List<Credentials> credentialsList) throws Exception;
	
	public String decryptData(String data, String appName) throws Exception;
	
	public AccessCredentialRef mapAccessCredentials(Auth2Response authEntity);

}
