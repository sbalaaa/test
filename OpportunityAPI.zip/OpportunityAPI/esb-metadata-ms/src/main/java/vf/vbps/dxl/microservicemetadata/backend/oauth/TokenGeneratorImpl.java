package vf.vbps.dxl.microservicemetadata.backend.oauth;

import java.net.URI;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import vf.common.security.encryption.util.DBConfigAES256;
import vf.vbps.dxl.microservicemetadata.backend.model.Auth2Response;
import vf.vbps.dxl.microservicemetadata.configuration.ApplicationConfig;
import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;
import vf.vbps.dxl.microservicemetadata.model.AccessCredentialRef;

@Service
public class TokenGeneratorImpl implements OAuthTokenGenerator {

	private static final Logger log = LoggerFactory.getLogger(TokenGeneratorImpl.class);
	
	@Autowired
	private ApplicationConfig applicationConfig;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public AccessCredentialRef generateToken(MetaData metadata, List<Credentials> credentialsList) throws Exception {
		AccessCredentialRef accessCredentialRef = null;
		log.debug(MicroserviceMetadataConstants.TOKEN_GENERATION_IMPLEMENTATION,"generateToken");
		for (Credentials credentials : credentialsList) {
			if ((credentials.getClientId() != null) && !(credentials.getClientId().equals(""))
					&& !(credentials.getClientId().equals(" "))) {
				
				String accessTokenUrl = credentials.getAccessTokenUrl();

				// client credentials
				String clientId = decryptData(credentials.getClientId(), metadata.getBackendApp());
				String clientSecret = decryptData(credentials.getClientSecret(), metadata.getBackendApp());
				String grantType = credentials.getGrantType();
				String scope = credentials.getScope();

				final MultiValueMap<String, String> credintials = new LinkedMultiValueMap<>();
				credintials.set(MicroserviceMetadataConstants.CLIENT_ID, clientId);
				credintials.set(MicroserviceMetadataConstants.CLIENT_SECRET, clientSecret);

				final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(accessTokenUrl);
				builder.queryParam(MicroserviceMetadataConstants.GRANT_TYPE, grantType);
				builder.queryParam(MicroserviceMetadataConstants.SCOPE, scope);

				URI oAuthUrl = builder.build().toUri();

				log.debug("Generated URI ==> {}", oAuthUrl);
				
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

				HttpEntity<Object> entity = new HttpEntity<>(credintials, httpHeaders);

				log.debug("Auth Entity Request ==> {}", entity);
				
				//HttpEntity<Auth2Response> authEntity = restTemplate.exchange(oAuthUrl, HttpMethod.POST, entity,
				//		Auth2Response.class);

				//log.debug("Auth Entity ==> {}", authEntity);
				
				Auth2Response auth2Response = new Auth2Response();
				auth2Response.setAccessToken("1wYgQkKWNugfyzoHIpzaqk0WbMk7");
				auth2Response.setTokenType("Bearer");
				auth2Response.setScope("RESOURCE_INVENTORY_RESOURCE_CREATE");
				auth2Response.setExpiresIn("3600");

				accessCredentialRef = mapAccessCredentials(auth2Response);

			}
		}
		return accessCredentialRef;
	}

	@Override
	public String decryptData(String data, String appName) throws Exception {

		log.debug(MicroserviceMetadataConstants.TOKEN_GENERATION_IMPLEMENTATION,"decryptData");
		System.setProperty(MicroserviceMetadataConstants.ENV, applicationConfig.getEnvironment());
		DBConfigAES256 cryptographyAes256 = new DBConfigAES256();
		
		//String plainText = cryptographyAes256.decrypt(data, appName);
		String plainText = "Please Modify";
		log.debug("Decrypted Text ==> {}", plainText);
		
		return plainText;
	}

	@Override
	public AccessCredentialRef mapAccessCredentials(Auth2Response authEntity) {
		AccessCredentialRef accessCredentialRef = null;
		log.debug(MicroserviceMetadataConstants.TOKEN_GENERATION_IMPLEMENTATION,"mapAccessCredentials");
		if (authEntity != null) {
			accessCredentialRef = new AccessCredentialRef();
			accessCredentialRef.setId(MicroserviceMetadataConstants.TOKEN);
			accessCredentialRef.setValue(authEntity.getAccessToken());
		}
		return accessCredentialRef;
	}
}
