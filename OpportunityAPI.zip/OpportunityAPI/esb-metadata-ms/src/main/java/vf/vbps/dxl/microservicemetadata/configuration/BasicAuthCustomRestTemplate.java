package vf.vbps.dxl.microservicemetadata.configuration;

import org.apache.http.HttpHost;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import lombok.Data;

@lombok.Generated
@Data
@Configuration
public class BasicAuthCustomRestTemplate {

	@Autowired
	public ApplicationConfig applicationConfig;

	@Autowired
	RestTemplateBuilder builder;
	
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		CloseableHttpClient client = getCloseableHttpClient();
		return builder.requestFactory(() -> new HttpComponentsClientHttpRequestFactory(client)).build();
	}
	
	private CloseableHttpClient getCloseableHttpClient() {
		
		CloseableHttpClient client;

		String isproxyenabled = applicationConfig.getIsproxyenabled();
		if (isproxyenabled.equalsIgnoreCase("true")) {
			String proxyHost = applicationConfig.getHttpproxyhost();
			int proxyPort = Integer.parseInt(applicationConfig.getHttpproxyport());
			RequestConfig requestConfig = RequestConfig.custom().setProxy(new HttpHost(proxyHost, proxyPort)).build();

			client = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
		} else {
			int alliesTimeout = Integer.parseInt(applicationConfig.getBackendtimeout());
			RequestConfig requestConfig =RequestConfig.custom()
			.setConnectTimeout(alliesTimeout).setConnectionRequestTimeout(alliesTimeout).setSocketTimeout(alliesTimeout)
			.build();
			client = HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build();
		}
		return client;
	}

}
