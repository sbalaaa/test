package vf.vbps.dxl.microservicemetadata.constants;

public class MicroserviceMetadataConstants {
	
	private MicroserviceMetadataConstants() {
		
	}
	
	//Error Codes
	public static final String ERROR_CODE_401 = "401";
	public static final String ERROR_CODE_493 = "493";
	public static final String ERROR_CODE_495 = "495";
	public static final String ERROR_CODE_400 = "400";
	public static final String ERROR_CODE_404 = "404";
	public static final String ERROR_SERIES_4XX = "4XX";
	public static final String ERROR_SERIES_5XX = "5XX";
	
	//Response Constants
	public static final String ACCESS_TOKEN="access_token";
	public static final String TOKEN_TYPE="token_type";
	public static final String EXPIRES_IN="expires_in";
	public static final String SCOPE="scope";
	
	//Request Constants
	public static final String GRANT_TYPE="grant_type";
	
	//Request Params
	public static final String CLIENT_ID="client_id";
	public static final String CLIENT_SECRET="client_secret";
	
	//Response Constants
	public static final String TOKEN="TOKEN";
	public static final String USERNAME="USERNAME";
	public static final String PASSWORD="PASSWORD";
	public static final String APIKEY="APIKEY";
	
	//Generic Constants for Logging
	public static final String GET_MICROSERVICE_META_DATA_CONTROLLER="Controller Method {}";
	public static final String MICROSERVICE_META_DATA="microserviceMetaData";
	public static final String MICROSERVICE_META_DATA_RESPONSE="microserviceMetaData Response ==> {}";
	public static final String MONGODB_RESPONSE="MongoDB Response ==> {}";
	public static final String NOT_FOUND="Not Found ==> {}";
	public static final String AUTH2_URI="Auth2 URI ==> {}";
	public static final String DUPLICATE_ENTRIES="Duplicate entries found ==> {}";
	public static final String TOKEN_GENERATION_IMPLEMENTATION="TokenGenerationImplementation : Method {}";
	public static final String MONGO_SERVICE_IMPLEMENTATION="MongoServiceImplementation : Method {}";
	public static final String MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION="MicroServiceMetadataServiceImplementation : Method {}";
	
	public static final String ERROR ="error";
	public static final String TOTAL_QUANTITY="TotalQuantity";
	public static final String X_TOTAL_COUNT="X-Total-Count";
	public static final String TRUE="true";
	public static final String FALSE="false";
	public static final String CUSTOMER="Customer";
	public static final String VODAFONE="Vodafone";
	public static final String CSM_ERROR_CODE="CSM Error Code";
	public static final String EXIT_CODE="exitcode";
	public static final String INTERNAL_SERVER_ERROR="internal server error";
	public static final String ENV="env";
	
}