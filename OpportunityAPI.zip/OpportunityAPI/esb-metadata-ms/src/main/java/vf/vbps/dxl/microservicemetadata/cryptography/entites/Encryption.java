package vf.vbps.dxl.microservicemetadata.cryptography.entites;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@lombok.Generated
@Data
@Document(collection = "Encryption")
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class Encryption {
	
	@Id
	private String id;
	
	@Field("BACKEND_APP")
	private String backendApp;
	
	@Field("MECHANISM")
	private String mechanism;
	
	@Field("ENCYRPTION_KEY")
	private String encryptionKey;
	
	@Field("CIPHER")
	private String cipher;
	
	@Field("INITIALIZATION_VECTOR")
	private String initializationVector;
	
	@Field("_class")
	private String classPath;

}
