package vf.vbps.dxl.microservicemetadata.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import vf.vbps.dxl.microservicemetadata.entites.ApiList;

public interface ApiListDao extends MongoRepository<ApiList, String> {

}
