package vf.vbps.dxl.microservicemetadata.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import vf.vbps.dxl.microservicemetadata.entites.Attributes;

public interface AttributesDao extends MongoRepository<Attributes, String> {

}
