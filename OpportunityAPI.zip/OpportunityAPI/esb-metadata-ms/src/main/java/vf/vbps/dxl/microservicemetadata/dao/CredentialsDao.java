package vf.vbps.dxl.microservicemetadata.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import vf.vbps.dxl.microservicemetadata.entites.Credentials;

public interface CredentialsDao extends MongoRepository<Credentials, String> {

}
