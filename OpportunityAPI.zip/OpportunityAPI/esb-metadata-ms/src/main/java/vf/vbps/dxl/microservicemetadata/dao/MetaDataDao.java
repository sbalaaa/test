package vf.vbps.dxl.microservicemetadata.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import vf.vbps.dxl.microservicemetadata.entites.MetaData;

public interface MetaDataDao extends MongoRepository<MetaData, String> {
	
	public List<MetaData> findAllByBackendAppAndApplicationNameAndServiceNameAndCountryCode(String backendApp, String applicationName, String serviceName, String countryCode);

}
