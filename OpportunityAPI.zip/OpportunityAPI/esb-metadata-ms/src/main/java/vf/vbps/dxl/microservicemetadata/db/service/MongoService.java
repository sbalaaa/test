package vf.vbps.dxl.microservicemetadata.db.service;

import java.util.List;

import vf.vbps.dxl.microservicemetadata.entites.ApiList;
import vf.vbps.dxl.microservicemetadata.entites.Attributes;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;

public interface MongoService {
	
	public List<MetaData> getData(String backendApp, String applicationName, String serviceName, String countryCode);
	public List<Credentials> getCredentials(List<String> credentialsObjectList);
	public List<ApiList> getApiList(List<String> apiObjectList);
	public List<Attributes> getAttributes(List<String> attributesObjectList);

}
