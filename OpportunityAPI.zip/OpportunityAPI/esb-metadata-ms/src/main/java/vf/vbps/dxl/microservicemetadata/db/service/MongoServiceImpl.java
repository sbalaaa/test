package vf.vbps.dxl.microservicemetadata.db.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.dao.ApiListDao;
import vf.vbps.dxl.microservicemetadata.dao.AttributesDao;
import vf.vbps.dxl.microservicemetadata.dao.CredentialsDao;
import vf.vbps.dxl.microservicemetadata.dao.MetaDataDao;
import vf.vbps.dxl.microservicemetadata.entites.ApiList;
import vf.vbps.dxl.microservicemetadata.entites.Attributes;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;

@Service
public class MongoServiceImpl implements MongoService {

	@Autowired
	private MetaDataDao metaDataDao;

	@Autowired
	private CredentialsDao credentialsDao;

	@Autowired
	private ApiListDao apiListDao;

	@Autowired
	private AttributesDao attributesDao;

	private static final Logger log = LoggerFactory.getLogger(MongoServiceImpl.class);

	@Override
	public List<MetaData> getData(String backendApp, String applicationName, String serviceName, String countryCode) {
		log.debug(MicroserviceMetadataConstants.MONGO_SERVICE_IMPLEMENTATION, "getData");
		log.info("getDataArguments backendApp:: {} ,  ::applicationName:: {} , ::serviceName::{} , ::countryCode::{}", backendApp, applicationName, serviceName, countryCode);
		return metaDataDao.findAllByBackendAppAndApplicationNameAndServiceNameAndCountryCode(backendApp,
				applicationName, serviceName, countryCode);
	}

	@Override
	public List<Credentials> getCredentials(List<String> credentialsObjectList) {
		List<Credentials> credentialsList = new ArrayList<>();
		log.info("getCredentials credentialsList:: {} " , credentialsList );
		log.debug(MicroserviceMetadataConstants.MONGO_SERVICE_IMPLEMENTATION, "getCredentials");
		for (String temp : credentialsObjectList) {
//			Credentials credential = credentialsDao.findById(temp).get();
			Optional<Credentials> credential = credentialsDao.findById(temp);
			if (credential.isPresent()) {
				credentialsList.add(credential.get());
			}
		}
		return credentialsList;
	}

	@Override
	public List<ApiList> getApiList(List<String> apiObjectList) {
		List<ApiList> apiLists = new ArrayList<>();
		log.info("getApiList apiLists:: {} " , apiLists );
		log.debug(MicroserviceMetadataConstants.MONGO_SERVICE_IMPLEMENTATION, "getApiList");
		for (String temp : apiObjectList) {
//			ApiList apiList = apiListDao.findById(temp).get();
			Optional<ApiList> apiList = apiListDao.findById(temp);
			if (apiList.isPresent()) {
				apiLists.add(apiList.get());
			}
		}
		return apiLists;
	}

	@Override
	public List<Attributes> getAttributes(List<String> attributesObjectList) {
		List<Attributes> attributesList = new ArrayList<>();
		log.info("getAttributes attributesList:: {} " , attributesList );
		log.debug(MicroserviceMetadataConstants.MONGO_SERVICE_IMPLEMENTATION, "getAttributes");
		for (String temp : attributesObjectList) {
//			Attributes attribute = attributesDao.findById(temp).get();
			Optional<Attributes> attribute = attributesDao.findById(temp);
			if (attribute.isPresent()) {
				attributesList.add(attribute.get());
			}
		}
		return attributesList;
	}

}
