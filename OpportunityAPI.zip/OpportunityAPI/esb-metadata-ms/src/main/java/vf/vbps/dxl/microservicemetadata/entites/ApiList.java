package vf.vbps.dxl.microservicemetadata.entites;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@lombok.Generated
@Data
@Document(collection = "apilist")
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class ApiList implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4284054780585510023L;

	@Id
//	@Field("_id")
	private String id;
	
	@Field("name")
	private String name;
	
	@Field("value")
	private String value;

}
