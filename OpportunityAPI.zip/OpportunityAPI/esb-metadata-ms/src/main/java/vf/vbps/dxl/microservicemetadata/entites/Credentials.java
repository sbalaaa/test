package vf.vbps.dxl.microservicemetadata.entites;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@lombok.Generated
@Data
@Document(collection = "credentials")
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class Credentials implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2995660981209571137L;

	@Id
//	@Field("_id")
	private String id;
	
	@Field("client_id")
	private String clientId;
	
	@Field("client_secret")
	private String clientSecret;
	
	@Field("grant_type")
	private String grantType;
	
	@Field("scope")
	private String scope;
	
	@Field("last_modified")
	private String lastModified;
	
	@Field("access_token_url")
	private String accessTokenUrl;
	
	@Field("username")
	private String userName;
	
	@Field("password")
	private String password;
	
	@Field("apikey")
	private String apiKey;

}
