package vf.vbps.dxl.microservicemetadata.entites;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@lombok.Generated
@Data
@Document(collection = "metadata")
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class MetaData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7586169390788188289L;

	@Id
//	@Field("_id")
	private String id;
	
	@Field("backend_app")
	private String backendApp;
	
	@Field("application_name")
	private String applicationName;
	
	@Field("service_name")
	private String serviceName;
	
	@Field("country_code")
	private String countryCode;
	
	@Field("additional_key")
	private String additionalKey;
	
	@Field("last_modified")
	private String lastModified;
	
	@Field("endpoint_url")
	private String endpointUrl;
	
	@Field("credentials")
	private List<String> credentialsList;
	
	@Field("attributes")
	private List<String> attributesList;
	
	@Field("apilist")
	private List<String> apiList;

}
