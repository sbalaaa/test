package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BackEndSystemError500Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static BackEndSystemError500Exception newBackEndSystemError500Exception() {
		return new BackEndSystemError500Exception();
	}

	public static BackEndSystemError500Exception newBackEndSystemError500Exception(ErrorResponse errorResponse) {
		return new BackEndSystemError500Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected BackEndSystemError500Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

}