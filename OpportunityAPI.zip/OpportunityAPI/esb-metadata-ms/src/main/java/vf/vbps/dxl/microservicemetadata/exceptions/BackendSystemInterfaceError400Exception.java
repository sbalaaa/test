package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BackendSystemInterfaceError400Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static BackendSystemInterfaceError400Exception newBackendSystemInterfaceError400Exception() {
		return new BackendSystemInterfaceError400Exception();
	}

	public static BackendSystemInterfaceError400Exception newBackendSystemInterfaceError400Exception(
			ErrorResponse errorResponse) {
		return new BackendSystemInterfaceError400Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected BackendSystemInterfaceError400Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

}
