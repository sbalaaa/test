package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BackendSystemInterfaceTimeout401Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static BackendSystemInterfaceTimeout401Exception newBackendSystemInterfaceTimeout401Exception() {
		return new BackendSystemInterfaceTimeout401Exception();
	}

	public static BackendSystemInterfaceTimeout401Exception newBackendSystemInterfaceTimeout401Exception(
			ErrorResponse errorResponse) {
		return new BackendSystemInterfaceTimeout401Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected BackendSystemInterfaceTimeout401Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

}