package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BackendSystemUnavailable410Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static BackendSystemUnavailable410Exception newBackendSystemUnavailable410Exception() {
		return new BackendSystemUnavailable410Exception();
	}

	public static BackendSystemUnavailable410Exception newBackendSystemUnavailable410Exception(
			ErrorResponse errorResponse) {
		return new BackendSystemUnavailable410Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected BackendSystemUnavailable410Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

}
