package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;

/**
 * response responseCode
 */
@Getter
public enum CSMResponseCode {

	ERROR_CODE_210("210", "Unauthorized", "Minor", "System", "The client is not authorized to execute the operation."),
	ERROR_CODE_400("400", "Backend System Interface Error", "Minor", "System",
			"A general backend system interface error was encountered"),
	ERROR_CODE_401("401", "Backend System Interface Timeout", "Minor", "System",
			"The back-end system reply was not received after a defined amount of time"),
	ERROR_CODE_410("410", "Backend System Unavailable", "Major", "External",
			"The backend system adapter could not communicate with the back-end system"),
	ERROR_CODE_491("491", "Missing Business Object", "Minor", "System",
			"The business object supplied was not found in the backend system."),
	ERROR_CODE_500("500", "Back End System Error", "Major", "External",
			"A general backend system error was encountered"),
	ERROR_CODE_542("542", "Invalid ID or Serial Number", "Minor", "External", "Invalid Identifier passed in the request.");

	private final String errorCode;
	private final String name;
	private final String severity;
	private final String category;
	private final String message;

	CSMResponseCode(String errorCode, String name, String severity, String category, String message) {
		this.errorCode = errorCode;
		this.name = name;
		this.severity = severity;
		this.message = message;
		this.category = category;
	}
}
