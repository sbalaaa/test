package vf.vbps.dxl.microservicemetadata.exceptions;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;


/**
 * Another Characteristic that is related to the current Characteristic;
 */


@Validated
@lombok.Generated
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CharacteristicRelationship   {

  
  private String id = null;
  
  private String href = null;
  
  private String relationshipType = null;
  
  private String baseType = null;
  
  private String schemaLocation = null;
  
  private String type = null;

}

