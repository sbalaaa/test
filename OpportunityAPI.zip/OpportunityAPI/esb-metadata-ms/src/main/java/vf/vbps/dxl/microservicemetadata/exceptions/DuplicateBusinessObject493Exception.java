package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DuplicateBusinessObject493Exception extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public static DuplicateBusinessObject493Exception newMissingBusinessObject491Exception() {
		return new DuplicateBusinessObject493Exception();
	}

	public static DuplicateBusinessObject493Exception newMissingBusinessObject491Exception(ErrorResponse errorResponse) {
		return new DuplicateBusinessObject493Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected DuplicateBusinessObject493Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
}
