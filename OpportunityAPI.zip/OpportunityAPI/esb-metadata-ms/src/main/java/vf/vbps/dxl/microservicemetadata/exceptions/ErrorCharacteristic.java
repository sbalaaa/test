package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.List;

import javax.validation.Valid;

import org.omg.CORBA.Any;
import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;


/**
 * Describes a given characteristic of an object or entity through a name/value pair.
 */


@Validated
@lombok.Generated
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorCharacteristic   {

  
  private String id = null;
  
  private String name = null;
  
  private String valueType = null;
  
  @Valid
  private List<CharacteristicRelationship> characteristicRelationship = null;
  
  private Any value = null;
  
  private String baseType = null;
  
  private String schemaLocation = null;
  
  private String type = null;

}

