package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;


/**
 * A component that describes individual failures within the fault. This component is used to support multiple causes to the fault; i.e. where the fault is generated from one or more API calls or one or more validation failures.
 */


@Validated
@lombok.Generated
@Data
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class ErrorItem   {

  
  private String code = null;
  
  private String text = null;
  
  private String severity = null;
  
  @Valid
  private List<ErrorCharacteristic> errorItemCharacteristic = null;
  
  private String baseType = null;
  
  private String schemaLocation = null;
  
  private String type = null;

}

