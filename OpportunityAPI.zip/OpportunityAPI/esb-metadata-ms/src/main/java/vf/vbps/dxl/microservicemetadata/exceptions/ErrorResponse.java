package vf.vbps.dxl.microservicemetadata.exceptions;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ErrorResponse implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static ErrorResponse newErrorResponse(CSMResponseCode responseCode) {
		return new ErrorResponse(responseCode);
	}

	public static ErrorResponse newErrorResponse(String error, String message) {
		return new ErrorResponse(error, message);
	}

	public static ErrorResponse newErrorResponse(String error, String message, String description) {
		return new ErrorResponse(error, message, description);
	}

	private String error;

	private String message;

	private String description;

	private ErrorResponse(CSMResponseCode responseCode) {
		error = responseCode.getName();
		message = responseCode.getName();
		description = responseCode.getMessage();
	}

	private ErrorResponse(String error, String message) {
		this.error = error;
		this.message = message;
	}

	private ErrorResponse(String error, String message, String description) {
		this(error, message);
		this.description = description;
	}
}