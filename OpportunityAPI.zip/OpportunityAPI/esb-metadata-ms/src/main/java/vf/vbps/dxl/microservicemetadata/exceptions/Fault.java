package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * Fault
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Fault {
	@JsonProperty("timestamp")
	private String timestamp = null;

	@JsonProperty("originator")
	@Valid
	private List<FaultOriginator> originator = null;

	@JsonProperty("errorCode")
	@Valid
	private List<FaultErrorCode> errorCode = null;

	@JsonProperty("description")
	@Valid
	private List<FaultDescription> description = null;

	@JsonProperty("faultCause")
	private Object faultCause = null;

	@JsonProperty("name")
	private String name = null;

	@JsonProperty("severity")
	private String severity = null;

	@JsonProperty("category")
	private String category = null;

	@JsonProperty("reasonCode")
	private String reasonCode = null;

	@JsonProperty("message")
	private String message = null;

	@JsonProperty("characteristic")
	@Valid
	private List<FaultCharacteristic> characteristic = null;

	@JsonProperty("failure")
	@Valid
	private List<FaultFailure> failure = null;

	public Fault addCharacteristicItem(FaultCharacteristic characteristicItem) {
		if (this.characteristic == null) {
			this.characteristic = new ArrayList<FaultCharacteristic>();
		}
		this.characteristic.add(characteristicItem);
		return this;
	}

	public Fault addDescriptionItem(FaultDescription descriptionItem) {
		if (this.description == null) {
			this.description = new ArrayList<FaultDescription>();
		}
		this.description.add(descriptionItem);
		return this;
	}

	public Fault addErrorCodeItem(FaultErrorCode errorCodeItem) {
		if (this.errorCode == null) {
			this.errorCode = new ArrayList<FaultErrorCode>();
		}
		this.errorCode.add(errorCodeItem);
		return this;
	}

	public Fault addFailureItem(FaultFailure failureItem) {
		if (this.failure == null) {
			this.failure = new ArrayList<FaultFailure>();
		}
		this.failure.add(failureItem);
		return this;
	}

	public Fault addOriginatorItem(FaultOriginator originatorItem) {
		if (this.originator == null) {
			this.originator = new ArrayList<FaultOriginator>();
		}
		this.originator.add(originatorItem);
		return this;
	}

	public Fault category(String category) {
		this.category = category;
		return this;
	}

	public Fault characteristic(List<FaultCharacteristic> characteristic) {
		this.characteristic = characteristic;
		return this;
	}

	public Fault description(List<FaultDescription> description) {
		this.description = description;
		return this;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Fault fault = (Fault) o;
		return Objects.equals(this.timestamp, fault.timestamp) && Objects.equals(this.originator, fault.originator)
				&& Objects.equals(this.errorCode, fault.errorCode)
				&& Objects.equals(this.description, fault.description)
				&& Objects.equals(this.faultCause, fault.faultCause) && Objects.equals(this.name, fault.name)
				&& Objects.equals(this.severity, fault.severity) && Objects.equals(this.category, fault.category)
				&& Objects.equals(this.reasonCode, fault.reasonCode) && Objects.equals(this.message, fault.message)
				&& Objects.equals(this.characteristic, fault.characteristic)
				&& Objects.equals(this.failure, fault.failure);
	}

	public Fault errorCode(List<FaultErrorCode> errorCode) {
		this.errorCode = errorCode;
		return this;
	}

	public Fault failure(List<FaultFailure> failure) {
		this.failure = failure;
		return this;
	}

	public Fault faultCause(Object faultCause) {
		this.faultCause = faultCause;
		return this;
	}

	/**
	 * A classification of the fault indicating whether it has been generated
	 * through some technical aspect of the interaction or on account of a failure
	 * of business logic, rules or processing. It provides an indication of the type
	 * that may be used to trigger different behaviours in the consumer. Required if
	 * the Error Code >= 100, may be omitted or set to Business if the object is
	 * being used to indicate success.
	 * 
	 * @return category
	 **/
	@ApiModelProperty(value = "A classification of the fault indicating whether it has been generated through some technical aspect of the interaction or on account of a failure of business logic, rules or processing. It provides an indication of the type that may be used to trigger different behaviours in the consumer. Required if the Error Code >= 100, may be omitted or set to Business if the object is being used to indicate success.")

	public String getCategory() {
		return category;
	}

	/**
	 * Get characteristic
	 * 
	 * @return characteristic
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<FaultCharacteristic> getCharacteristic() {
		return characteristic;
	}

	/**
	 * Get description
	 * 
	 * @return description
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<FaultDescription> getDescription() {
		return description;
	}

	/**
	 * Get errorCode
	 * 
	 * @return errorCode
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<FaultErrorCode> getErrorCode() {
		return errorCode;
	}

	/**
	 * Get failure
	 * 
	 * @return failure
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<FaultFailure> getFailure() {
		return failure;
	}

	/**
	 * The legacy fault from the backend system.
	 * 
	 * @return faultCause
	 **/
	@ApiModelProperty(value = "The legacy fault from the backend system.")

	public Object getFaultCause() {
		return faultCause;
	}

	/**
	 * A human readable description of the fault as identified by the Error Code.
	 * Required if the Error Code >= 100, may be omitted or set to
	 * 
	 * @return message
	 **/
	@ApiModelProperty(value = "A human readable description of the fault as identified by the Error Code. Required if the Error Code >= 100, may be omitted or set to ")

	public String getMessage() {
		return message;
	}

	/**
	 * A human readable short text name for the fault. Required if the Error Code >=
	 * 100, may be omitted or set to
	 * 
	 * @return name
	 **/
	@ApiModelProperty(value = "A human readable short text name for the fault. Required if the Error Code >= 100, may be omitted or set to ")

	public String getName() {
		return name;
	}

	/**
	 * Get originator
	 * 
	 * @return originator
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public List<FaultOriginator> getOriginator() {
		return originator;
	}

	/**
	 * An enumeration of the reasons why the fault has been generated by the
	 * provider. Currently this is not used.
	 * 
	 * @return reasonCode
	 **/
	@ApiModelProperty(value = "An enumeration of the reasons why the fault has been generated by the provider. Currently this is not used.")

	public String getReasonCode() {
		return reasonCode;
	}

	/**
	 * The degree of severity and impact the fault has inccured, provides an
	 * indication of the level that may be used to trigger different behaviours in
	 * the consumer. Required if the Error Code >= 100, may be omitted or set to
	 * Information if the object is being used to indicate success.
	 * 
	 * @return severity
	 **/
	@ApiModelProperty(value = "The degree of severity and impact the fault has inccured, provides an indication of the level that may be used to trigger different behaviours in the consumer. Required if the Error Code >= 100, may be omitted or set to Information if the object is being used to indicate success.")

	public String getSeverity() {
		return severity;
	}

	/**
	 * Get timestamp
	 * 
	 * @return timestamp
	 **/
	@ApiModelProperty(required = true, value = "")
	@NotNull

	public String getTimestamp() {
		return timestamp;
	}

	@Override
	public int hashCode() {
		return Objects.hash(timestamp, originator, errorCode, description, faultCause, name, severity, category,
				reasonCode, message, characteristic, failure);
	}

	public Fault message(String message) {
		this.message = message;
		return this;
	}

	public Fault name(String name) {
		this.name = name;
		return this;
	}

	public Fault originator(List<FaultOriginator> originator) {
		this.originator = originator;
		return this;
	}

	public Fault reasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
		return this;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setCharacteristic(List<FaultCharacteristic> characteristic) {
		this.characteristic = characteristic;
	}

	public void setDescription(List<FaultDescription> description) {
		this.description = description;
	}

	public void setErrorCode(List<FaultErrorCode> errorCode) {
		this.errorCode = errorCode;
	}

	public void setFailure(List<FaultFailure> failure) {
		this.failure = failure;
	}

	public void setFaultCause(Object faultCause) {
		this.faultCause = faultCause;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOriginator(List<FaultOriginator> originator) {
		this.originator = originator;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public Fault severity(String severity) {
		this.severity = severity;
		return this;
	}

	public Fault timestamp(String timestamp) {
		this.timestamp = timestamp;
		return this;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class Fault {\n");

		sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
		sb.append("    originator: ").append(toIndentedString(originator)).append("\n");
		sb.append("    errorCode: ").append(toIndentedString(errorCode)).append("\n");
		sb.append("    description: ").append(toIndentedString(description)).append("\n");
		sb.append("    faultCause: ").append(toIndentedString(faultCause)).append("\n");
		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    severity: ").append(toIndentedString(severity)).append("\n");
		sb.append("    category: ").append(toIndentedString(category)).append("\n");
		sb.append("    reasonCode: ").append(toIndentedString(reasonCode)).append("\n");
		sb.append("    message: ").append(toIndentedString(message)).append("\n");
		sb.append("    characteristic: ").append(toIndentedString(characteristic)).append("\n");
		sb.append("    failure: ").append(toIndentedString(failure)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}
