package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A characteristic of the fault; these have both a name and a value.
 */
@ApiModel(description = "A characteristic of the fault; these have both a name and a value.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")

public class FaultCharacteristic {
	@JsonProperty("name")
	private String name = null;

	@JsonProperty("value")
	private String value = null;

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FaultCharacteristic faultCharacteristic = (FaultCharacteristic) o;
		return Objects.equals(this.name, faultCharacteristic.name)
				&& Objects.equals(this.value, faultCharacteristic.value);
	}

	/**
	 * Get name
	 * 
	 * @return name
	 **/
	@ApiModelProperty(required = true, value = "")
	@NotNull

	public String getName() {
		return name;
	}

	/**
	 * Get value
	 * 
	 * @return value
	 **/
	@ApiModelProperty(required = true, value = "")
	@NotNull

	public String getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, value);
	}

	public FaultCharacteristic name(String name) {
		this.name = name;
		return this;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FaultCharacteristic {\n");

		sb.append("    name: ").append(toIndentedString(name)).append("\n");
		sb.append("    value: ").append(toIndentedString(value)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	public FaultCharacteristic value(String value) {
		this.value = value;
		return this;
	}
}
