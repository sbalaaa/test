package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * FaultDescription
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FaultDescription {
	@JsonProperty("value")
	private String value = null;

	@JsonProperty("lang")
	private String lang = null;

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FaultDescription faultDescription = (FaultDescription) o;
		return Objects.equals(this.value, faultDescription.value) && Objects.equals(this.lang, faultDescription.lang);
	}

	/**
	 * Get lang
	 * 
	 * @return lang
	 **/
	@ApiModelProperty(value = "")

	public String getLang() {
		return lang;
	}

	/**
	 * Get value
	 * 
	 * @return value
	 **/
	@ApiModelProperty(required = true, value = "")
	@NotNull

	public String getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value, lang);
	}

	public FaultDescription lang(String lang) {
		this.lang = lang;
		return this;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FaultDescription {\n");

		sb.append("    value: ").append(toIndentedString(value)).append("\n");
		sb.append("    lang: ").append(toIndentedString(lang)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	public FaultDescription value(String value) {
		this.value = value;
		return this;
	}
}
