package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.Objects;

import javax.validation.constraints.NotNull;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * FaultErrorCode
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FaultErrorCode {
	@JsonProperty("value")
	private String value = null;

	@JsonProperty("dialect")
	private String dialect = null;

	public FaultErrorCode dialect(String dialect) {
		this.dialect = dialect;
		return this;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FaultErrorCode faultErrorCode = (FaultErrorCode) o;
		return Objects.equals(this.value, faultErrorCode.value) && Objects.equals(this.dialect, faultErrorCode.dialect);
	}

	/**
	 * Get dialect
	 * 
	 * @return dialect
	 **/
	@ApiModelProperty(value = "")

	public String getDialect() {
		return dialect;
	}

	/**
	 * Get value
	 * 
	 * @return value
	 **/
	@ApiModelProperty(required = true, value = "")
	@NotNull

	public String getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value, dialect);
	}

	public void setDialect(String dialect) {
		this.dialect = dialect;
	}

	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FaultErrorCode {\n");

		sb.append("    value: ").append(toIndentedString(value)).append("\n");
		sb.append("    dialect: ").append(toIndentedString(dialect)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	public FaultErrorCode value(String value) {
		this.value = value;
		return this;
	}
}
