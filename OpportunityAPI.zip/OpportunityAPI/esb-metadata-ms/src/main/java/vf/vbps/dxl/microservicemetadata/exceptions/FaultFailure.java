package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * A component that describes individual failures within the fault. This
 * component is used to support multiple causes to the fault; i.e. where the
 * fault is generated from one or more API calls or one or more validation
 * failures.
 */
@ApiModel(description = "A component that describes individual failures within the fault. This component is used to support multiple causes to the fault; i.e. where the fault is generated from one or more API calls or one or more validation failures.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class FaultFailure {
	@JsonProperty("code")
	private String code = null;

	@JsonProperty("text")
	private String text = null;

	@JsonProperty("dataRef")
	private FaultDataRef dataRef = null;

	@JsonProperty("Severity")
	private String severity = null;

	public FaultFailure code(String code) {
		this.code = code;
		return this;
	}

	public FaultFailure dataRef(FaultDataRef dataRef) {
		this.dataRef = dataRef;
		return this;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FaultFailure faultFailure = (FaultFailure) o;
		return Objects.equals(this.code, faultFailure.code) && Objects.equals(this.text, faultFailure.text)
				&& Objects.equals(this.dataRef, faultFailure.dataRef)
				&& Objects.equals(this.severity, faultFailure.severity);
	}

	/**
	 * The code identifying the specific failure.
	 * 
	 * @return code
	 **/
	@ApiModelProperty(value = "The code identifying the specific failure.")

	public String getCode() {
		return code;
	}

	/**
	 * Get dataRef
	 * 
	 * @return dataRef
	 **/
	@ApiModelProperty(value = "")

	@Valid

	public FaultDataRef getDataRef() {
		return dataRef;
	}

	/**
	 * The degree of severity and impact the fault has inccured, provides an
	 * indication of the level that may be used to trigger different behaviours in
	 * the consumer. Required if the Error Code >= 100, may be omitted or set to
	 * Information if the object is being used to indicate success.
	 * 
	 * @return severity
	 **/
	@ApiModelProperty(value = "The degree of severity and impact the fault has inccured, provides an indication of the level that may be used to trigger different behaviours in the consumer. Required if the Error Code >= 100, may be omitted or set to Information if the object is being used to indicate success.")

	public String getSeverity() {
		return severity;
	}

	/**
	 * The human-readable text of the specific failure.
	 * 
	 * @return text
	 **/
	@ApiModelProperty(value = "The human-readable text of the specific failure.")

	public String getText() {
		return text;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code, text, dataRef, severity);
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setDataRef(FaultDataRef dataRef) {
		this.dataRef = dataRef;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public void setText(String text) {
		this.text = text;
	}

	public FaultFailure severity(String severity) {
		this.severity = severity;
		return this;
	}

	public FaultFailure text(String text) {
		this.text = text;
		return this;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FaultFailure {\n");

		sb.append("    code: ").append(toIndentedString(code)).append("\n");
		sb.append("    text: ").append(toIndentedString(text)).append("\n");
		sb.append("    dataRef: ").append(toIndentedString(dataRef)).append("\n");
		sb.append("    severity: ").append(toIndentedString(severity)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}
