package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * FaultOriginator
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-04-29T13:10:13.274+05:30")

public class FaultOriginator {
	@JsonProperty("address")
	private String address = null;

	@JsonProperty("reference-parameters")
	@Valid
	private List<Object> referenceParameters = null;

	@JsonProperty("metadata")
	@Valid
	private List<Object> metadata = null;

	public FaultOriginator addMetadataItem(Object metadataItem) {
		if (this.metadata == null) {
			this.metadata = new ArrayList<Object>();
		}
		this.metadata.add(metadataItem);
		return this;
	}

	public FaultOriginator addReferenceParametersItem(Object referenceParametersItem) {
		if (this.referenceParameters == null) {
			this.referenceParameters = new ArrayList<Object>();
		}
		this.referenceParameters.add(referenceParametersItem);
		return this;
	}

	public FaultOriginator address(String address) {
		this.address = address;
		return this;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		FaultOriginator faultOriginator = (FaultOriginator) o;
		return Objects.equals(this.address, faultOriginator.address)
				&& Objects.equals(this.referenceParameters, faultOriginator.referenceParameters)
				&& Objects.equals(this.metadata, faultOriginator.metadata);
	}

	/**
	 * 
	 * @return address
	 **/
	@ApiModelProperty(value = "")

	public String getAddress() {
		return address;
	}

	/**
	 * Get metadata
	 * 
	 * @return metadata
	 **/
	@ApiModelProperty(value = "")

	public List<Object> getMetadata() {
		return metadata;
	}

	/**
	 * Get referenceParameters
	 * 
	 * @return referenceParameters
	 **/
	@ApiModelProperty(value = "")

	public List<Object> getReferenceParameters() {
		return referenceParameters;
	}

	@Override
	public int hashCode() {
		return Objects.hash(address, referenceParameters, metadata);
	}

	public FaultOriginator metadata(List<Object> metadata) {
		this.metadata = metadata;
		return this;
	}

	public FaultOriginator referenceParameters(List<Object> referenceParameters) {
		this.referenceParameters = referenceParameters;
		return this;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setMetadata(List<Object> metadata) {
		this.metadata = metadata;
	}

	public void setReferenceParameters(List<Object> referenceParameters) {
		this.referenceParameters = referenceParameters;
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class FaultOriginator {\n");

		sb.append("    address: ").append(toIndentedString(address)).append("\n");
		sb.append("    referenceParameters: ").append(toIndentedString(referenceParameters)).append("\n");
		sb.append("    metadata: ").append(toIndentedString(metadata)).append("\n");
		sb.append("}");
		return sb.toString();
	}
}
