package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InvalidIdOrSerialNumber542Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static InvalidIdOrSerialNumber542Exception newInvalidIdOrSerialNumber542Exception() {
		return new InvalidIdOrSerialNumber542Exception();
	}

	public static InvalidIdOrSerialNumber542Exception newInvalidIdOrSerialNumber542Exception(
			ErrorResponse errorResponse) {
		return new InvalidIdOrSerialNumber542Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected InvalidIdOrSerialNumber542Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}

}