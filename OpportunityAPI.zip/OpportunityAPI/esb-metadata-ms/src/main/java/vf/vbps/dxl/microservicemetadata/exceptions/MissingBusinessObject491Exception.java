package vf.vbps.dxl.microservicemetadata.exceptions;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MissingBusinessObject491Exception extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public static MissingBusinessObject491Exception newMissingBusinessObject491Exception() {
		return new MissingBusinessObject491Exception();
	}

	public static MissingBusinessObject491Exception newMissingBusinessObject491Exception(ErrorResponse errorResponse) {
		return new MissingBusinessObject491Exception(errorResponse);
	}

	private ErrorResponse errorResponse;

	protected MissingBusinessObject491Exception(ErrorResponse errorResponse) {
		this.errorResponse = errorResponse;
	}
}
