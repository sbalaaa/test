package vf.vbps.dxl.microservicemetadata.exceptions;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)
 */


@Validated
@Getter
@Setter
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
public class TMFError   {

  
  private String code = null;
  
  private String reason = null;
  
  private String message = null;
  
  private String status = null;
  
  private String referenceError = null;
  
  private String description = null;
  
  private String timestamp = null;
  
  @Valid
  private List<ErrorItem> errorItem = null;
  
  private String baseType = null;
  
  private String schemaLocation = null;
  
  private String type = null;

}

