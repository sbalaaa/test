package vf.vbps.dxl.microservicemetadata.exceptions.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.kafka.common.errors.InvalidRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoSocketOpenException;
import com.mongodb.MongoTimeoutException;
import com.vodafone.gigthree.ulff.ULFF;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.exceptions.DuplicateBusinessObject493Exception;
import vf.vbps.dxl.microservicemetadata.exceptions.EnumExceptions;
import vf.vbps.dxl.microservicemetadata.exceptions.ErrorItem;
import vf.vbps.dxl.microservicemetadata.exceptions.MissingBusinessObject491Exception;
import vf.vbps.dxl.microservicemetadata.exceptions.TMFError;

/**
 * @author
 *
 */
@Slf4j
@ControllerAdvice
public class ControllerExceptionManager {

	@Autowired(required = false)
	private ULFF ulff;

	@Autowired
	ObjectMapper objectMapper;

	private List<ErrorItem> errorItem =null;

	/* Handling backend 4xx series */
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<TMFError> handleHttpClientErrorException(HttpClientErrorException ex) throws Exception {
		TMFError TMFError = null;

		String errorMessage = ex.getResponseBodyAsString();

		HttpStatus finalResponseCode = null;

		if ((ex.getMessage() != null) && !(ex.getMessage().equals(""))) {
			errorItem = setErrorItems(ex.getMessage(), ex.getStatusCode());
		}

		log.error(MicroserviceMetadataConstants.ERROR_SERIES_4XX);
		log.error("4xx Series: status :{}  message :{}", ex.getMessage(), ex);
		switch (ex.getRawStatusCode()) {

		case 400:
			TMFError = setTMFErrorResponse(EnumExceptions.INVALID_INPUT_DATA, errorMessage);
			finalResponseCode = HttpStatus.BAD_REQUEST;
			break;

		case 401:
			TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_UNAUTHORIZED_CLIENT_ERROR, errorMessage);
			finalResponseCode = HttpStatus.UNAUTHORIZED;
			break;

		case 403:
			TMFError = setTMFErrorResponse(EnumExceptions.UNAUTHENTICATED_CLIENT, errorMessage);
			finalResponseCode = HttpStatus.FORBIDDEN;
			break;

		case 404:

			TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, ex.getMessage());
//			TMFError.setStatus(GeographicaddressConstants.ERROR_CODE_404);
			finalResponseCode = HttpStatus.BAD_REQUEST;
			break;

		case 405:
			TMFError = setTMFErrorResponse(EnumExceptions.METHOD_NOT_ALLOWED, errorMessage);
			finalResponseCode = HttpStatus.METHOD_NOT_ALLOWED;
			break;

		case 410:
			TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE, errorMessage);
			finalResponseCode = HttpStatus.INTERNAL_SERVER_ERROR;
			break;

		default:
			TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, errorMessage);
			finalResponseCode = HttpStatus.INTERNAL_SERVER_ERROR;
			break;
		}

		return ResponseEntity.status(finalResponseCode).body(TMFError);

	}

	/* Handling backend 5xx series */
	@ExceptionHandler(HttpServerErrorException.class)
	public ResponseEntity<TMFError> handleHttpServerErrorException(HttpServerErrorException ex)
			throws JsonProcessingException {
		log.error(MicroserviceMetadataConstants.ERROR_SERIES_5XX);
		log.error("5xx Series: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = null;

		switch (ex.getRawStatusCode()) {
		case 502:
			TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, ex.getMessage());
			break;

		case 500:
			TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, ex.getMessage());
			break;

		case 504:
			TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_INTERFACE_TIMEOUT, ex.getMessage());
			break;

		default:
			TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, ex.getMessage());
			break;
		}

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(TMFError);
	}

	/* Custom Exception Thrown when backend gives empty or null */
	@ExceptionHandler(MissingBusinessObject491Exception.class)
	public ResponseEntity<TMFError> handleMissingBusinessObject491Exception(MissingBusinessObject491Exception ex) {
		log.error("handleMissingBusinessObject491Exception: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.MISSING_BUSINESS_OBJECT, ex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(TMFError);
	}
	
	/* Custom Exception Thrown when backend gives empty or null */
	@ExceptionHandler(DuplicateBusinessObject493Exception.class)
	public ResponseEntity<TMFError> handleDuplicateBusinessObject493Exception(DuplicateBusinessObject493Exception ex) {
		log.error("handleMissingBusinessObject493Exception: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.DUPLICATE_BUSINESS_OBJECT, ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(TMFError);
	}
	
	/* Custom Exception Thrown when MongoDB is not able to establish connection */
	@ExceptionHandler(MongoSocketOpenException.class)
	public ResponseEntity<TMFError> handleMongoSocketOpenException(MongoSocketOpenException ex) {
		log.error("handleMongoSocketOpenException: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE, ex.getMessage());
		return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(TMFError);
	}
	
	/* Custom Exception Thrown when MongoDB is not able to establish connection */
	@ExceptionHandler(DataAccessResourceFailureException.class)
	public ResponseEntity<TMFError> handleDataAccessResourceFailureException(DataAccessResourceFailureException ex) {
		log.error("handleDataAccessResourceFailureException: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_DB_UNAVAILABLE, ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(TMFError);
	}
	
	/* Custom Exception Thrown when MongoDB is not able to establish connection */
	@ExceptionHandler(MongoTimeoutException.class)
	public ResponseEntity<TMFError> handleMongoTimeoutException(MongoTimeoutException ex) {
		log.error("handleMongoTimeoutException: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE, ex.getMessage());
		return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(TMFError);
	}
	
	
	
	/* Custom Exception Thrown when input request parameter is missing gives empty or null */
	@ExceptionHandler(MissingServletRequestParameterException.class)
	public ResponseEntity<TMFError> handleMissingBusinessObject491Exception(MissingServletRequestParameterException ex) {
		log.error("handleMissingServletRequestParameterException: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.MISSING_BUSINESS_OBJECT, ex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(TMFError);
	}

	/* Custom Exception thrown when critical filed in input request is missing */
	@ExceptionHandler(InvalidRequestException.class)
	public ResponseEntity<TMFError> handleInvalidRequestException(InvalidRequestException ex) {
		log.info("ControllerExceptionManager : invalidRequestException :start");
		log.error("Invalid request exception caught: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.INVALID_INPUT_DATA, ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(TMFError);
	}

	/* Default Exception */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<TMFError> handleDefaultException(Exception ex) {
		log.info("ControllerExceptionManager : defaultException :start");
		log.error("Default exception caught: status :{}  message :{}", ex.getMessage(), ex);
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.UNKNOWN_FAILURE, ex.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(TMFError);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<TMFError> handleMethodArgumentNotValidExceptionException(MethodArgumentNotValidException ex) {
		log.info("ControllerExceptionManager : MethodArgumentNotValidException :start");
		log.error("Default exception caught: status :{}  message :{}", ex.getMessage(), ex);
		String[] errMessage = new String[1];
		ex.getBindingResult().getFieldErrors().forEach(fieldError -> {
			errMessage[0] = fieldError.getField();
		});
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.INVALID_INPUT_DATA, "" + errMessage[0] + " is missing");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(TMFError);
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public ResponseEntity<TMFError> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
		log.info("ControllerExceptionManager : HttpMessageNotReadableException :start");
		errorItem = null;
		TMFError TMFError = setTMFErrorResponse(EnumExceptions.INVALID_INPUT_DATA, ex.getMessage());
		TMFError.setDescription(ex.getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(TMFError);
	}

	private List<ErrorItem> setErrorItems(String errorMessage, HttpStatus code) {
		errorItem = new ArrayList<>();
		if (errorMessage != null && (!errorMessage.equals(""))) {
			ErrorItem error = new ErrorItem();
			error.setText(code.getReasonPhrase());
			error.setCode(""+code.value());
			errorItem.add(error);
		}
		return errorItem;
	}

	private TMFError setTMFErrorResponse(EnumExceptions enumxceptions, String errorMessage) {
		TMFError TMFError = new TMFError();
		TMFError.setReason(enumxceptions.getReason());
		TMFError.setMessage(enumxceptions.getMessage());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		TMFError.setTimestamp(dateFormat.format(new Date()));
		if (errorItem != null) {
			if (!errorItem.isEmpty()) {
				TMFError.setErrorItem(errorItem);
			}
		} else {
			errorItem = null;
			TMFError.setCode(enumxceptions.getCode());
		}
		if (ulff != null) {
			ulff.populateErrorOutboundResponse(TMFError.getCode(), TMFError.getMessage());
		}
		return TMFError;
	}
}