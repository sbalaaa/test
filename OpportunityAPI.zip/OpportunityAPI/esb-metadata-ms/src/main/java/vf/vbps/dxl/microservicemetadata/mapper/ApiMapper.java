package vf.vbps.dxl.microservicemetadata.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import vf.vbps.dxl.microservicemetadata.entites.ApiList;
import vf.vbps.dxl.microservicemetadata.model.ApipathRef;

public class ApiMapper implements Function<List<ApiList>, List<ApipathRef>> {

	@Override
	public List<ApipathRef> apply(List<ApiList> apiLists) {

		List<ApipathRef> apipathRefList=null;
		if((apiLists!=null)&&!(apiLists.isEmpty())) {
			apipathRefList=new ArrayList<>();
			for(ApiList temp:apiLists) {
				
				if((temp.getValue()!=null)&&!(temp.getValue().equals(""))&&!(temp.getValue().equals(" "))) {
					ApipathRef apipathRef=new ApipathRef();
					apipathRef.setValue(temp.getValue());
					apipathRef.setId(temp.getName());
					apipathRefList.add(apipathRef);
				}
				
			}
		}
		
		return apipathRefList;
	}

}
