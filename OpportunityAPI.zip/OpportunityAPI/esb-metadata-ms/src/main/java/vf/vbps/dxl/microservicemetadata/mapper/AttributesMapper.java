package vf.vbps.dxl.microservicemetadata.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import vf.vbps.dxl.microservicemetadata.entites.Attributes;
import vf.vbps.dxl.microservicemetadata.model.AttributesRef;

public class AttributesMapper implements Function<List<Attributes>, List<AttributesRef>> {

	@Override
	public List<AttributesRef> apply(List<Attributes> attributesList) {

		List<AttributesRef> attributesRefList = null;

		if ((attributesList != null) && !(attributesList.isEmpty())) {

			attributesRefList = new ArrayList<>();

			for (Attributes temp : attributesList) {

				if ((temp.getValue() != null) && !(temp.getValue().equals("")) && !(temp.getValue().endsWith(" "))) {
					AttributesRef attributesRef = new AttributesRef();
					attributesRef.setId(temp.getName());
					attributesRef.setValue(temp.getValue());
					attributesRefList.add(attributesRef);
				}
			}

		}
		return attributesRefList;
	}

}
