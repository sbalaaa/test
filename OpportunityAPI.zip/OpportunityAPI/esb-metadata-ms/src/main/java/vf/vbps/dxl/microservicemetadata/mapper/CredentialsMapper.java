package vf.vbps.dxl.microservicemetadata.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.model.AccessCredentialRef;

public class CredentialsMapper implements Function<List<Credentials>, List<AccessCredentialRef>> {

	@Override
	public List<AccessCredentialRef> apply(List<Credentials> credentialsList) {

		List<AccessCredentialRef> accessCredentialRefsList = null;

		if ((credentialsList != null) && !(credentialsList.isEmpty())) {
			accessCredentialRefsList = new ArrayList<>();
			for (Credentials temp : credentialsList) {

				mapUserNameAndPassword(temp, accessCredentialRefsList);

				// Mapping ApiKey
				if ((temp.getApiKey() != null) && !(temp.getApiKey().equals("")) && !(temp.getApiKey().equals(" "))) {
					AccessCredentialRef accessCredentialApiKey = new AccessCredentialRef();
					accessCredentialApiKey.setId(MicroserviceMetadataConstants.APIKEY);
					accessCredentialApiKey.setValue(temp.getApiKey());
					accessCredentialRefsList.add(accessCredentialApiKey);
				}
			}
		}
		return accessCredentialRefsList;
	}
	
	public void mapUserNameAndPassword(Credentials temp, List<AccessCredentialRef> accessCredentialRefsList) {
		// Mapping UserName and Password
		if ((temp.getUserName() != null) && !(temp.getUserName().equals(""))
				&& !(temp.getUserName().equals(" "))) {
			AccessCredentialRef accessCredentialUserName = new AccessCredentialRef();
			accessCredentialUserName.setId(MicroserviceMetadataConstants.USERNAME);
			accessCredentialUserName.setValue(temp.getUserName());
			accessCredentialRefsList.add(accessCredentialUserName);
		}

		if ((temp.getPassword() != null) && !(temp.getPassword().equals(""))
				&& !(temp.getPassword().equals(" "))) {
			AccessCredentialRef accessCredentialPassword = new AccessCredentialRef();
			accessCredentialPassword.setId(MicroserviceMetadataConstants.PASSWORD);
			accessCredentialPassword.setValue(temp.getPassword());
			accessCredentialRefsList.add(accessCredentialPassword);
		}
	}

}
