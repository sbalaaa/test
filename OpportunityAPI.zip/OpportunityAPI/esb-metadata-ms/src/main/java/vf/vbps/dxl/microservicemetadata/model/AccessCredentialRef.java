package vf.vbps.dxl.microservicemetadata.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * Agreement reference. An agreement represents a contract or arrangement, either written or verbal and sometimes enforceable by law, such as a service level agreement or a customer price agreement. An agreement involves a number of other business entities, such as products, services, and resources and/or their specifications.
 */


@Validated
@Getter
@Setter
@ToString
@lombok.Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccessCredentialRef   {

  
  private String id = null;
  
  private String value = null;

}

