package vf.vbps.dxl.microservicemetadata.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * attributes refered in microservice
 */


@Validated
@Getter
@Setter
@ToString
@lombok.Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttributesRef   {

  
  private String id = null;
  
  private String value = null;

}

