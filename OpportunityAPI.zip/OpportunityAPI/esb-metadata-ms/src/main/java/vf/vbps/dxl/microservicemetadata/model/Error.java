package vf.vbps.dxl.microservicemetadata.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * Used when an API throws an Error, typically with a HTTP error response-code (3xx, 4xx, 5xx)
 */


@Validated
@Getter
@Setter
@ToString
@lombok.Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Error   {

  
  private String code = null;
  
  private String reason = null;
  
  private String message = null;
  
  private String status = null;
  
  private String referenceError = null;

}

