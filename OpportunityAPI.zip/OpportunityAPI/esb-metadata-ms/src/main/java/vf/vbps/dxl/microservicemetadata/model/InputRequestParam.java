package vf.vbps.dxl.microservicemetadata.model;

import lombok.Data;
import lombok.ToString;

@lombok.Generated
@Data
@ToString
public class InputRequestParam {

	private String backendApplication;
	
	private String applicationName;
	
	private String serviceName;
	
	private String countryCode;
	
	private String additionalKey;
	
}
