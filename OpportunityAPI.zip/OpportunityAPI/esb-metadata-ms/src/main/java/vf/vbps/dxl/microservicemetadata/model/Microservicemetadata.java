package vf.vbps.dxl.microservicemetadata.model;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * microservice meta data
 */


@Validated
@Getter
@Setter
@ToString
@lombok.Generated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Microservicemetadata   {

  
  private String backendApplication = null;
  
  private String applicationName = null;
  
  private String serviceName = null;
  
  private String countryCode = null;
  
  private String additionalKey = null;
  
  private Date lastUpdated = null;
  
  private String backendURL = null;
  
  @Valid
  private List<AccessCredentialRef> accessCredentials = null;
  
  @Valid
  private List<AttributesRef> attributes = null;
  
  @Valid
  private List<ApipathRef> apiPaths = null;

}

