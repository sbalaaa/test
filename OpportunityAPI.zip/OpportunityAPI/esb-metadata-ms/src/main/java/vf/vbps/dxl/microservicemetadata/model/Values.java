package vf.vbps.dxl.microservicemetadata.model;

import lombok.Data;

@lombok.Generated
@Data
public class Values {
	
	private String name;
	private String value;

}
