package vf.vbps.dxl.microservicemetadata.rest;

import java.util.List;

import javax.annotation.Nonnull;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vodafone.gigthree.ulff.Transaction;
import com.vodafone.gigthree.ulff.ULFF;

import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.model.Microservicemetadata;
import vf.vbps.dxl.microservicemetadata.service.MicroserviceMetadataService;

@RestController
@RequestMapping(value = "/technical-api/metadata-ms/v1/")
public class MicroserviceMetaDataApiController {

	private static final Logger log = LoggerFactory.getLogger(MicroserviceMetaDataApiController.class);

	@Autowired(required = false)
	private ULFF ulff;

	@Autowired
	private MicroserviceMetadataService microserviceMetadataService;

	/**
	 * find microserviceMetaData objects
	 *
	 * @return List<Microservicemetadata>
	 * @throws Exception 
	 */
	@GetMapping(value = "/microserviceMetaData", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Microservicemetadata> microserviceMetaData(
			@RequestParam(value = "backendApplication", required = true) String backendApplication,
			@RequestParam(value = "applicationName", required = true) String applicationName,
			@RequestParam(value = "serviceName", required = true) String serviceName,
			@RequestParam(value = "countryCode", required = true) String countryCode,
			@RequestParam(value = "additionalKey", required = false) String additionalKey) throws Exception {

		if (ulff != null) {
			setUlffTransactionServiceId("microserviceMetaData");
		}
		
		log.info(MicroserviceMetadataConstants.GET_MICROSERVICE_META_DATA_CONTROLLER,MicroserviceMetadataConstants.MICROSERVICE_META_DATA);
		ResponseEntity<Microservicemetadata> response = microserviceMetadataService
				.microserviceMetaData(backendApplication, applicationName, serviceName, countryCode, additionalKey);

		return response;
	}

	/**
	 * It sets the service Id to for ulff record
	 */
	private void setUlffTransactionServiceId(String serviceId) {
		// log the ulff record
		if (ulff != null) {
			Transaction transaction = ulff.getCurrentTransaction();
			transaction.setServiceId(serviceId);
		}
	}
}
