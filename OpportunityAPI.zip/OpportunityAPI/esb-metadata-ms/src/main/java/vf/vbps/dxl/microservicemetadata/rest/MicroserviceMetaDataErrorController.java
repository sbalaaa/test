package vf.vbps.dxl.microservicemetadata.rest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.microservicemetadata.exceptions.EnumExceptions;
import vf.vbps.dxl.microservicemetadata.exceptions.TMFError;

@Slf4j
@lombok.Generated
@Controller
public class MicroserviceMetaDataErrorController implements ErrorController {

	@RequestMapping("/error")
	public Object fallback() {
		log.debug("MicroserviceMetaDataErrorController : Error caught : Http status is : {}", HttpStatus.NOT_FOUND);
		TMFError error = new TMFError();
		error.setCode(EnumExceptions.UNKNOWN_FAILURE.getCode());
		error.setStatus(EnumExceptions.UNKNOWN_FAILURE.getStatus());
		error.setReason(EnumExceptions.UNKNOWN_FAILURE.getReason());
		error.setMessage(EnumExceptions.UNKNOWN_FAILURE.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}
	
}
