package vf.vbps.dxl.microservicemetadata.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import vf.vbps.dxl.microservicemetadata.backend.oauth.OAuthTokenGenerator;
import vf.vbps.dxl.microservicemetadata.constants.MicroserviceMetadataConstants;
import vf.vbps.dxl.microservicemetadata.db.service.MongoService;
import vf.vbps.dxl.microservicemetadata.entites.ApiList;
import vf.vbps.dxl.microservicemetadata.entites.Attributes;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;
import vf.vbps.dxl.microservicemetadata.exceptions.DuplicateBusinessObject493Exception;
import vf.vbps.dxl.microservicemetadata.exceptions.MissingBusinessObject491Exception;
import vf.vbps.dxl.microservicemetadata.mapper.ApiMapper;
import vf.vbps.dxl.microservicemetadata.mapper.AttributesMapper;
import vf.vbps.dxl.microservicemetadata.mapper.CredentialsMapper;
import vf.vbps.dxl.microservicemetadata.model.AccessCredentialRef;
import vf.vbps.dxl.microservicemetadata.model.ApipathRef;
import vf.vbps.dxl.microservicemetadata.model.AttributesRef;
import vf.vbps.dxl.microservicemetadata.model.InputRequestParam;
import vf.vbps.dxl.microservicemetadata.model.Microservicemetadata;

@Service
public class MicroserviceMetadataServiceImpl implements MicroserviceMetadataService {

	private static final Logger log = LoggerFactory.getLogger(MicroserviceMetadataServiceImpl.class);

	@Autowired
	private MongoService mongoService;

	@Autowired
	private OAuthTokenGenerator oAuthTokenGenerator;

	@Override
	public ResponseEntity<Microservicemetadata> microserviceMetaData(String backendApplication,
			String applicationName, String serviceName, String countryCode, String additionalKey) throws Exception {

		log.debug(MicroserviceMetadataConstants.MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION,"microserviceMetaData");
		log.info("microserviceMetaData backendApp:: {} ,  ::applicationName:: {} , ::serviceName::{} , ::countryCode::{}", backendApplication, applicationName, serviceName, countryCode);
		
		log.info("microserviceMetaData additionalKey:: {}", additionalKey);
		InputRequestParam inputRequestParam=mapInputRequestParam(backendApplication, applicationName, serviceName,
				countryCode, additionalKey);
		log.info("microserviceMetaData InputRequestParam:: {}", inputRequestParam);
		List<MetaData> metaDataList = mongoService.getData(backendApplication, applicationName, serviceName,
				countryCode);

		MetaData metaData = null;

		Microservicemetadata microservicemetadata = null;

		List<Microservicemetadata> microservicemetadataList=null;
		
		List<Credentials> credentialsList = null;
		List<ApiList> apiLists = null;
		List<Attributes> attributesList = null;

		if ((metaDataList != null) && !(metaDataList.isEmpty())) {
			if ((additionalKey != null) && !(additionalKey.equals("")) && !(additionalKey.equals(" "))) {
				metaData = getMetaData(metaDataList, additionalKey);
				credentialsList = mongoService.getCredentials(metaData.getCredentialsList());
				apiLists = mongoService.getApiList(metaData.getApiList());
				attributesList = mongoService.getAttributes(metaData.getAttributesList());
				decryptData(credentialsList, metaData);
				log.info("Credentials List After Decrypting ==> {}", credentialsList);
				microservicemetadata = mapLists(metaData, inputRequestParam, credentialsList, apiLists, attributesList);
			} else {
				if (metaDataList.size() == 1) {
					metaData = metaDataList.get(0);
					credentialsList = mongoService.getCredentials(metaData.getCredentialsList());
					apiLists = mongoService.getApiList(metaData.getApiList());
					attributesList = mongoService.getAttributes(metaData.getAttributesList());
					decryptData(credentialsList, metaData);
					log.info("Credentials List After Decrypting ==> {}", credentialsList);
					microservicemetadata = mapLists(metaData, inputRequestParam, credentialsList, apiLists, attributesList);
				} else {
					log.debug(MicroserviceMetadataConstants.DUPLICATE_ENTRIES,"dupliccate entries found in database for the given search criteria");
					throw new DuplicateBusinessObject493Exception();
				}

			}
		}else {
			log.debug(MicroserviceMetadataConstants.NOT_FOUND,"No records found for the given search criteria");
			throw new MissingBusinessObject491Exception();
		}
		

		ResponseEntity<Microservicemetadata> response = ResponseEntity.status(HttpStatus.OK).body(microservicemetadata);

		log.debug(MicroserviceMetadataConstants.MICROSERVICE_META_DATA_RESPONSE, response);
		
		return response;
	}
	
	public InputRequestParam mapInputRequestParam(String backendApplication, String applicationName, String serviceName,
			String countryCode, String additionalKey){
		
		InputRequestParam inputRequestParam=new InputRequestParam();
		inputRequestParam.setBackendApplication(backendApplication);
		inputRequestParam.setApplicationName(applicationName);
		inputRequestParam.setAdditionalKey(additionalKey);
		inputRequestParam.setCountryCode(countryCode);
		inputRequestParam.setServiceName(serviceName);
		inputRequestParam.setAdditionalKey(additionalKey);
		
		return inputRequestParam;
		
	}

	public MetaData getMetaData(List<MetaData> metaDataList, String additionalKey) {
		MetaData metaData = null;
		log.debug(MicroserviceMetadataConstants.MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION,"getMetaData");
		int count=0;
		for (MetaData temp : metaDataList) {
			if (temp.getAdditionalKey().equalsIgnoreCase(additionalKey)) {
				metaData = temp;
				count++;
			}
		}
		if(count>1) {
			throw new DuplicateBusinessObject493Exception();
		}
		if(count==0) {
			throw new MissingBusinessObject491Exception();
		}
		return metaData;
	}

	public Microservicemetadata mapLists(MetaData metaData, InputRequestParam inputRequestParam, List<Credentials> credentialsList,
			List<ApiList> apiLists, List<Attributes> attributes) throws Exception {
		log.debug(MicroserviceMetadataConstants.MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION,"mapLists");
		Microservicemetadata microservicemetadata = null;
		if (metaData != null) {
			List<AccessCredentialRef> accessCredentialList = Optional.ofNullable(credentialsList)
					.map(new CredentialsMapper()).orElse(null);
			List<ApipathRef> apiPathList = Optional.ofNullable(apiLists).map(new ApiMapper()).orElse(null);
			List<AttributesRef> attributesList = Optional.ofNullable(attributes).map(new AttributesMapper())
					.orElse(null);
			
			//Request to generate Auth2 Token
			AccessCredentialRef accessCredentialRef=oAuthTokenGenerator.generateToken(metaData, credentialsList);
			
			microservicemetadata = mapMicroservicemetadataResponse(inputRequestParam, accessCredentialList, apiPathList, attributesList,
					metaData.getLastModified(), metaData.getEndpointUrl());
			if(accessCredentialRef!=null) {
				microservicemetadata.getAccessCredentials().add(accessCredentialRef);
			}
		} else {
			// Exception should be Thrown
			log.error(MicroserviceMetadataConstants.NOT_FOUND, "The Requested Addition field is not found");
			throw new MissingBusinessObject491Exception();
		}
		return microservicemetadata;
	}
	
	

	public Microservicemetadata mapMicroservicemetadataResponse(InputRequestParam inputRequestParam, List<AccessCredentialRef> credentialsList,
			List<ApipathRef> apiPathList, List<AttributesRef> attributesList, String lastUpdated, String backendUrl) throws ParseException {
		Microservicemetadata microservicemetadata = new Microservicemetadata();
		log.debug(MicroserviceMetadataConstants.MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION,"mapMicroservicemetadataResponse");
		microservicemetadata.setBackendApplication(inputRequestParam.getBackendApplication());
		microservicemetadata.setApplicationName(inputRequestParam.getApplicationName());
		microservicemetadata.setServiceName(inputRequestParam.getServiceName());
		microservicemetadata.setCountryCode(inputRequestParam.getCountryCode());
		if ((inputRequestParam.getAdditionalKey() != null) && !(inputRequestParam.getAdditionalKey().equals("")) && !(inputRequestParam.getAdditionalKey().equals(" "))) {
			microservicemetadata.setAdditionalKey(inputRequestParam.getAdditionalKey());
		}
		microservicemetadata.setAccessCredentials(credentialsList);
		microservicemetadata.setApiPaths(apiPathList);
		microservicemetadata.setAttributes(attributesList);
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yy hh.mm.ss");
		microservicemetadata.setLastUpdated(sdf.parse(lastUpdated));
		microservicemetadata.setBackendURL(backendUrl);
		return microservicemetadata;
	}
	
	public void decryptData(List<Credentials> credentialsList, MetaData metadata) throws Exception {
		log.debug(MicroserviceMetadataConstants.MICROSERVICE_METADATA_SERVICE_IMPLEMENTATION,"decryptData");
		for(Credentials credentials:credentialsList) {
			if ((credentials.getUserName() != null) && !(credentials.getUserName().equals(""))
					&& !(credentials.getUserName().equals(" "))) {
				credentials.setUserName(oAuthTokenGenerator.decryptData(credentials.getUserName(), metadata.getBackendApp()));
			}
			if ((credentials.getPassword() != null) && !(credentials.getPassword().equals(""))
					&& !(credentials.getPassword().equals(" "))) {
				credentials.setPassword(oAuthTokenGenerator.decryptData(credentials.getPassword(), metadata.getBackendApp()));
			}
			if ((credentials.getApiKey() != null) && !(credentials.getApiKey().equals(""))
					&& !(credentials.getApiKey().equals(" "))) {
				credentials.setApiKey(oAuthTokenGenerator.decryptData(credentials.getApiKey(), metadata.getBackendApp()));
			}
		}
	}

}
