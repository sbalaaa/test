package vf.vbps.dxl.microservicemetadata.backend.oauth;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import vf.common.security.encryption.util.DBConfigAES256;
import vf.vbps.dxl.microservicemetadata.backend.model.Auth2Response;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;
import vf.vbps.dxl.microservicemetadata.model.AccessCredentialRef;

//@RunWith(SpringRunner.class)
//@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
//public class TokenGeneratorTest {

//	@MockBean
//	private RestTemplate restTemplate;
//
//	@Autowired
//	private OAuthTokenGenerator oAuthTokenGenerator;
//
//	private DBConfigAES256 cryptographyAes256Mock = null;
//	
//	private List<Credentials> credentialsListMock = null;
//
//	private MetaData metaDataMock = null;
//	private Credentials credentialsOAuthMock = null;
//	private Credentials credentialsBasicAuthMock = null;
//	private Credentials credentialsApiKeyMock = null;
//	
//	private Auth2Response auth2ResponseMock=null;
//
//	@Before
//	public void setData() {
//
//		// Cryptography Initialization
//		cryptographyAes256Mock = Mockito.mock(DBConfigAES256.class);
//
//		// Metadata and Credentials OAuth 2 Initialization
//		credentialsListMock = new ArrayList<>();
//		metaDataMock = Mockito.mock(MetaData.class);
//		credentialsOAuthMock = Mockito.mock(Credentials.class);
//		credentialsBasicAuthMock = Mockito.mock(Credentials.class);
//		credentialsApiKeyMock = Mockito.mock(Credentials.class);
//		
//		//Initializing Auth2Response
//		auth2ResponseMock=Mockito.mock(Auth2Response.class);
//		
//		// Assignments for Credentials - OAUTH
//		when(credentialsOAuthMock.getId()).thenReturn("credentials3");
//		when(credentialsOAuthMock.getClientId()).thenReturn("lIjDQKGWCrqkS7sAWCTTRA==");
//		when(credentialsOAuthMock.getClientSecret()).thenReturn("35FA4qCpzG2AR5vW1EM9/2sOO0BUYyaa0Y3v7nQZEow=");
//		when(credentialsOAuthMock.getGrantType()).thenReturn("grantType");
//		when(credentialsOAuthMock.getScope()).thenReturn("scope");
//		when(credentialsOAuthMock.getLastModified()).thenReturn("21-May-21 10.04.12.000000000");
//		when(credentialsOAuthMock.getAccessTokenUrl()).thenReturn("https://testvfuk.appdirect.com");
//
//		// Assignments for Credentials - API-KEY
//		when(credentialsApiKeyMock.getId()).thenReturn("credentials1");
//		when(credentialsApiKeyMock.getApiKey()).thenReturn("ApiKey");
//
//		// Assignments for Credentials - BASIC-AUTH
//		when(credentialsBasicAuthMock.getId()).thenReturn("credentials2");
//		when(credentialsBasicAuthMock.getUserName()).thenReturn("UserName");
//		when(credentialsBasicAuthMock.getPassword()).thenReturn("Password");
//
//		// Adding credentials to List
//		credentialsListMock.add(credentialsApiKeyMock);
//		credentialsListMock.add(credentialsBasicAuthMock);
//		credentialsListMock.add(credentialsOAuthMock);
//
//		// Assignment for MetaData
//		when(metaDataMock.getBackendApp()).thenReturn("APPDIRECT");
//		when(metaDataMock.getCountryCode()).thenReturn("UK");
//		when(metaDataMock.getAdditionalKey()).thenReturn("additional_key");
//		when(metaDataMock.getEndpointUrl()).thenReturn("endPointURL");
//		when(metaDataMock.getLastModified()).thenReturn("lastModified");
//		when(metaDataMock.getId()).thenReturn("metadata_id");
//		when(metaDataMock.getServiceName()).thenReturn("serviceName");
//		when(metaDataMock.getApplicationName()).thenReturn("applicationName");
//		
//		//Assignments for Auth2ResponseMock
//		when(auth2ResponseMock.getAccessToken()).thenReturn("access_token");
//		when(auth2ResponseMock.getExpiresIn()).thenReturn("expiresIn");
//		when(auth2ResponseMock.getScope()).thenReturn("scope");
//		when(auth2ResponseMock.getTokenType()).thenReturn("token_type");
//	}
//
//	@Test
//	public void generateTokenTest() throws Exception {	
//		
//		ResponseEntity<Auth2Response> authEntity= new ResponseEntity<>(
//				auth2ResponseMock, HttpStatus.OK);
//		doReturn(authEntity).when(restTemplate).exchange(any(URI.class),
//				any(HttpMethod.class), any(HttpEntity.class), any(Class.class));
//		
//		AccessCredentialRef accessCredentialRef=oAuthTokenGenerator.generateToken(metaDataMock, credentialsListMock);
//		
//		assertNotNull(accessCredentialRef);
//
//	}

//}
