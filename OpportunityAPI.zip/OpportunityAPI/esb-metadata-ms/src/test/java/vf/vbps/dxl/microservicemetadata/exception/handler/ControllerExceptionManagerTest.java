package vf.vbps.dxl.microservicemetadata.exception.handler;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.kafka.common.errors.InvalidRequestException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.support.ErrorMessage;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vf.vbps.dxl.microservicemetadata.exceptions.EnumExceptions;
import vf.vbps.dxl.microservicemetadata.exceptions.ErrorCharacteristic;
import vf.vbps.dxl.microservicemetadata.exceptions.ErrorItem;
import vf.vbps.dxl.microservicemetadata.exceptions.MissingBusinessObject491Exception;
import vf.vbps.dxl.microservicemetadata.exceptions.TMFError;
import vf.vbps.dxl.microservicemetadata.exceptions.handler.ControllerExceptionManager;
import vf.vbps.dxl.microservicemetadata.model.Error;

//@RunWith(SpringRunner.class)
//@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
//public class ControllerExceptionManagerTest {
//
//	@Autowired
//	ControllerExceptionManager controllerExceptionManager;
//
//	@MockBean
//	ObjectMapper objectMapper;
//
//	BindingResult bindingResult;
//	FieldError fieldError;
//	List<FieldError> fieldErrorList;
//	MethodArgumentNotValidException methodArgumentNotValidException;
//
//	List<ErrorItem> errorItemMockList;
//	ErrorItem errorItemMock;
//	List<ErrorCharacteristic> errorCharacteristicMockList;
//	ErrorCharacteristic errorCharacteristicMock;
//	Error errorMock;
//	ErrorMessage errorMessageMock;
//
//	@Before
//	public void setData() throws JsonMappingException, JsonProcessingException {
//
//		methodArgumentNotValidException = Mockito.mock(MethodArgumentNotValidException.class);
//		bindingResult = Mockito.mock(BindingResult.class);
//		fieldError = Mockito.mock(FieldError.class);
//		fieldErrorList = new ArrayList<>();
//		fieldErrorList.add(fieldError);
//		when(methodArgumentNotValidException.getBindingResult()).thenReturn(bindingResult);
//		when(bindingResult.getFieldErrors()).thenReturn(fieldErrorList);
//
//		errorMock = Mockito.mock(Error.class);
//		errorItemMock = Mockito.mock(ErrorItem.class);
//		errorCharacteristicMock = Mockito.mock(ErrorCharacteristic.class);
//		errorItemMockList = new ArrayList<>();
//		errorItemMockList.add(errorItemMock);
//		errorCharacteristicMockList = new ArrayList<>();
//		errorCharacteristicMockList.add(errorCharacteristicMock);
//		when(errorItemMock.getErrorItemCharacteristic()).thenReturn(errorCharacteristicMockList);
//		// when(errorMock.getMessage()).thenReturn(errorMessageMock.toString());
//		errorMessageMock = Mockito.mock(ErrorMessage.class);
//
//		objectMapper = Mockito.mock(ObjectMapper.class);
//	}
//
//	/*----- HttpClientErrorException 4xx series test -----*/
//	@Test
//	public void badRequest400test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.BadRequest.create(HttpStatus.BAD_REQUEST, "not found",
//				null, responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	@Test
//	public void unauthorizedClient401Test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.Unauthorized.create(HttpStatus.UNAUTHORIZED,
//				"unauthorized client", null, responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	@Test
//	public void unauthenticatedClient403Test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.Forbidden.create(HttpStatus.FORBIDDEN, "forbidden", null,
//				responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	@Test
//	public void methodNotAllowed405Test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.MethodNotAllowed.create(HttpStatus.METHOD_NOT_ALLOWED,
//				"method not allowed", null, responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	@Test
//	public void invalidResourceState409Test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.Conflict.create(HttpStatus.CONFLICT, "resource conflict",
//				null, responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	@Test
//	public void unSupportedMediaType415Test() throws Exception {
//		String responseBody = "{\"code\":\"400\",\"message\":\"Please provide a valid Identifier\"}";
//		HttpClientErrorException ex = HttpClientErrorException.UnsupportedMediaType.create(
//				HttpStatus.UNSUPPORTED_MEDIA_TYPE, "unsupported media type", null, responseBody.getBytes(), null);
//		assertNotNull(controllerExceptionManager.handleHttpClientErrorException(ex));
//	}
//
//	/*----- HttpServerException 5xx series test -----*/
//	@Test
//	public void badGateWay502Test() throws JsonMappingException, JsonProcessingException {
//		HttpServerErrorException httpServerErrorException = new HttpServerErrorException(HttpStatus.BAD_GATEWAY);
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleHttpServerErrorException(httpServerErrorException);
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//		// assertEquals(EnumExceptions.BACK_END_SYSTEM_ERROR.getCode(),
//		// response.getStatusCode());
//	}
//
//	@Test
//	public void internalServerError500Test() throws JsonMappingException, JsonProcessingException {
//		HttpServerErrorException httpServerErrorException = new HttpServerErrorException(
//				HttpStatus.INTERNAL_SERVER_ERROR);
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleHttpServerErrorException(httpServerErrorException);
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//		assertEquals(EnumExceptions.BACK_END_SYSTEM_ERROR.getCode().toString(),
//				Integer.toString(response.getStatusCodeValue()));
//	}
//
//	@Test
//	public void gateWayTimeout504Test() throws JsonMappingException, JsonProcessingException {
//		HttpServerErrorException httpServerErrorException = new HttpServerErrorException(HttpStatus.GATEWAY_TIMEOUT);
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleHttpServerErrorException(httpServerErrorException);
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//		// assertEquals(EnumExceptions.BUSINESS_RULE_VIOLATION.getStatus(),
//		// Integer.toString(response.getStatusCodeValue()));
//	}
//
//	/*---- custom exception tests ----*/
//	@Test
//	public void missingBusinessObject491ExceptionTest() {
//		MissingBusinessObject491Exception missingBusinessObject491Exception = new MissingBusinessObject491Exception();
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleMissingBusinessObject491Exception(missingBusinessObject491Exception);
//		assertNotNull(response);
//		assertEquals(EnumExceptions.INVALID_REQUEST.getStatus(), Integer.toString(response.getStatusCodeValue()));
//	}
//
//	@Test
//	public void invalidRequestException400Test() {
//		InvalidRequestException invalidRequestException = new InvalidRequestException(null);
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleInvalidRequestException(invalidRequestException);
//		assertNotNull(response);
//		assertEquals(EnumExceptions.BACKEND_SYSTEM_INTERFACE_ERROR.getCode(),
//				Integer.toString(response.getStatusCodeValue()));
//	}
//
//	@Test
//	public void methodArgumentNotValidExceptionTest() {
//		ResponseEntity<TMFError> response = controllerExceptionManager
//				.handleMethodArgumentNotValidExceptionException(methodArgumentNotValidException);
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//		// assertEquals(EnumExceptions.INVALID_INPUT_DATA.getCode(),
//		// response.getStatusCode());
//	}
//
//	@Test
//	public void defaultExceptionTest() {
//		Exception defaultException = new Exception("A failure occurred that is unknown or can not be classified.");
//		ResponseEntity<TMFError> response = controllerExceptionManager.handleDefaultException(defaultException);
//		assertNotNull(response);
//	}
//
//}
