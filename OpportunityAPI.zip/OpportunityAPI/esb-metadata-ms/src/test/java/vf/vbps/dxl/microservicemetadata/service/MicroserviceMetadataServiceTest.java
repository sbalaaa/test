package vf.vbps.dxl.microservicemetadata.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import vf.vbps.dxl.microservicemetadata.backend.oauth.OAuthTokenGenerator;
import vf.vbps.dxl.microservicemetadata.cryptography.entites.Encryption;
import vf.vbps.dxl.microservicemetadata.dao.ApiListDao;
import vf.vbps.dxl.microservicemetadata.dao.AttributesDao;
import vf.vbps.dxl.microservicemetadata.dao.CredentialsDao;
import vf.vbps.dxl.microservicemetadata.dao.MetaDataDao;
import vf.vbps.dxl.microservicemetadata.db.service.MongoService;
import vf.vbps.dxl.microservicemetadata.entites.ApiList;
import vf.vbps.dxl.microservicemetadata.entites.Attributes;
import vf.vbps.dxl.microservicemetadata.entites.Credentials;
import vf.vbps.dxl.microservicemetadata.entites.MetaData;
import vf.vbps.dxl.microservicemetadata.model.Microservicemetadata;

//@RunWith(SpringRunner.class)
//@SpringBootTest
//@TestPropertySource(locations = "classpath:application.properties")
//public class MicroserviceMetadataServiceTest {
//
//	@MockBean
//	private OAuthTokenGenerator oAuthTokenGenerator;
//
//	@Autowired
//	MicroserviceMetadataService microserviceMetadataService;
//
//	@Autowired
//	private MongoService mongoService;
//
//	@MockBean
//	private MetaDataDao metaDataDaoMock;
//
//	@MockBean
//	private ApiListDao apiListDaoMock;
//
//	@MockBean
//	private AttributesDao attributesDaoMock;
//
//	@MockBean
//	private CredentialsDao credentialsDaoMock;
//
//	// Variable Declaration
//	private List<MetaData> metadataListMock = null;
//	private List<Attributes> attributesListMock = null;
//	private List<ApiList> apiListMock = null;
//	private List<Credentials> credentialsListMock = null;
//
//	// String Mappings for Entites
//	private List<String> attributesStringListMock = null;
//	private List<String> apiStringListMock = null;
//	private List<String> credentialsStringListMock = null;
//
//	private MetaData metaDataMock = null;
//	private Credentials credentialsOAuthMock = null;
//	private Credentials credentialsBasicAuthMock = null;
//	private Credentials credentialsApiKeyMock = null;
//	private ApiList api1Mock = null;
//	private ApiList api2Mock = null;
//	private Attributes attributes1Mock = null;
//	private Attributes attributes2Mock = null;
//	private Encryption encryptionMock = null;
//
//	// Optional Values Initialization
//	private List<Optional<ApiList>> OptionalApiListListMock = null;
//	Optional<ApiList> optionalApiList1Mock = null;
//	Optional<ApiList> optionalApiList2Mock = null;
//	private List<Optional<Attributes>> OptionalAttributesListMock = null;
//	Optional<Attributes> optionalAttribute1Mock = null;
//	Optional<Attributes> optionalAttribute2Mock = null;
//	private List<Optional<Credentials>> OptionalCredentialsListMock = null;
//	Optional<Credentials> optionalCredentials1Mock = null;
//	Optional<Credentials> optionalCredentials2Mock = null;
//	Optional<Credentials> optionalCredentials3Mock = null;
//
//	@Before
//	public void setData() throws Exception {
//
//		MockitoAnnotations.initMocks(this);
//
//		// Variable Initialization
//		metadataListMock = new ArrayList<>();
//		attributesListMock = new ArrayList<>();
//		apiListMock = new ArrayList<>();
//		credentialsListMock = new ArrayList<>();
//		attributesStringListMock = new ArrayList<>();
//		apiStringListMock = new ArrayList<>();
//		credentialsStringListMock = new ArrayList<>();
//
//		// Credentials OAuth 2 Initialization
//		metaDataMock = Mockito.mock(MetaData.class);
//		credentialsOAuthMock = Mockito.mock(Credentials.class);
//		credentialsBasicAuthMock = Mockito.mock(Credentials.class);
//		credentialsApiKeyMock = Mockito.mock(Credentials.class);
//		api1Mock = Mockito.mock(ApiList.class);
//		api2Mock = Mockito.mock(ApiList.class);
//		attributes1Mock = Mockito.mock(Attributes.class);
//		attributes2Mock = Mockito.mock(Attributes.class);
//		encryptionMock = Mockito.mock(Encryption.class);
//
//		// Adding Credentials, ApiList and Attributes to String List
//		credentialsStringListMock.add("credentials1");
//		credentialsStringListMock.add("credentials2");
//		credentialsStringListMock.add("credentials3");
//
//		apiStringListMock.add("apilist1");
//		apiStringListMock.add("apilist2");
//
//		attributesStringListMock.add("attribute1");
//		attributesStringListMock.add("attribute2");
//
//		// Assignment for Attributes
//		when(attributes1Mock.getId()).thenReturn("attribute1");
//		when(attributes1Mock.getName()).thenReturn("Attribute1_Name");
//		when(attributes1Mock.getValue()).thenReturn("Attribute1_Value");
//		attributesListMock.add(attributes1Mock);
//		when(attributes2Mock.getId()).thenReturn("attribute2");
//		when(attributes2Mock.getName()).thenReturn("Attribute2_Name");
//		when(attributes2Mock.getValue()).thenReturn("Attribute2_Value");
//		attributesListMock.add(attributes2Mock);
//
//		// Assignment for ApiList
//		when(api1Mock.getId()).thenReturn("apilist1");
//		when(api1Mock.getName()).thenReturn("ApiMock_Name");
//		when(api1Mock.getValue()).thenReturn("ApiMock_Value");
//		apiListMock.add(api1Mock);
//		when(api2Mock.getId()).thenReturn("apilist2");
//		when(api2Mock.getName()).thenReturn("ApiMock_Name");
//		when(api2Mock.getValue()).thenReturn("ApiMock_Value");
//		apiListMock.add(api2Mock);
//
//		// Assignments for Credentials - OAUTH
//		when(credentialsOAuthMock.getId()).thenReturn("credentials3");
//		when(credentialsOAuthMock.getClientId()).thenReturn("clientId");
//		when(credentialsOAuthMock.getClientSecret()).thenReturn("clientSecret");
//		when(credentialsOAuthMock.getGrantType()).thenReturn("grantType");
//		when(credentialsOAuthMock.getScope()).thenReturn("scope");
//		when(credentialsOAuthMock.getLastModified()).thenReturn("lastModified");
//		when(credentialsOAuthMock.getAccessTokenUrl()).thenReturn("accessTokenUrl");
//
//		// Assignments for Credentials - API-KEY
//		when(credentialsApiKeyMock.getId()).thenReturn("credentials1");
//		when(credentialsApiKeyMock.getApiKey()).thenReturn("ApiKey");
//
//		// Assignments for Credentials - BASIC-AUTH
//		when(credentialsBasicAuthMock.getId()).thenReturn("credentials2");
//		when(credentialsBasicAuthMock.getUserName()).thenReturn("UserName");
//		when(credentialsBasicAuthMock.getPassword()).thenReturn("Password");
//
//		// Adding credentials to List
//		credentialsListMock.add(credentialsApiKeyMock);
//		credentialsListMock.add(credentialsBasicAuthMock);
//		credentialsListMock.add(credentialsOAuthMock);
//
//		// Assignment for MetaData
//		when(metaDataMock.getBackendApp()).thenReturn("backend_app");
//		when(metaDataMock.getCountryCode()).thenReturn("UK");
//		when(metaDataMock.getAdditionalKey()).thenReturn("additional_key");
//		when(metaDataMock.getEndpointUrl()).thenReturn("endPointURL");
//		when(metaDataMock.getLastModified()).thenReturn("21-May-21 10.04.12.000000000");
//		when(metaDataMock.getId()).thenReturn("metadata_id");
//		when(metaDataMock.getServiceName()).thenReturn("serviceName");
//		when(metaDataMock.getApplicationName()).thenReturn("applicationName");
//		when(metaDataMock.getAttributesList()).thenReturn(attributesStringListMock);
//		when(metaDataMock.getApiList()).thenReturn(apiStringListMock);
//		when(metaDataMock.getCredentialsList()).thenReturn(credentialsStringListMock);
//		metadataListMock.add(metaDataMock);
//
//		// Mongo DB Mock for MetaData
//		when(metaDataDaoMock.findAllByBackendAppAndApplicationNameAndServiceNameAndCountryCode("backendApp",
//				"applicationName", "ServiceName", "countryCode")).thenReturn(metadataListMock);
//
//		// Optional Attributes Mock
//		optionalApiList1Mock = Optional.of(api1Mock);
//		optionalApiList2Mock = Optional.of(api2Mock);
//		optionalAttribute1Mock = Optional.of(attributes1Mock);
//		optionalAttribute2Mock = Optional.of(attributes2Mock);
//		optionalCredentials1Mock = Optional.of(credentialsBasicAuthMock);
//		optionalCredentials2Mock = Optional.of(credentialsApiKeyMock);
//		optionalCredentials3Mock = Optional.of(credentialsOAuthMock);
//
//		when(apiListDaoMock.findById("apilist1")).thenReturn(optionalApiList1Mock);
//		when(apiListDaoMock.findById("apilist2")).thenReturn(optionalApiList2Mock);
//		when(attributesDaoMock.findById("attribute1")).thenReturn(optionalAttribute1Mock);
//		when(attributesDaoMock.findById("attribute2")).thenReturn(optionalAttribute2Mock);
//		when(credentialsDaoMock.findById("credentials1")).thenReturn(optionalCredentials1Mock);
//		when(credentialsDaoMock.findById("credentials2")).thenReturn(optionalCredentials2Mock);
//		when(credentialsDaoMock.findById("credentials3")).thenReturn(optionalCredentials3Mock);
//
//		// Cryptography mocks
//		when(oAuthTokenGenerator.decryptData("clientId", "backendApp")).thenReturn("decClientId");
//		when(oAuthTokenGenerator.decryptData("clientSecret", "backendApp")).thenReturn("decClientSecret");
//	}
//
//	@Test
//	public void microserviceMetaDataTest() throws Exception {
//
//		ResponseEntity<List<Microservicemetadata>> response = microserviceMetadataService
//				.microserviceMetaData("backendApp", "applicationName", "ServiceName", "countryCode", "additional_key");
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//	}
//
//	// Without Additional Key
//	@Test
//	public void microserviceMetaDataTest2() throws Exception {
//
//		ResponseEntity<List<Microservicemetadata>> response = microserviceMetadataService
//				.microserviceMetaData("backendApp", "applicationName", "ServiceName", "countryCode", null);
//		assertNotNull(response);
//		assertNotNull(response.getBody());
//	}
//
//	// Negative Scenario Throwing MissingBusinessObject491Exception
//	@Test
//	public void microserviceMetaDataTest3() {
//		try {
//			ResponseEntity<List<Microservicemetadata>> response = microserviceMetadataService
//					.microserviceMetaData("pravin", "applicationName", "ServiceName", "countryCode", null);
//
//		} catch (Exception exc) {
//			if (exc.toString().contains("MissingBusinessObject491Exception")) {
//				assertTrue(true);
//			} else {
//				assertTrue(false);
//			}
//		}
//	}
//
//	// Negative Scenario Throwing MissingBusinessObject491Exception
//	@Test
//	public void microserviceMetaDataTest4() {
//		MetaData metaData2Mock = Mockito.mock(MetaData.class);
//		// Assignment for MetaData
//		when(metaData2Mock.getBackendApp()).thenReturn("backend_app");
//		when(metaData2Mock.getCountryCode()).thenReturn("UK");
//		when(metaData2Mock.getAdditionalKey()).thenReturn("additional_key");
//		when(metaData2Mock.getEndpointUrl()).thenReturn("endPointURL");
//		when(metaData2Mock.getLastModified()).thenReturn("lastModified");
//		when(metaData2Mock.getId()).thenReturn("metadata_id");
//		when(metaData2Mock.getServiceName()).thenReturn("serviceName");
//		when(metaData2Mock.getApplicationName()).thenReturn("applicationName");
//		when(metaData2Mock.getAttributesList()).thenReturn(attributesStringListMock);
//		when(metaData2Mock.getApiList()).thenReturn(apiStringListMock);
//		when(metaData2Mock.getCredentialsList()).thenReturn(credentialsStringListMock);
//		metadataListMock.add(metaData2Mock);
//		try {
//			ResponseEntity<List<Microservicemetadata>> response = microserviceMetadataService
//					.microserviceMetaData("backendApp", "applicationName", "ServiceName", "countryCode", null);
//
//		} catch (Exception exc) {
//			if (exc.toString().contains("MissingBusinessObject491Exception")) {
//				System.out.println(exc.toString());
//				assertTrue(true);
//			} else {
//				assertTrue(false);
//			}
//		}
//	}
//}
