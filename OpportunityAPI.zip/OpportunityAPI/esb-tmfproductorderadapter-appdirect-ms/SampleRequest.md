{
    "productOrderId": 1,
    "category": "MSTeam",
    "description": "MSTeam description"
}



public class ProductOrderCreate   {

  
  private Integer productOrderId;
	
  private Date cancellationDate = null;
  
  private String cancellationReason = null;
  
  private String category = null;
  
  private String description = null;
  
  private String externalId = null;
  
  private String notificationContact = null;
  
  private String priority = null;
  
  private Date requestedCompletionDate = null;
  
  private Date requestedStartDate = null;