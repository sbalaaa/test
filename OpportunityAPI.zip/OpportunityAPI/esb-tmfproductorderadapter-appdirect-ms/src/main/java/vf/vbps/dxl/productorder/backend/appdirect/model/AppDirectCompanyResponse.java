
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@JsonInclude(value = JsonInclude.Include.NON_EMPTY, content = JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class AppDirectCompanyResponse {

	private String id;
	private String name;
	private boolean enabled;
	private String status;
	public String uuid;
	public String externalId;
	public String countryCode;

}
