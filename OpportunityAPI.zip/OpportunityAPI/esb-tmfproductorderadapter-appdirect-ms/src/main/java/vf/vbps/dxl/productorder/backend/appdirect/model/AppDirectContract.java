
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "autoExtensionPricingId", "blockContractDowngrades", "blockContractUpgrades",
		"blockSwitchToShorterContract", "cancellationPeriodLimit", "endOfContractGracePeriod", "gracePeriod",
		"minimumServiceLength", "terminationFee" })
@Data
public class AppDirectContract {

	@JsonProperty("autoExtensionPricingId")
	private Integer autoExtensionPricingId;
	@JsonProperty("blockContractDowngrades")
	private Boolean blockContractDowngrades;
	@JsonProperty("blockContractUpgrades")
	private Boolean blockContractUpgrades;
	@JsonProperty("blockSwitchToShorterContract")
	private Boolean blockSwitchToShorterContract;
	@JsonProperty("cancellationPeriodLimit")
	private Object cancellationPeriodLimit;
	@JsonProperty("endOfContractGracePeriod")
	private Object endOfContractGracePeriod;
	@JsonProperty("gracePeriod")
	private Object gracePeriod;
	@JsonProperty("minimumServiceLength")
	private Integer minimumServiceLength;
	@JsonProperty("terminationFee")
	private Object terminationFee;

}
