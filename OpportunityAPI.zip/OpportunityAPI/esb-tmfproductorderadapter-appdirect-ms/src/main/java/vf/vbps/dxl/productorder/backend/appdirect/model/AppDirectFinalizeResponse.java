
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "availableActions", "createdOn", "currency", "customerUser", "id", "items", "name", "ownerUser",
		"purchaseEffectiveDate", "purchaseId", "purchaseNumber", "status" })
@Data
public class AppDirectFinalizeResponse {

	@JsonProperty("availableActions")
	private List<Object> availableActions = new ArrayList<>();
	@JsonProperty("createdOn")
	private String createdOn;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("customerUser")
	private AppDirectCustomerUser customerUser;
	@JsonProperty("id")
	private String id;
	@JsonProperty("items")
	private List<AppDirectItem> items = new ArrayList<>();
	@JsonProperty("name")
	private String name;
	@JsonProperty("ownerUser")
	private AppDirectOwnerUser ownerUser;
	@JsonProperty("purchaseEffectiveDate")
	private String purchaseEffectiveDate;
	@JsonProperty("purchaseId")
	private String purchaseId;
	@JsonProperty("purchaseNumber")
	private String purchaseNumber;
	@JsonProperty("status")
	private String status;

}
