
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "costId", "costType", "costTypeCategory", "description", "priceRanges", "pricingStrategy",
		"quantity", "salePrice", "totalSalePrice", "wholesalePrice", "unit" })
@Data
public class AppDirectPricing {

	@JsonProperty("costId")
	private String costId;
	@JsonProperty("costType")
	private String costType;
	@JsonProperty("costTypeCategory")
	private String costTypeCategory;
	@JsonProperty("description")
	private String description;
	@JsonProperty("priceRanges")
	private List<PriceRange> priceRanges = new ArrayList<>();
	@JsonProperty("pricingStrategy")
	private String pricingStrategy;
	@JsonProperty("quantity")
	private String quantity;
	@JsonProperty("salePrice")
	private String salePrice;
	@JsonProperty("totalSalePrice")
	private String totalSalePrice;
	@JsonProperty("wholesalePrice")
	private String wholesalePrice;
	@JsonProperty("unit")
	private String unit;
	@JsonProperty("frequency")
	private String frequency;

}
