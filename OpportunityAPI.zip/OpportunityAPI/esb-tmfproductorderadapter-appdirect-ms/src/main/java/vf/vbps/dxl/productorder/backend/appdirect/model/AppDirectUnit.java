
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "quantity", "unit" })
@Data
public class AppDirectUnit {

	@JsonProperty("quantity")
	private Double quantity;
	@JsonProperty("unit")
	private String unit;

}
