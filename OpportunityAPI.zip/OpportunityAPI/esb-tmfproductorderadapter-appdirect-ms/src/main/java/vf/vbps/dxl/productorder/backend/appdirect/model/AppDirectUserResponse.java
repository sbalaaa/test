
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AppDirectUserResponse {

	private String id;
    private String openId;
    private String email;
    private String username;
    private String firstName;
    private String lastName;
    private String language;
    private String locale;
    private boolean deleted;
    private String status;
    private String internalId;
    private String externalId;
    private boolean enabled;

}
