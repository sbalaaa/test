
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "email", "lastname", "name" })
@Data
public class AppDirectVendorRequiredFields {

	@JsonProperty("OrganizationRegistrationNumber")
	private List<String> organizationRegistrationNumber = new ArrayList<>();
	@JsonProperty("BusinessName")
	private List<String> businessName = new ArrayList<>();
	@JsonProperty("ConsentUser/PhoneNumber")
	private List<String> consentUserPhoneNumber = new ArrayList<>();
	@JsonProperty("FirstName")
	private List<String> firstName = new ArrayList<>();
	@JsonProperty("Address/ISO3Country")
	private List<String> addressISO3Country = new ArrayList<>();
	@JsonProperty("ConsentUser/FirstName")
	private List<String> consentUserFirstName = new ArrayList<>();
	@JsonProperty("ConsentUser/Email")
	private List<String> consentUserEmail = new ArrayList<>();
	@JsonProperty("AlternateEmail")
	private List<String> alternateEmail = new ArrayList<>();
	@JsonProperty("UserPrincipleName")
	private List<String> userPrincipleName = new ArrayList<>();
	@JsonProperty("SubDomain")
	private List<String> subDomain = new ArrayList<>();
	@JsonProperty("Address/State")
	private List<String> addressState = new ArrayList<>();
	@JsonProperty("Address/PhoneNumber")
	private List<String> addressPhoneNumber = new ArrayList<>();
	@JsonProperty("Address/City")
	private List<String> addressCity = new ArrayList<>();
	@JsonProperty("Address/Line2")
	private List<Object> addressLine2 = new ArrayList<Object>();
	@JsonProperty("Address/Line1")
	private List<String> addressLine1 = new ArrayList<>();
	@JsonProperty("DateConsentConfirmed")
	private List<String> dateConsentConfirmed = new ArrayList<>();
	@JsonProperty("LastName")
	private List<String> lastName = new ArrayList<>();
	@JsonProperty("Address/PostalCode")
	private List<String> addressPostalCode = new ArrayList<>();
	@JsonProperty("ConsentUser/LastName")
	private List<String> consentUserLastName = new ArrayList<>();
	@JsonProperty("email")
	private List<String> email = new ArrayList<>();
	@JsonProperty("lastname")
	private List<String> lastname = new ArrayList<>();
	@JsonProperty("name")
	private List<String> name = new ArrayList<>();

}
