
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "amountDueAfterTax",
    "amountDueBeforeTax",
    "items",
    "recurringTotals",
    "taxSummary"
})
public class ApplyDiscountResponse {

    @JsonProperty("amountDueAfterTax")
    private String amountDueAfterTax;
    @JsonProperty("amountDueBeforeTax")
    private String amountDueBeforeTax;
    @JsonProperty("items")
    private List<DiscountItem> items = new ArrayList<>();
    @JsonProperty("recurringTotals")
    private List<RecurringTotal> recurringTotals = new ArrayList<>();
    @JsonProperty("taxSummary")
    private List<Object> taxSummary = new ArrayList<>();

}
