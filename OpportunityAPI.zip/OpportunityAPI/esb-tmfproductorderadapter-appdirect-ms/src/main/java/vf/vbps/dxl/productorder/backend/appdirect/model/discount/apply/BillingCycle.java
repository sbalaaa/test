
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dayOfMonth",
    "period"
})
public class BillingCycle {

    @JsonProperty("dayOfMonth")
    private Integer dayOfMonth;
    @JsonProperty("period")
    private String period;


}
