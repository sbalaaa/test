
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "code", "description" })
@Data
public class Discount {

	@JsonProperty("code")
	private String code;
	@JsonProperty("description")
	private String description;

}
