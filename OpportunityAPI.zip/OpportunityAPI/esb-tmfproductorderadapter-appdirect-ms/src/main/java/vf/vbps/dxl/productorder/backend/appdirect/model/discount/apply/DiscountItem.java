
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPricing;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPricingPlan;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "discount", "id", "pricing", "pricingPlan", "product", "unitDefinitions" })
@Data
public class DiscountItem {

	@JsonProperty("discount")
	private Discount discount;
	@JsonProperty("id")
	private String id;
	@JsonProperty("pricing")
	private List<AppDirectPricing> pricing = new ArrayList<>();
	@JsonProperty("pricingPlan")
	private AppDirectPricingPlan pricingPlan;
	@JsonProperty("product")
	private Product product;
	@JsonProperty("unitDefinitions")
	private List<UnitDefinition> unitDefinitions = new ArrayList<>();

}
