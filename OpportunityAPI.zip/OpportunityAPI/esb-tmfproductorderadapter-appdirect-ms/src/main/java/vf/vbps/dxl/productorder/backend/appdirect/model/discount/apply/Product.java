
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "hasAddons", "id", "isAddon", "name", "type" })
public class Product {

	@JsonProperty("hasAddons")
	private Boolean hasAddons;
	@JsonProperty("id")
	private String id;
	@JsonProperty("isAddon")
	private Boolean isAddon;
	@JsonProperty("name")
	private String name;
	@JsonProperty("type")
	private String type;

}
