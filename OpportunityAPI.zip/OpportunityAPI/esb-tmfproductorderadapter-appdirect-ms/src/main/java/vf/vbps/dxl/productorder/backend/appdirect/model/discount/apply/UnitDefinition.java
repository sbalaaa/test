
package vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "allowDecimals", "meteredUsage", "minimum", "pricePerIncrement", "readOnly", "unit" })
@Data
public class UnitDefinition {

	@JsonProperty("allowDecimals")
	private Boolean allowDecimals;
	@JsonProperty("meteredUsage")
	private Boolean meteredUsage;
	@JsonProperty("minimum")
	private String minimum;
	@JsonProperty("pricePerIncrement")
	private Boolean pricePerIncrement;
	@JsonProperty("readOnly")
	private Boolean readOnly;
	@JsonProperty("unit")
	private String unit;

}
