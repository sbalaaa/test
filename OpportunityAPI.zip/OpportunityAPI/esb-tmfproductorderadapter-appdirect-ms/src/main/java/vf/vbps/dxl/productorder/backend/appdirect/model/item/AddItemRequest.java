
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectSubscriptionCustomAttributes;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectVendorRequiredFields;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "billingConfiguration", "pricingPlanId", "provisioningConfiguration",
		"subscriptionCustomAttributes", "units", "vendorRequiredFields" })
@Data
public class AddItemRequest {

	@JsonProperty("billingConfiguration")
	private BillingConfiguration billingConfiguration;
	@JsonProperty("pricingPlanId")
	private String pricingPlanId;
	@JsonProperty("provisioningConfiguration")
	private ProvisioningConfiguration provisioningConfiguration;
	@JsonProperty("subscriptionCustomAttributes")
	private Map<String,List<String>> subscriptionCustomAttributes;
	@JsonProperty("units")
	private List<AppDirectUnit> units = new ArrayList<>();
	@JsonProperty("vendorRequiredFields")
	private Map<String,List<String>> vendorRequiredFields;

}
