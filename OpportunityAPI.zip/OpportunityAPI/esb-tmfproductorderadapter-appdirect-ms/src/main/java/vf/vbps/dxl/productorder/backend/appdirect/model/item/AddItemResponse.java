
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectSubscriptionCustomAttributes;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectVendorRequiredFields;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "billingConfiguration", "id", "pricingPlanId", "provisioningConfiguration",
		"subscriptionCustomAttributes", "units", "vendorRequiredFields" })
@Data
public class AddItemResponse {

	@JsonProperty("billingConfiguration")
	private BillingConfiguration billingConfiguration;
	@JsonProperty("id")
	private String id;
	@JsonProperty("pricingPlanId")
	private String pricingPlanId;
	@JsonProperty("provisioningConfiguration")
	private ProvisioningConfiguration provisioningConfiguration;
	@JsonProperty("subscriptionCustomAttributes")
	private AppDirectSubscriptionCustomAttributes subscriptionCustomAttributes;
	@JsonProperty("units")
	private List<AppDirectUnit> units = new ArrayList<>();
	@JsonProperty("vendorRequiredFields")
	private AppDirectVendorRequiredFields vendorRequiredFields;

}
