
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "blockContractDowngrades", "blockContractUpgrades", "blockSwitchToShorterContract",
		"contractCancellationPeriodLimit", "contractCancellationPeriodUnit", "endOfContractGracePeriod",
		"endOfContractGracePeriodUnit", "keepContractDateOnPlanChange", "minimumServiceLength",
		"minimumServiceLengthUnit", "renewalConfiguration", "terminationFee", "terminationFeeGracePeriod",
		"terminationFeeGracePeriodUnit", "unitTerms" })
@Data
public class ContractConfiguration {

	@JsonProperty("blockContractDowngrades")
	private Boolean blockContractDowngrades;
	@JsonProperty("blockContractUpgrades")
	private Boolean blockContractUpgrades;
	@JsonProperty("blockSwitchToShorterContract")
	private Boolean blockSwitchToShorterContract;
	@JsonProperty("contractCancellationPeriodLimit")
	private Integer contractCancellationPeriodLimit;
	@JsonProperty("contractCancellationPeriodUnit")
	private String contractCancellationPeriodUnit;
	@JsonProperty("endOfContractGracePeriod")
	private Integer endOfContractGracePeriod;
	@JsonProperty("endOfContractGracePeriodUnit")
	private String endOfContractGracePeriodUnit;
	@JsonProperty("keepContractDateOnPlanChange")
	private Boolean keepContractDateOnPlanChange;
	@JsonProperty("minimumServiceLength")
	private Integer minimumServiceLength;
	@JsonProperty("minimumServiceLengthUnit")
	private String minimumServiceLengthUnit;
	@JsonProperty("renewalConfiguration")
	private String renewalConfiguration;
	@JsonProperty("terminationFee")
	private TerminationFee terminationFee;
	@JsonProperty("terminationFeeGracePeriod")
	private Integer terminationFeeGracePeriod;
	@JsonProperty("terminationFeeGracePeriodUnit")
	private String terminationFeeGracePeriodUnit;
	@JsonProperty("unitTerms")
	private Map<String, UnitTerm> unitTerms;
	@JsonProperty("isDefault")
	private Boolean isDefault;

}
