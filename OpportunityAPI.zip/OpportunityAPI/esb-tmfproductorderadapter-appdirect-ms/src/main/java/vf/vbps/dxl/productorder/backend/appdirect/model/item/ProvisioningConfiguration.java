
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "date", "strategy" })
@Data
public class ProvisioningConfiguration {

	@JsonProperty("date")
	private String date;
	@JsonProperty("strategy")
	private String strategy;

}
