
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "USER" })
@Data
public class UnitTerm {

	@JsonProperty("blockContractDecrease")
	private Boolean blockContractDecrease;
	@JsonProperty("blockContractIncrease")
	private Boolean blockContractIncrease;
	@JsonProperty("blockOriginalContractDecrease")
	private Boolean blockOriginalContractDecrease;

}
