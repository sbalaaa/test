package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;

@Slf4j
@Component
public class AppDirectOpportunityService {

	@Autowired
	private WebClient webClient;
	
	@Autowired
	private ObjectMapper objectMapper;

	public AppDirectFinalizeResponse invokeFinalizeOpportunity(String opportunityId, Metadata metadata) {
		
		log.info("invokeFinalizeOpportunity started opportunityId {} " , opportunityId);

		long start = System.currentTimeMillis();

		String fializeEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata,
				ProductOrderConstants.FINALIZEOPPORTUNITY);
		String uri = UriComponentsBuilder.fromUriString(fializeEndpointUrl).buildAndExpand(opportunityId).toUriString();
		log.info("fializeEndpointUrl is {} ", uri);

		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info(ProductOrderConstants.LOG_ACCESS_TOKEN, token);

		AppDirectFinalizeResponse apiResponse = null;
		
		try {
		
		    apiResponse = webClient.post().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			}).retrieve().bodyToMono(AppDirectFinalizeResponse.class).block();
		    
		    log.debug("\n \n AppDirectFinalizeOpportunityResponse :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
	    
		} catch (WebClientResponseException e) {
			log.error("\n \n Error from invokeFinalizeOpportunity Request - Status {}, Body {} \n \n", e.getRawStatusCode(), e.getResponseBodyAsString(), e);
			log.error(e.toString());
			throw e;
		} catch (Exception e) {
			log.error(e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);
		
		log.info("invokeFinalizeOpportunity ended");

		return apiResponse;
	}

	
}
