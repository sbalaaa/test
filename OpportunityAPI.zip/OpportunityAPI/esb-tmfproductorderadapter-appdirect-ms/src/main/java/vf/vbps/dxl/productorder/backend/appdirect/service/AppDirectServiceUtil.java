package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ContractConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.exceptions.UnauthorizedClientError403Exception;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.RelatedParty;
import vf.vbps.dxl.productorder.model.Unit;

@Slf4j
public class AppDirectServiceUtil {

	private AppDirectServiceUtil() {

	}

	public static String getOwnerCompanyId(ProductOrder productOrder) {
		return AppDirectServiceUtil.getId(productOrder, ProductOrderConstants.AGENT_COMPANY);
	}

	public static String getOwnerId(ProductOrder productOrder) {
		return AppDirectServiceUtil.getId(productOrder, ProductOrderConstants.AGENT);
	}

	public static String getId(ProductOrder productOrder, String matchingValue) {
		List<RelatedParty> relatedParties = productOrder.getRelatedParty();
		for (RelatedParty relatedParty : relatedParties) {
			if (matchingValue.equals(relatedParty.getRole())) {
				return relatedParty.getId();
			}
		}
		return null;
	}

	public static String getOAuthAccessToken(Metadata metadata) {
		String accessToken = null;
		if (metadata.getAccessCredentials() != null) {
			Optional<AccessCredentialRef> accessCredential = metadata.getAccessCredentials().stream()
					.filter(ref -> ref.getId().equals(ProductOrderConstants.TOKEN)).filter(Objects::nonNull).findAny();
			if (accessCredential.isPresent()) {
				accessToken = accessCredential.get().getValue();
				log.info(ProductOrderConstants.LOG_ACCESS_TOKEN, accessToken);
			} else {
				throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
			}
		} else {
			throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
		}
		return accessToken;
	}

	public static String getEndpoint(Metadata metadata, String id) {
		String backEndUrl = metadata.getBackendURL();
		String finalizeEndpointUrl = "";
		List<ApipathRef> apiPaths = metadata.getApiPaths();
		for (ApipathRef apiPath : apiPaths) {
			if (apiPath.getId().equals(id)) {
				finalizeEndpointUrl = apiPath.getValue();
				break;
			}
		}

		return (backEndUrl + finalizeEndpointUrl).trim();
	}

	public static BillingConfiguration getBillingConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.BILLINGCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, BillingConfiguration>) c.getValue());
					BillingConfiguration billingConfigurationValue = new BillingConfiguration();
					try {
						billingConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<BillingConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					if (!StringUtils.isEmpty(billingConfigurationValue.getDate())) {
						billingConfigurationValue
								.setDate(String.valueOf(getEPOCHMilliseconds(billingConfigurationValue.getDate())));
					}

					return billingConfigurationValue;
				}).findFirst().orElse(null);

	}

	public static ProvisioningConfiguration getProvisioningConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.PROVISIOINGCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, ProvisioningConfiguration>) c.getValue());
					ProvisioningConfiguration provisioningConfigurationValue = new ProvisioningConfiguration();
					try {
						provisioningConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<ProvisioningConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					if (!StringUtils.isEmpty(provisioningConfigurationValue.getDate())) {
						provisioningConfigurationValue.setDate(
								String.valueOf(getEPOCHMilliseconds(provisioningConfigurationValue.getDate())));
					}

					return provisioningConfigurationValue;

				}).findFirst().orElse(null);

	}

	public static ContractConfiguration getContractConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.CONTRACTCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, ContractConfiguration>) c.getValue());
					ContractConfiguration contractConfigurationValue = new ContractConfiguration();
					try {
						contractConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<ContractConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}

					return contractConfigurationValue;

				}).findFirst().orElse(null);

	}

	public static Map<String, List<String>> getSubscriptionCustomAttributes(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.SUBSCRIPTION.equals(c.getName())).map(c -> {

			ObjectMapper objectMapper = new ObjectMapper();
			JSONObject json = new JSONObject((LinkedHashMap<String, Map<String, List<String>>>) c.getValue());
			Map<String, List<String>> subscriptionValue = new HashMap<>();
			try {
				subscriptionValue = objectMapper.readValue(json.toString(),
						new TypeReference<Map<String, List<String>>>() {
						});
			} catch (JsonMappingException e) {
				log.error(e.getMessage());
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
			}

			return subscriptionValue;
		}).findFirst().orElse(null);

	}

	public static Map<String, List<String>> getVendorRequiredFields(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.VENDORATTRIBUTES.equals(c.getName()))
				.map(c -> {
					ObjectMapper objectMapper = new ObjectMapper();
					JSONObject json = new JSONObject((LinkedHashMap<String, Map<String, List<String>>>) c.getValue());
					Map<String, List<String>> subscriptionValue = new HashMap<>();
					try {
						subscriptionValue = objectMapper.readValue(json.toString(),
								new TypeReference<Map<String, List<String>>>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					return subscriptionValue;
				}).findFirst().orElse(null);

	}

	public static List<AppDirectUnit> getUnits(List<Characteristic> characterstics) {
		List<AppDirectUnit> appDirectunits = new ArrayList<>();
		for (Characteristic characteristic : characterstics) {
			if (ProductOrderConstants.UNITS.equals(characteristic.getName())) {

				ObjectMapper objectMapper = new ObjectMapper();

				JSONObject json = new JSONObject((LinkedHashMap<String, AppDirectUnit>) characteristic.getValue());
				AppDirectUnit appDirectUnit = new AppDirectUnit();
				try {
					appDirectUnit = objectMapper.readValue(json.toString(), new TypeReference<AppDirectUnit>() {
					});
				} catch (JsonMappingException e) {
					log.error(e.getMessage());
				} catch (JsonProcessingException e) {
					log.error(e.getMessage());
				}

				appDirectunits.add(appDirectUnit);

			}
		}
		return appDirectunits;

	}

	public static Long getEPOCHMilliseconds(String dateStr) {
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			Date date = null;

			date = formatter.parse(dateStr);

			return date.getTime();

		} catch (Exception e) {
			log.error("Error is Date to Long conversion {} ", e.toString());
		}
		return 0L;
	}

	public static String getDate(String epochDate) {
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			Date date = new Date(Long.valueOf(epochDate));

			return formatter.format(date);

		} catch (Exception e) {
			log.error("Error is Date to Long conversion {} ", e.toString());
		}
		return null;
	}

}
