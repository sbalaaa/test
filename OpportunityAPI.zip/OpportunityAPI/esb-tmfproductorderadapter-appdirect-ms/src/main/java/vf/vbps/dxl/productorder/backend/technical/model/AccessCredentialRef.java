package vf.vbps.dxl.productorder.backend.technical.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@lombok.Generated
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccessCredentialRef {

	@JsonProperty("id")
	private String id = null;

	@JsonProperty("value")
	private String value = null;

}
