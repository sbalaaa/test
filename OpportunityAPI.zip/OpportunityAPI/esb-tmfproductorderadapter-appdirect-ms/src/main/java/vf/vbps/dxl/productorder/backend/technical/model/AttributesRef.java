package vf.vbps.dxl.productorder.backend.technical.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * attributes refered in microservice
 */

@lombok.Generated
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttributesRef {

	@JsonProperty("id")
	private String id = null;

	@JsonProperty("value")
	private String value = null;

}
