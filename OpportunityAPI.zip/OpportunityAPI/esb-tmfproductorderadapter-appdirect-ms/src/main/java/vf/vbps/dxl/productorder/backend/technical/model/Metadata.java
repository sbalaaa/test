package vf.vbps.dxl.productorder.backend.technical.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


/**
 * microservice meta data
 */

@lombok.Generated
@Data
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Metadata {

	@JsonProperty("backendApplication")
	private String backendApplication = null;

	@JsonProperty("applicationName")
	private String applicationName = null;

	@JsonProperty("serviceName")
	private String serviceName = null;

	@JsonProperty("countryCode")
	private String countryCode = null;

	@JsonProperty("additionalKey")
	private String additionalKey = null;

	@JsonProperty("backendURL")
	private String backendURL = null;

	private List<AccessCredentialRef> accessCredentials = null;

	private List<AttributesRef> attributes = null;

	private List<ApipathRef> apiPaths = null;

}
