package vf.vbps.dxl.productorder.backend.technical.service;

import org.springframework.http.HttpHeaders;

import vf.vbps.dxl.productorder.backend.technical.model.Metadata;

public interface MetadataService {

	Metadata getMetadataDetails(HttpHeaders httpHeaders, String operation);

	Metadata getNotificationMetadata(String countryCode, String operation);

}
