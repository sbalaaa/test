package vf.vbps.dxl.productorder.backend.technical.service;

import java.net.URI;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.configuration.ApplicationConfig;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.exceptions.InvalidInputDataException;
import vf.vbps.dxl.productorder.exceptions.InvalidSourceSystemHeaderException;
import vf.vbps.dxl.productorder.exceptions.MissingBusinessObject491Exception;

@Service
public class MetadataServiceImpl implements MetadataService {

	private static final Logger log = LoggerFactory.getLogger(MetadataServiceImpl.class);

	@Autowired
	ApplicationConfig applicationconfig;

	@Autowired
	RestTemplate restTemplate;

	@Override
	public Metadata getMetadataDetails(HttpHeaders httpHeaders, String operation) {

		log.info("getMetadataDetails ::countrycode:: {} , ::destinationsystem:: {} , ::operation:: {}",
				httpHeaders.get(ProductOrderConstants.X_COUNTRY_CODE),
				httpHeaders.get(ProductOrderConstants.X_DESTINATION_SYSTEM), operation);

		if (httpHeaders.get(ProductOrderConstants.X_COUNTRY_CODE) != null
				&& httpHeaders.get(ProductOrderConstants.X_DESTINATION_SYSTEM) != null) {

			String countryCode = httpHeaders.get(ProductOrderConstants.X_COUNTRY_CODE).get(0);
			String backendApp = httpHeaders.get(ProductOrderConstants.X_DESTINATION_SYSTEM).get(0);

			if (StringUtils.isNotEmpty(countryCode) && StringUtils.isNotEmpty(backendApp)) {
				
				log.info("getMetadataDetails ::countrycode:: {} , ::destinationsystem:: {} ",
						countryCode,
						backendApp);

				final UriComponentsBuilder builder = UriComponentsBuilder
						.fromHttpUrl(applicationconfig.getTechmsbasepath())
						.path(applicationconfig.getTechmsmetadataapi());

				HttpHeaders httpHeadres = new HttpHeaders();
				httpHeadres.set(ProductOrderConstants.ACCEPT, ProductOrderConstants.APPLICATION_JSON);
				httpHeadres.set(ProductOrderConstants.CONTENT_TYPE, ProductOrderConstants.APPLICATION_JSON);
				HttpEntity<Object> entity = new HttpEntity<>(httpHeadres);

				builder.queryParam(ProductOrderConstants.COUNTRY, countryCode);
				builder.queryParam(ProductOrderConstants.BACKEND_APPLICATION, backendApp);
				builder.queryParam(ProductOrderConstants.APPLICATION_NAME,
						ProductOrderConstants.PRODUCT_ORDER_OPPORTUNITY);
				builder.queryParam(ProductOrderConstants.SERVICE_NAME,
						ProductOrderConstants.PRODUCT_ORDER_OPPORTUNITY_SERVICE);
				builder.queryParam(ProductOrderConstants.ADDITIONAL_KEY, operation);
				URI url = builder.build().toUri();

				ResponseEntity<Metadata> result = restTemplate.exchange(url, HttpMethod.GET, entity, Metadata.class);

				if (result.getBody() == null)
					throw MissingBusinessObject491Exception.newMissingBusinessObject491Exception();

				log.debug(ProductOrderConstants.LOG_METADATA, result.getBody());

				return result.getBody();
			}
			throw InvalidSourceSystemHeaderException.newInvalidSourceSystemHeaderException();
		}
		throw InvalidSourceSystemHeaderException.newInvalidSourceSystemHeaderException();
	}

	@Override
	public Metadata getNotificationMetadata(String countryCode, String operation) {

		log.info("getNotificationMetadata ::countrycode:: {} , ::operation:: {}", countryCode, operation);

		if (StringUtils.isNotEmpty(countryCode)) {

			final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(applicationconfig.getTechmsbasepath())
					.path(applicationconfig.getTechmsmetadataapi());

			HttpHeaders httpHeadres = new HttpHeaders();
			httpHeadres.set(ProductOrderConstants.ACCEPT, ProductOrderConstants.APPLICATION_JSON);
			httpHeadres.set(ProductOrderConstants.CONTENT_TYPE, ProductOrderConstants.APPLICATION_JSON);
			HttpEntity<Object> entity = new HttpEntity<>(httpHeadres);

			builder.queryParam(ProductOrderConstants.COUNTRY, countryCode);
			builder.queryParam(ProductOrderConstants.BACKEND_APPLICATION, ProductOrderConstants.APPDIRECT);
			builder.queryParam(ProductOrderConstants.APPLICATION_NAME, ProductOrderConstants.PRODUCT_ORDER_OPPORTUNITY);
			builder.queryParam(ProductOrderConstants.SERVICE_NAME,
					ProductOrderConstants.PRODUCT_ORDER_OPPORTUNITY_SERVICE);
			builder.queryParam(ProductOrderConstants.ADDITIONAL_KEY, operation);
			URI url = builder.build().toUri();

			ResponseEntity<Metadata> result = restTemplate.exchange(url, HttpMethod.GET, entity, Metadata.class);

			if (result.getBody() == null)
				throw MissingBusinessObject491Exception.newMissingBusinessObject491Exception();

			log.debug(ProductOrderConstants.LOG_METADATA, result.getBody());

			return result.getBody();
		}
		throw InvalidInputDataException.newInvalidInputDataException();
	}

}
