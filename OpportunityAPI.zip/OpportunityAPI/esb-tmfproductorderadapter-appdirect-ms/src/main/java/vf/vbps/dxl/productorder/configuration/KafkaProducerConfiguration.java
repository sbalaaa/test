package vf.vbps.dxl.productorder.configuration;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

@Configuration
public class KafkaProducerConfiguration {
	@Autowired
	private ApplicationConfig applicationConfig;


	@Bean
	public ProducerFactory<Integer, String> producerFactory() {

		String username = applicationConfig.getMskusername();
		String password = applicationConfig.getMskpassword();
		String hostNames = applicationConfig.getMskhostname();

		String credentials = "org.apache.kafka.common.security.scram.ScramLoginModule required username=".concat("'")
				.concat(username).concat("'").concat(" ").concat("password=").concat("'").concat(password).concat("';");

		Map<String, Object> config = new HashMap<>();

		config.put("bootstrap.servers", hostNames);
		config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
		config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		config.put("ssl.endpoint.identification.algorithm", "");
		config.put("security.protocol", "SSL");
		config.put(SslConfigs.DEFAULT_SSL_ENABLED_PROTOCOLS, "TLSv1.2,TLSv1.1,TLSv1");
		config.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "/opt/jre/lib/security/cacerts");
		config.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, applicationConfig.getTruststorepassword());
		config.put("ssl.protocol", "TLS");
		config.put("security.protocol", "SASL_SSL");
		config.put("sasl.mechanism", "SCRAM-SHA-512");
		config.put("sasl.jaas.config", credentials);

		return new DefaultKafkaProducerFactory<>(config);
	}

	@Bean
	public KafkaTemplate<Integer, String> kafkaTemplate() {
		return new KafkaTemplate<>(producerFactory());
	}

}
