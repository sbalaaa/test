package vf.vbps.dxl.productorder.constants;

public class ProductOrderConstants {

	private ProductOrderConstants() {

	}

	public static final String ERROR = "error";
	public static final String MANDATORY_HEADER_ERROR = "One of the mandatory header is missed : x-country-code, x-destination-system, x-vf-api-process";
	public static final String MANDATORY_HEADER_ERROR_VF_PROCESS = "x-vf-api-process header has incorrect value: It should be Submit or Orchestrate";
	public static final String OPPORTUNITY_ID_MISSED = "Opportunity Id missed in the Product Order Payload for Submit action";
	public static final String SUBMIT_OPERATION = "Submit";
	public static final String ORCHESTRATE_OPERATION = "Orchestrate";
	public static final String TOTAL_QUANTITY = "TotalQuantity";
	public static final String X_TOTAL_COUNT = "X-Total-Count";
	public static final String CREATE_OPPORTUNITY_STEP = "CREATE-OPPORTUNITY";
	public static final String STEP_NONE = "NONE";
	public static final String PROCESSING_TYPE = "ADOpportunity";
	public static final String RESOURCE_TYPE = "ProductOrder";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String CUSTOMER = "Customer";
	public static final String VODAFONE = "Vodafone";
	public static final String CSM_ERROR_CODE = "CSM Error Code";
	public static final String EXIT_CODE = "exitcode";
	public static final String INTERNAL_SERVER_ERROR = "internal server error";
	public static final String CREATE_PRODUCT_ORDER = "createProductOrder";

	public static final String PRODUCT_ORDER_OPPORTUNITY_SERVICE = "OpportunityService";
	public static final String PRODUCT_ORDER_OPPORTUNITY = "OpportunityService";
	public static final String VF_VBPS_DXL_PRODUCTODER_CONFIGURATION = "vf.vbps.dxl.productorder.configuration";
	public static final String VF_VBPS_DXL_PRODUCTODER_REST = "vf.vbps.dxl.productorder.rest";
	public static final String VF_VBPS_DXL_PRODUCTODER = "vf.vbps.dxl.productorder";
	public static final String SOAP_BASE_PACKAGE = "vf.vbps.dxl.tmfsiemensadapterms.backend.appdirect.soap";
	public static final String X_COUNTRY_CODE = "x-country-code";
	public static final String X_SOURCE_SYSTEM = "x-source-system";
	public static final String X_DESTINATION_SYSTEM = "x-destination-system";
	public static final String X_ROUTE_KEY = "x-route-key";
	public static final String VF_API_PROCESS_HEADER = "x-vf-api-process";
	public static final String UPDATE_V2_USER = "Update Order Details";
	public static final String DB_ADDITIONAL_KEY = "ADDITIONAL_KEY";
	public static final String DB_APPLICATION_NAME = "APPLICATION_NAME";
	public static final String DB_BACKEND_APP = "BACKEND_APP";
	public static final String DB_COUNTRY_CODE = "COUNTRY_CODE";
	public static final String COUNTRY_CODE = "CountryCode";
	public static final String BACKEND_APP = "BackendApp";
	public static final String BACKEND_APPLICATION = "backendApplication";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String SERVICE_NAME = "serviceName";
	public static final String COUNTRY = "countryCode";
	public static final String ADDITIONAL_KEY = "additionalKey";
	public static final String CREATE_OPERATION = "CREATE";
	public static final String UPDATE_OPERATION = "UPDATE";
	public static final String DELETE_OPERATION = "DELETE";
	public static final String GET_OPERATION = "GET";
	public static final String IT = "IT";
	public static final String ES = "ES";
	public static final String DE = "DE";
	public static final String GR = "GR";
	public static final String ZA = "ZA";
	public static final String SOUTH_AFRICA = "za";
	public static final String GERMANY = "germany";
	public static final String ITALY = "italy";
	public static final String GREECE = "greece";
	public static final String SPAIN = "spain";

	public static final String APPDIRECT = "APPDIRECT";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String ACCEPT = "Accept";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPLICATION_XML = "application/xml";
	public static final String USER_NAME = "username";
	public static final String USER_PASSWORD = "password";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String GRANT_TYPE = "grant_type";
	public static final String SCOPE = "scope";
	public static final String TOKEN = "TOKEN";

	public static final String LOG_ACCESS_TOKEN = "Access Token : {} ";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer ";

	public static final String LOG_METADATA = "Metadata :";

	// Related Party constant
	public static final String ORGANIZATIONAL_EXTERNAL = "organizationExternal";
	public static final String ORGANIZATION = "organization";
	public static final String USERL_EXTERNAL = "userExternal";
	public static final String USER = "user";
	public static final String AGENT_COMPANY_EXTERNAL = "agentCompanyExternal";
	public static final String AGENT_COMPANY = "agentCompany";
	public static final String AGENT_EXTERNAL = "agentExternal";
	public static final String AGENT = "agent";

	public static final String IS_ADD_ITEM = "addon";
	public static final String IS_PRODUCT = "product";

	// Characteristic related constants
	public static final String UNITS = "units";
	public static final String BILLINGCONFIGURATION = "billingConfiguration";
	public static final String PROVISIOINGCONFIGURATION = "provisioningConfiguration";
	public static final String CONTRACTCONFIGURATION = "contractConfiguration";
	public static final String SUBSCRIPTION = "subscription";
	public static final String VENDORATTRIBUTES = "vendorAttributes";

	// Needs to remove
	public static final String TIME_TAKEN_MESSAGE_STRING = "Time taken to getResponse service is {} ms";
	public static final String TOKEN_STRING = "token is {} ";

	public static final String FINALIZEOPPORTUNITY = "OS_OpportunityFinalize";

	public static final String RECURRING_AD = "RECURRING";
	public static final String RECURRING_TMF = "recurring";
	public static final String ONE_TIME_AD = "ONE_TIME";
	public static final String ONE_TIME_TMF = "oneTime";
	public static final String RECURRING_FLAT_AD = "RECURRING_FLAT";
	public static final String RECURRING_FLAT_TMF = "recurringFlat";
	public static final String ONE_TIME_FLAT_AD = "ONE_TIME_FLAT";
	public static final String ONE_TIME_FLAT_TMF = "oneTimeFlat";
	public static final String INCLUDED_AD = "INCLUDED";
	public static final String INCLUDED_TMF = "included";
	public static final String RECURRING_PER_UNIT_AD = "RECURRING_PER_UNIT";
	public static final String RECURRING_PER_UNIT_TMF = "recurringPerUnit";
	public static final String ONE_TIME_PER_UNIT_AD = "ONE_TIME_PER_UNIT";
	public static final String ONE_TIME_PER_UNIT_TMF = "oneTimePerUnit";
	public static final String SETUP_PER_UNIT_AD = "SETUP_PER_UNIT";
	public static final String SETUP_PER_UNIT_TMF = "setUpPerUnit";
	public static final String SETUP_FEE_AD = "SETUP_FEE";
	public static final String SETUP_FEE_TMF = "setUpFee";
	public static final String CONTRACT_FEE_AD = "CONTRACT_FEE";
	public static final String CONTRACT_FEE_TMF = "contractFee";
	public static final String DISCOUNT_PER_UNIT_AD = "DISCOUNT_PER_UNIT";
	public static final String DISCOUNT_PER_UNIT_TMF = "discountPerUnit";
	public static final String DISCOUNT_FLAT_AD = "DISCOUNT_FLAT";
	public static final String DISCOUNT_FLAT_TMF = "discountFlat";
	public static final String METERED_USAGE_AD = "METERED_USAGE";
	public static final String METERED_USAGE_TMF = "meteredUsage";
	public static final String SALE = "sale";
	public static final String WHOLE_SALE = "wholeSale";
	public static final String TOTAL_SALE = "totalSale";
	public static final String DAILY_AD = "DAILY";
	public static final String DAILY_TMF = "daily";
	public static final String MONTHLY_AD = "MONTHLY";
	public static final String MONTHLY_TMF = "monthly";
	public static final String QUATERLY_AD = "QUATERLY";
	public static final String QUATERLY_TMF = "quaterly";
	public static final String SIX_MONTHS_AD = "SIX_MONTHS";
	public static final String SIX_MONTHS_TMF = "sixMonths";
	public static final String YEARLY_AD = "YEARLY";
	public static final String YEARLY_TMF = "yearly";
	public static final String TWO_YEARS_AD = "TWO_YEARS";
	public static final String TWO_YEARS_TMF = "twoYears";
	public static final String THREE_YEARS_AD = "THREE_YEARS";
	public static final String THREE_YEARS_TMF = "threeYears";
	public static final String FREE_AD = "FREE";
	public static final String FLAT_AD = "FLAT";
	public static final String UNIT_AD = "UNIT";
	public static final String VOLUME_AD = "VOLUME";
	public static final String TIERED_AD = "TIERED";
	public static final String UNLIMITED_AD = "UNLIMITED";
	public static final String CUSTOM_AD = "CUSTOM";
	public static final String ACCEPT_LANGUAGE = "Accept-Language";
	public static final String LOCALE = "en-US";
	public static final String PRICE_CUSTOM = "custom";
	public static final String PARENT = "parent";
	public static final String PURCHASE_NUMBER = "purchaseNumber";
	public static final String PURCHASE_ID = "purchaseId";
	public static final String PRICING_PLAN_UUID = "uuid";
	public static final String PRICING_PLAN_ID = "id";

}