package vf.vbps.dxl.productorder.exceptions;

import lombok.Getter;

@lombok.Generated
@Getter
public enum EnumExceptions {

	INVALID_INPUT_DATA("101", "Invalid Input Data",
			"The syntactic validation of the input business object ($vbo-id) failed for ", "400"),
	MISMATCHED_CODELISTS("106", "Mismatched Codelists",
			"A codelist ($vbo-codelist-name) value cannot be matched to a list of values found in one or more back-end systems.",
			"400"),
	MISSING_TRANSPORT_HEADER("160", "Missing Transport Header",
			"  An expected transport header or property ($transport-header-name) is missing or is not known from the request message.",
			"400"),
	MISSING_MESSAGE_HEADER("161", "Missing Message Header",
			"An expected message header ($message-header-name) is missing or is not known from the request message.",
			"400"),
	INVALID_REQUEST_MESSAGE("190", "Invalid Request Message",
			"The received ($transport-name) request message is invalid.", "400"),
	SECURITY_ERROR("200", "Security TmfError", "A general security error was encountered.", "400"),
	TOKEN_MALFORMED("220", "Token Malformed", "Security Token malformed", "400"),
	TOKEN_MISSING("221", "Token Missing", "Security Token is not supplied in the request", "400"),
	TOKEN_EXPIRED("222", "Token Expired", "Security Token supplied in the request has expired", "400"),
	TOKEN_INVALID("223", "Token Invalid", "Security Token supplied in the request is invalid for the invocation",
			"400"),
	TOKEN_INVALID_SIGNATURE("225", "Token Invalid Signature",
			"Signature Validation of the security token has failed", "400"),
	DUPLICATE_BUSINESS_OBJECT("493", "Duplicate Business Object",
			"The business object ($vbo-id) supplied already exists on the backend system.", "400"),
	BUSINESS_RULE_VIOLATION("504", "Business Rule Violation",
			"The business object ($vbo-id) supplied has violated one or more business rules.", "400"),
	UNAUTHORIZED_CLIENT("210", "Unauthorized Client",
			"The system client is not authorize to execute the operation: $action.", "401"),
	UNAUTHENTICATED_CLIENT("211", "Unauthenticated Client",
			"The system client has not been authenticated to invoke the operation: $action.", "403"),
	MISSING_BUSINESS_OBJECT("491", "Missing Business Object",
			"The business object ($vbo-id) supplied was not found in the backend system.", "404"),
	METHOD_NOT_ALLOWED("59", "Method Not Allowed",
			"The request method is not supported by this resource", "405"),
	INVALID_ACCEPT_HEADER("25", "Invalid Accept Header", "The Accept header is invalid", "406"),
	INVALID_ACCEPT_CHARSET_HEADER("25", "Invalid Accept Charset Header",
			"The server cannot return a response that satisfies the Accept-Charset Header", "406"),
	INVALID_RESOURCE_STATE("108", "Invalid Resource State",
			"The business object ($vbo-id) supplied was found to be in an incorrect state, thus violating a concurrency constraint. ",
			"409"),
	REQUEST_URI_IS_TOO_LONG("20", "Request-URI is too long", "Request-URI is too long", "414"),
	INVALID_CONTENT_TYPE_HEADER("26", "The value of the Content-Type header is invalid",
			"The value of the Content-Type header is invalid", "415"),
	THROTTLE_LIMIT_EXCEPTION("230", "Throttle Limit Exception", "Throttle limit exceeded", "429"),
	REQUEST_HEADERS_TOO_LARGE("26", "Request Headers Too Large",
			"The server is unwilling to process the request because either an individual header field, or all the header fields collectively, are too large",
			"431"),
	INTERFACE_ERROR("100", "Interface TmfError", "A general interface error was encountered.",
			"500"),
	INVALID_OUTPUT_DATA("103", "Invalid Output Data",
			"The syntactic validation of the output business object ($vbo-id) failed.", "500"),
	INVALID_RESPONSE_MESSAGE("191", "Invalid Response Message",
			"The ($transport-name) response message is invalid.", "500"),
	UNKNOWN_FAILURE("198", "Unknown Failure",
			"A failure occurred that is unknown or can not be classified.", "500"),
	ENCRYPTION_ERROR("201", "Encryption TmfError",
			"An error happened during the encryption of a data field.", "500"),
	DECRYPTION_ERROR("202", "Decryption TmfError",
			"An error happened during the decryption of a data field.", "500"),
	NETWORK_ERROR("300", "Network TmfError", "A general network error was encountered.",
			"500"),
	BACKEND_SYSTEM_INTERFACE_ERROR("400", "Backend System Interface TmfError",
			"A general backend system interface error was encountered.", "500"),
	PARTIAL_UPDATE_ERROR("403", "Partial Update TmfError",
			"A component ($vbo-component-name) of the core business object ($vbo-name) could not be created/modified.",
			"500"),
	BACKEND_SYSTEM_UNAVAILABLE("410", "Backend System Unavailable",
			"The backend system adapter could not communicate with the back-end system.", "500"),
	BACKEND_SYSTEM_SECURITY_ERROR("470", "Backend System Security TmfError",
			"General security error has occurred with the backend system.", "500"),
	BACKEND_SYSTEM_ENCRYPTION_ERROR("471", "Backend System Encryption TmfError",
			"The data to send to the back-end cannot be encrypted.", "500"),
	BACKEND_SYSTEM_DECRYPTION_ERROR("472", "Backend System Decryption TmfError",
			"The data received from the back-end cannot be decrypted.", "500"),
	BACKEND_SYSTEM_UNAUTHORIZED_CLIENT_ERROR("473",
			"Backend System Unauthorized Client TmfError",
			"The provided authentication credentials ($security-token) is not authorized to access the requested resource.",
			"500"),
	BACK_END_SYSTEM_ERROR("500", "Back End System TmfError",
			"A general backend system error was encountered.", "500"),
	THE_SERVICE_IS_TEMPORARILY_UNAVAILABLE("503", "The service is temporarily unavailable",
			"The service is temporarily unavailable.", "503"),
	BACKEND_SYSTEM_INTERFACE_TIMEOUT("401", "Backend System Interface Timeout",
			"The back-end system reply was not received after a defined amount of time.", "504"),
	INVALID_REQUEST("404", "Not Found", "Invalid Request", "404");

	private final String code;
	private final String reason;
	private final String message;
	private final String status;

	EnumExceptions(String code, String reason, String message, String status) {
		this.code = code;
		this.reason = reason;
		this.message = message;
		this.status = status;
	}
}
