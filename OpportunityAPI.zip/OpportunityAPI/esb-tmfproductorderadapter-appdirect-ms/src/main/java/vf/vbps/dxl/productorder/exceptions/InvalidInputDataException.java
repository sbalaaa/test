package vf.vbps.dxl.productorder.exceptions;

@lombok.Generated
public class InvalidInputDataException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static InvalidInputDataException newInvalidInputDataException() {
		return new InvalidInputDataException();
	}

}
