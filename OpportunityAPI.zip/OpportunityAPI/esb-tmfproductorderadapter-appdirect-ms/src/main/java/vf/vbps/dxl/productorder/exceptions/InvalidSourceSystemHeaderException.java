package vf.vbps.dxl.productorder.exceptions;

@lombok.Generated
public class InvalidSourceSystemHeaderException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static InvalidSourceSystemHeaderException newInvalidSourceSystemHeaderException() {
		return new InvalidSourceSystemHeaderException();
	}

}
