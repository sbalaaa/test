package vf.vbps.dxl.productorder.exceptions;

@lombok.Generated
public class MissingBusinessObject491Exception extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public static MissingBusinessObject491Exception newMissingBusinessObject491Exception() {
		return new MissingBusinessObject491Exception();
	}
}
