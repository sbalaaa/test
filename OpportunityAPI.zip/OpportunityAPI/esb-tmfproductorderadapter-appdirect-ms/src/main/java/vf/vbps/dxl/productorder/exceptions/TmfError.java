package vf.vbps.dxl.productorder.exceptions;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;
import lombok.ToString;

/**
 * Used when an API throws an TmfError, typically with a HTTP error response-code
 * (3xx, 4xx, 5xx)
 */

@lombok.Generated
@Validated
@Data
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TmfError {

	private String code = null;

	private String reason = null;

	private String message = null;

	private String status = null;

	private String referenceError = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
