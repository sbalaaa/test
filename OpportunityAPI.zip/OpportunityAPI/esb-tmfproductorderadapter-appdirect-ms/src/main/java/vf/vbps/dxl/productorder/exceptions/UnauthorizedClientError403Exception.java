package vf.vbps.dxl.productorder.exceptions;

public class UnauthorizedClientError403Exception extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public static UnauthorizedClientError403Exception newUnauthorizedClientError403Exception() {
		return new UnauthorizedClientError403Exception();
	}

}
