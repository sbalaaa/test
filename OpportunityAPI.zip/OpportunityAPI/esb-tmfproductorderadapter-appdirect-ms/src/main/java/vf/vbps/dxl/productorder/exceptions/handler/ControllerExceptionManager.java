package vf.vbps.dxl.productorder.exceptions.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.vodafone.gigthree.ulff.ULFF;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.exceptions.EnumExceptions;
import vf.vbps.dxl.productorder.exceptions.TmfError;

/**
 * @author
 *
 */
@Slf4j
@ControllerAdvice
public class ControllerExceptionManager {

	@Autowired(required = false)
	private ULFF ulff;
	
	@ExceptionHandler(HttpClientErrorException.class)
	public ResponseEntity<TmfError> handleHttpClientErrorException(HttpClientErrorException ex)  {
		ErrorObject errorObject = setTMFErrorResponse( ex );
		return ResponseEntity.status(errorObject.getStatus()).body(errorObject.getTmfError());
	}
	
	@ExceptionHandler(IllegalArgumentException.class)
	public ResponseEntity<TmfError> handleInvalidClientRequestException(IllegalArgumentException ex) {
		log.error(ex.getMessage(), ex);
		String errorMessage = ex.getMessage();
		TmfError tmfError = setTMFErrorResponse(EnumExceptions.INVALID_REQUEST_MESSAGE, errorMessage);
		HttpStatus finalResponseCode  = HttpStatus.BAD_REQUEST;
		return ResponseEntity.status(finalResponseCode).body(tmfError);
	}
	
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<TmfError> handleMethodNotAllowedException(HttpRequestMethodNotSupportedException ex) {
		log.error(ex.getMessage(), ex);
		String errorMessage = ex.getMessage();
		TmfError tmfError = setTMFErrorResponse(EnumExceptions.METHOD_NOT_ALLOWED, errorMessage);
		HttpStatus finalResponseCode  = HttpStatus.BAD_REQUEST;
		return ResponseEntity.status(finalResponseCode).body(tmfError);
	}


	@ExceptionHandler(Exception.class)
	public ResponseEntity<TmfError> handleDefaultException(Exception ex) {
		log.error(ex.getMessage(), ex);
		String errorMessage = ex.getMessage();
		TmfError tmfError  = setTMFErrorResponse(EnumExceptions.BACK_END_SYSTEM_ERROR, errorMessage);
		HttpStatus finalResponseCode  = HttpStatus.INTERNAL_SERVER_ERROR;
		return ResponseEntity.status(finalResponseCode).body(tmfError);
	}
	
	@ExceptionHandler(WebClientResponseException.class)
	public ResponseEntity<String> handleWebClientResponseException(WebClientResponseException ex) {
	    log.error("Error from WebClient - Status {}, Body {}", ex.getRawStatusCode(), ex.getResponseBodyAsString(), ex);
	    return ResponseEntity.status(ex.getRawStatusCode()).body(ex.getResponseBodyAsString());
	}
	
	/* Handling backend 5xx series */
	@ExceptionHandler(HttpServerErrorException.class)
	public ResponseEntity<TmfError> handleHttpServerErrorException(HttpServerErrorException ex) {

		TmfError tmfError = new TmfError();

		tmfError.setCode(EnumExceptions.INTERFACE_ERROR.getCode());
		tmfError.setStatus(EnumExceptions.INTERFACE_ERROR.getStatus());
		tmfError.setReason(EnumExceptions.INTERFACE_ERROR.getReason());
		tmfError.setMessage(EnumExceptions.INTERFACE_ERROR.getMessage());

		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(tmfError);
	}
	
	@ExceptionHandler(ResourceAccessException.class)
	public ResponseEntity<TmfError> handleConnectionTimeoutException(ResourceAccessException ex) {
		log.info("ControllerExceptionManager : handleConnectionTimeoutException :start");
		log.error("Resource Access exception caught: status :{}  message :{}", ex.getMessage(), ex);
		TmfError tmfError = new TmfError();

		tmfError.setCode(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE.getCode());
		tmfError.setStatus(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE.getStatus());
		tmfError.setReason(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE.getReason());
		tmfError.setMessage(EnumExceptions.BACKEND_SYSTEM_UNAVAILABLE.getMessage());
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(tmfError);
	}
	
	private ErrorObject setTMFErrorResponse(HttpClientErrorException ex) {
		log.error("Error response is {} ", ex.getResponseBodyAsString());
		log.error("Error response Status Code is {} ", ex.getStatusCode());
		EnumExceptions enumxceptions = EnumExceptions.UNKNOWN_FAILURE;
		HttpStatus responseCode = HttpStatus.BAD_REQUEST;
		String backendErrorMessage = ex.getResponseBodyAsString();

		if (ex.getStatusCode() == HttpStatus.NOT_FOUND) {
			enumxceptions = EnumExceptions.MISSING_BUSINESS_OBJECT;
			responseCode = HttpStatus.NOT_FOUND;
		} else if (ex.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR) {
			enumxceptions = EnumExceptions.BACKEND_SYSTEM_INTERFACE_ERROR;
			responseCode = HttpStatus.INTERNAL_SERVER_ERROR;
		} 

		TmfError tmfError = setTMFErrorResponse(enumxceptions, backendErrorMessage);
		ErrorObject errorObject = new ErrorObject();
		errorObject.setStatus(responseCode);
		errorObject.setTmfError(tmfError);
		return errorObject;
	}	
	
	

	private TmfError setTMFErrorResponse(EnumExceptions enumxceptions, String errorMessage) {

		TmfError tmfError = new TmfError();
		tmfError.setCode(enumxceptions.getCode());
		tmfError.setStatus(enumxceptions.getStatus());
		tmfError.setReason(enumxceptions.getReason());
		tmfError.setMessage(enumxceptions.getMessage());
		tmfError.setReferenceError(errorMessage);
		if (ulff != null) {
			ulff.populateErrorOutboundResponse(tmfError.getCode(), tmfError.getMessage());
		}
 		return tmfError;
	}	
	
	@Getter
	@Setter
	private class ErrorObject {
		HttpStatus status;
		TmfError tmfError;
	}
}