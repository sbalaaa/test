package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Agreement reference. An agreement represents a contract or arrangement,
 * either written or verbal and sometimes enforceable by law, such as a service
 * level agreement or a customer price agreement. An agreement involves a number
 * of other business entities, such as products, services, and resources and/or
 * their specifications.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AgreementRef {

	private String id = null;

	private String href = null;

	private String name = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String referredType = null;

}
