package vf.vbps.dxl.productorder.model;

import java.util.Date;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Request for cancellation an existing product order
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CancelProductOrder {

	private String id = null;

	private String href = null;

	private String cancellationReason = null;

	private Date effectiveCancellationDate = null;

	private Date requestedCancellationDate = null;

	private ProductOrderRef productOrder = null;

	private TaskStateType state = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
