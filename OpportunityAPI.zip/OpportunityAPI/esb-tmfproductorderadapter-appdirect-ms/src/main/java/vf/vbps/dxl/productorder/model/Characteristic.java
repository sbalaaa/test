package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Describes a given characteristic of an object or entity through a name/value
 * pair.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Characteristic {

	private String name = null;

	private String valueType = null;

	private Object value = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;
	
}
