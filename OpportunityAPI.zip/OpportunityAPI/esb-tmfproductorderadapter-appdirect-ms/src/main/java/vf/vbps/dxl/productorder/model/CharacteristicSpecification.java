package vf.vbps.dxl.productorder.model;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * This class defines a characteristic specification.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CharacteristicSpecification {

	private String id = null;

	private Boolean configurable = null;

	private String description = null;

	private Boolean extensible = null;

	private Boolean isUnique = null;

	private Integer maxCardinality = null;

	private Integer minCardinality = null;

	private String name = null;

	private String regex = null;

	private String valueType = null;

	@Valid
	private List<CharacteristicSpecificationRelationship> charSpecRelationship = null;

	@Valid
	private List<CharacteristicValueSpecification> characteristicValueSpecification = null;

	private TimePeriod validFor = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String valueSchemaLocation = null;

}
