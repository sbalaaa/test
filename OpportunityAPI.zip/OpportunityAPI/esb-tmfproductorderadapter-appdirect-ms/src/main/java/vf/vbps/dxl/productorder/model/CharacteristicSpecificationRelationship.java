package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * An aggregation, migration, substitution, dependency or exclusivity
 * relationship between/among Characteristic specifications. The specification
 * characteristic is embedded within the specification whose ID and href are in
 * this entity, and identified by its ID.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CharacteristicSpecificationRelationship {

	private String characteristicSpecificationId = null;

	private String name = null;

	private String parentSpecificationHref = null;

	private String parentSpecificationId = null;

	private String relationshipType = null;

	private TimePeriod validFor = null;

}
