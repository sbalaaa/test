package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * specification of a value (number or text or an object) that can be assigned
 * to a Characteristic.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CharacteristicValueSpecification {

	private Boolean isDefault = null;

	private String rangeInterval = null;

	private String regex = null;

	private String unitOfMeasure = null;

	private Integer valueFrom = null;

	private Integer valueTo = null;

	private String valueType = null;

	private TimePeriod validFor = null;

	private Any value = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
