package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Indicates the contact medium that could be used to contact the party.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactMedium {

	private String mediumType = null;

	private Boolean preferred = null;

	private MediumCharacteristic characteristic = null;

	private TimePeriod validFor = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
