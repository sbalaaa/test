package vf.vbps.dxl.productorder.model;

import java.util.Date;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Represents our registration of information used as proof of identity by an
 * individual (passport, national identity card, drivers license, social
 * security number, birth certificate)
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class IndividualIdentification {

	private String id = null;

	private String href = null;

	private String identificationId = null;

	private String identificationType = null;

	private String issuingAuthority = null;

	private Date issuingDate = null;

	private AttachmentRefOrValue attachment = null;

	private TimePeriod validFor = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
