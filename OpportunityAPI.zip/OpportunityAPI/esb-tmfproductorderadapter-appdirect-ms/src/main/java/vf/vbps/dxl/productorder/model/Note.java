package vf.vbps.dxl.productorder.model;

import java.util.Date;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Extra information about a given entity
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Note {

	private String id = null;

	private String author = null;

	private Date date = null;

	private String text = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
