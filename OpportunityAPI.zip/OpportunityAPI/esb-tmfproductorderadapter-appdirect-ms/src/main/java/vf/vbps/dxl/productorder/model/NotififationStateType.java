package vf.vbps.dxl.productorder.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Possible values for the state of the order
 */
public enum NotififationStateType {

	PENDING("pending"),

	COMPLETE("complete"),

	ERROR("error");

	private String value;

	NotififationStateType(String value) {
		this.value = value;
	}

	@Override
	@JsonValue
	public String toString() {
		return String.valueOf(value);
	}

	@JsonCreator
	public static NotififationStateType fromValue(String text) {
		for (NotififationStateType b : NotififationStateType.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}
}
