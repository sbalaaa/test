package vf.vbps.dxl.productorder.model;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * OrderPriceExtended
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderPriceExtended {

	private String description = null;

	private String name = null;

	private String priceType = null;

	private String recurringChargePeriod = null;

	private String unitOfMeasure = null;

	private BillingAccountRef billingAccount = null;

	private Price price = null;

	@Valid
	private List<PriceAlteration> priceAlteration = null;

	private ProductOfferingPriceRef productOfferingPrice = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String id = null;

	private String href = null;

	private String priceSubType = null;

	private PriceStrategyType priceStrategy = null;

	private Integer quantity = null;

	@Valid
	private List<PriceExtended> prices = null;

	@Valid
	private List<Characteristic> priceCharacteristic = null;

}
