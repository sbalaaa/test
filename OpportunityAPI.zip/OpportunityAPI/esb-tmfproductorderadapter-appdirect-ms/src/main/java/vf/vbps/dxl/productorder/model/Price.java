package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Provides all amounts (tax included, duty free, tax rate), used currency and
 * percentage to apply for Price Alteration.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Price {

	private Float percentage = null;

	private Float taxRate = null;

	private Money dutyFreeAmount = null;

	private Money taxIncludedAmount = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;
	
	private String description = null;

}
