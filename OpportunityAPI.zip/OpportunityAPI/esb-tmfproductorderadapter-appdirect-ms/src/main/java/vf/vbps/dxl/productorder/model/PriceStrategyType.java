package vf.vbps.dxl.productorder.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Possible values for the pricing strategy in the extended price object
 */
public enum PriceStrategyType {

	FREE("free"),

	FLAT("flat"),

	UNIT("unit"),

	VOLUME("volume"),

	TIERED("tiered"),

	UNLIMITED("unlimited"),

	CUSTOM("custom");

	private String value;

	PriceStrategyType(String value) {
		this.value = value;
	}

	@Override
	@JsonValue
	public String toString() {
		return String.valueOf(value);
	}

	@JsonCreator
	public static PriceStrategyType fromValue(String text) {
		for (PriceStrategyType b : PriceStrategyType.values()) {
			if (String.valueOf(b.value).equals(text)) {
				return b;
			}
		}
		return null;
	}
}
