package vf.vbps.dxl.productorder.model;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * A product offering procured by a customer or other interested party playing a
 * party role. A product is realized as one or more service(s) and / or
 * resource(s).
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Product {

	private String id = null;

	private String href = null;

	private String description = null;

	private Boolean isBundle = null;

	private Boolean isCustomerVisible = null;

	private String name = null;

	private Date orderDate = null;

	private String productSerialNumber = null;

	private Date startDate = null;

	private Date terminationDate = null;

	@Valid
	private List<AgreementItemRef> agreement = null;

	private BillingAccountRef billingAccount = null;

	@Valid
	private List<RelatedPlaceRefOrValue> place = null;

	@Valid
	private List<ProductRefOrValue> product = null;

	@Valid
	private List<Characteristic> productCharacteristic = null;

	private ProductOfferingRef productOffering = null;

	@Valid
	private List<RelatedProductOrderItem> productOrderItem = null;

	@Valid
	private List<ProductPrice> productPrice = null;

	@Valid
	private List<ProductRelationship> productRelationship = null;

	private ProductSpecificationRef productSpecification = null;

	@Valid
	private List<ProductTerm> productTerm = null;

	@Valid
	private List<ResourceRef> realizingResource = null;

	@Valid
	private List<ServiceRef> realizingService = null;

	@Valid
	private List<RelatedParty> relatedParty = null;

	private ProductStatusType status = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
