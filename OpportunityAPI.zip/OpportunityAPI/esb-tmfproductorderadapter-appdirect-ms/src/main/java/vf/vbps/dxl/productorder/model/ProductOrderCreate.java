package vf.vbps.dxl.productorder.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * A Product Order is a type of order which can be used to place an order
 * between a customer and a service provider or between a service provider and a
 * partner and vice versa, Skipped properties:
 * id,href,completionDate,orderDate,state,expectedCompletionDate,productOrderItem.state
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductOrderCreate {

	private Date cancellationDate = null;

	private String cancellationReason = null;

	private String category = null;

	private String description = null;

	private String externalId = null;

	private String notificationContact = null;

	private String priority = null;

	private Date requestedCompletionDate = null;

	private Date requestedStartDate = null;

	@Valid
	private List<AgreementRef> agreement = null;

	private BillingAccountRef billingAccount = null;

	@Valid
	private List<RelatedChannel> channel = null;

	@Valid
	private List<Note> note = null;

	@Valid
	private List<OrderPrice> orderTotalPrice = null;

	@Valid
	private List<PaymentRef> payment = null;

	@Valid
	private List<ProductOfferingQualificationRef> productOfferingQualification = null;

	@Valid
	private List<ProductOrderItem> productOrderItem = new ArrayList<>();

	@Valid
	private List<QuoteRef> quote = null;

	@Valid
	private List<RelatedParty> relatedParty = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
