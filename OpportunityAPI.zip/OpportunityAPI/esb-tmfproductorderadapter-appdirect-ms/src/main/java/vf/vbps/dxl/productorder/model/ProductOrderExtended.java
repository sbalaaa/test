package vf.vbps.dxl.productorder.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * ProductOrderExtended
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductOrderExtended {

	private String id = null;

	private String href = null;

	private Date cancellationDate = null;

	private String cancellationReason = null;

	private String category = null;

	private Date completionDate = null;

	private String description = null;

	private Date expectedCompletionDate = null;

	private String externalId = null;

	private String notificationContact = null;

	private Date orderDate = null;

	private String priority = null;

	private Date requestedCompletionDate = null;

	private Date requestedStartDate = null;

	@Valid
	private List<AgreementRef> agreement = null;

	private BillingAccountRef billingAccount = null;

	@Valid
	private List<RelatedChannel> channel = null;

	@Valid
	private List<Note> note = null;

	@Valid
	private List<OrderPrice> orderTotalPrice = null;

	@Valid
	private List<PaymentRef> payment = null;

	@Valid
	private List<ProductOfferingQualificationRef> productOfferingQualification = null;

	@Valid
	private List<ProductOrderItem> productOrderItem = new ArrayList<>();

	@Valid
	private List<QuoteRef> quote = null;

	@Valid
	private List<RelatedParty> relatedParty = null;

	private ProductOrderStateType state = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	@Valid
	private List<ExternalIdentifier> externalIdentifier = null;

}
