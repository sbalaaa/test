package vf.vbps.dxl.productorder.model;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * An identified part of the order. A product order is decomposed into one or
 * more order items.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductOrderItem {

	private String id = null;

	private Integer quantity = null;

	private OrderItemActionType action = null;

	private AppointmentRef appointment = null;

	private BillingAccountRef billingAccount = null;

	@Valid
	private List<OrderPrice> itemPrice = null;

	@Valid
	private List<OrderTerm> itemTerm = null;

	@Valid
	private List<OrderPrice> itemTotalPrice = null;

	@Valid
	private List<PaymentRef> payment = null;

	private ProductRefOrValue product = null;

	@Valid
	private List<OrderItemRelationship> productOrderItemRelationship = null;

	private ProductOfferingRef productOffering = null;

	private ProductOfferingQualificationItemRef productOfferingQualificationItem = null;

	@Valid
	private List<ProductOfferingQualificationRef> qualification = null;

	private QuoteItemRef quoteItem = null;

	private ProductOrderItemStateType state = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
