package vf.vbps.dxl.productorder.model;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
 * A Product Order is a type of order which  can  be used to place an order between a customer and a service provider or between a service provider and a partner and vice versa,
 */


@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductOrderResponse   {

  private String id;
  
  private String externalId;
   
  @Valid
  private List<ProductOrderItemResponse> productOrderItem = new ArrayList<>();
  
  private ProductOrderStateType state;
  
}

