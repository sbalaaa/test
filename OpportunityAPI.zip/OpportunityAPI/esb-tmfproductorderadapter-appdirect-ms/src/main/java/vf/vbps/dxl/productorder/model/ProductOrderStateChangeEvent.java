package vf.vbps.dxl.productorder.model;

import java.util.Date;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * The notification data structure
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductOrderStateChangeEvent {

	private String id = null;

	private String href = null;

	private String eventId = null;

	private Date eventTime = null;

	private String eventType = null;

	private String correlationId = null;

	private String domain = null;

	private String title = null;

	private String description = null;

	private String priority = null;

	private Date timeOcurred = null;

	private ProductOrderStateChangeEventPayload event = null;

}
