package vf.vbps.dxl.productorder.model;

import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * An amount, usually of money, that represents the actual price paid by a
 * Customer for a purchase, a rent or a lease of a Product. The price is valid
 * for a defined period of time.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductPrice {

	private String description = null;

	private String name = null;

	private String priceType = null;

	private String recurringChargePeriod = null;

	private String unitOfMeasure = null;

	private BillingAccountRef billingAccount = null;

	private Price price = null;

	private ProductOfferingPriceRef productOfferingPrice = null;

	@Valid
	private List<PriceAlteration> productPriceAlteration = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

}
