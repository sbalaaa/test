package vf.vbps.dxl.productorder.model;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * RelatedPartyWithContactInfo and additional attributes from the Party -
 * Individual component. It is necessary that the @referredType is being set
 * accordingly. Individual represents a single human being (a man, woman or
 * child). The individual can be a customer, an employee or any other person
 * that the organization needs to store information about.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedPartyWithContactInfoIndividual {

	@Valid
	private List<ContactMedium> contact = null;

	private String id = null;

	private String href = null;

	private String name = null;

	private String role = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String referredType = null;

	private String familyName = null;

	private String familyNamePrefix = null;

	private String formattedName = null;

	private String fullName = null;

	private String givenName = null;

	private String legalName = null;

	private String middleName = null;

	private String preferredGivenName = null;

	private Date birthDate = null;

	private String nationality = null;

	private String placeOfBirth = null;

	private String gender = null;

	private String countryOfBirth = null;

	@Valid
	private List<IndividualIdentification> individualIdentification = null;

}
