package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Related Entity reference. A related place defines a place described by
 * reference or by value linked to a specific entity. The polymorphic
 * attributes @type, @schemaLocation &amp; @referredType are related to the
 * place entity and not the RelatedPlaceRefOrValue class itself
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedPlaceRefOrValue {

	private String id = null;

	private String href = null;

	private String name = null;

	private String role = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String referredType = null;

}
