package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * RelatedProductOrderItem (ProductOrder item) .The product order item which
 * triggered product creation/change/termination.
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RelatedProductOrderItem {

	private String orderItemAction = null;

	private String orderItemId = null;

	private String productOrderHref = null;

	private String productOrderId = null;

	private String role = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String referredType = null;

}
