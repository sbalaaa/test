package vf.vbps.dxl.productorder.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Service reference, for when Service is used by other entities
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceRef {

	private String id = null;

	private String href = null;

	private String name = null;

	private String baseType = null;

	private String schemaLocation = null;

	private String type = null;

	private String referredType = null;

}
