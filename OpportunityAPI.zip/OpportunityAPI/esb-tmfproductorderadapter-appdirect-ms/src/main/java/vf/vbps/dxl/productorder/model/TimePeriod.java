package vf.vbps.dxl.productorder.model;

import java.util.Date;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * A period of time, either as a deadline (endDateTime only) a startDateTime
 * only, or both
 */

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimePeriod {

	private Date endDateTime = null;

	private Date startDateTime = null;

}
