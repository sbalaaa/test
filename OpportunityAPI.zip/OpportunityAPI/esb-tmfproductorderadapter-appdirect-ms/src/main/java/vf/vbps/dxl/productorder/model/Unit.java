
package vf.vbps.dxl.productorder.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "quantity", "unit" })
@Data
public class Unit {

	@JsonProperty("quantity")
	private Integer quantity;
	@JsonProperty("unit")
	private String unit;

}
