package vf.vbps.dxl.productorder.repository;

import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@Document(collection="DXLAsyncProcessing")
@Data
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class DXLAsyncProcessing {
	
	@Id
	private String id;
	
	@Field("ResourceType")
	private String resourceType;
	
	@Field("ProcessingType")
	private String processingType;
	
	@Field("DXLIdentifier")
	private String dxlIdentifier;
	
	@Field("ExternalIdentifier")
	private String externalIdentifier;
	
	@Field("SourceApplication")
	private String sourceApplication;
	
	@Field("SourceMarket")
	private String sourceMarket;
	
	@Field("ProcessingStatus")
	private String processingStatus;
	
	@Field("ProcessingStep")
	private String processingStep;
	
	@Field("CreatedOn")
	private LocalDateTime createdOn;
	
	@Field("ProcessingStartedOn")
	private LocalDateTime processingStartedOn;
	
	@Field("LastUpdatedOn")
	private LocalDateTime lastUpdatedOn;
	
	@Field("NotificationStatus")
	private String notificationStatus;
	
	@Field("NotificationTimestamp")
	private LocalDateTime notificationTimestamp;
	


}

