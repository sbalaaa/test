package vf.vbps.dxl.productorder.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DXLAsyncProcessingRepository extends MongoRepository<DXLAsyncProcessing, String>{
	List<DXLAsyncProcessing> findByDxlIdentifier(String dxlIdentifier);
}
