package vf.vbps.dxl.productorder.rest;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.vodafone.gigthree.ulff.Transaction;
import com.vodafone.gigthree.ulff.ULFF;

import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.service.ProductOrderService;

@RestController
@Slf4j
@RequestMapping(value = "/tmf-api/productOrderingManagement/v4")
public class ProductOrderApiController {

	@Autowired(required = false)
	private ULFF ulff;

	@Autowired
	private ProductOrderService service;

	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * Creates a ProductOrder
	 *
	 * @return ProductOrder
	 * @throws JsonProcessingException
	 */
	@PostMapping(value = "/productOrder", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProductOrder> createProductOrder(
			@ApiParam(value = "The ProductOrder to be created", required = true) @Valid @RequestBody ProductOrder productOrder,
			@RequestHeader HttpHeaders headers) throws JsonProcessingException {

		log.debug("Headers are: " + headers);

		log.debug("create ProductOrder request :\n {}",
				objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(productOrder));

		if (headers != null && headers.get(ProductOrderConstants.X_COUNTRY_CODE) == null
				|| headers.get(ProductOrderConstants.VF_API_PROCESS_HEADER) == null) {
			throw new IllegalArgumentException(ProductOrderConstants.MANDATORY_HEADER_ERROR);
		}

		setUlffTransactionServiceId(ProductOrderConstants.CREATE_PRODUCT_ORDER);

		String processingHeader = headers.get(ProductOrderConstants.VF_API_PROCESS_HEADER).get(0);

		log.info("Headers ::CountryCode:: {} , ::ProcessingHeader:: {} ",
				headers.get(ProductOrderConstants.X_COUNTRY_CODE).get(0),
				headers.get(ProductOrderConstants.VF_API_PROCESS_HEADER).get(0));

		ProductOrder response = null;
		if (processingHeader.equals(ProductOrderConstants.ORCHESTRATE_OPERATION)) {
			response = service.orchestrateCreateProductOrder(productOrder, headers);
		} else if (processingHeader.equals(ProductOrderConstants.SUBMIT_OPERATION)) {
			response = service.finalizeCreateProductOrder(productOrder, headers);
		} else {
			throw new IllegalArgumentException(ProductOrderConstants.MANDATORY_HEADER_ERROR_VF_PROCESS);
		}

		return ResponseEntity.ok(response);
	}

	/**
	 * It sets the service Id to for ulff record
	 */
	private void setUlffTransactionServiceId(String serviceId) {
		// log the ulff record
		if (ulff != null) {
			Transaction transaction = ulff.getCurrentTransaction();
			transaction.setServiceId(serviceId);
		}
	}
}
