package vf.vbps.dxl.productorder.rest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.exceptions.EnumExceptions;
import vf.vbps.dxl.productorder.exceptions.TmfError;


@Slf4j
@lombok.Generated
@Controller
public class ResourceInventoryValidationApiErrorController implements ErrorController {

	@RequestMapping("/error")
	public Object fallback() {
		log.debug("ResourceInventoryValidationApiErrorController : Error caught : Http status is : {}", HttpStatus.NOT_FOUND);
		TmfError error = new TmfError();
		error.setCode(EnumExceptions.UNKNOWN_FAILURE.getCode());
		error.setStatus(EnumExceptions.UNKNOWN_FAILURE.getStatus());
		error.setReason(EnumExceptions.UNKNOWN_FAILURE.getReason());
		error.setMessage(EnumExceptions.UNKNOWN_FAILURE.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
	}

	@Override
	public String getErrorPath() {
		return "/error";
	}
	
}
