package vf.vbps.dxl.productorder.service;

import org.springframework.http.HttpHeaders;

import vf.vbps.dxl.productorder.model.ProductOrder;



public interface ProductOrderService {

	ProductOrder   orchestrateCreateProductOrder( ProductOrder productOrder, HttpHeaders headers    );
	ProductOrder   finalizeCreateProductOrder( ProductOrder productOrder, HttpHeaders headers);
}
