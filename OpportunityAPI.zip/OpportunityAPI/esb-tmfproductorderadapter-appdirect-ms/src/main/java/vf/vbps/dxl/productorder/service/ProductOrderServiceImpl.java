package vf.vbps.dxl.productorder.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectOpportunityService;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectServiceUtil;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.backend.technical.service.MetadataService;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.exceptions.UnauthorizedClientError403Exception;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.NotififationStateType;
import vf.vbps.dxl.productorder.model.OrderItemActionType;
import vf.vbps.dxl.productorder.model.OrderItemRelationship;
import vf.vbps.dxl.productorder.model.OrderPrice;
import vf.vbps.dxl.productorder.model.Price;
import vf.vbps.dxl.productorder.model.ProcessOrderStateType;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderItem;
import vf.vbps.dxl.productorder.model.ProductOrderStateType;
import vf.vbps.dxl.productorder.model.RelatedParty;
import vf.vbps.dxl.productorder.repository.DXLAsyncProcessing;
import vf.vbps.dxl.productorder.repository.DXLAsyncProcessingRepository;
import vf.vbps.dxl.productorder.service.kafka.producer.ProductOrderEventProducer;

@Slf4j
@Service
public class ProductOrderServiceImpl implements ProductOrderService {

	@Autowired
	private ProductOrderEventProducer productOrderEventProducer;

	@Autowired
	private DXLAsyncProcessingRepository repository;

	@Autowired
	private MetadataService metadataService;

	@Autowired
	private AppDirectOpportunityService opportunityService;

	/**
	 * Creates a ProductOrder
	 *
	 * @return ProductOrder
	 */
	@Override
	public ProductOrder orchestrateCreateProductOrder(ProductOrder productOrder, HttpHeaders headers) {
		validateOrchestratePayload(productOrder);
		DXLAsyncProcessing asyncProcessing = getDXLAsyncProcessing(productOrder, headers);

		productOrder.setCountryCode(headers.get(ProductOrderConstants.X_COUNTRY_CODE).get(0));
		productOrder.setDxlIdentifier(asyncProcessing.getDxlIdentifier());
		try {
			productOrderEventProducer.sendProductOrderEvent(productOrder);
		} catch (Exception e) {
			log.error(e.toString());
		}
		repository.save(asyncProcessing);

		ProductOrder response = new ProductOrder();
		response.setId(asyncProcessing.getDxlIdentifier());
		List<ProductOrderItem> productOrderItems = new ArrayList<>();
		for (ProductOrderItem item : productOrder.getProductOrderItem()) {
			ProductOrderItem productOrderItem = new ProductOrderItem();
			productOrderItem.setId(item.getId());
			productOrderItem.setAction(item.getAction());
			productOrderItems.add(productOrderItem);
		}

		response.setProductOrderItem(productOrderItems);
		response.setExternalId(productOrder.getExternalId());
		response.setState(ProductOrderStateType.ACKNOWLEDGED);

		return response;
	}

	private DXLAsyncProcessing getDXLAsyncProcessing(ProductOrder productOrder, HttpHeaders headers) {

		DXLAsyncProcessing record = new DXLAsyncProcessing();
		record.setResourceType(ProductOrderConstants.RESOURCE_TYPE);
		record.setProcessingType(ProductOrderConstants.PROCESSING_TYPE);
		UUID uuid = UUID.randomUUID();
		record.setDxlIdentifier(uuid.toString());
		record.setExternalIdentifier(productOrder.getExternalId());
		record.setSourceApplication(headers.get(ProductOrderConstants.X_SOURCE_SYSTEM).get(0)); // from header
		record.setSourceMarket(headers.get(ProductOrderConstants.X_COUNTRY_CODE).get(0));
		record.setProcessingStatus(ProcessOrderStateType.PENDING.toString());
		record.setProcessingStep(ProductOrderConstants.STEP_NONE);
		record.setCreatedOn(LocalDateTime.now());
		record.setProcessingStartedOn(LocalDateTime.now());
		record.setLastUpdatedOn(LocalDateTime.now());
		record.setNotificationStatus(NotififationStateType.PENDING.toString());
		return record;

	}

	@Override
	public ProductOrder finalizeCreateProductOrder(ProductOrder productOrder, HttpHeaders headers) {
		if (CollectionUtils.isEmpty(productOrder.getProductOrderItem())) {
			throw new IllegalArgumentException("Missing product order items in request");
		}
		if (!CollectionUtils.isEmpty(productOrder.getProductOrderItem())
				&& productOrder.getProductOrderItem().size() > 1) {
			throw new IllegalArgumentException("More than 1 product order item in request");
		}
		if (StringUtils.isEmpty(productOrder.getExternalId())) {
			throw new IllegalArgumentException("Missing external id in request");
		}
		if (productOrder.getProductOrderItem().get(0).getQuoteItem() == null
				|| StringUtils.isEmpty(productOrder.getProductOrderItem().get(0).getQuoteItem().getId())) {
			throw new IllegalArgumentException("Missing opportunity id in request");
		}
		if (StringUtils.isEmpty(productOrder.getProductOrderItem().get(0).getId())) {
			throw new IllegalArgumentException("Missing  id for product order item in request");
		}
		if (StringUtils.isEmpty(productOrder.getProductOrderItem().get(0).getAction())) {
			throw new IllegalArgumentException("Missing action for product order item in request");
		}
		long start = System.currentTimeMillis();

		Metadata metadata = metadataService.getMetadataDetails(headers, ProductOrderConstants.CREATE_OPERATION);
		log.info("metadata value is {} ms", metadata);

		log.info("endpoint value is {} ms", metadata.getBackendURL());
		log.info("apilist value is {} ms", metadata.getApiPaths());

		String fializeEndpointUrl = getFinalizeEndpoint(metadata);
		String uri = UriComponentsBuilder.fromUriString(fializeEndpointUrl)
				.buildAndExpand(getOpportunityId(productOrder)).toUriString();
		log.info("fializeEndpointUrl is {} ", uri);

		String token = getOAuthAccessToken(metadata);
		log.info("token is {} ", token);

		AppDirectFinalizeResponse apiResponse = opportunityService
				.invokeFinalizeOpportunity(getOpportunityId(productOrder), metadata);

		long timeTaken = System.currentTimeMillis() - start;
		log.debug("Time taken to getResponse service is {} ms", timeTaken);

		ProductOrder response = new ProductOrder();
		response.setId(apiResponse.getId());
		response.setExternalId(productOrder.getExternalId());
		response.setProductOrderItem(productOrder.getProductOrderItem());
		if (!StringUtils.isEmpty(apiResponse.getPurchaseEffectiveDate())) {
			response.setRequestedStartDate(AppDirectServiceUtil.getDate(apiResponse.getPurchaseEffectiveDate()));
		}
		if (!StringUtils.isEmpty(apiResponse.getCreatedOn())) {
			response.setOrderDate(AppDirectServiceUtil.getDate(apiResponse.getCreatedOn()));
		}
		List<Note> notes = new ArrayList<>();
		Note noteOne = new Note();
		noteOne.setId(ProductOrderConstants.PURCHASE_ID);
		noteOne.setText(apiResponse.getPurchaseId());
		notes.add(noteOne);

		Note noteTwo = new Note();
		noteTwo.setId(ProductOrderConstants.PURCHASE_NUMBER);
		noteTwo.setText(apiResponse.getPurchaseNumber());
		notes.add(noteTwo);

		response.setNote(notes);
		response.setState(ProductOrderStateType.INPROGRESS);

		return response;
	}

	private String getOAuthAccessToken(Metadata metadata) {
		String accessToken = null;
		if (metadata.getAccessCredentials() != null) {
			Optional<AccessCredentialRef> accessCredential = metadata.getAccessCredentials().stream()
					.filter(ref -> ref.getId().equals(ProductOrderConstants.TOKEN)).filter(Objects::nonNull).findAny();
			if (accessCredential.isPresent()) {
				accessToken = accessCredential.get().getValue();
				log.info(ProductOrderConstants.LOG_ACCESS_TOKEN, accessToken);
			} else {
				throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
			}
		} else {
			throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
		}
		return accessToken;
	}

	private String getFinalizeEndpoint(Metadata metadata) {
		String backEndUrl = metadata.getBackendURL();
		String finalizeEndpointUrl = "";
		List<ApipathRef> apiPaths = metadata.getApiPaths();
		for (ApipathRef apiPath : apiPaths) {
			if (apiPath.getId().equals(ProductOrderConstants.FINALIZEOPPORTUNITY)) {
				finalizeEndpointUrl = apiPath.getValue();
				break;
			}
		}

		return (backEndUrl + finalizeEndpointUrl).trim();
	}

	private String getOpportunityId(ProductOrder productOrder) {
		if (productOrder != null && productOrder.getProductOrderItem() != null
				&& !productOrder.getProductOrderItem().isEmpty()) {
			ProductOrderItem productOrderItem = productOrder.getProductOrderItem().get(0);
			if (productOrderItem != null && productOrderItem.getQuoteItem() != null
					&& productOrderItem.getQuoteItem().getId() != null) {
				log.info("Opportunity Id is {} ", productOrderItem.getQuoteItem().getId());
				return productOrderItem.getQuoteItem().getId();
			} else {
				throw new IllegalArgumentException(ProductOrderConstants.OPPORTUNITY_ID_MISSED);
			}

		} else {
			throw new IllegalArgumentException(ProductOrderConstants.OPPORTUNITY_ID_MISSED);
		}
	}

	private void validateOrchestratePayload(ProductOrder productOrder) {

		validateCustomerId(productOrder);
		validateCustomerCompanyId(productOrder);
		validateOwnerCompanyId(productOrder);
		validateOwnerId(productOrder);
		validateCreateOpportunityProductOrderItems(productOrder);

	}

	private void validateCustomerCompanyId(ProductOrder productOrder) {
		String customerCompanyId = getRelatedPartyId(productOrder, ProductOrderConstants.ORGANIZATIONAL_EXTERNAL);
		if (customerCompanyId == null) {
			customerCompanyId = getRelatedPartyId(productOrder, ProductOrderConstants.ORGANIZATION);
		}
		if (customerCompanyId == null) {
			throw new IllegalArgumentException("Customer Company Id not found in the productOrder Payload ");
		}
	}

	private void validateCustomerId(ProductOrder productOrder) {
		String customerId = getRelatedPartyId(productOrder, ProductOrderConstants.USERL_EXTERNAL);
		if (customerId == null) {
			customerId = getRelatedPartyId(productOrder, ProductOrderConstants.USER);
		}
		if (customerId == null) {
			throw new IllegalArgumentException("Customer Id not found in the productOrder Payload ");
		}
	}

	private void validateOwnerCompanyId(ProductOrder productOrder) {
		String ownerCompanyId = getRelatedPartyId(productOrder, ProductOrderConstants.AGENT_COMPANY_EXTERNAL);
		if (ownerCompanyId == null) {
			ownerCompanyId = getRelatedPartyId(productOrder, ProductOrderConstants.AGENT_COMPANY);
		}
		if (ownerCompanyId == null) {
			throw new IllegalArgumentException("Owner Company Id not found in the productOrder Payload ");
		}
	}

	private void validateOwnerId(ProductOrder productOrder) {
		String ownerId = getRelatedPartyId(productOrder, ProductOrderConstants.AGENT_EXTERNAL);
		if (ownerId == null) {
			ownerId = getRelatedPartyId(productOrder, ProductOrderConstants.AGENT);
		}
		if (ownerId == null) {
			throw new IllegalArgumentException("OwnerId not found in the productOrder Payload ");
		}
	}

	private String getRelatedPartyId(ProductOrder productOrder, String matchingValue) {
		if (productOrder != null && productOrder.getRelatedParty() != null
				&& !productOrder.getRelatedParty().isEmpty()) {
			List<RelatedParty> relatedParties = productOrder.getRelatedParty();
			for (RelatedParty relatedParty : relatedParties) {
				if (matchingValue.equals(relatedParty.getRole())) {
					return relatedParty.getId();
				}
			}

		}
		return null;
	}

	private void validateCreateOpportunityProductOrderItems(ProductOrder productOrder) {
		if (CollectionUtils.isEmpty(productOrder.getProductOrderItem())) {
			throw new IllegalArgumentException("Missing product order item in request ");
		}
		List<ProductOrderItem> items = productOrder.getProductOrderItem();

		String step = "";
		for (ProductOrderItem item : items) {
			if (StringUtils.isEmpty(item.getId())) {
				throw new IllegalArgumentException("Missing id for item");
			}
			if (StringUtils.isEmpty(item.getAction()) || !item.getAction().equals(OrderItemActionType.ADD)) {
				throw new IllegalArgumentException("Missing/Unsupported action for item with id " + item.getId());
			}
			if (!CollectionUtils.isEmpty(item.getItemPrice())) {
				for (OrderPrice itemPrice : item.getItemPrice()) {
					if (itemPrice.getId() != null && CollectionUtils.isEmpty(itemPrice.getPrices())) {
						throw new IllegalArgumentException("Missing customized price for cost id " + itemPrice.getId());
					}
					if (!CollectionUtils.isEmpty(itemPrice.getPrices())) {
						if (itemPrice.getPrices().size() > 1) {
							throw new IllegalArgumentException("More than one price for cost id " + itemPrice.getId());
						}
						Price price = itemPrice.getPrices().get(0);
						if (StringUtils.isEmpty(price.getDescription())
								|| !price.getDescription().equals(ProductOrderConstants.PRICE_CUSTOM)) {
							throw new IllegalArgumentException(
									"Missing/Incorrect description for price item with cost id " + itemPrice.getId());
						}
						if (price.getDutyFreeAmount() == null || price.getDutyFreeAmount().getValue() == null) {
							throw new IllegalArgumentException(
									"Missing amount for price item with cost id " + itemPrice.getId());
						}

					}
				}
			}
			if (item.getProduct() == null) {
				throw new IllegalArgumentException("Missing product for item with id " + item.getId());
			}
			if (StringUtils.isEmpty(item.getProduct().getId()) && (item.getProduct().getProductOffering() == null
					|| StringUtils.isEmpty(item.getProduct().getProductOffering().getId()))) {
				throw new IllegalArgumentException(
						"Missing pricing plan id and product id for product in item with id " + item.getId());
			}
			if (!StringUtils.isEmpty(item.getProduct().getId()) && StringUtils.isEmpty(item.getProduct().getName())) {
				throw new IllegalArgumentException(
						"Missing identifier for pricing plan id for product in item with id " + item.getId());
			}
			if (!StringUtils.isEmpty(item.getProduct().getName())
					&& (!item.getProduct().getName().equals(ProductOrderConstants.PRICING_PLAN_UUID)
							&& !item.getProduct().getName().equals(ProductOrderConstants.PRICING_PLAN_ID))) {
				throw new IllegalArgumentException(
						"Invalid identifier type for pricing plan id for product in item with id " + item.getId());
			}

			if (StringUtils.isEmpty(item.getProduct().getDescription())
					|| (!item.getProduct().getDescription().equals(ProductOrderConstants.IS_PRODUCT)
							&& !item.getProduct().getDescription().equals(ProductOrderConstants.IS_ADD_ITEM))) {
				throw new IllegalArgumentException(
						"Missing or Invalid description for product in item with id " + item.getId());
			}

			if (isProduct(item)) {

				List<Characteristic> characterstics = item.getProduct().getProductCharacteristic();

				if (characterstics != null) {

					try {

						step = ProductOrderConstants.BILLINGCONFIGURATION;
						ProductOrderServiceUtil.getBillingConfiguration(characterstics);

						step = ProductOrderConstants.PROVISIOINGCONFIGURATION;
						ProductOrderServiceUtil.getProvisioningConfiguration(characterstics);

						step = ProductOrderConstants.SUBSCRIPTION;
						ProductOrderServiceUtil.getSubscriptionCustomAttributes(characterstics);

						step = ProductOrderConstants.SUBSCRIPTION;
						ProductOrderServiceUtil.getVendorRequiredFields(characterstics);

					} catch (NullPointerException | IndexOutOfBoundsException e) {
						throw new IllegalArgumentException(step + " is incorrect in the productOrder Payload ");
					}

				}
			}

			if (isAddOn(item)) {
				if (CollectionUtils.isEmpty(item.getProductOrderItemRelationship())) {
					throw new IllegalArgumentException("Missing parent item id for addOn item with id " + item.getId());
				}
				OrderItemRelationship itemRelationship = item.getProductOrderItemRelationship().get(0);
				if (StringUtils.isEmpty(itemRelationship.getRelationshipType())
						|| !itemRelationship.getRelationshipType().equals(ProductOrderConstants.PARENT)) {
					throw new IllegalArgumentException(
							"Missing relationship type for addOn item with id " + item.getId());
				}
				if (StringUtils.isEmpty(itemRelationship.getId())) {
					throw new IllegalArgumentException("Missing parent item id for addOn item with id " + item.getId());
				}
			}
		}
	}

	private boolean isProduct(ProductOrderItem item) {
		if (item.getProduct() != null && item.getProduct().getDescription() != null
				&& item.getProduct().getDescription().equals(ProductOrderConstants.IS_PRODUCT)) {
			return true;
		}
		return false;
	}

	private boolean isAddOn(ProductOrderItem item) {
		if (item.getProduct() != null && item.getProduct().getDescription() != null
				&& item.getProduct().getDescription().equals(ProductOrderConstants.IS_ADD_ITEM)) {
			return true;
		}
		return false;
	}

}
