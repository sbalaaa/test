package vf.vbps.dxl.productorder.service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectSubscriptionCustomAttributes;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectVendorRequiredFields;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.exceptions.UnauthorizedClientError403Exception;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.RelatedParty;
import vf.vbps.dxl.productorder.model.Unit;

@Slf4j
public class ProductOrderServiceUtil {

	private ProductOrderServiceUtil() {

	}

	public static String getCustomerCompanyId(ProductOrder productOrder) {
		String customerCompanyId = ProductOrderServiceUtil.getId(productOrder,
				ProductOrderConstants.ORGANIZATIONAL_EXTERNAL);
		if (customerCompanyId == null) {
			customerCompanyId = getId(productOrder, ProductOrderConstants.ORGANIZATION);
		}

		return customerCompanyId;
	}

	public static String getCustomerId(ProductOrder productOrder) {
		String customerId = ProductOrderServiceUtil.getId(productOrder, ProductOrderConstants.USERL_EXTERNAL);
		if (customerId == null) {
			customerId = getId(productOrder, ProductOrderConstants.USER);
		}

		return customerId;
	}

	public static String getOwnerCompanyId(ProductOrder productOrder) {
		String ownerCompanyId = ProductOrderServiceUtil.getId(productOrder, ProductOrderConstants.AGENT_COMPANY_EXTERNAL);
		if (ownerCompanyId == null) {
			ownerCompanyId = ProductOrderServiceUtil.getId(productOrder, ProductOrderConstants.AGENT_COMPANY);
		}
		return ownerCompanyId;
	}

	public static String getOwnerId(ProductOrder productOrder) {
		String ownerId = ProductOrderServiceUtil.getId(productOrder, ProductOrderConstants.AGENT_EXTERNAL);
		if (ownerId == null) {
			ownerId = ProductOrderServiceUtil.getId(productOrder, ProductOrderConstants.AGENT);
		}

		return ownerId;
	}

	public static String getId(ProductOrder productOrder, String matchingValue) {
		List<RelatedParty> relatedParties = productOrder.getRelatedParty();
		for (RelatedParty relatedParty : relatedParties) {
			if (matchingValue.equals(relatedParty.getRole())) {
				return relatedParty.getId();
			}
		}
		return null;
	}

	public static String getOAuthAccessToken(Metadata metadata) {
		String accessToken = null;
		if (metadata.getAccessCredentials() != null) {
			Optional<AccessCredentialRef> accessCredential = metadata.getAccessCredentials().stream()
					.filter(ref -> ref.getId().equals(ProductOrderConstants.TOKEN)).filter(Objects::nonNull).findAny();
			if (accessCredential.isPresent()) {
				accessToken = accessCredential.get().getValue();
				log.info(ProductOrderConstants.LOG_ACCESS_TOKEN, accessToken);
			} else {
				throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
			}
		} else {
			throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
		}
		return accessToken;
	}

	public static String getEndpoint(Metadata metadata, String id) {
		String backEndUrl = metadata.getBackendURL();
		String finalizeEndpointUrl = "";
		List<ApipathRef> apiPaths = metadata.getApiPaths();
		log.info("getEndpoint apiPaths {} ", apiPaths);
		for (ApipathRef apiPath : apiPaths) {
			if (apiPath.getId().equals(id)) {
				finalizeEndpointUrl = apiPath.getValue();
				break;
			}
		}

		return (backEndUrl + finalizeEndpointUrl).trim();
	}

	public static BillingConfiguration getBillingConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream()
				.filter(c -> ProductOrderConstants.BILLINGCONFIGURATION.equals(c.getName())).map(c -> {
					BillingConfiguration filterBillingConfiguration = new BillingConfiguration();
					//filterBillingConfiguration.setDate(getEPOCHMilliseconds(c.getValue().getDate()));
					//filterBillingConfiguration.setStrategy(c.getValue().getStrategy());
					return filterBillingConfiguration;
				}).findFirst().orElse(null);

	}

	public static ProvisioningConfiguration getProvisioningConfiguration(List<Characteristic> characterstics) {
		return  characterstics.stream()
				.filter(c -> ProductOrderConstants.PROVISIOINGCONFIGURATION.equals(c.getName())).map(c -> {
					ProvisioningConfiguration filterProvisioningConfiguration = new ProvisioningConfiguration();
					//filterProvisioningConfiguration.setDate(getEPOCHMilliseconds(c.getValue().getDate()));
					//filterProvisioningConfiguration.setStrategy(c.getValue().getStrategy());
					return filterProvisioningConfiguration;
				}).findFirst().orElse(null);

	}

	public static AppDirectSubscriptionCustomAttributes getSubscriptionCustomAttributes(
			List<Characteristic> characterstics) {
		return characterstics.stream()
				.filter(c -> ProductOrderConstants.SUBSCRIPTION.equals(c.getName())).map(c -> {
					AppDirectSubscriptionCustomAttributes filterSubscriptionCustomAttribute = new AppDirectSubscriptionCustomAttributes();
					//filterSubscriptionCustomAttribute.setIntendedOs(c.getValue().getIntendedOs());
					//filterSubscriptionCustomAttribute.setSalesAgentId(c.getValue().getSalesAgentId());
					return filterSubscriptionCustomAttribute;
				}).findFirst().orElse(null);


	}

	public static AppDirectVendorRequiredFields getVendorRequiredFields(List<Characteristic> characterstics) {
		return characterstics.stream()
				.filter(c -> ProductOrderConstants.VENDORATTRIBUTES.equals(c.getName())).map(c -> {
					AppDirectVendorRequiredFields filterVendorRequiredField = new AppDirectVendorRequiredFields();
					//filterVendorRequiredField.setEmail(c.getValue().getEmail());
					//filterVendorRequiredField.setName(c.getValue().getName());
					//filterVendorRequiredField.setLastname(c.getValue().getLastname());
					return filterVendorRequiredField;
				}).findFirst().orElse(null);

	}
	
}
