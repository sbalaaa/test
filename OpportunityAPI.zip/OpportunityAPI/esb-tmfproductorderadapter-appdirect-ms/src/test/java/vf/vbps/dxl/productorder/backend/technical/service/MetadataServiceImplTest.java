package vf.vbps.dxl.productorder.backend.technical.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import java.net.URI;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.configuration.ApplicationConfig;
import vf.vbps.dxl.productorder.test.MockUtil;

public class MetadataServiceImplTest {
	
	@InjectMocks
	private MetadataServiceImpl metadataService;

	@Mock
	RestTemplate restTemplate;


	@Mock
	ApplicationConfig applicationConfig;

	@Before
	public void setData() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getMetadataDetailsTest() {
		HttpHeaders headers;
		headers = new HttpHeaders();
		headers.set("X-Country-Code", "UK");
		headers.set("X-Destination-System", "APPDIRECT");
		headers.set("x-vf-trace-transaction-id", "111111");

		Mockito.when(applicationConfig.getTechmsbasepath()).thenReturn("http://localhost:9082");
		Mockito.when(applicationConfig.getTechmsmetadataapi()).thenReturn("/technical-api/metadata-ms/v1/microserviceMetaData");
		
		ResponseEntity<Metadata> result = ResponseEntity.ok(MockUtil.getMetadata());
		Mockito.when(restTemplate.exchange(any(URI.class),any(HttpMethod.class),any(HttpEntity.class),eq(Metadata.class))).thenReturn(result);
		
		Metadata metadata = metadataService.getMetadataDetails(headers, "GET");

		assertNotNull(metadata);

	}
	
	@Test
	public void getNotificationMetadataTest() {

		Mockito.when(applicationConfig.getTechmsbasepath()).thenReturn("http://localhost:9082");
		Mockito.when(applicationConfig.getTechmsmetadataapi()).thenReturn("/technical-api/metadata-ms/v1/microserviceMetaData");
		
		ResponseEntity<Metadata> result = ResponseEntity.ok(MockUtil.getMetadata());
		Mockito.when(restTemplate.exchange(any(URI.class),any(HttpMethod.class),any(HttpEntity.class),eq(Metadata.class))).thenReturn(result);
		
		Metadata metadata = metadataService.getNotificationMetadata("UK", "GET");

		assertNotNull(metadata);

	}
}
