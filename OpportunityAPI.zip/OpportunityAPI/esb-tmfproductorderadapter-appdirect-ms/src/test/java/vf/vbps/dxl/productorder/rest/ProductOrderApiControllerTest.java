package vf.vbps.dxl.productorder.rest;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderResponse;
import vf.vbps.dxl.productorder.service.ProductOrderService;
import vf.vbps.dxl.productorder.test.MockUtil;

public class ProductOrderApiControllerTest {

	
	@InjectMocks
	private ProductOrderApiController productOrderApiController;
	
	@Mock
	private ProductOrderService service;
	
	@Mock
	private ObjectMapper objectMapper;
	
	@Before
 	public void initSetupMock() {
		MockitoAnnotations.initMocks(this);
 	}
	
	
	@Test
	public void createProductOrderSubmitTest() throws Exception {
		ProductOrder request = MockUtil.createProductOrderRequest();
		ObjectWriter objectWriter = new ObjectMapper().writerWithDefaultPrettyPrinter();
		Mockito.when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);

		assertNotNull(request);
		
		HttpHeaders headers = new HttpHeaders();
		headers.set(ProductOrderConstants.X_SOURCE_SYSTEM, "VF-IT-HUB");
		headers.set(ProductOrderConstants.X_DESTINATION_SYSTEM, "APPDIRECT");
		headers.set(ProductOrderConstants.X_COUNTRY_CODE, "UK");
		headers.set(ProductOrderConstants.VF_API_PROCESS_HEADER, "Submit");
		Mockito.when(service.finalizeCreateProductOrder(request,headers)).thenReturn(MockUtil.createProductOrderResponse());
		ResponseEntity<ProductOrder> response = productOrderApiController.createProductOrder(request,headers);
		System.out.println(response);
		assertNotNull(response);
	}
	
	
	@Test
	public void createProductOrderOrchestrateTest() throws Exception {
		ProductOrder request = MockUtil.createProductOrderRequest();
		ObjectWriter objectWriter = new ObjectMapper().writerWithDefaultPrettyPrinter();
		Mockito.when(objectMapper.writerWithDefaultPrettyPrinter()).thenReturn(objectWriter);

		assertNotNull(request);
		
		HttpHeaders headers = new HttpHeaders();
		headers.set(ProductOrderConstants.X_SOURCE_SYSTEM, "VF-IT-HUB");
		headers.set(ProductOrderConstants.X_DESTINATION_SYSTEM, "APPDIRECT");
		headers.set(ProductOrderConstants.X_COUNTRY_CODE, "UK");
		headers.set(ProductOrderConstants.VF_API_PROCESS_HEADER, "Orchestrate");
		Mockito.when(service.orchestrateCreateProductOrder(request,headers)).thenReturn(MockUtil.createProductOrderResponse());
		ResponseEntity<ProductOrder> response = productOrderApiController.createProductOrder(request,headers);
		System.out.println(response);
		assertNotNull(response);
	}
}
