package vf.vbps.dxl.productorder.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.technical.service.MetadataService;
import vf.vbps.dxl.productorder.configuration.ApplicationConfig;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.repository.DXLAsyncProcessingRepository;
import vf.vbps.dxl.productorder.service.kafka.producer.ProductOrderEventProducer;
import vf.vbps.dxl.productorder.test.MockUtil;

public class ProductOrderServiceImplTest {
	
	@InjectMocks
	private ProductOrderServiceImpl productOrderServiceImpl;
	
	@Mock
	private ProductOrderEventProducer productOrderEventProducer;

	@Mock
	private DXLAsyncProcessingRepository repository;

	@Mock
	private ApplicationConfig config;
	
	@Mock
	private MetadataService metadataService;

	@Mock
	private WebClient webClient;
	
	@Mock
	private WebClient.RequestBodyUriSpec requestBodyUriSpec;
	
	@Mock
	private WebClient.RequestHeadersSpec requestHeadersSpec;

	@Mock
	private WebClient.RequestBodySpec requestBodySpec;

	@Mock
	private WebClient.ResponseSpec responseSpec;
	
	@Before
 	public void initSetupMock() {
		MockitoAnnotations.initMocks(this);
 	}
	

	@Test
	@Ignore
	public void orchestrateCreateProductOrderTest() throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.set(ProductOrderConstants.X_SOURCE_SYSTEM, "VF-IT-HUB");
		headers.set(ProductOrderConstants.X_DESTINATION_SYSTEM, "APPDIRECT");
		headers.set(ProductOrderConstants.X_COUNTRY_CODE, "UK");
		headers.set(ProductOrderConstants.VF_API_PROCESS_HEADER, "Submit");
		ProductOrder order = MockUtil.createProductOrderRequest();
		ProductOrder response = productOrderServiceImpl.orchestrateCreateProductOrder(order,headers);
		assertNotNull(response);
	}
	
	@Test
	@Ignore
	public void finalizeCreateProductOrderTest() throws Exception {
		ProductOrder order = MockUtil.createProductOrderRequest();
		HttpHeaders headers = new HttpHeaders();
		Mockito.when(metadataService.getMetadataDetails(any(), any())).thenReturn(MockUtil.getMetadata());
		
		Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.retrieve()).thenReturn(responseSpec);
		AppDirectFinalizeResponse finalizeResponse = MockUtil.finalizeOpportunityResponse();
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectFinalizeResponse>>notNull()))
                .thenReturn(Mono.just(finalizeResponse));
		ProductOrder response = productOrderServiceImpl.finalizeCreateProductOrder(order,headers);
		assertNotNull(response);
	}
	
	
	
}
