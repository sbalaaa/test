package vf.vbps.dxl.productorder.test;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.model.ProductOrder;

public class MockUtil {
	
	public static ProductOrder createProductOrderRequest() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ProductOrder requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("create_productorder_request.json"), ProductOrder.class);
		return requestOject;
	}
	
	public static ProductOrder createProductOrderResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ProductOrder requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("create_productorder_response.json"), ProductOrder.class);
		return requestOject;
	}
	
	public static AppDirectFinalizeResponse finalizeOpportunityResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectFinalizeResponse requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("finalizeOpportunityResponse.json"), AppDirectFinalizeResponse.class);
		return requestOject;
	}
	
	public static Metadata getMetadata() {
		Metadata metadata = new Metadata();
		metadata.setBackendURL("http://localhost:8080/restservice");
		
		List<ApipathRef> apiPaths = new ArrayList<>();
		ApipathRef pathOne = new ApipathRef();
		pathOne.setId("FINALIZEOPPORTUNITY");
		pathOne.setValue("/api/assistedSales/v1/opportunities/{opportunityId}/finalize");
		apiPaths.add(pathOne);
		
		List<AccessCredentialRef> accessCredentials = new ArrayList<>();
		AccessCredentialRef credentialRef = new AccessCredentialRef();
		credentialRef.setId("TOKEN");
		credentialRef.setValue("1wYgQkKWNugfyzoHIpzaqk0WbMk7");
		accessCredentials.add(credentialRef);
		
		
		metadata.setApiPaths(apiPaths);
		metadata.setAccessCredentials(accessCredentials);
		
		return metadata;
	}

}
