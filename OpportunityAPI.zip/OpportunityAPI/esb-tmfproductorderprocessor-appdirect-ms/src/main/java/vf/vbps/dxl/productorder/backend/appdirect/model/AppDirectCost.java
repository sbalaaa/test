
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "amount", "blockContractDecrease", "blockContractIncrease", "blockOriginalContractDecrease",
		"increment", "maxUnits", "meteredUsage", "minUnits", "pricePerIncrement", "unit", "unitDependency" })
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectCost {

	@JsonProperty("amount")
	private AppDirectAmount amount;
	@JsonProperty("blockContractDecrease")
	private Boolean blockContractDecrease;
	@JsonProperty("blockContractIncrease")
	private Boolean blockContractIncrease;
	@JsonProperty("blockOriginalContractDecrease")
	private Boolean blockOriginalContractDecrease;
	@JsonProperty("increment")
	private Integer increment;
	@JsonProperty("maxUnits")
	private Object maxUnits;
	@JsonProperty("meteredUsage")
	private Boolean meteredUsage;
	@JsonProperty("minUnits")
	private Integer minUnits;
	@JsonProperty("pricePerIncrement")
	private Boolean pricePerIncrement;
	@JsonProperty("unit")
	private String unit;
	@JsonProperty("unitDependency")
	private Object unitDependency;

}
