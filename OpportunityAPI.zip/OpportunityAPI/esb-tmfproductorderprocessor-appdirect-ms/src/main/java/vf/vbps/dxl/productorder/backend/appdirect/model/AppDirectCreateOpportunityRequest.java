
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "currency", "customerCompanyId", "customerId", "items", "ownerCompanyId", "ownerId" })
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectCreateOpportunityRequest {

	@JsonProperty("currency")
	private String currency;
	@JsonProperty("customerCompanyId")
	private String customerCompanyId;
	@JsonProperty("customerId")
	private String customerId;
	@JsonProperty("items")
	private List<AppDirectItem> items;
	@JsonProperty("ownerCompanyId")
	private String ownerCompanyId;
	@JsonProperty("ownerId")
	private String ownerId;
	@JsonProperty("name")
	private String name;
	@JsonProperty("purchaseEffectiveDate")
	private Long purchaseEffectiveDate;
	

}
