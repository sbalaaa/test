
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "attributeType", "hint", "label", "name", "value", "valueKeys" })
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectCustomAttribute {

	@JsonProperty("attributeType")
	private String attributeType;
	@JsonProperty("hint")
	private String hint;
	@JsonProperty("label")
	private String label;
	@JsonProperty("name")
	private String name;
	@JsonProperty("value")
	private String value;
	@JsonProperty("valueKeys")
	private List<Object> valueKeys = new ArrayList<>();

}
