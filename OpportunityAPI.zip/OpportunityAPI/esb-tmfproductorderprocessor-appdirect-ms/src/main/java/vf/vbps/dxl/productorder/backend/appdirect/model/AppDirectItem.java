
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ContractConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "pricingPlanId", "subscriptionCustomAttributes", "units", "vendorRequiredFields",
		"billingConfiguration", "provisioningConfiguration" })
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectItem {

	@JsonProperty("id")
	private String id;
	@JsonProperty("pricingPlanId")
	private String pricingPlanId;
	@JsonProperty("subscriptionCustomAttributes")
	private Map<String, List<String>> subscriptionCustomAttributes;
	@JsonProperty("units")
	private List<AppDirectUnit> units;
	@JsonProperty("vendorRequiredFields")
	private Map<String, List<String>> vendorRequiredFields;
	@JsonProperty("billingConfiguration")
	private BillingConfiguration billingConfiguration;
	@JsonProperty("provisioningConfiguration")
	private ProvisioningConfiguration provisioningConfiguration;
	@JsonProperty("contractConfiguration")
	private ContractConfiguration contractConfiguration;

}
