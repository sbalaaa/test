
package vf.vbps.dxl.productorder.backend.appdirect.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@lombok.Generated
@Data
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectPaymentInstrument {

	@JsonProperty("id")
	private String id;

	@JsonProperty("accountDisplay")
	private String accountDisplay;

	@JsonProperty("paymentMethod")
	private String paymentMethod;

	@JsonProperty("default")
	private Boolean isDefault;

	@JsonProperty("user")
	private AppDirectCustomerUser user;

	@JsonProperty("company")
	private AppDirectCompany company;

	@JsonProperty("createdOn")
	private Long createdOn;

}
