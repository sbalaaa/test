
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "allowCustomUsage", "contract", "costs", "discount", "frequency", "href", "id", "isPrimaryPrice",
		"keepBillDateOnUsageChange", "links", "primaryPrice", "separatePrepaid", "uuid" })
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectPaymentPlanResponse {

	@JsonProperty("allowCustomUsage")
	private Boolean allowCustomUsage;
	@JsonProperty("contract")
	private AppDirectContract contract;
	@JsonProperty("costs")
	private List<AppDirectCost> costs = new ArrayList<>();
	@JsonProperty("discount")
	private Object discount;
	@JsonProperty("frequency")
	private String frequency;
	@JsonProperty("href")
	private String href;
	@JsonProperty("id")
	private Integer id;
	@JsonProperty("isPrimaryPrice")
	private Boolean isPrimaryPrice;
	@JsonProperty("keepBillDateOnUsageChange")
	private Boolean keepBillDateOnUsageChange;
	@JsonProperty("links")
	private List<AppDirectLink> links = new ArrayList<>();
	@JsonProperty("primaryPrice")
	private Boolean primaryPrice;
	@JsonProperty("separatePrepaid")
	private Boolean separatePrepaid;
	@JsonProperty("uuid")
	private String uuid;

}
