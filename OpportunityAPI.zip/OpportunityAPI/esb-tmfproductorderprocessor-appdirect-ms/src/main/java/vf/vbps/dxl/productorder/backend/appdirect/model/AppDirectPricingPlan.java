
package vf.vbps.dxl.productorder.backend.appdirect.model;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectPricingPlan {

	@JsonProperty("editionCode")
	private String editionCode;
	@JsonProperty("id")
	private String id;
	@JsonProperty("name")
	private String name;

}
