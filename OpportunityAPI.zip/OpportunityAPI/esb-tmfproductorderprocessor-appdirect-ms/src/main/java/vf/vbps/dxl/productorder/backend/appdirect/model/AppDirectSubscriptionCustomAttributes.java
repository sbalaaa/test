
package vf.vbps.dxl.productorder.backend.appdirect.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;


import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppDirectSubscriptionCustomAttributes {

	@JsonProperty("Partner_Name")
	private List<String> partnerName = new ArrayList<>();
	@JsonProperty("Product_Description")
	private List<String> productDescription = new ArrayList<>();
	@JsonProperty("External_Order_ID")
	private List<String> externalOrderID = new ArrayList<>();
	@JsonProperty("Sales_Opportunity_ID")
	private List<String> salesOpportunityID = new ArrayList<>();

}
