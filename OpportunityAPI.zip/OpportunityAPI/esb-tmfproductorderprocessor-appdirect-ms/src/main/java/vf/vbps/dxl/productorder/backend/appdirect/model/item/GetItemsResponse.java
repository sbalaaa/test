
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPricing;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPricingPlan;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;

@Validated
@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetItemsResponse {

	@JsonProperty("billingConfiguration")
	private BillingConfiguration billingConfiguration;
	@JsonProperty("contractConfiguration")
	private ContractConfiguration contractConfiguration;
	@JsonProperty("id")
	private String id;
	@JsonProperty("pricing")
	private List<AppDirectPricing> pricing = new ArrayList<>();
	@JsonProperty("pricingPlan")
	private AppDirectPricingPlan pricingPlan;
	@JsonProperty("product")
	private Product product;
	@JsonProperty("provisioningConfiguration")
	private ProvisioningConfiguration provisioningConfiguration;
	@JsonProperty("subscriptionCustomAttributes")
	private  Map<String,List<String>> subscriptionCustomAttributes;
	@JsonProperty("units")
	private List<AppDirectUnit> units = new ArrayList<>();
	@JsonProperty("vendorRequiredFields")
	private  Map<String,List<String>> vendorRequiredFields;

}
