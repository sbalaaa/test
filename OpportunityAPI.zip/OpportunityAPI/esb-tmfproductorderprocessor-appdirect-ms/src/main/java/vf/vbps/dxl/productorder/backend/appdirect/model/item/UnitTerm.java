
package vf.vbps.dxl.productorder.backend.appdirect.model.item;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@lombok.Generated
@Data
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UnitTerm {

	private Boolean blockContractDecrease;
	private Boolean blockContractIncrease;
	private Boolean blockOriginalContractDecrease;

}
