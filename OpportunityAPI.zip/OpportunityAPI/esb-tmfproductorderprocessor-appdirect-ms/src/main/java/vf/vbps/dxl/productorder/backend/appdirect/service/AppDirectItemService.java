package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentPlanResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPricing;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.AddItemRequest;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.AddItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ContractConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.CustomPrice;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.EditItemRequest;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.EditItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.GetItemsResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.Money;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.OrderPrice;
import vf.vbps.dxl.productorder.model.Price;
import vf.vbps.dxl.productorder.model.PriceStrategyType;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderItem;

@Slf4j
@Component
public class AppDirectItemService {

	@Autowired
	private AppDirectOpportunityService opportunityService;

	@Autowired
	private WebClient webClient;

	@Autowired
	private ObjectMapper objectMapper;

	public List<AddItemResponse> invokeAddItem(Metadata metadata, ProductOrder productOrder, String opportunityId,
			List<Note> errorNotes) {

		log.info("invokeAddItem started");

		List<AddItemRequest> addItemRequests = new ArrayList<>();

		List<ProductOrderItem> items = productOrder.getProductOrderItem();

		for (ProductOrderItem item : items) {

			if (canItemAdded(item)) {

				String pricingPlanId = null;

				if ("id".equals(item.getProduct().getName())) {
					AppDirectPaymentPlanResponse paymentPlanResponse = opportunityService.invokePaymentPlan(metadata,
							item.getProduct().getId(), errorNotes);
					if (CollectionUtils.isEmpty(errorNotes)) {
						if (paymentPlanResponse != null) {
							pricingPlanId = paymentPlanResponse.getUuid();
							item.setType(paymentPlanResponse.getUuid());
						}
					} else {
						return null;
					}
				} else {
					pricingPlanId = item.getProduct().getId();
					item.setType(item.getProduct().getId());
				}

				AddItemRequest request = new AddItemRequest();
				request.setPricingPlanId(pricingPlanId);
				List<Characteristic> characterstics = item.getProduct().getProductCharacteristic();

				if (characterstics != null) {

					BillingConfiguration billingConfiguration = AppDirectServiceUtil
							.getBillingConfiguration(characterstics);
					if (billingConfiguration != null) {
						request.setBillingConfiguration(billingConfiguration);
					}

					ProvisioningConfiguration provisioningConfiguration = AppDirectServiceUtil
							.getProvisioningConfiguration(characterstics);
					if (provisioningConfiguration != null) {
						request.setProvisioningConfiguration(provisioningConfiguration);
					}
					Map<String, List<String>> subscriptions = AppDirectServiceUtil
							.getSubscriptionCustomAttributes(characterstics);
					if (!CollectionUtils.isEmpty(subscriptions)) {
						request.setSubscriptionCustomAttributes(subscriptions);
					}
					Map<String, List<String>> vendorRequiredFields = AppDirectServiceUtil
							.getVendorRequiredFields(characterstics);
					if (!CollectionUtils.isEmpty(vendorRequiredFields)) {
						request.setVendorRequiredFields(vendorRequiredFields);
					}
					List<AppDirectUnit> units = AppDirectServiceUtil.getUnits(characterstics);
					if (!CollectionUtils.isEmpty(units)) {
						request.setUnits(units);
					}

				}
				if (!CollectionUtils.isEmpty(item.getProductOrderItemRelationship())
						&& item.getProductOrderItemRelationship().get(0) != null
						&& item.getProductOrderItemRelationship().get(0).getId() != null) {
					for (ProductOrderItem tempItem : items) {
						if (tempItem.getType() != null && item.getProductOrderItemRelationship() != null
								&& item.getProductOrderItemRelationship().get(0) != null
								&& tempItem.getType().equals(item.getProductOrderItemRelationship().get(0).getId())) {
							request.setParentItemId(tempItem.getId());
							item.getProductOrderItemRelationship().get(0).setId(tempItem.getId());
							break;
						}
					}
				}
				addItemRequests.add(request);

			}

		}
		List<AddItemResponse> apiResponse = null;
		if (!CollectionUtils.isEmpty(addItemRequests)) {
			String addItemsEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata, ProductOrderConstants.ADDITEMS);

			String uri = UriComponentsBuilder.fromUriString(addItemsEndpointUrl).buildAndExpand(opportunityId)
					.toUriString();
			log.info("Add Item URL is {}", uri);

			String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);

			try {
				log.debug("Add Items Request is :\n {} \n",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(addItemRequests));
			} catch (Exception e) {
				log.error(e.toString());
			}

			try {

				apiResponse = webClient.post().uri(uri).bodyValue(addItemRequests).headers(httpHeaders -> {
					httpHeaders.setBearerAuth(token);
					httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					httpHeaders.setContentType(MediaType.APPLICATION_JSON);
					httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
				}).retrieve().bodyToMono(new ParameterizedTypeReference<List<AddItemResponse>>() {
				}).block();
			} catch (WebClientResponseException e) {
				AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_ADDITEM_OPPORTUNITY, errorNotes, e);
				log.error("Error from AddItem Request - Status {}, Body {}, Exception {} \n \n", e.getRawStatusCode(),
						e.getResponseBodyAsString(), e.toString());
				log.error(e.toString());
			} catch (Exception e) {
				AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_ADDITEM_OPPORTUNITY, errorNotes, e);
				log.error(e.toString());
			}

			try {
				log.info("AppDirectAddItemsResponse :\n {} \n",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
			} catch (Exception e) {
				log.error("Exception as print AppDirectAddItemsResponse is {} \n \n ", e.toString());
			}
		} else {
			log.info("No items for add");
		}
		log.info("invokeAddItem ended");

		return apiResponse;

	}

	private boolean canItemAdded(ProductOrderItem item) {
		if (item.getProduct() != null && item.getProduct().getDescription() != null
				&& item.getProduct().getDescription().equals(ProductOrderConstants.IS_ADD_ITEM)) {
			return true;
		}
		return false;

	}

	public List<GetItemsResponse> invokeGetItems(String opportunityId, Metadata metadata, List<Note> errorNotes) {
		log.info("invokeGetItems started");

		long start = System.currentTimeMillis();

		String uri = UriComponentsBuilder
				.fromUriString(AppDirectServiceUtil.getEndpoint(metadata, ProductOrderConstants.GETITEMS))
				.buildAndExpand(opportunityId).toUriString();

		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info("Get items URI: {}", uri);
		List<GetItemsResponse> apiResponse = null;
		try {
			apiResponse = webClient.get().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
			}).retrieve().bodyToMono(new ParameterizedTypeReference<List<GetItemsResponse>>() {
			}).block();
		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_GETITEMS_OPPORTUNITY, errorNotes, e);
			log.error("Error from Get Items Request - Status {}, Body {}, Exception {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e.toString());
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_GETITEMS_OPPORTUNITY, errorNotes, e);
			log.error(e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		try {
			log.info("AppDirectGetItemsResponse :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
		} catch (Exception e) {
			log.error("Exception as print GetItemsResponse is {} \n \n ", e.toString());
		}

		log.info("invokeGetItems ended");

		return apiResponse;
	}

	public void invokeEditItem(String opportunityId, Metadata metadata, ProductOrder productOrder,
			List<Note> errorNotes) {

		log.info("invokeEditItem started");

		boolean isEditRequired = false;

		List<ProductOrderItem> items = productOrder.getProductOrderItem();

		for (ProductOrderItem item : items) {

			List<Characteristic> characterstics = item.getProduct().getProductCharacteristic();
			long count = characterstics.stream()
					.filter(c -> ProductOrderConstants.CONTRACTCONFIGURATION.equals(c.getName())).count();

			if (count > 0 || (item.getItemPrice() != null && !item.getItemPrice().isEmpty())) {
				isEditRequired = true;
				break;
			}

		}

		if (isEditRequired) {

			log.info("edit data is available");

			List<GetItemsResponse> getItemsResponse = invokeGetItems(opportunityId, metadata, errorNotes);
			if (CollectionUtils.isEmpty(errorNotes)) {
				for (ProductOrderItem item : items) {

					List<Characteristic> characterstics = item.getProduct().getProductCharacteristic();
					long count = characterstics.stream()
							.filter(c -> ProductOrderConstants.CONTRACTCONFIGURATION.equals(c.getName())).count();

					if (count > 0 || !CollectionUtils.isEmpty(item.getItemPrice())) {
						EditItemRequest request = new EditItemRequest();

						ContractConfiguration itemContractConfiguration = null;
						for (GetItemsResponse getItemResponse : getItemsResponse) {

							if (getItemResponse.getId().equals(item.getId())) {
								if (getItemResponse.getBillingConfiguration() != null) {
									request.setBillingConfiguration(getItemResponse.getBillingConfiguration());
								}
								if (getItemResponse.getProvisioningConfiguration() != null) {
									request.setProvisioningConfiguration(
											getItemResponse.getProvisioningConfiguration());
								}
								if (getItemResponse.getVendorRequiredFields() != null
										&& !CollectionUtils.isEmpty(getItemResponse.getVendorRequiredFields())) {
									request.setVendorRequiredFields(getItemResponse.getVendorRequiredFields());
								}
								if (getItemResponse.getSubscriptionCustomAttributes() != null && !CollectionUtils
										.isEmpty(getItemResponse.getSubscriptionCustomAttributes())) {
									request.setSubscriptionCustomAttributes(
											getItemResponse.getSubscriptionCustomAttributes());
								}
								if (getItemResponse.getUnits() != null
										&& !CollectionUtils.isEmpty(getItemResponse.getUnits())) {
									request.setUnits(getItemResponse.getUnits());
								}
								request.setId(getItemResponse.getId());
								if (getItemResponse.getPricingPlan() != null) {
									request.setPricingPlanId(getItemResponse.getPricingPlan().getId());
								}
								itemContractConfiguration = getItemResponse.getContractConfiguration();
							}

						}

						if (characterstics != null) {

							ContractConfiguration contractConfiguration = AppDirectServiceUtil
									.getContractConfiguration(characterstics);
							if (contractConfiguration != null) {

								if (itemContractConfiguration == null) {
									request.setContractConfiguration(contractConfiguration);
								} else {
									if (contractConfiguration.getBlockContractDowngrades() == null) {
										if (itemContractConfiguration.getBlockContractDowngrades() != null) {
											contractConfiguration.setBlockContractDowngrades(
													itemContractConfiguration.getBlockContractDowngrades());
										}
									}
									if (contractConfiguration.getBlockContractUpgrades() == null) {
										if (itemContractConfiguration.getBlockContractUpgrades() != null) {
											contractConfiguration.setBlockContractUpgrades(
													itemContractConfiguration.getBlockContractUpgrades());
										}
									}
									if (contractConfiguration.getBlockSwitchToShorterContract() == null) {
										if (itemContractConfiguration.getBlockSwitchToShorterContract() != null) {
											contractConfiguration.setBlockSwitchToShorterContract(
													itemContractConfiguration.getBlockSwitchToShorterContract());
										}
									}
									if (contractConfiguration.getContractCancellationPeriodLimit() == null) {
										if (itemContractConfiguration.getContractCancellationPeriodLimit() != null) {
											contractConfiguration.setContractCancellationPeriodLimit(
													itemContractConfiguration.getContractCancellationPeriodLimit());
										}
									}

									if (StringUtils
											.isEmpty(contractConfiguration.getContractCancellationPeriodUnit())) {
										if (itemContractConfiguration.getContractCancellationPeriodUnit() != null) {
											contractConfiguration.setContractCancellationPeriodUnit(
													itemContractConfiguration.getContractCancellationPeriodUnit());
										}
									}
									if (contractConfiguration.getEndOfContractGracePeriod() == null) {
										if (itemContractConfiguration.getEndOfContractGracePeriod() != null) {
											contractConfiguration.setEndOfContractGracePeriod(
													itemContractConfiguration.getEndOfContractGracePeriod());
										}
									}

									if (StringUtils.isEmpty(contractConfiguration.getEndOfContractGracePeriodUnit())) {
										if (itemContractConfiguration.getEndOfContractGracePeriodUnit() != null) {
											contractConfiguration.setEndOfContractGracePeriodUnit(
													itemContractConfiguration.getEndOfContractGracePeriodUnit());
										}
									}

									if (contractConfiguration.getKeepContractDateOnPlanChange() == null) {
										if (itemContractConfiguration.getBlockContractDowngrades() != null) {
											contractConfiguration.setKeepContractDateOnPlanChange(
													itemContractConfiguration.getKeepContractDateOnPlanChange());
										}
									}

									if (contractConfiguration.getMinimumServiceLength() == null) {
										if (itemContractConfiguration.getMinimumServiceLength() != null) {
											contractConfiguration.setMinimumServiceLength(
													itemContractConfiguration.getMinimumServiceLength());
										}
									}

									if (StringUtils.isEmpty(contractConfiguration.getMinimumServiceLengthUnit())) {
										if (itemContractConfiguration.getMinimumServiceLengthUnit() != null) {
											contractConfiguration.setMinimumServiceLengthUnit(
													itemContractConfiguration.getMinimumServiceLengthUnit());
										}
									}

									if (StringUtils.isEmpty(contractConfiguration.getRenewalConfiguration())) {
										if (itemContractConfiguration.getRenewalConfiguration() != null) {
											contractConfiguration.setRenewalConfiguration(
													itemContractConfiguration.getRenewalConfiguration());
										}
									}
									if (contractConfiguration.getTerminationFeeGracePeriod() == null) {
										if (itemContractConfiguration.getTerminationFeeGracePeriod() != null) {
											contractConfiguration.setTerminationFeeGracePeriod(
													itemContractConfiguration.getTerminationFeeGracePeriod());
										}
									}

									if (StringUtils.isEmpty(contractConfiguration.getTerminationFeeGracePeriodUnit())) {
										if (itemContractConfiguration.getTerminationFeeGracePeriodUnit() != null) {
											contractConfiguration.setTerminationFeeGracePeriodUnit(
													itemContractConfiguration.getTerminationFeeGracePeriodUnit());
										}
									}

									if (contractConfiguration.getIsDefault() == null) {
										if (itemContractConfiguration.getIsDefault() != null) {
											contractConfiguration
													.setIsDefault(itemContractConfiguration.getIsDefault());
										}
									}

									if (contractConfiguration.getTerminationFee() == null) {
										if (itemContractConfiguration.getTerminationFee() != null) {
											contractConfiguration
													.setTerminationFee(itemContractConfiguration.getTerminationFee());
										}
									} else {
										if (contractConfiguration.getTerminationFee().getAmount() == null) {
											if (itemContractConfiguration.getTerminationFee().getAmount() != null) {
												contractConfiguration.getTerminationFee().setAmount(
														itemContractConfiguration.getTerminationFee().getAmount());
											}
										}

										if (contractConfiguration.getTerminationFee().getFeeType() == null) {
											if (itemContractConfiguration.getTerminationFee().getFeeType() != null) {
												contractConfiguration.getTerminationFee().setFeeType(
														itemContractConfiguration.getTerminationFee().getFeeType());
											}
										}
										if (contractConfiguration.getTerminationFee().getDescription() == null) {
											if (itemContractConfiguration.getTerminationFee()
													.getDescription() != null) {
												contractConfiguration.getTerminationFee().setDescription(
														itemContractConfiguration.getTerminationFee().getDescription());
											}
										}
									}

									if (contractConfiguration.getUnitTerms() == null
											&& !CollectionUtils.isEmpty(itemContractConfiguration.getUnitTerms())) {
										if (itemContractConfiguration.getUnitTerms() != null) {
											contractConfiguration
													.setUnitTerms(itemContractConfiguration.getUnitTerms());
										}
									}

									request.setContractConfiguration(contractConfiguration);
								}
							} else if (itemContractConfiguration != null) {
								request.setContractConfiguration(itemContractConfiguration);
							}

						}

						if (!CollectionUtils.isEmpty(item.getItemPrice())) {
							List<CustomPrice> customPrices = new ArrayList<>();
							for (OrderPrice price : item.getItemPrice()) {
								CustomPrice customPrice = new CustomPrice();
								customPrice.setCostId(price.getId());
								customPrice.setPrice(price.getPrices().get(0).getDutyFreeAmount().getValue());
								customPrices.add(customPrice);

							}
							request.setCustomPrices(customPrices);
						}

						try {
							log.debug("Edit Item Request is :\n {} \n",
									objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));
						} catch (Exception e) {
							log.error(e.toString());
						}

						String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);

						String editItemEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata,
								ProductOrderConstants.EDITITEM);

						String uri = UriComponentsBuilder.fromUriString(editItemEndpointUrl)
								.buildAndExpand(opportunityId, item.getId()).toUriString();

						log.info("Edit Item URL is :{}", uri);

						EditItemResponse apiResponse = null;

						try {
							apiResponse = webClient.put().uri(uri).bodyValue(request).headers(httpHeaders -> {
								httpHeaders.setBearerAuth(token);
								httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
								httpHeaders.setContentType(MediaType.APPLICATION_JSON);
								httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
							}).retrieve().bodyToMono(EditItemResponse.class).block();

						} catch (WebClientResponseException e) {
							AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_EDITITEM_OPPORTUNITY,
									errorNotes, e);
							log.error("Error from Edit Items Request - Status {}, Body {}, Exception {} \n \n",
									e.getRawStatusCode(), e.getResponseBodyAsString(), e.toString());
							log.error(e.toString());
						} catch (Exception e) {
							AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_EDITITEM_OPPORTUNITY,
									errorNotes, e);
							log.error(e.toString());
						}

						try {
							log.info("EditItemResponse :\n {} \n",
									objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
						} catch (Exception e) {
							log.error("Exception as print EditItemResponse is {} \n \n ", e.toString());
						}

						if (CollectionUtils.isEmpty(errorNotes) && apiResponse != null
								&& !CollectionUtils.isEmpty(apiResponse.getPricing())) {
							List<OrderPrice> orderPrices = new ArrayList<>();
							for (AppDirectPricing apiDirectPricing : apiResponse.getPricing()) {
								OrderPrice orderPrice = new OrderPrice();
								orderPrice.setId(apiDirectPricing.getCostId());
								orderPrice.setDescription(apiDirectPricing.getDescription());
								orderPrice.setUnitOfMeasure(apiDirectPricing.getUnit());
								List<Price> prices = new ArrayList<>();
								Price price = null;
								Money money = null;
								if (!StringUtils.isEmpty(apiDirectPricing.getSalePrice())) {
									price = new Price();
									price.setDescription(ProductOrderConstants.SALE);
									money = new Money();
									money.setValue(Float.valueOf(apiDirectPricing.getSalePrice()));
									price.setTaxIncludedAmount(money);
									prices.add(price);
								}

								if (!StringUtils.isEmpty(apiDirectPricing.getTotalSalePrice())) {
									price = new Price();
									price.setDescription(ProductOrderConstants.WHOLE_SALE);
									money = new Money();
									money.setValue(Float.valueOf(apiDirectPricing.getTotalSalePrice()));
									price.setTaxIncludedAmount(money);
									prices.add(price);
								}

								if (!StringUtils.isEmpty(apiDirectPricing.getWholesalePrice())) {
									price = new Price();
									price.setDescription(ProductOrderConstants.TOTAL_SALE);
									money = new Money();
									money.setValue(Float.valueOf(apiDirectPricing.getWholesalePrice()));
									price.setTaxIncludedAmount(money);
									prices.add(price);
								}

								orderPrice.setPrices(prices);

								if (apiDirectPricing.getCostTypeCategory() != null) {
									if (apiDirectPricing.getCostTypeCategory()
											.equals(ProductOrderConstants.RECURRING_AD)) {
										orderPrice.setPriceType(ProductOrderConstants.RECURRING_TMF);
									}
									if (apiDirectPricing.getCostTypeCategory()
											.equals(ProductOrderConstants.ONE_TIME_AD)) {
										orderPrice.setPriceType(ProductOrderConstants.ONE_TIME_TMF);
									}
								}
								if (apiDirectPricing.getCostType() != null) {
									if (apiDirectPricing.getCostType()
											.equals(ProductOrderConstants.RECURRING_FLAT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.RECURRING_FLAT_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.ONE_TIME_FLAT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.ONE_TIME_FLAT_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.INCLUDED_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.INCLUDED_TMF);
									}
									if (apiDirectPricing.getCostType()
											.equals(ProductOrderConstants.SETUP_PER_UNIT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.SETUP_PER_UNIT_TMF);
									}
									if (apiDirectPricing.getCostType()
											.equals(ProductOrderConstants.RECURRING_PER_UNIT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.RECURRING_PER_UNIT_TMF);
									}
									if (apiDirectPricing.getCostType()
											.equals(ProductOrderConstants.ONE_TIME_PER_UNIT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.ONE_TIME_PER_UNIT_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.SETUP_FEE_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.SETUP_FEE_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.CONTRACT_FEE_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.CONTRACT_FEE_TMF);
									}
									if (apiDirectPricing.getCostType()
											.equals(ProductOrderConstants.DISCOUNT_PER_UNIT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.DISCOUNT_PER_UNIT_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.DISCOUNT_FLAT_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.DISCOUNT_FLAT_TMF);
									}
									if (apiDirectPricing.getCostType().equals(ProductOrderConstants.METERED_USAGE_AD)) {
										orderPrice.setPriceSubType(ProductOrderConstants.METERED_USAGE_TMF);
									}

								}
								if (apiDirectPricing.getFrequency() != null) {
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.DAILY_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.DAILY_TMF);
									}
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.MONTHLY_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.MONTHLY_TMF);
									}
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.SIX_MONTHS_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.SIX_MONTHS_TMF);
									}
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.YEARLY_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.YEARLY_TMF);
									}
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.TWO_YEARS_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.TWO_YEARS_TMF);
									}
									if (apiDirectPricing.getFrequency().equals(ProductOrderConstants.THREE_YEARS_AD)) {
										orderPrice.setRecurringChargePeriod(ProductOrderConstants.THREE_YEARS_TMF);
									}
								}
								if (apiDirectPricing.getPricingStrategy() != null) {
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.FREE_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.FREE);
									}
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.FLAT_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.FLAT);
									}
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.UNIT_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.UNIT);
									}
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.VOLUME_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.VOLUME);
									}
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.TIERED_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.TIERED);
									}
									if (apiDirectPricing.getPricingStrategy()
											.equals(ProductOrderConstants.UNLIMITED_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.UNLIMITED);
									}
									if (apiDirectPricing.getPricingStrategy().equals(ProductOrderConstants.CUSTOM_AD)) {
										orderPrice.setPriceStrategy(PriceStrategyType.CUSTOM);
									}
								}
								orderPrice.setBaseType(ProductOrderConstants.ORDER_PRICE);
								orderPrice.setType(ProductOrderConstants.ORDER_PRICE_EXTENDED);
								orderPrices.add(orderPrice);
							}

							item.setItemPrice(orderPrices);

						}
						if (CollectionUtils.isEmpty(errorNotes) && apiResponse != null
								&& apiResponse.getContractConfiguration() != null) {

							boolean updated = false;
							if (item.getProduct().getProductCharacteristic() == null) {
								item.getProduct().setProductCharacteristic(new ArrayList<Characteristic>());
							}
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName().equals(ProductOrderConstants.CONTRACTCONFIGURATION)) {
									itemCharacteristic.setValue(apiResponse.getContractConfiguration());
									updated = true;
								}
							}
							if (!updated && apiResponse.getContractConfiguration() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.CONTRACTCONFIGURATION);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getContractConfiguration());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
							updated = false;
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName().equals(ProductOrderConstants.BILLINGCONFIGURATION)) {
									itemCharacteristic.setValue(apiResponse.getBillingConfiguration());
									updated = true;
								}
							}
							if (!updated && apiResponse.getBillingConfiguration() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.BILLINGCONFIGURATION);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getBillingConfiguration());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
							updated = false;
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName()
										.equals(ProductOrderConstants.PROVISIONINGCONFIGURATION)) {
									itemCharacteristic.setValue(apiResponse.getProvisioningConfiguration());
									updated = true;
								}
							}
							if (!updated && apiResponse.getProvisioningConfiguration() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.PROVISIONINGCONFIGURATION);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getProvisioningConfiguration());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
							updated = false;
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName().equals(ProductOrderConstants.UNITS)) {
									itemCharacteristic.setValue(apiResponse.getUnits());
									updated = true;
								}
							}
							if (!updated && apiResponse.getUnits() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.UNITS);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getUnits());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
							updated = false;
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName().equals(ProductOrderConstants.SUBSCRIPTION)) {
									itemCharacteristic.setValue(apiResponse.getSubscriptionCustomAttributes());
									updated = true;
								}
							}
							if (!updated && apiResponse.getSubscriptionCustomAttributes() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.SUBSCRIPTION);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getSubscriptionCustomAttributes());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
							updated = false;
							for (Characteristic itemCharacteristic : item.getProduct().getProductCharacteristic()) {
								if (itemCharacteristic.getName().equals(ProductOrderConstants.VENDORATTRIBUTES)) {
									itemCharacteristic.setValue(apiResponse.getVendorRequiredFields());
									updated = true;
								}
							}
							if (!updated && apiResponse.getVendorRequiredFields() != null) {
								Characteristic characteristic = new Characteristic();
								characteristic.setName(ProductOrderConstants.VENDORATTRIBUTES);
								characteristic.setValueType(ProductOrderConstants.TYPE_OBJECT);
								characteristic.setValue(apiResponse.getVendorRequiredFields());
								item.getProduct().getProductCharacteristic().add(characteristic);
							}
						}

					}

				}
			}

		}

		log.info("invokeEditItem ended");

	}

}
