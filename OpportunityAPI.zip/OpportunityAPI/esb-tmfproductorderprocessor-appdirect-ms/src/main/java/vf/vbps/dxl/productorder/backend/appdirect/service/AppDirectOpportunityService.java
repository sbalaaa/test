package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCompanyResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCreateOpportunityRequest;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCreateOpportunityResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectItem;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentPlanResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUserResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply.ApplyDiscountResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.OrderPrice;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderItem;

@Slf4j
@Component
public class AppDirectOpportunityService {

	@Autowired
	private WebClient webClient;

	@Autowired
	private ObjectMapper objectMapper;

	public AppDirectCompanyResponse getCompanyDetails(String companyExternalId, Metadata metadata,
			List<Note> errorNotes) throws JsonProcessingException {

		log.info("getCompanyDetails started");

		long start = System.currentTimeMillis();

		String uri = UriComponentsBuilder
				.fromUriString(AppDirectServiceUtil.getEndpoint(metadata, ProductOrderConstants.COMPANYDETAILS))
				.buildAndExpand(companyExternalId).toUriString();
		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info("Company URL is " + uri);

		AppDirectCompanyResponse apiResponse = null;
		try {

			apiResponse = webClient.get().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			}).retrieve().bodyToMono(AppDirectCompanyResponse.class).block();

			log.info("AppDirectCompanyResponse :\n {}",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_COMPANY, errorNotes, e);
			log.error("Error from Get Company Request - Status {}, Body {}, Exception {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_COMPANY, errorNotes, e);
			log.error("Exception as Get the Company Response {} ", e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		log.info("getCompanyDetails ended");

		return apiResponse;
	}

	public AppDirectUserResponse getUserDetails(String companyExternalId, String userExternalId, Metadata metadata,
			List<Note> errorNotes) throws JsonProcessingException {

		log.info("getUserDetails started");

		long start = System.currentTimeMillis();

		String uri = UriComponentsBuilder
				.fromUriString(AppDirectServiceUtil.getEndpoint(metadata, ProductOrderConstants.USERDETAILS))
				.buildAndExpand(companyExternalId, userExternalId).toUriString();
		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info("User URL is " + uri);

		AppDirectUserResponse apiResponse = null;
		try {

			apiResponse = webClient.get().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			}).retrieve().bodyToMono(AppDirectUserResponse.class).block();

			log.debug("AppDirectUserResponse :\n {}",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_USER, errorNotes, e);
			log.error("Error from Get User Request - Status {}, Body {}, Exception {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e.toString());
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_USER, errorNotes, e);
			log.error("Exception as get the user response {} ", e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		log.info("getUserDetails ended");

		return apiResponse;
	}

	public AppDirectCreateOpportunityResponse invokeCreateOpportunity(Metadata metadata, ProductOrder productOrder,
			String companyId, String userId, List<Note> errorNotes) {

		log.info("invokeCreateOpportunity started");

		log.info("companyId from API Response  is {} ", companyId);
		log.info("userId from API Response is {} ", userId);

		AppDirectCreateOpportunityRequest request = new AppDirectCreateOpportunityRequest();
		request.setCustomerCompanyId(companyId);
		request.setCustomerId(userId);
		if (!CollectionUtils.isEmpty(productOrder.getOrderTotalPrice())
				&& productOrder.getOrderTotalPrice().get(0) != null
				&& productOrder.getOrderTotalPrice().get(0).getPrice() != null
				&& productOrder.getOrderTotalPrice().get(0).getPrice().getDutyFreeAmount() != null
				&& productOrder.getOrderTotalPrice().get(0).getPrice().getDutyFreeAmount().getUnit() != null) {
			request.setCurrency(productOrder.getOrderTotalPrice().get(0).getPrice().getDutyFreeAmount().getUnit());
		}
		String ownerCompanyId = AppDirectServiceUtil.getOwnerCompanyId(productOrder);
		request.setOwnerCompanyId(ownerCompanyId);

		String ownerId = AppDirectServiceUtil.getOwnerId(productOrder);
		request.setOwnerId(ownerId);
		if (!StringUtils.isEmpty(productOrder.getDescription())) {
			request.setName(productOrder.getDescription());
		}
		if (!StringUtils.isEmpty(productOrder.getRequestedStartDate())) {
			request.setPurchaseEffectiveDate(
					AppDirectServiceUtil.getEPOCHMilliseconds(productOrder.getRequestedStartDate()));
		}
		List<AppDirectItem> appdiretItems = new ArrayList<>();
		List<ProductOrderItem> items = productOrder.getProductOrderItem();

		for (ProductOrderItem item : items) {

			if (isProduct(item)) {

				AppDirectItem appdiretItem = new AppDirectItem();

				if (ProductOrderConstants.PRODUCT_ID.equals(item.getProduct().getName())) {

					AppDirectPaymentPlanResponse paymentPlanResponse = invokePaymentPlan(metadata,
							item.getProduct().getId(), errorNotes);

					if (CollectionUtils.isEmpty(errorNotes)) {
						if (paymentPlanResponse != null) {
							appdiretItem.setPricingPlanId(paymentPlanResponse.getUuid());
							log.info("paymentPlanResponse uuid is {} ", paymentPlanResponse.getUuid());
						}

						appdiretItem.setPricingPlanId(paymentPlanResponse.getUuid());
						item.setType(paymentPlanResponse.getUuid());
					} else {
						return null;
					}

				} else {
					appdiretItem.setPricingPlanId(item.getProduct().getId());
					item.setType(item.getProduct().getId());
				}

				List<Characteristic> characterstics = item.getProduct().getProductCharacteristic();

				if (characterstics != null) {

					BillingConfiguration billingConfiguration = AppDirectServiceUtil
							.getBillingConfiguration(characterstics);
					if (billingConfiguration != null) {
						appdiretItem.setBillingConfiguration(billingConfiguration);
					}

					ProvisioningConfiguration provisioningConfiguration = AppDirectServiceUtil
							.getProvisioningConfiguration(characterstics);
					if (provisioningConfiguration != null) {
						appdiretItem.setProvisioningConfiguration(provisioningConfiguration);
					}
					Map<String, List<String>> subscriptions = AppDirectServiceUtil
							.getSubscriptionCustomAttributes(characterstics);
					if (!CollectionUtils.isEmpty(subscriptions)) {
						appdiretItem.setSubscriptionCustomAttributes(subscriptions);
					}
					Map<String, List<String>> vendorRequiredFields = AppDirectServiceUtil
							.getVendorRequiredFields(characterstics);
					if (!CollectionUtils.isEmpty(vendorRequiredFields)) {
						appdiretItem.setVendorRequiredFields(vendorRequiredFields);
					}
					List<AppDirectUnit> units = AppDirectServiceUtil.getUnits(characterstics);
					if (!CollectionUtils.isEmpty(units)) {
						appdiretItem.setUnits(units);
					}

					appdiretItems.add(appdiretItem);
				}
			}
		}

		request.setItems(appdiretItems);

		long start = System.currentTimeMillis();

		String createOpportunityEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata,
				ProductOrderConstants.CREATEOPPORTUNITY);
		String uri = UriComponentsBuilder.fromUriString(createOpportunityEndpointUrl).toUriString();
		log.info("CREATEOPPORTUNITY Url is {} ", uri);

		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);

		try {

			log.debug("CREATEOPPORTUNITY Request is :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request));
		} catch (Exception e) {
			log.error(e.toString());
		}

		AppDirectCreateOpportunityResponse apiResponse = null;

		try {

			apiResponse = webClient.post().uri(uri).bodyValue(request).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
			}).retrieve().bodyToMono(AppDirectCreateOpportunityResponse.class).block();

			log.debug("AppDirectCreateOpportunityResponse :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));

		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_CREATE_OPPORTUNITY, errorNotes, e);

			log.error("Error from invokeCreateOpportunity Request - Status {}, Body {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e);
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_CREATE_OPPORTUNITY, errorNotes, e);
			log.error(e.toString());
		}
		long timeTaken = System.currentTimeMillis() - start;

		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		log.info("invokeCreateOpportunity ended");

		return apiResponse;

	}

	private boolean isProduct(ProductOrderItem item) {
		if (item.getProduct() != null && item.getProduct().getDescription() != null
				&& item.getProduct().getDescription().equals(ProductOrderConstants.IS_PRODUCT)) {
			return true;
		}
		return false;
	}

	public AppDirectFinalizeResponse invokeFinalizeOpportunity(String opportunityId, Metadata metadata,
			List<Note> errorNotes) {

		log.info("invokeFinalizeOpportunity started");

		long start = System.currentTimeMillis();

		String fializeEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata,
				ProductOrderConstants.FINALIZEOPPORTUNITY);
		String uri = UriComponentsBuilder.fromUriString(fializeEndpointUrl).buildAndExpand(opportunityId).toUriString();
		log.info("fializeEndpointUrl is {} ", uri);

		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);

		AppDirectFinalizeResponse apiResponse = null;

		try {

			apiResponse = webClient.post().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
			}).retrieve().bodyToMono(AppDirectFinalizeResponse.class).block();

			log.debug("AppDirectFinalizeOpportunityResponse :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));

		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_FINALIZE_OPPORTUNITY, errorNotes, e);
			log.error("Error from invokeFinalizeOpportunity Request - Status {}, Body {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e);
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_FINALIZE_OPPORTUNITY, errorNotes, e);
			log.error(e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		log.info("invokeFinalizeOpportunity ended");

		return apiResponse;
	}

	public AppDirectPaymentPlanResponse invokePaymentPlan(Metadata metadata, String paymentPlanId,
			List<Note> errorNotes) {

		log.info("invokePaymentPlan started");

		long start = System.currentTimeMillis();

		String paymentPlanEndpointUrl = AppDirectServiceUtil.getEndpoint(metadata,
				ProductOrderConstants.PAYMENTDETAILS);
		String uri = UriComponentsBuilder.fromUriString(paymentPlanEndpointUrl).buildAndExpand(paymentPlanId)
				.toUriString();
		log.info("PAYMENTPLAN EndpointUrl is {} ", uri);

		String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);

		AppDirectPaymentPlanResponse apiResponse = null;
		try {
			apiResponse = webClient.get().uri(uri).headers(httpHeaders -> {
				httpHeaders.setBearerAuth(token);
				httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
				httpHeaders.setContentType(MediaType.APPLICATION_JSON);
				httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
			}).retrieve().bodyToMono(AppDirectPaymentPlanResponse.class).block();
			log.debug("AppDirectPaymentPlanResponse :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));

		} catch (WebClientResponseException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_PRICINGPLAN, errorNotes, e);
			log.error("Error from PaymentPlanRequest - Status {}, Body {} \n \n", e.getRawStatusCode(),
					e.getResponseBodyAsString(), e);
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_LOOKUP_PRICINGPLAN, errorNotes, e);
			log.error(e.toString());
		}

		long timeTaken = System.currentTimeMillis() - start;
		log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);

		log.info("invokePaymentPlan ended");

		return apiResponse;
	}

	public void invokeApplyDiscount(String opportunityId, Metadata metadata, ProductOrder productOrder,
			List<Note> errorNotes) {

		log.info("invokeApplyDiscount started");

		String discountId = "";
		ApplyDiscountResponse apiResponse = null;

		if (productOrder.getOrderTotalPrice() != null && !productOrder.getOrderTotalPrice().isEmpty()) {
			for (OrderPrice orderPrice : productOrder.getOrderTotalPrice()) {
				if (orderPrice.getPriceType() != null
						&& orderPrice.getPriceType().equals(ProductOrderConstants.DISCOUNT)) {
					discountId = orderPrice.getName();

					String token = AppDirectServiceUtil.getOAuthAccessToken(metadata);
					String uri = UriComponentsBuilder
							.fromUriString(
									AppDirectServiceUtil.getEndpoint(metadata, ProductOrderConstants.APPLYDISCOUNT))
							.buildAndExpand(opportunityId, discountId).toUriString();
					try {

						apiResponse = webClient.put().uri(uri).headers(httpHeaders -> {
							httpHeaders.setBearerAuth(token);
							httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
							httpHeaders.setContentType(MediaType.APPLICATION_JSON);
							httpHeaders.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);
						}).retrieve().bodyToMono(ApplyDiscountResponse.class).block();

						log.debug("AppDirectApplyDiscountResponse :\n {} \n",
								objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));

					} catch (WebClientResponseException e) {
						AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_APPLYDISCOUNT_OPPORTUNITY,
								errorNotes, e);
						log.error("Error from ApplyDiscountRequest - Status {}, Body {} \n \n", e.getRawStatusCode(),
								e.getResponseBodyAsString(), e);
						log.error(e.toString());
					} catch (Exception e) {
						AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_APPLYDISCOUNT_OPPORTUNITY,
								errorNotes, e);
						log.error(e.toString());
					}

				}
			}
		}

		log.info("invokeApplyDiscount ended");

	}

}
