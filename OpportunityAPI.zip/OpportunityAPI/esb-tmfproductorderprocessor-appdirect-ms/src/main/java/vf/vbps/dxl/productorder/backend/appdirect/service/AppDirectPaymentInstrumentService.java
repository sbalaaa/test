package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentInstrument;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.Note;

@Slf4j
@Component
public class AppDirectPaymentInstrumentService {

	@Autowired
	private RestTemplate restTemplate;

	public List<AppDirectPaymentInstrument> getPaymentInstruments(String companyId, String userId, Metadata metadata,
			List<Note> errorNotes) {
		URI url = generatePaymentInstrumentsUrl(metadata, companyId, userId, null);
		log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_URL + url.toString());
		String accessToken = AppDirectServiceUtil.getOAuthAccessToken(metadata);

		HttpEntity<Object> entity = getHttpEntity(accessToken);
		ParameterizedTypeReference<List<AppDirectPaymentInstrument>> appDirectPaymentInstruments = new ParameterizedTypeReference<List<AppDirectPaymentInstrument>>() {
		};
		List<AppDirectPaymentInstrument> paymentInstrumentList = null;
		try {
			ResponseEntity<List<AppDirectPaymentInstrument>> response = restTemplate.exchange(url, HttpMethod.GET,
					entity, appDirectPaymentInstruments);

			if (null != response.getBody()) {
				paymentInstrumentList = response.getBody();
			}
		} catch (HttpClientErrorException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error(" Error from Get payment instruments Request - Status {}, Body {}, Exception {}",
					e.getRawStatusCode(), e.getResponseBodyAsString(), e.toString());
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error("Error from Get payment instruments Request - Exception {}", e.getMessage());
			log.error(e.toString());
		}
		return paymentInstrumentList;
	}

	private URI generatePaymentInstrumentsUrl(Metadata metadata, String companyId, String userId,
			String paymentInstrumentId) {
		Map<String, String> apiMap = metadata.getApiPaths().stream()
				.collect(Collectors.toMap(ApipathRef::getId, ApipathRef::getValue));

		Map<String, String> urlParams = new HashMap<>();
		String apiurl = null;
		if (StringUtils.isNotEmpty(paymentInstrumentId)) {
			apiurl = metadata.getBackendURL().concat(apiMap.get(ProductOrderConstants.PAYMENT_INSTRUMENTS_PUT));
			urlParams.put(ProductOrderConstants.COMPANY_ID, companyId);
			urlParams.put(ProductOrderConstants.USER_ID, userId);
			urlParams.put(ProductOrderConstants.PAYMENT_INSTRUMENTS_ID, paymentInstrumentId);
		} else {
			apiurl = metadata.getBackendURL().concat(apiMap.get(ProductOrderConstants.PAYMENT_INSTRUMENTS_GET));
			urlParams.put(ProductOrderConstants.COMPANY_ID, companyId);
			urlParams.put(ProductOrderConstants.USER_ID, userId);
		}

		final UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(apiurl);
		return builder.buildAndExpand(urlParams).toUri();
	}

	public AppDirectPaymentInstrument createPaymentInstrument(String companyId, String userId,
			AppDirectPaymentInstrument appDirectPaymentInstrument, Metadata metadata, List<Note> errorNotes) {
		URI url = generatePaymentInstrumentsUrl(metadata, companyId, userId, null);
		String accessToken = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_URL + url.toString());
		HttpEntity<AppDirectPaymentInstrument> entity = getHttpEntity(appDirectPaymentInstrument, accessToken);
		AppDirectPaymentInstrument paymentInstrumentResponse = null;
		try {
			ResponseEntity<AppDirectPaymentInstrument> response = restTemplate.exchange(url, HttpMethod.POST, entity,
					AppDirectPaymentInstrument.class);

			if (null != response.getBody()) {
				paymentInstrumentResponse = response.getBody();
			}
		} catch (HttpClientErrorException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error(" Error from Get payment instruments Request - Status {}, Body {}, Exception {}",
					e.getRawStatusCode(), e.getResponseBodyAsString(), e.toString());
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error("Error from Get payment instruments Request - Exception {}", e.getMessage());
			log.error(e.toString());
		}
		return paymentInstrumentResponse;
	}

	public AppDirectPaymentInstrument updatePaymentInstrument(String companyId, String userId,
			String paymentInstrumentId, AppDirectPaymentInstrument appDirectPaymentInstrument, Metadata metadata,
			List<Note> errorNotes) {
		URI url = generatePaymentInstrumentsUrl(metadata, companyId, userId, paymentInstrumentId);
		String accessToken = AppDirectServiceUtil.getOAuthAccessToken(metadata);
		log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_PUT_URL + url.toString());
		HttpEntity<AppDirectPaymentInstrument> entity = getHttpEntity(appDirectPaymentInstrument, accessToken);
		AppDirectPaymentInstrument paymentInstrumentResponse = null;
		try {
			ResponseEntity<AppDirectPaymentInstrument> response = restTemplate.exchange(url, HttpMethod.PUT, entity,
					AppDirectPaymentInstrument.class);

			if (null != response.getBody()) {
				paymentInstrumentResponse = response.getBody();
			}
		} catch (HttpClientErrorException e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error(" Error from Get payment instruments Request - Status {}, Body {}, Exception {}",
					e.getRawStatusCode(), e.getResponseBodyAsString(), e.toString());
			log.error(e.toString());
		} catch (Exception e) {
			AppDirectServiceUtil.getErrorNotes(ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION, errorNotes,
					e);
			log.error("Error from Get payment instruments Request - Exception {}", e.getMessage());
			log.error(e.toString());
		}

		return paymentInstrumentResponse;
	}

	private HttpEntity<AppDirectPaymentInstrument> getHttpEntity(AppDirectPaymentInstrument request,
			String accessToken) {

		HttpHeaders httpHeadres = new HttpHeaders();
		httpHeadres.set(ProductOrderConstants.AUTHORIZATION, ProductOrderConstants.BEARER + accessToken);
		httpHeadres.set(ProductOrderConstants.ACCEPT, ProductOrderConstants.APPLICATION_JSON);
		httpHeadres.set(ProductOrderConstants.CONTENT_TYPE, ProductOrderConstants.APPLICATION_JSON);
		httpHeadres.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);

		return new HttpEntity<>(request, httpHeadres);
	}

	private HttpEntity<Object> getHttpEntity(String accessToken) {

		HttpHeaders httpHeadres = new HttpHeaders();
		httpHeadres.set(ProductOrderConstants.AUTHORIZATION, ProductOrderConstants.BEARER + accessToken);
		httpHeadres.set(ProductOrderConstants.ACCEPT, ProductOrderConstants.APPLICATION_JSON);
		httpHeadres.set(ProductOrderConstants.CONTENT_TYPE, ProductOrderConstants.APPLICATION_JSON);
		httpHeadres.set(ProductOrderConstants.ACCEPT_LANGUAGE, ProductOrderConstants.LOCALE);

		return new HttpEntity<>(httpHeadres);
	}

	public void validatePaymentInstruments(String companyId, String userId, Metadata metadata, String countryCode,
			List<Note> errorNotes) {
		log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_GET);
		log.info("Metadata:" + metadata);
		List<AppDirectPaymentInstrument> paymentInstruments = getPaymentInstruments(companyId, userId, metadata,
				errorNotes);
		if (CollectionUtils.isEmpty(errorNotes)) {
			log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENTS + AppDirectServiceUtil.logger(paymentInstruments));
			Optional<AppDirectPaymentInstrument> response = paymentInstruments.stream().filter(Objects::nonNull)
					.findAny();
			if (response.isPresent()) {
				AppDirectPaymentInstrument paymentInstrument = response.get();
				if (paymentInstrument.getId() != null
						&& !ProductOrderConstants.MANUAL.equals(paymentInstrument.getPaymentMethod())) {
					log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_PUT);
					paymentInstrument.setIsDefault(true);
					paymentInstrument.setPaymentMethod(ProductOrderConstants.MANUAL);
					updatePaymentInstrument(companyId, userId, paymentInstrument.getId(), paymentInstrument, metadata,
							errorNotes);
				}
			} else {
				log.info(ProductOrderConstants.LOG_PAYMENT_INSTRUMENT_POST);
				AppDirectPaymentInstrument request = new AppDirectPaymentInstrument();
				request.setIsDefault(true);
				request.setPaymentMethod(ProductOrderConstants.MANUAL);
				createPaymentInstrument(companyId, userId, request, metadata, errorNotes);
			}
		}

	}

}
