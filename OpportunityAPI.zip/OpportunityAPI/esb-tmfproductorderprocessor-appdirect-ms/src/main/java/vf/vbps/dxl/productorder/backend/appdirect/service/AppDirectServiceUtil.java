package vf.vbps.dxl.productorder.backend.appdirect.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUnit;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.BillingConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ContractConfiguration;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.ProvisioningConfiguration;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.exceptions.ADErrorResponse;
import vf.vbps.dxl.productorder.exceptions.EnumExceptions;
import vf.vbps.dxl.productorder.exceptions.UnauthorizedClientError403Exception;
import vf.vbps.dxl.productorder.model.Characteristic;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.RelatedParty;

@Slf4j
public class AppDirectServiceUtil {

	private AppDirectServiceUtil() {

	}

	public static String getOwnerCompanyId(ProductOrder productOrder) {
		return AppDirectServiceUtil.getId(productOrder, ProductOrderConstants.AGENT_COMPANY);
	}

	public static String getOwnerId(ProductOrder productOrder) {
		return AppDirectServiceUtil.getId(productOrder, ProductOrderConstants.AGENT);
	}

	public static String getId(ProductOrder productOrder, String matchingValue) {
		List<RelatedParty> relatedParties = productOrder.getRelatedParty();
		for (RelatedParty relatedParty : relatedParties) {
			if (matchingValue.equals(relatedParty.getRole())) {
				return relatedParty.getId();
			}
		}
		return null;
	}

	public static String getOAuthAccessToken(Metadata metadata) {
		String accessToken = null;
		if (metadata.getAccessCredentials() != null) {
			Optional<AccessCredentialRef> accessCredential = metadata.getAccessCredentials().stream()
					.filter(ref -> ref.getId().equals(ProductOrderConstants.TOKEN)).filter(Objects::nonNull).findAny();
			if (accessCredential.isPresent()) {
				accessToken = accessCredential.get().getValue();
			} else {
				throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
			}
		} else {
			throw UnauthorizedClientError403Exception.newUnauthorizedClientError403Exception();
		}
		return accessToken;
	}

	public static void getErrorNotes(String failureStep, List<Note> errorNotes, WebClientResponseException exception) {
		log.info(exception.toString());
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_STEP, failureStep);
		if (exception.getRawStatusCode() == HttpStatus.UNAUTHORIZED.value()
				|| exception.getRawStatusCode() == HttpStatus.FORBIDDEN.value()
				|| exception.getRawStatusCode() == HttpStatus.GATEWAY_TIMEOUT.value()
				|| exception.getRawStatusCode() == HttpStatus.BAD_GATEWAY.value()) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_REASON, ProductOrderConstants.TECHNICAL_BACKEND);
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_REASON, ProductOrderConstants.FUNCTIONAL);
		}
		ADErrorResponse error = null;
		if (StringUtils.isNotEmpty(exception.getResponseBodyAsString())) {

			ObjectMapper mapper = new ObjectMapper();
			try {
				error = mapper.readValue(exception.getResponseBodyAsString(), ADErrorResponse.class);
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		if (error != null && StringUtils.isNotEmpty(error.getMessage())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, error.getMessage());
		} else if (StringUtils.isNotEmpty(exception.getResponseBodyAsString())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, exception.getResponseBodyAsString());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, exception.getMessage());
		}
		if (exception.getRawStatusCode() == HttpStatus.NOT_FOUND.value()) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_DXL_CODE,
					EnumExceptions.MISSING_BUSINESS_OBJECT.getCode());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_DXL_CODE,
					EnumExceptions.BACK_END_SYSTEM_ERROR.getCode());
		}
		if (error != null && StringUtils.isNotEmpty(error.getCode())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_AD_CODE, error.getCode());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_AD_CODE,
					String.valueOf(exception.getRawStatusCode()));
		}

	}

	public static void getErrorNotes(String failureStep, List<Note> errorNotes, HttpClientErrorException exception) {
		log.info(exception.toString());
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_STEP, failureStep);
		if (exception.getRawStatusCode() == HttpStatus.UNAUTHORIZED.value()
				|| exception.getRawStatusCode() == HttpStatus.FORBIDDEN.value()
				|| exception.getRawStatusCode() == HttpStatus.GATEWAY_TIMEOUT.value()
				|| exception.getRawStatusCode() == HttpStatus.BAD_GATEWAY.value()) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_REASON, ProductOrderConstants.TECHNICAL_BACKEND);
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_REASON, ProductOrderConstants.FUNCTIONAL);
		}
		ADErrorResponse error = null;
		if (StringUtils.isNotEmpty(exception.getResponseBodyAsString())) {

			ObjectMapper mapper = new ObjectMapper();
			try {
				error = mapper.readValue(exception.getResponseBodyAsString(), ADErrorResponse.class);
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}
		if (error != null && StringUtils.isNotEmpty(error.getMessage())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, error.getMessage());
		} else if (StringUtils.isNotEmpty(exception.getResponseBodyAsString())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, exception.getResponseBodyAsString());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, exception.getMessage());
		}
		if (exception.getRawStatusCode() == HttpStatus.NOT_FOUND.value()) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_DXL_CODE,
					EnumExceptions.MISSING_BUSINESS_OBJECT.getCode());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_DXL_CODE,
					EnumExceptions.BACK_END_SYSTEM_ERROR.getCode());
		}
		if (error != null && StringUtils.isNotEmpty(error.getCode())) {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_AD_CODE, error.getCode());
		} else {
			addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_AD_CODE,
					String.valueOf(exception.getRawStatusCode()));
		}

	}

	public static void getErrorNotes(String failureStep, List<Note> errorNotes, Exception exception) {
		log.info(exception.toString());
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_STEP, failureStep);
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_REASON, ProductOrderConstants.TECHNICAL_INTERNAL);
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_MESSAGE, exception.toString());
		addErrorNotes(errorNotes, ProductOrderConstants.FAILURE_DXL_CODE, EnumExceptions.UNKNOWN_FAILURE.getCode());

	}

	private static void addErrorNotes(List<Note> errorNotes, String id, String text) {
		Note errorNote = new Note();
		errorNote.setId(id);
		errorNote.setText(text);
		errorNote.setAuthor(ProductOrderConstants.DXL);
		errorNote.setDate(getDate(String.valueOf(new Date().getTime())));
		errorNotes.add(errorNote);
	}

	public static String getEndpoint(Metadata metadata, String id) {
		String backEndUrl = metadata.getBackendURL();
		String endpointUrl = "";
		List<ApipathRef> apiPaths = metadata.getApiPaths();
		for (ApipathRef apiPath : apiPaths) {
			if (apiPath.getId().equals(id)) {
				endpointUrl = apiPath.getValue();
				break;
			}
		}

		return (backEndUrl + endpointUrl).trim();
	}

	public static BillingConfiguration getBillingConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.BILLINGCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, BillingConfiguration>) c.getValue());
					BillingConfiguration billingConfigurationValue = new BillingConfiguration();
					try {
						billingConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<BillingConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					if (!StringUtils.isEmpty(billingConfigurationValue.getDate())) {
						billingConfigurationValue
								.setDate(String.valueOf(getEPOCHMilliseconds(billingConfigurationValue.getDate())));
					}

					return billingConfigurationValue;
				}).findFirst().orElse(null);

	}

	public static ProvisioningConfiguration getProvisioningConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.PROVISIONINGCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, ProvisioningConfiguration>) c.getValue());
					ProvisioningConfiguration provisioningConfigurationValue = new ProvisioningConfiguration();
					try {
						provisioningConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<ProvisioningConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					if (!StringUtils.isEmpty(provisioningConfigurationValue.getDate())) {
						provisioningConfigurationValue.setDate(
								String.valueOf(getEPOCHMilliseconds(provisioningConfigurationValue.getDate())));
					}

					return provisioningConfigurationValue;

				}).findFirst().orElse(null);

	}

	public static ContractConfiguration getContractConfiguration(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.CONTRACTCONFIGURATION.equals(c.getName()))
				.map(c -> {

					ObjectMapper objectMapper = new ObjectMapper();

					JSONObject json = new JSONObject((LinkedHashMap<String, ContractConfiguration>) c.getValue());
					ContractConfiguration contractConfigurationValue = new ContractConfiguration();
					try {
						contractConfigurationValue = objectMapper.readValue(json.toString(),
								new TypeReference<ContractConfiguration>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}

					return contractConfigurationValue;

				}).findFirst().orElse(null);

	}

	public static Map<String, List<String>> getSubscriptionCustomAttributes(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.SUBSCRIPTION.equals(c.getName())).map(c -> {

			ObjectMapper objectMapper = new ObjectMapper();
			JSONObject json = new JSONObject((LinkedHashMap<String, Map<String, List<String>>>) c.getValue());
			Map<String, List<String>> subscriptionValue = new HashMap<>();
			try {
				subscriptionValue = objectMapper.readValue(json.toString(),
						new TypeReference<Map<String, List<String>>>() {
						});
			} catch (JsonMappingException e) {
				log.error(e.getMessage());
			} catch (JsonProcessingException e) {
				log.error(e.getMessage());
			}

			return subscriptionValue;
		}).findFirst().orElse(null);

	}

	public static Map<String, List<String>> getVendorRequiredFields(List<Characteristic> characterstics) {
		return characterstics.stream().filter(c -> ProductOrderConstants.VENDORATTRIBUTES.equals(c.getName()))
				.map(c -> {
					ObjectMapper objectMapper = new ObjectMapper();
					JSONObject json = new JSONObject((LinkedHashMap<String, Map<String, List<String>>>) c.getValue());
					Map<String, List<String>> subscriptionValue = new HashMap<>();
					try {
						subscriptionValue = objectMapper.readValue(json.toString(),
								new TypeReference<Map<String, List<String>>>() {
								});
					} catch (JsonMappingException e) {
						log.error(e.getMessage());
					} catch (JsonProcessingException e) {
						log.error(e.getMessage());
					}
					return subscriptionValue;
				}).findFirst().orElse(null);

	}

	public static List<AppDirectUnit> getUnits(List<Characteristic> characterstics) {
		List<AppDirectUnit> appDirectunits = new ArrayList<>();
		for (Characteristic characteristic : characterstics) {
			if (ProductOrderConstants.UNITS.equals(characteristic.getName())) {

				ObjectMapper objectMapper = new ObjectMapper();

				JSONObject json = new JSONObject((LinkedHashMap<String, AppDirectUnit>) characteristic.getValue());
				AppDirectUnit appDirectUnit = new AppDirectUnit();
				try {
					appDirectUnit = objectMapper.readValue(json.toString(), new TypeReference<AppDirectUnit>() {
					});
				} catch (JsonMappingException e) {
					log.error(e.getMessage());
				} catch (JsonProcessingException e) {
					log.error(e.getMessage());
				}

				appDirectunits.add(appDirectUnit);

			}
		}
		return appDirectunits;

	}

	public static Long getEPOCHMilliseconds(String dateStr) {
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			Date date = null;

			date = formatter.parse(dateStr);

			return date.getTime();

		} catch (Exception e) {
			log.error("Error is Date to Long conversion {} ", e.toString());
		}
		return 0L;
	}

	public static String getDate(String epochDate) {
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			Date date = new Date(Long.valueOf(epochDate));

			return formatter.format(date);

		} catch (Exception e) {
			log.error("Error is Date to Long conversion {} ", e.toString());
		}
		return null;
	}

	public static Object logger(Object obj) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(Include.NON_NULL);
		Object result = new Object();
		try {
			result = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			log.error("logger error : {}", e.getMessage());
		}
		return result;
	}

}
