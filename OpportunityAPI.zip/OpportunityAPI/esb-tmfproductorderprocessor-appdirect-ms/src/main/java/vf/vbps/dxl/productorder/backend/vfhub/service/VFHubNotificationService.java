package vf.vbps.dxl.productorder.backend.vfhub.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectServiceUtil;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.backend.technical.service.MetadataService;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderStateChangeEvent;
import vf.vbps.dxl.productorder.model.ProductOrderStateChangeEventPayload;
import vf.vbps.dxl.productorder.model.ProductOrderStateType;
import vf.vbps.dxl.productorder.repository.MongoProductOrderStateChangeEvent;
import vf.vbps.dxl.productorder.repository.MongoProductOrderStateChangeEventRepository;

@Slf4j
@Component
public class VFHubNotificationService {

	@Autowired
	private WebClient webClient;

	@Autowired
	private MongoProductOrderStateChangeEventRepository eventrepository;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MetadataService metadataService;

	public void sendProudctOrderSuccessNotififation(ProductOrder productOrder) {

		Metadata metadata = null;
		try {
			metadata = metadataService.getNotificationMetadata(productOrder.getCountryCode(),
					ProductOrderConstants.NOTIFY_OPERATION);
		} catch (Exception e) {
			log.info("Exception will getting metadata for notification" + e);
		}
		ProductOrderStateChangeEvent event = new ProductOrderStateChangeEvent();

		ProductOrderStateChangeEventPayload productOrderPayload = new ProductOrderStateChangeEventPayload();
		productOrder.setDxlIdentifier(null);
		productOrder.setCountryCode(null);
		productOrder.setState(ProductOrderStateType.INPROGRESS);
		productOrderPayload.setProductOrder(productOrder);

		event.setEvent(productOrderPayload);

		if (metadata != null && metadata.getBackendURL() != null) {
			long start = System.currentTimeMillis();

			String proudctOrderSuccessNotififationUrl = metadata.getBackendURL();

			String uri = UriComponentsBuilder.fromUriString(proudctOrderSuccessNotififationUrl).toUriString();
			log.info("proudctOrderSuccessNotififationUrl is {} ", uri);

			try {
				log.debug("Success notification request is {}",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(event));
			} catch (JsonProcessingException e) {
				log.debug(e.getMessage());
			}

			ProductOrderStateChangeEventResponse apiResponse = webClient.post().uri(uri).bodyValue(event)
					.headers(httpHeaders -> {
						httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					}).retrieve().bodyToMono(ProductOrderStateChangeEventResponse.class).block();

			try {
				log.debug("Notififation Response is {} ",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
			} catch (JsonProcessingException e) {
				log.info(e.getMessage());
			}

			long timeTaken = System.currentTimeMillis() - start;
			log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);
		} else {
			try {
				log.info("No notification URL configured"
						+ objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(event));
			} catch (JsonProcessingException e) {
				log.info(e.getMessage());
			}
		}

	}

	public void sendProudctOrderErrorNotififation(String countryCode, ProductOrder request, List<Note> errorNotes) {
		ProductOrderStateChangeEvent event = new ProductOrderStateChangeEvent();
		Metadata metadata = null;
		try {
			metadata = metadataService.getNotificationMetadata(countryCode, ProductOrderConstants.NOTIFY_OPERATION);
		} catch (Exception e) {
			log.info("Exception will getting metadata for notification" + e);
		}
		ProductOrderStateChangeEventPayload productOrderPayload = new ProductOrderStateChangeEventPayload();
		ProductOrder productOrder = new ProductOrder();
		productOrder.setId(request.getDxlIdentifier());
		productOrder.setExternalId(request.getExternalId());
		productOrder.setNote(errorNotes);
		productOrder.setState(ProductOrderStateType.FAILED);
		productOrderPayload.setProductOrder(productOrder);
		event.setEvent(productOrderPayload);

		if (metadata != null && metadata.getBackendURL() != null) {
			long start = System.currentTimeMillis();

			String proudctOrderFailureNotififationUrl = metadata.getBackendURL();

			String uri = UriComponentsBuilder.fromUriString(proudctOrderFailureNotififationUrl).toUriString();
			log.info("proudctOrderSuccessNotififationUrl is {} ", uri);

			ProductOrderStateChangeEventResponse apiResponse = webClient.post().uri(uri).bodyValue(event)
					.headers(httpHeaders -> {
						httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
					}).retrieve().bodyToMono(ProductOrderStateChangeEventResponse.class).block();

			try {
				log.debug("Notififation Response is {} ",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(apiResponse));
			} catch (JsonProcessingException e) {
				log.info(e.getMessage());
			}

			long timeTaken = System.currentTimeMillis() - start;
			log.debug(ProductOrderConstants.TIME_TAKEN_MESSAGE_STRING, timeTaken);
		} else {
			try {
				log.info("No notification URL configured {}",
						objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(event));
			} catch (JsonProcessingException e) {
				log.info(e.getMessage());
			}
		}

	}

}
