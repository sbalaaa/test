package vf.vbps.dxl.productorder.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import lombok.Data;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.ProxyProvider;


@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "props")
@Data
@Component
public class ApplicationConfig {

	private String httpproxyhost;
	private String httpproxyport;
	private String backendusername;
	private String backendpassword;
	
	private String isproxyenabled;
	private String backendtimeout;
	
	private String techmsbasepath;
	private String techmsmetadataapi;
	private String topics;
	private String producertopicname;
	
	private String mskhostname;
	private String truststorepassword;
	private String mskusername;
	private String mskpassword;

	
	@Bean
	public Builder getWebClientBuilder() {
		return WebClient.builder().clientConnector(getReactorClientHttpConnector());
	}

	private ReactorClientHttpConnector getReactorClientHttpConnector() {

		HttpClient httpClient = null;

		if (this.getIsproxyenabled().equalsIgnoreCase("true")) {
			httpClient = HttpClient.create().tcpConfiguration(tcpClient -> tcpClient.proxy(
					// set Proxy
					proxy -> proxy.type(ProxyProvider.Proxy.HTTP).host(this.getHttpproxyhost())
							.port(Integer.parseInt(this.getHttpproxyport())))
					// set connection timeout
					.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000)
					.doOnConnected(conn -> conn
							/*
							 * Raises a ReadTimeoutException when no data was read within a certain period
							 * of time.The connection is closed when there is no inbound traffic for 10
							 * seconds.
							 */
							.addHandlerLast(new ReadTimeoutHandler(30000))
							/*
							 * Raises a WriteTimeoutException when a write operation cannot finish in a
							 * certain period of time. The connection is closed when a write operation
							 * cannot finish in 53 seconds.
							 */
							.addHandlerLast(new WriteTimeoutHandler(30000))));
		} else {
			httpClient = HttpClient.create().tcpConfiguration(tcpClient -> tcpClient
					// set connection timeout
					.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 30000)
					.doOnConnected(
							conn -> conn.addHandlerLast(new ReadTimeoutHandler(30000))
									.addHandlerLast(new WriteTimeoutHandler(30000))));
		}
		return new ReactorClientHttpConnector(httpClient);
	}
	
	@Bean
	public WebClient getWebClient() {
		return getWebClientBuilder().build();
	}

}
