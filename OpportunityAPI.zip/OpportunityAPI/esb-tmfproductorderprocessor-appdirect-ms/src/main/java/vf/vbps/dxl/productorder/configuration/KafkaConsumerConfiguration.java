package vf.vbps.dxl.productorder.configuration;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.IntegerDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

@EnableKafka
@Configuration
public class KafkaConsumerConfiguration {

	@Autowired
	private ApplicationConfig applicationConfig;

	@Bean
	public ConsumerFactory<Integer, String> consumerFactory() {

		String username = applicationConfig.getMskusername();
		String password = applicationConfig.getMskpassword();
		String hostNames = applicationConfig.getMskhostname();

		final Map<String, Object> config = new HashMap<>();

		String credentials = "org.apache.kafka.common.security.scram.ScramLoginModule required username=".concat("'")
				.concat(username).concat("'").concat(" ").concat("password=").concat("'").concat(password).concat("';");

		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, hostNames);
		config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, IntegerDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

		config.put("ssl.endpoint.identification.algorithm", "");
		config.put("security.protocol", "SSL");
		config.put(SslConfigs.DEFAULT_SSL_ENABLED_PROTOCOLS, "TLSv1.2,TLSv1.1,TLSv1");
		config.put("ssl.protocol", "TLS");
		config.put("security.protocol", "SASL_SSL");
		config.put("sasl.mechanism", "SCRAM-SHA-512");
		config.put("sasl.jaas.config", credentials);
		config.put(ConsumerConfig.GROUP_ID_CONFIG, "productordersync");

		return new DefaultKafkaConsumerFactory<>(config);
	}

	@Bean
	public ConcurrentKafkaListenerContainerFactory<Integer, String> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<Integer, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		return factory;
	}

}
