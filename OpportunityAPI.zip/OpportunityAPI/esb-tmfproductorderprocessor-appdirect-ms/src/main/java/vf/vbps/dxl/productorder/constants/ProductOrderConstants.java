package vf.vbps.dxl.productorder.constants;

public class ProductOrderConstants {

	private ProductOrderConstants() {

	}

	public static final String ERROR = "error";
	public static final String TOTAL_QUANTITY = "TotalQuantity";
	public static final String X_TOTAL_COUNT = "X-Total-Count";
	public static final String CREATE_OPPORTUNITY_STEP = "CREATE-OPPORTUNITY";
	public static final String PROCESSING_TYPE = "ADOpportunity";
	public static final String RESOURCE_TYPE = "ProductOrder";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String CUSTOMER = "Customer";
	public static final String VODAFONE = "Vodafone";
	public static final String CSM_ERROR_CODE = "CSM Error Code";
	public static final String EXIT_CODE = "exitcode";
	public static final String INTERNAL_SERVER_ERROR = "internal server error";
	public static final String TIME_TAKEN_MESSAGE_STRING = "Time taken to getResponse service is {} ms";
	public static final String TOKEN_STRING = "token is {} ";

	public static final String PRODUCT_ORDER_OPPORTUNITY_SERVICE = "OpportunityService";
	public static final String PRODUCT_ORDER_OPPORTUNITY = "OpportunityService";
	public static final String VF_VBPS_DXL_PRODUCTODER_CONFIGURATION = "vf.vbps.dxl.productorder.configuration";
	public static final String VF_VBPS_DXL_PRODUCTODER_REST = "vf.vbps.dxl.productorder.rest";
	public static final String VF_VBPS_DXL_PRODUCTODER = "vf.vbps.dxl.productorder";
	public static final String SOAP_BASE_PACKAGE = "vf.vbps.dxl.tmfsiemensadapterms.backend.appdirect.soap";
	public static final String X_COUNTRY_CODE = "x-country-code";
	public static final String X_SOURCE_SYSTEM = "x-source-system";

	public static final String X_DESTINATION_SYSTEM = "x-destination-system";
	public static final String X_ROUTE_KEY = "x-route-key";
	public static final String UPDATE_V2_USER = "Update Order Details";
	public static final String DB_ADDITIONAL_KEY = "ADDITIONAL_KEY";
	public static final String DB_APPLICATION_NAME = "APPLICATION_NAME";
	public static final String DB_BACKEND_APP = "BACKEND_APP";
	public static final String DB_COUNTRY_CODE = "COUNTRY_CODE";
	public static final String COUNTRY_CODE = "CountryCode";
	public static final String BACKEND_APP = "BackendApp";
	public static final String BACKEND_APPLICATION = "backendApplication";
	public static final String APPLICATION_NAME = "applicationName";
	public static final String SERVICE_NAME = "serviceName";
	public static final String COUNTRY = "countryCode";
	public static final String ADDITIONAL_KEY = "additionalKey";
	public static final String CREATE_OPERATION = "CREATE";
	public static final String UPDATE_OPERATION = "UPDATE";
	public static final String DELETE_OPERATION = "DELETE";
	public static final String GET_OPERATION = "GET";
	public static final String IT = "IT";
	public static final String ES = "ES";
	public static final String DE = "DE";
	public static final String GR = "GR";
	public static final String ZA = "ZA";
	public static final String SOUTH_AFRICA = "za";
	public static final String GERMANY = "germany";
	public static final String ITALY = "italy";
	public static final String GREECE = "greece";
	public static final String SPAIN = "spain";

	public static final String APPDIRECT = "APPDIRECT";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String ACCEPT = "Accept";
	public static final String APPLICATION_JSON = "application/json";
	public static final String APPLICATION_XML = "application/xml";
	public static final String USER_NAME = "username";
	public static final String USER_PASSWORD = "password";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String GRANT_TYPE = "grant_type";
	public static final String SCOPE = "scope";

	public static final String LOG_ACCESS_TOKEN = "Access Token : {} ";
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER = "Bearer ";
	public static final String TOKEN = "TOKEN";

	public static final String LOG_METADATA = "Metadata :";

	// Kafka consumers records
	public static final String ORGANIZATIONAL_EXTERNAL = "organizationExternal";
	public static final String ORGANIZATION = "organization";
	public static final String USERL_EXTERNAL = "userExternal";
	public static final String USER = "user";
	public static final String AGENT_COMPANY_EXTERNAL = "agentCompanyExternal";
	public static final String AGENT_COMPANY = "agentCompany";
	public static final String AGENT_EXTERNAL = "agentExternal";
	public static final String AGENT = "agent";

	public static final String IS_ADD_ITEM = "addon";
	public static final String IS_PRODUCT = "product";

	// APPDIRECT API ENDPOINT KEYS
	public static final String ADDITEMS = "OS_ItemPost";
	public static final String GETITEMS = "OS_Items";
	public static final String EDITITEM = "OS_ItemPut";
	public static final String COMPANYDETAILS = "CP_Company";
	public static final String USERDETAILS = "CSUA_CompanyUser";
	public static final String PAYMENTDETAILS = "OS_PaymentPlan";
	public static final String CREATEOPPORTUNITY = "OS_OpportunityPost";
	public static final String APPLYDISCOUNT = "OS_DiscountPut";
	public static final String FINALIZEOPPORTUNITY = "OS_OpportunityFinalize";
	public static final String VFHUBNOTIFICATION = "OS_NotificationPost";
	public static final String PAYMENT_INSTRUMENTS_GET = "PO_PaymentInstrmentsGetPost";
	public static final String PAYMENT_INSTRUMENTS_PUT = "PO_PaymentInstrmentsPut";

	public static final String RECURRING_AD = "RECURRING";
	public static final String RECURRING_TMF = "recurring";
	public static final String ONE_TIME_AD = "ONE_TIME";
	public static final String ONE_TIME_TMF = "oneTime";
	public static final String RECURRING_FLAT_AD = "RECURRING_FLAT";
	public static final String RECURRING_FLAT_TMF = "recurringFlat";
	public static final String ONE_TIME_FLAT_AD = "ONE_TIME_FLAT";
	public static final String ONE_TIME_FLAT_TMF = "oneTimeFlat";
	public static final String INCLUDED_AD = "INCLUDED";
	public static final String INCLUDED_TMF = "included";
	public static final String RECURRING_PER_UNIT_AD = "RECURRING_PER_UNIT";
	public static final String RECURRING_PER_UNIT_TMF = "recurringPerUnit";
	public static final String ONE_TIME_PER_UNIT_AD = "ONE_TIME_PER_UNIT";
	public static final String ONE_TIME_PER_UNIT_TMF = "oneTimePerUnit";
	public static final String SETUP_PER_UNIT_AD = "SETUP_PER_UNIT";
	public static final String SETUP_PER_UNIT_TMF = "setUpPerUnit";
	public static final String SETUP_FEE_AD = "SETUP_FEE";
	public static final String SETUP_FEE_TMF = "setUpFee";
	public static final String CONTRACT_FEE_AD = "CONTRACT_FEE";
	public static final String CONTRACT_FEE_TMF = "contractFee";
	public static final String DISCOUNT_PER_UNIT_AD = "DISCOUNT_PER_UNIT";
	public static final String DISCOUNT_PER_UNIT_TMF = "discountPerUnit";
	public static final String DISCOUNT_FLAT_AD = "DISCOUNT_FLAT";
	public static final String DISCOUNT_FLAT_TMF = "discountFlat";
	public static final String METERED_USAGE_AD = "METERED_USAGE";
	public static final String METERED_USAGE_TMF = "meteredUsage";
	public static final String SALE = "sale";
	public static final String WHOLE_SALE = "wholeSale";
	public static final String TOTAL_SALE = "totalSale";
	public static final String DAILY_AD = "DAILY";
	public static final String DAILY_TMF = "daily";
	public static final String MONTHLY_AD = "MONTHLY";
	public static final String MONTHLY_TMF = "monthly";
	public static final String QUATERLY_AD = "QUATERLY";
	public static final String QUATERLY_TMF = "quaterly";
	public static final String SIX_MONTHS_AD = "SIX_MONTHS";
	public static final String SIX_MONTHS_TMF = "sixMonths";
	public static final String YEARLY_AD = "YEARLY";
	public static final String YEARLY_TMF = "yearly";
	public static final String TWO_YEARS_AD = "TWO_YEARS";
	public static final String TWO_YEARS_TMF = "twoYears";
	public static final String THREE_YEARS_AD = "THREE_YEARS";
	public static final String THREE_YEARS_TMF = "threeYears";
	public static final String FREE_AD = "FREE";
	public static final String FLAT_AD = "FLAT";
	public static final String UNIT_AD = "UNIT";
	public static final String VOLUME_AD = "VOLUME";
	public static final String TIERED_AD = "TIERED";
	public static final String UNLIMITED_AD = "UNLIMITED";
	public static final String CUSTOM_AD = "CUSTOM";

	// Characteristic related constants
	public static final String UNITS = "units";
	public static final String BILLINGCONFIGURATION = "billingConfiguration";
	public static final String PROVISIONINGCONFIGURATION = "provisioningConfiguration";
	public static final String CONTRACTCONFIGURATION = "contractConfiguration";
	public static final String SUBSCRIPTION = "subscription";
	public static final String VENDORATTRIBUTES = "vendorAttributes";

	// ORCHESTRATION STEPS
	public static final String STEP_LOOKUP_COMPANY = "LOOKUP-COMPANY";
	public static final String STEP_LOOKUP_USER = " LOOKUP-USER";
	public static final String STEP_LOOKUP_PRICINGPLAN = "LOOKUP-PRICINGPLAN";
	public static final String STEP_CREATE_OPPORTUNITY = " CREATE-OPPORTUNITY";
	public static final String STEP_EDITITEM_OPPORTUNITY = "EDIT-OPPORTUNITY";
	public static final String STEP_ADDITEM_OPPORTUNITY = "ADDITEM-OPPORTUNITY";
	public static final String STEP_GETITEMS_OPPORTUNITY = "GETITEMS-OPPORTUNITY";
	public static final String STEP_APPLYDISCOUNT_OPPORTUNITY = "APPLYDISCOUNT-OPPORTUNITY";
	public static final String STEP_FINALIZE_OPPORTUNITY = "FINALIZE-OPPORTUNITY";
	public static final String FAILURE_STEP = "FAILURE-STEP";
	public static final String FAILURE_REASON = "FAILURE-REASON";
	public static final String FAILURE_MESSAGE = "FAILURE-MESSAGE";
	public static final String FAILURE_DXL_CODE = "FAILURE-DXL-CODE";
	public static final String FAILURE_AD_CODE = "FAILURE-AD-CODE";
	public static final String TECHNICAL_BACKEND = "TECHNICAL-BACKEND";
	public static final String TECHNICAL_INTERNAL = "TECHNICAL-INTERNAL";
	public static final String FUNCTIONAL = "FUNCTIONAL";

	// Payment instrumentation constants
	public static final String LOG_PAYMENT_INSTRUMENT_URL = "Payment Instrument GET/POST URL :";
	public static final String LOG_PAYMENT_INSTRUMENT_PUT_URL = "Payment Instrument PUT URL :";
	public static final String LOG_PAYMENT_INSTRUMENT_GET = "GET Payment Instruments";
	public static final String LOG_PAYMENT_INSTRUMENT_PUT = "PUT Payment Instrument";
	public static final String LOG_PAYMENT_INSTRUMENT_POST = "POST Payment Instrument";
	public static final String LOG_PAYMENT_INSTRUMENTS = "Payment Instruments >>";

	public static final String ACCEPT_LANGUAGE = "Accept-Language";
	public static final String LOCALE = "en-US";
	public static final String COMPANY_ID = "companyId";
	public static final String USER_ID = "userId";
	public static final String PAYMENT_INSTRUMENTS_ID = "paymentInstrumentId";
	public static final String MANUAL = "MANUAL";
	public static final String NOTIFY_OPERATION = "NOTIFY";
	public static final String STEP_PAYMENT_INSTRUMENT_VERIFICATION = "PAYMENT-INSTRUMENT-VERIFICATION";
	public static final String TYPE_OBJECT = "Object";
	public static final String DISCOUNT = "discount";
	public static final String PRODUCT_ID = "id";
	public static final String DXL = "DXL";
	public static final String PURCHASE_ID = "purchaseId";
	public static final String PURCHASE_NUMBER = "purchaseNumber";
	public static final String OPPORTUNITY_ID = "appDirectOpportunityId";
	public static final String ORDER_PRICE = "OrderPrice";
	public static final String ORDER_PRICE_EXTENDED = "OrderPriceExtended";

}