package vf.vbps.dxl.productorder.repository;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.ToString;

@Document(collection="ProductOrderStateChangeEvent")
@Data
@ToString
@JsonInclude(value = Include.NON_EMPTY, content = Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class MongoProductOrderStateChangeEvent {
	
	@Id
	private String id;
	
	@Field("DXLIdentifier")
	private String dxlIdentifier;
	
	@Field("payload")
	private String payload;
	


}
