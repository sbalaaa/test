package vf.vbps.dxl.productorder.repository;



import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MongoProductOrderStateChangeEventRepository extends MongoRepository<MongoProductOrderStateChangeEvent, String>{
	MongoProductOrderStateChangeEvent findByDxlIdentifier(String dxlIdentifier);
}
