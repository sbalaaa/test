package vf.vbps.dxl.productorder.service.kafka.consumer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCompanyResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCreateOpportunityResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectItem;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUserResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.AddItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectItemService;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectOpportunityService;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectPaymentInstrumentService;
import vf.vbps.dxl.productorder.backend.appdirect.service.AppDirectServiceUtil;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.backend.technical.service.MetadataService;
import vf.vbps.dxl.productorder.backend.vfhub.service.VFHubNotificationService;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderItem;
import vf.vbps.dxl.productorder.model.ProductOrderStateType;
import vf.vbps.dxl.productorder.model.RelatedParty;
import vf.vbps.dxl.productorder.repository.DXLAsyncProcessingRepository;

@Component
@Slf4j
public class ProductOrderEventConsumer {

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private MetadataService metadataService;

	@Autowired
	private AppDirectItemService itemService;

	@Autowired
	private AppDirectOpportunityService opportunityService;

	@Autowired
	private VFHubNotificationService notificationService;

	@Autowired
	private AppDirectPaymentInstrumentService paymentInstrumentService;

	@Autowired
	private DXLAsyncProcessingRepository repository;

	// @KafkaListener(topics = {"${props.topics}"})
	@KafkaListener(topicPartitions = { @TopicPartition(topic = "${props.topics}", partitions = { "0", "1",
			"2" }) }, groupId = "productordersync", containerFactory = "kafkaListenerContainerFactory")
	public void onMessage(ConsumerRecord<Integer, String> consumerRecord) throws JsonProcessingException {
		String step = ProductOrderConstants.STEP_LOOKUP_COMPANY;
		log.info("ConsumerRecord : {} ", consumerRecord);

		ProductOrder productOrder = objectMapper.readValue(consumerRecord.value(), ProductOrder.class);
		try {
			log.debug("Product order in input :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(productOrder));
		} catch (Exception e) {
			log.error(e.toString());
		}

		List<Note> errorNotes = new ArrayList<>();

		String companyId = null;
		String companyExternalId = null;
		String userId = null;
		String userExternalId = null;
		String opportunityId = null;

		companyExternalId = getId(productOrder, "organizationExternal");

		log.info("companyExternalId : {} ", companyExternalId);

		companyId = getId(productOrder, "organization");

		log.info("companylId : {} ", companyId);

		userExternalId = getId(productOrder, "userExternal");

		log.info("userExternalId : {} ", userExternalId);

		userId = getId(productOrder, "user");

		log.info("userId : {} ", userId);

		HttpHeaders headers = new HttpHeaders();
		headers.add(ProductOrderConstants.X_COUNTRY_CODE, productOrder.getCountryCode());
		headers.add(ProductOrderConstants.X_DESTINATION_SYSTEM, ProductOrderConstants.APPDIRECT);

		Metadata metadata = metadataService.getMetadataDetails(headers, ProductOrderConstants.CREATE_OPERATION);

		String countryCode = productOrder.getCountryCode();

		if (companyId == null) {
			step = ProductOrderConstants.STEP_LOOKUP_COMPANY;
			AppDirectCompanyResponse companyResponse = opportunityService.getCompanyDetails(companyExternalId, metadata,
					errorNotes);
			if (companyResponse != null) {
				companyId = companyResponse.getUuid();
			}
		}

		log.info("Final companyId is : {} ", companyId);
		if (CollectionUtils.isEmpty(errorNotes)) {
			if (userId == null) {
				step = ProductOrderConstants.STEP_LOOKUP_USER;
				AppDirectUserResponse userResponse = opportunityService.getUserDetails(companyExternalId,
						userExternalId, metadata, errorNotes);

				if (userResponse != null) {
					userId = userResponse.getInternalId();
				}
			}

			log.info("Final userId is : {} ", userId);

			try {
				if (CollectionUtils.isEmpty(errorNotes)) {
					step = ProductOrderConstants.STEP_PAYMENT_INSTRUMENT_VERIFICATION;
					// Payment Instrument Validation
					if (!StringUtils.isEmpty(countryCode) && !StringUtils.isEmpty(companyExternalId)
							&& !StringUtils.isEmpty(userExternalId)) {
						paymentInstrumentService.validatePaymentInstruments(companyExternalId, userExternalId, metadata,
								countryCode, errorNotes);
					} else if (!StringUtils.isEmpty(countryCode) && !StringUtils.isEmpty(companyId)
							&& !StringUtils.isEmpty(userId)) {
						paymentInstrumentService.validatePaymentInstruments(companyId, userId, metadata, countryCode,
								errorNotes);
					}
				}
			} catch (Exception e) {
				log.error("Error Payment Instrument Validation : {} ", e.toString());
			}

			try {
				if (CollectionUtils.isEmpty(errorNotes)) {
					log.info("CreateOpportunity Started ");
					step = ProductOrderConstants.STEP_CREATE_OPPORTUNITY;
					AppDirectCreateOpportunityResponse createOpportunityResponse = opportunityService
							.invokeCreateOpportunity(metadata, productOrder, companyId, userId, errorNotes);
					if (CollectionUtils.isEmpty(errorNotes)) {
						log.info("Opportunity id is : {} ", createOpportunityResponse.getId());

						opportunityId = createOpportunityResponse.getId();
						productOrder.setId(opportunityId);

						List<AppDirectItem> appDiretItems = createOpportunityResponse.getItems();

						List<ProductOrderItem> items = productOrder.getProductOrderItem();

						for (ProductOrderItem item : items) {

							if (appDiretItems != null && !appDiretItems.isEmpty()) {

								for (AppDirectItem appDirectItem : appDiretItems) {
									if (item.getType() != null
											&& item.getType().equals(appDirectItem.getPricingPlanId())) {
										String inputId = item.getId();
										item.setId(appDirectItem.getId());
										item.setType(inputId);
									}
								}

							}

						}

						log.info("AddItem Started ");
						step = ProductOrderConstants.STEP_ADDITEM_OPPORTUNITY;
						List<AddItemResponse> addItemResponse = itemService.invokeAddItem(metadata, productOrder,
								opportunityId, errorNotes);
						if (CollectionUtils.isEmpty(errorNotes)) {

							for (ProductOrderItem item : items) {

								if (addItemResponse != null && !addItemResponse.isEmpty()) {

									for (AddItemResponse appDirectAddItemResponse : addItemResponse) {
										if (item.getType() != null
												&& item.getType().equals(appDirectAddItemResponse.getPricingPlanId())) {
											item.setId(appDirectAddItemResponse.getId());
											item.setType(null);
										}
									}

								}

							}
							log.info("EditItem Started ");
							step = ProductOrderConstants.STEP_EDITITEM_OPPORTUNITY;
							itemService.invokeEditItem(opportunityId, metadata, productOrder, errorNotes);
							log.info("Edit is completed ");
							if (CollectionUtils.isEmpty(errorNotes)) {

								opportunityService.invokeApplyDiscount(opportunityId, metadata, productOrder,
										errorNotes);
								if (CollectionUtils.isEmpty(errorNotes)) {
									step = ProductOrderConstants.STEP_FINALIZE_OPPORTUNITY;
									AppDirectFinalizeResponse finalizeResponse = opportunityService
											.invokeFinalizeOpportunity(opportunityId, metadata, errorNotes);
									if (CollectionUtils.isEmpty(errorNotes)) {
										List<Note> notes = new ArrayList<>();
										Note noteOne = new Note();
										noteOne.setId(ProductOrderConstants.PURCHASE_ID);
										noteOne.setText(finalizeResponse.getPurchaseId());
										notes.add(noteOne);

										Note noteTwo = new Note();
										noteTwo.setId(ProductOrderConstants.PURCHASE_NUMBER);
										noteTwo.setText(finalizeResponse.getPurchaseNumber());
										notes.add(noteTwo);

										productOrder.setNote(notes);
										if (!StringUtils.isEmpty(finalizeResponse.getPurchaseEffectiveDate())) {
											productOrder.setRequestedStartDate(AppDirectServiceUtil
													.getDate(finalizeResponse.getPurchaseEffectiveDate()));
										}
										if (!StringUtils.isEmpty(finalizeResponse.getCreatedOn())) {
											productOrder.setOrderDate(
													AppDirectServiceUtil.getDate(finalizeResponse.getCreatedOn()));
										}

										productOrder.setState(ProductOrderStateType.INPROGRESS);
									}
//							DXLAsyncProcessing record = repository.findByDxlIdentifier(productOrder.getDxlIdentifier());
//							record.setProcessingStatus("Completed");
//							record.setNotificationStatus("Completed");
//							repository.save(record);
								}
							}

						}
					}
				}
			} catch (Exception e) {
				log.error(e.toString());
				log.debug(e.getStackTrace().toString());
				try {
					log.debug("Product order :\n {} \n",
							objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(productOrder));
				} catch (Exception ex) {
					log.error(ex.toString());
				}
				AppDirectServiceUtil.getErrorNotes(step, errorNotes, e);

//				log.info("sendProudctOrderErrorNotififation Started Error Note Size{} , Errors: {}", errorNotes.size(),
//						errorNotes);
//				notificationService.sendProudctOrderErrorNotififation(metadata, productOrder.getDxlIdentifier(),
//						errorNotes);
//				log.info("sendProudctOrderErrorNotififation Ended ");
			}
		}
		try {
			log.debug("Product order after orchestration :\n {} \n",
					objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(productOrder));
		} catch (Exception e) {
			log.error(e.toString());
		}
		if (CollectionUtils.isEmpty(errorNotes)) {
			log.info("sendProudctOrderSuccessNotififation Started ");

			for (ProductOrderItem item : productOrder.getProductOrderItem()) {
				item.setType(null);
			}

			notificationService.sendProudctOrderSuccessNotififation(productOrder);
			log.info("sendProudctOrderSuccessNotififation Ended ");
		} else {
			log.info("sendProudctOrderErrorNotififation Started ");
			if (opportunityId != null) {
				Note note = new Note();
				note.setId(ProductOrderConstants.OPPORTUNITY_ID);
				note.setText(opportunityId);
				note.setAuthor(ProductOrderConstants.DXL);
				note.setDate(AppDirectServiceUtil.getDate(String.valueOf(new Date().getTime())));
				errorNotes.add(note);
			}
			notificationService.sendProudctOrderErrorNotififation(countryCode, productOrder, errorNotes);
			log.info("sendProudctOrderErrorNotififation Ended ");
		}

	}

	private String getId(ProductOrder productOrder, String matchingValue) {
		List<RelatedParty> relatedParties = productOrder.getRelatedParty();
		for (RelatedParty relatedParty : relatedParties) {
			if (matchingValue.equals(relatedParty.getRole())) {
				return relatedParty.getId();
			}
		}
		return null;
	}
}
