package vf.vbps.dxl.productorder.backend.appdirect.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentPlanResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.AddItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.EditItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.GetItemsResponse;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.test.MockUtil;

public class AppDirectItemServiceTest {
	
	@InjectMocks
	private AppDirectItemService appDirectItemService;
	
	@Mock
	private AppDirectOpportunityService opportunityService;
	
	@Mock
	private WebClient webClient;
	
	@Mock
	private WebClient.RequestBodyUriSpec requestBodyUriSpec;
	
	@Mock
	private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
	
	@Mock
	private WebClient.RequestHeadersSpec requestHeadersSpec;

	@Mock
	private WebClient.RequestBodySpec requestBodySpec;

	@Mock
	private WebClient.ResponseSpec responseSpec;
	
	@Before
	public void setData() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void invokeAddItemTest() throws Exception {
		
		ProductOrder productOrder = MockUtil.createProductOrderRequest();
		Metadata metadata = MockUtil.getMetadata();
		String opportunityId = "1234";
		AppDirectPaymentPlanResponse paymentPlanResponse = new AppDirectPaymentPlanResponse();
		paymentPlanResponse.setUuid("dsdsds");
		Mockito.when(opportunityService.invokePaymentPlan(any(), any(),any())).thenReturn(paymentPlanResponse);
		
		Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.headers(any())).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.retrieve()).thenReturn(responseSpec);
		List<AddItemResponse> addItemResponse = MockUtil.addItemsResponse();

		List<Note> errorNotes = new ArrayList<>();
		Mockito.when(responseSpec.bodyToMono(new ParameterizedTypeReference<List<AddItemResponse>>() {
		})).thenReturn(Mono.just(addItemResponse));
		List<AddItemResponse> apiResponse = appDirectItemService.invokeAddItem(metadata, productOrder, opportunityId, errorNotes);
		
		assertNotNull(apiResponse);
	}
	
	@Test
	public void invokeGetItemsTest() throws Exception {
		Metadata metadata = MockUtil.getMetadata();
		List<GetItemsResponse> getItemResponse = MockUtil.getItemsResponse();
		
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(new ParameterizedTypeReference<List<GetItemsResponse>>() {
		})).thenReturn(Mono.just(getItemResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		String opportunityId = "80349d02-c68c-4e00-99f4-1436a1579743";
		List<GetItemsResponse> apiResponse = appDirectItemService.invokeGetItems(opportunityId,metadata, errorNotes);
		assertNotNull(apiResponse);
	}
	
	@Test
	public void invokeEditItemTest() throws Exception {
		ProductOrder productOrder = MockUtil.createProductOrderRequest();
		Metadata metadata = MockUtil.getMetadata();
		String opportunityId = "1234";
		EditItemResponse item = MockUtil.editItemResponse();
		
		List<GetItemsResponse> getItemResponse = MockUtil.getItemsResponse();
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(new ParameterizedTypeReference<List<GetItemsResponse>>() {
		})).thenReturn(Mono.just(getItemResponse));
		
		
		Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<EditItemResponse>>notNull()))
        .thenReturn(Mono.just(item));
		
		List<Note> errorNotes = new ArrayList<>();
		appDirectItemService.invokeEditItem(opportunityId, metadata, productOrder, errorNotes);
		assertTrue(true);
	}

}
