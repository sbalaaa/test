package vf.vbps.dxl.productorder.backend.appdirect.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCompanyResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCreateOpportunityResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentPlanResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUserResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply.ApplyDiscountResponse;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.model.Note;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.test.MockUtil;

public class AppDirectOpportunityServiceTest {

	@InjectMocks
	private AppDirectOpportunityService appDirectOpportunityService;	
	
	@Mock
	private WebClient webClient;
	
	@Mock
	private WebClient.RequestBodyUriSpec requestBodyUriSpec;
	
	@Mock
	private WebClient.RequestHeadersUriSpec requestHeadersUriSpec;
	
	@Mock
	private WebClient.RequestHeadersSpec requestHeadersSpec;

	@Mock
	private WebClient.RequestBodySpec requestBodySpec;

	@Mock
	private WebClient.ResponseSpec responseSpec;
	
	@Mock
	private WebClient.ResponseSpec responseCreateOpportunitySpec;
	
	@Before
	public void setData() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void getCompanyDetailsTest() throws Exception {
		Metadata metadata = MockUtil.getMetadata();
		AppDirectCompanyResponse companyResponse = MockUtil.getCompanyResponse();
		
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectCompanyResponse>>notNull()))
        .thenReturn(Mono.just(companyResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		AppDirectCompanyResponse apiResponse = appDirectOpportunityService.getCompanyDetails("companyExternalId", metadata,errorNotes);
		
		assertNotNull(apiResponse);
	}
	
	
	@Test
	public void getUserDetailsTest() throws Exception {
		Metadata metadata = MockUtil.getMetadata();
		AppDirectUserResponse userResponse = MockUtil.getUserResponse();
		
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectUserResponse>>notNull()))
        .thenReturn(Mono.just(userResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		AppDirectUserResponse apiResponse = appDirectOpportunityService.getUserDetails("companyExternalId", "userExternalId", metadata,errorNotes);
		
		assertNotNull(apiResponse);
		
	}
	
	@Test
	@Ignore
	public void invokeCreateOpportunityTest() throws Exception {
		Metadata metadata = MockUtil.getMetadata();
		ProductOrder productOrder = MockUtil.createProductOrderRequest();
		AppDirectCreateOpportunityResponse createOpportunityResponse = MockUtil.createOpportunityResponse();

		
		
		AppDirectPaymentPlanResponse paymentPlanResponse = MockUtil.getPaymentResponse();
		
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectPaymentPlanResponse>>notNull()))
        .thenReturn(Mono.just(paymentPlanResponse));
		
		Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.headers(any())).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.retrieve()).thenReturn(responseCreateOpportunitySpec);
		
		Mockito.when(responseCreateOpportunitySpec.bodyToMono(ArgumentMatchers.<Class<AppDirectCreateOpportunityResponse>>notNull())).thenReturn(Mono.just(createOpportunityResponse));
		
		List<Note> errorNotes = new ArrayList<>();
	    AppDirectCreateOpportunityResponse  apiResponse = appDirectOpportunityService.invokeCreateOpportunity(metadata,productOrder,
				"companyId", "userId",errorNotes);
	    assertNotNull(apiResponse);
	}
	
	@Test
	public void invokeFinalizeOpportunityTest() throws Exception{
		Metadata metadata = MockUtil.getMetadata();
		AppDirectFinalizeResponse finalizeOpportunityResponse = MockUtil.finalizeOpportunityResponse();
		
		Mockito.when(webClient.post()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectFinalizeResponse>>notNull()))
                .thenReturn(Mono.just(finalizeOpportunityResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		AppDirectFinalizeResponse apiResponse = appDirectOpportunityService.invokeFinalizeOpportunity("opportunityId", metadata, errorNotes);
		assertNotNull(apiResponse);
	}
	
	
	@Test
	public void invokePaymentPlanTest() throws Exception {
		
		Metadata metadata = MockUtil.getMetadata();
		AppDirectPaymentPlanResponse paymentPlanResponse = MockUtil.getPaymentResponse();
		
		Mockito.when(webClient.get()).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.uri(any(String.class))).thenReturn(requestHeadersUriSpec);
		Mockito.when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersSpec);
		Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<AppDirectPaymentPlanResponse>>notNull()))
        .thenReturn(Mono.just(paymentPlanResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		AppDirectPaymentPlanResponse apiResponse = appDirectOpportunityService.invokePaymentPlan(metadata,"paymentPlanId",errorNotes);
		
		assertNotNull(apiResponse);
	}
	
	@Test
	public void invokeApplyDiscountTest() throws Exception {
		ProductOrder productOrder = MockUtil.createProductOrderRequest();
		Metadata metadata = MockUtil.getMetadata();
		ApplyDiscountResponse applyDiscountResponse = MockUtil.getApplyDiscountResponse();
		
		Mockito.when(webClient.put()).thenReturn(requestBodyUriSpec);
		Mockito.when(requestBodyUriSpec.uri(any(String.class))).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.headers(any())).thenReturn(requestBodySpec);
		Mockito.when(requestBodySpec.retrieve()).thenReturn(responseSpec);
		Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<ApplyDiscountResponse>>notNull()))
        .thenReturn(Mono.just(applyDiscountResponse));
		
		List<Note> errorNotes = new ArrayList<>();
		appDirectOpportunityService.invokeApplyDiscount("opportunityId",metadata,productOrder,errorNotes);
		assertTrue(true);
	}
}
