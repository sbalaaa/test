package vf.vbps.dxl.productorder.test;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCompanyResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectCreateOpportunityResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectFinalizeResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectPaymentPlanResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.AppDirectUserResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.discount.apply.ApplyDiscountResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.AddItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.EditItemResponse;
import vf.vbps.dxl.productorder.backend.appdirect.model.item.GetItemsResponse;
import vf.vbps.dxl.productorder.backend.technical.model.AccessCredentialRef;
import vf.vbps.dxl.productorder.backend.technical.model.ApipathRef;
import vf.vbps.dxl.productorder.backend.technical.model.Metadata;
import vf.vbps.dxl.productorder.constants.ProductOrderConstants;
import vf.vbps.dxl.productorder.model.ProductOrder;
import vf.vbps.dxl.productorder.model.ProductOrderResponse;

public class MockUtil {
	
	public static ProductOrder createProductOrderRequest() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ProductOrder requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("create_productorder_request.json"), ProductOrder.class);
		return requestOject;
	}
	
	public static ProductOrderResponse createProductOrderResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ProductOrderResponse requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("create_productorder_response.json"), ProductOrderResponse.class);
		return requestOject;
	}
	
	public static List<GetItemsResponse> getItemsResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<GetItemsResponse> items = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("getItemsResponse.json"), new TypeReference<List<GetItemsResponse>>(){});
		return items;
	}
	
	public static List<AddItemResponse> addItemsResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		List<AddItemResponse> items = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("addItemResponse.json"), new TypeReference<List<AddItemResponse>>(){});
		return items;
	}
	
	public static EditItemResponse editItemResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		EditItemResponse item = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("editItemResponse.json"), EditItemResponse.class);
		return item;
	}
	
	public static AppDirectCompanyResponse getCompanyResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectCompanyResponse companyResponse = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("retrieveCompany.json"), AppDirectCompanyResponse.class);
		return companyResponse;
	}
	
	public static AppDirectUserResponse getUserResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectUserResponse userResponse = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("retrieveUsers.json"), AppDirectUserResponse.class);
		return userResponse;
	}
	
	
	public static ApplyDiscountResponse getApplyDiscountResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		ApplyDiscountResponse discountResponse = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("applyDiscount.json"), ApplyDiscountResponse.class);
		return discountResponse;
	}
	
	public static AppDirectCreateOpportunityResponse createOpportunityResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectCreateOpportunityResponse response = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("createOpportunitiesResponse.json"), AppDirectCreateOpportunityResponse.class);
		return response;
	}
	
	public static AppDirectPaymentPlanResponse getPaymentResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectPaymentPlanResponse paymentPlanResponse = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("retrievePayments.json"), AppDirectPaymentPlanResponse.class);
		return paymentPlanResponse;
	}
	
	public static AppDirectFinalizeResponse finalizeOpportunityResponse() throws Exception {
		ObjectMapper mapper =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		AppDirectFinalizeResponse requestOject = mapper.readValue(MockUtil.class.getClassLoader().getResourceAsStream("finalizeOpportunityResponse.json"), AppDirectFinalizeResponse.class);
		return requestOject;
	}
	
	public static Metadata getMetadata() {
		Metadata metadata = new Metadata();
		metadata.setBackendURL("http://localhost:8080/restservice");
		
		List<ApipathRef> apiPaths = new ArrayList<>();
		ApipathRef finalize = new ApipathRef();
		finalize.setId(ProductOrderConstants.FINALIZEOPPORTUNITY);
		finalize.setValue("/api/assistedSales/v1/opportunities/{opportunityId}/finalize");
		
		ApipathRef addItem = new ApipathRef();
		addItem.setId(ProductOrderConstants.ADDITEMS);
		addItem.setValue("/api/assistedSales/v1/opportunities/{opportunityId}/items");
		
		ApipathRef getItem = new ApipathRef();
		getItem.setId(ProductOrderConstants.GETITEMS);
		getItem.setValue("/api/assistedSales/v1/opportunities/{opportunityId}/items");
		
		ApipathRef editItem = new ApipathRef();
		editItem.setId(ProductOrderConstants.EDITITEM);
		editItem.setValue("/api/assistedSales/v1/opportunities/{opportunityId}/items/{iemid}");
		
		ApipathRef paymentPlan = new ApipathRef();
		paymentPlan.setId(ProductOrderConstants.PAYMENTDETAILS);
		paymentPlan.setValue("/marketplace/v1/paymentPlans/{paymentPlanId}");
		
		ApipathRef applyDiscount = new ApipathRef();
		applyDiscount.setId(ProductOrderConstants.APPLYDISCOUNT);
		applyDiscount.setValue("/assistedSales/v1/opportunities/{opportunityId}/discounts/{discountId}");
		
		ApipathRef createOpportunity = new ApipathRef();
		createOpportunity.setId(ProductOrderConstants.CREATEOPPORTUNITY);
		createOpportunity.setValue("/assistedSales/v1/opportunities");
		
		apiPaths.add(finalize);
		apiPaths.add(addItem);
		apiPaths.add(getItem);
		apiPaths.add(editItem);
		apiPaths.add(paymentPlan);
		apiPaths.add(applyDiscount);
		apiPaths.add(createOpportunity);
		
		List<AccessCredentialRef> accessCredentials = new ArrayList<>();
		AccessCredentialRef credentialRef = new AccessCredentialRef();
		credentialRef.setId("TOKEN");
		credentialRef.setValue("1wYgQkKWNugfyzoHIpzaqk0WbMk7");
		accessCredentials.add(credentialRef);
		
		
		metadata.setApiPaths(apiPaths);
		metadata.setAccessCredentials(accessCredentials);
		
		return metadata;
	}

}
