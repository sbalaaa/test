package com.training.equal;

import com.training.entity.Employee;

public class EmployeeEqualTest {

	
	public static void main(String args[]){
		
		Employee first = new Employee();
		first.setFirstName("Ravi");
		first.setLastName("Sankar");
		
		Employee second = new Employee();
		second.setFirstName("Ravi");
		second.setLastName("Sankar");
		
		
		//second = first;
		
		System.out.println(first + " & "  + second + "	are equal is 	: " + first.equals(second));
		
	}
}
