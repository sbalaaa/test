package com.training.set;

import java.util.HashSet;
import java.util.Set;

import com.training.entity.Employee;

public class EmployeeHashSetTest {

	
public static void main(String args[]){
		
		Employee first = new Employee();
		first.setFirstName("Ravi");
		first.setLastName("Sankar");
		
		Employee second = new Employee();
		second.setFirstName("Ravi");
		second.setLastName("Sankar");
		
		Set<Employee> employeeSet = new HashSet<Employee>();
		
		System.out.println("Adding first Employee");
		employeeSet.add(first);
		
		System.out.println("Employee Set Size is :" + employeeSet.size());
		
		System.out.println("Adding Second Employee");
		employeeSet.add(second);
		
		System.out.println("Employee Set Size is :" + employeeSet.size());
		
	}
	
	
}
