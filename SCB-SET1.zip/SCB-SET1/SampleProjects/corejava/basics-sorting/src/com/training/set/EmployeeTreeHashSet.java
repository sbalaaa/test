package com.training.set;

import java.util.Set;
import java.util.TreeSet;

import com.training.entity.Employee;

public class EmployeeTreeHashSet {

public static void main(String args[]){
		
		Employee first = new Employee();
		first.setFirstName("Ravi");
		first.setLastName("Sankar");
		
		Employee second = new Employee();
		second.setFirstName("Ravi");
		second.setLastName("Sankar");
		
		Set<Employee> employeeSet = new TreeSet<Employee>();
		
		System.out.println("Adding first Employee");
		employeeSet.add(first);
		
		System.out.println("Employee Set Size is :" + employeeSet.size());
		
		System.out.println("Adding Second Employee");
		employeeSet.add(second);
		
		System.out.println("Employee Set Size is :" + employeeSet.size());
		
	}
	
	
}
