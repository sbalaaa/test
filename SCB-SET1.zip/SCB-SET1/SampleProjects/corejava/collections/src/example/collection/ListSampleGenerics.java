package example.collection;

import java.util.ArrayList;

public class ListSampleGenerics {

	public ListSampleGenerics() {
		// TODO Auto-generated constructor stub
	}
	
	
	static public void main(String[] args) {
		ArrayList<String> argsList =
				new ArrayList<String>();
		for(String str : args) {
			 argsList.add(str); // argsList.add(7) would fail
		}
		if(argsList.contains("Koko")) {
			System.out.println("We have Koko");
		}
		String first = argsList.get(0); // no casting!
		System.out.println("First: " + first);	
		
		//argsList.add(new Integer(10));
		
	}


}
