package example.collection.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class HashMapSample {

	public HashMapSample() {
		// TODO Auto-generated constructor stub
	}
	
	
	public static void main(String args[]){
		
		HashMap<String,String> strMap = new HashMap<String,String>();
		// adding values inside map
		strMap.put("a", "apple");
		strMap.put("b", "banana");
		strMap.put("o", "orange");
		strMap.put("A", "APPLE");
		
		// get value from map
		System.out.println(strMap.get("a"));
		strMap.put("a", "APPLE");
		// get value from map after overwrite it
		System.out.println(strMap.get("a"));
		System.out.println();
		
		
		System.out.println("Keys inside map are  : ->>      ");
		Set<String> keySet = strMap.keySet();
		for(String key:keySet){
			System.out.print(key);
			System.out.print("\t");
		}
		System.out.println();
		
		System.out.println();
		System.out.println("Values inside map are  : ->>      ");
		Collection<String> values = strMap.values();
		for(String value:values){
			System.out.print(value);
			System.out.print("\t");
		}
		System.out.println();
		
		
		System.out.println();
		System.out.println("Keys/Values inside map are  : ->>      ");
		Set<Map.Entry<String,String>> entrySet =strMap.entrySet();
		for(Map.Entry<String,String> entry:entrySet){
			System.out.print(entry.getKey());
			System.out.print("\t");
			System.out.print(entry.getValue());
			System.out.println();
		}
		System.out.println();
		
		
		System.out.println();
		System.out.println("Get all the value using key   : ->>      ");
		keySet = strMap.keySet();
		for(String key:keySet){
			System.out.print(key);
			System.out.print("\t");
			System.out.println(strMap.get(key));
		}
	}

}
