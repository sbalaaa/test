package example.collection.queue;

import java.util.Collection;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueQueue {

	public PriorityQueueQueue() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		PriorityQueue<String> fruitQueue = new PriorityQueue<String>();
		fruitQueue.add("Orange");fruitQueue.add("Pappaya");fruitQueue.add("Apple");fruitQueue.add("Bannana");
		System.out.println(fruitQueue);

		

		
		PriorityQueue<Employee> employees = new PriorityQueue<Employee>(10, new Comparator<Employee>(){
			@Override
			public int compare(Employee arg0, Employee arg1) {
				if(arg0.getEmployeeId() < arg1.getEmployeeId()){
					return -1;
				}else if(arg0.getEmployeeId() > arg1.getEmployeeId()){
					return 1;
				}else{
					return 0;
				}
			}
			
		});
		
		getEmployees(employees);
		
		System.out.println(employees.poll());
		System.out.println(employees.poll());
		System.out.println(employees.poll());
		System.out.println(employees.poll());
		
		System.out.println(employees);
	}

	
	
	static void getEmployees(Collection<Employee> employees){
		Employee one = new Employee();
		one.setEmployeeId(3);one.setFirstName("Martin");one.setLastName("Ford");one.setAge(40);one.setSalary(10000);
		Employee two = new Employee();
		two.setEmployeeId(2);two.setFirstName("Balachandar");two.setLastName("Sivalingam");two.setAge(36);two.setSalary(5000);
		Employee three = new Employee();
		three.setEmployeeId(1);three.setFirstName("Zavin");three.setLastName("Soffer");three.setAge(37);three.setSalary(6000);
		
		employees.add(one);
		employees.add(two);
		employees.add(three);
		
	}
}



class Employee{
	
	int employeeId;
	String firstName;
	String lastName;
	int salary;
	int age;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", age=" + age + "]";
	}
	
	
	
	
	
	
	
	
	
}