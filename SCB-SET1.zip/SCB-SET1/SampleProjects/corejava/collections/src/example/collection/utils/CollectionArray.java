package example.collection.utils;

import java.util.ArrayList;
import java.util.List;

public class CollectionArray {

	public static void main(String args[]){
		
		List<String> strList = new ArrayList<>();
		strList.add("one");
		strList.add("two");
		
		Object[] obj = strList.toArray();
		for(Object str : obj){
			System.out.println(str);
		}
		
		String[] strArray = new String[strList.size()];
		strArray = strList.toArray(strArray);
		for(String str : strArray){
			System.out.println(str);
		}
	}
	
	
}
