package example.collection.utils;

import java.util.Comparator;

class EmployeeAgeComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee arg0, Employee arg1) {
		if(arg0.getAge() < arg1.getAge()){
			return -1;
		}else if(arg0.getAge() > arg1.getAge()){
			return 1;
		}else{
			return 0;
		}
	}
	
}
