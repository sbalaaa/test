package example.collection.utils;

import java.util.Comparator;

class EmployeeSalaryComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee arg0, Employee arg1) {
		if(arg0.getSalary() < arg1.getSalary()){
			return -1;
		}else if(arg0.getSalary() > arg1.getSalary()){
			return 1;
		}else{
			return 0;
		}
	}
	
}
