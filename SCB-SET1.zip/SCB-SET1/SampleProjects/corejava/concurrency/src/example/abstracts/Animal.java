package example.abstracts;

public abstract class Animal {
	public void whoIAM(){
		System.out.println("I am animal");
	}
	
	public abstract void eat();
}
