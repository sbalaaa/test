package example.abstracts;

public class Cow extends Animal {

	@Override
	public void eat() {
		System.out.println("I eat Veg");
	}

}
