package example.abstracts;

public class Lion extends Animal {

	@Override
	public void eat() {
		System.out.println("I eat Non-veg");

	}

}
