package example.accessmodifer.first;

public class FirstBaseClass {

	String noModifierFirstBase = " I am noModifer in FirstBaseClass";
	private String privateModifierFirstBase = " I am privateModifier in FirstBaseClass";
	protected String protectedModifierFirstBase = " I am protectedModifier in FirstBaseClass";
	protected String publicModifierFirstBase = " I am publicModifier in FirstBaseClass";
	
	private void printFirstBaseClassVariables(){
		System.out.println(noModifierFirstBase);
		System.out.println(privateModifierFirstBase);
		System.out.println(protectedModifierFirstBase);
		System.out.println(publicModifierFirstBase);
	}
	
	
	public static void main(String args[]){
		
		FirstBaseClass firstBaseClassObj = new FirstBaseClass();
		firstBaseClassObj.printFirstBaseClassVariables();
		
	}
	
}
