package example.accessmodifer.first;

public class FirstSubClass extends FirstBaseClass {

	String noModifierFirstSub = " I am noModifer in FirstSubClass";
	private String privateModifierFirstSub = " I am privateModifier in FirstSubClass";
	protected String protectedModifierFirstSub = " I am protectedModifier in FirstSubClass";
	protected String publicModifierFirstSub = " I am publicModifier in FirstSubClass";
	
	private void printFirstSubClassVariables(){
		//From Base Class in the same package
		System.out.println(noModifierFirstBase);
		//System.out.println(privateModifierFirstBase); // If you remove the comment, it will not compile since it has private access modifier
		System.out.println(protectedModifierFirstBase);
		System.out.println(publicModifierFirstBase);
		System.out.println();
		//From With in the same class
		System.out.println(noModifierFirstSub);
		System.out.println(privateModifierFirstSub);
		System.out.println(protectedModifierFirstSub);
		System.out.println(publicModifierFirstSub);
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirstSubClass obj = new FirstSubClass();
		obj.printFirstSubClassVariables();
	}

}
