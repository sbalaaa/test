package example.accessmodifer.second;

import example.accessmodifer.first.FirstBaseClass;

public class SecondBaseClass extends FirstBaseClass{

	String noModifierSecondBase = " I am noModifer in SecondBaseClass";
	private String privateModifierSecondBase = " I am privateModifier in SecondBaseClass";
	protected String protectedModifierSecondBase = " I am protectedModifier in SecondBaseClass";
	protected String publicModifierSecondBase = " I am publicModifier in SecondBaseClass";
	
	private void printSecondBaseClassVariables(){
		System.out.println(noModifierSecondBase);
		System.out.println(privateModifierSecondBase);
		System.out.println(protectedModifierSecondBase);
		System.out.println(publicModifierSecondBase);
		System.out.println();
		
		//From Base Class in the First(another) package
		//System.out.println(noModifierFirstBase);      // // If you remove the comment, it will not compile since it has default access modifier
		//System.out.println(privateModifierFirstBase); // If you remove the comment, it will not compile since it has private access modifier
		System.out.println(protectedModifierFirstBase);
		System.out.println(publicModifierFirstBase);
		
		FirstBaseClass obj = new FirstBaseClass();
		/**
		 * If we remove the below comment, it will not compile since protected access modifier is being
		 * accessed through creating object, not through inheritance
		 */
		//System.out.println(obj.protectedModifierFirstBase); 
		
		/**
		The below code does not work, since this class is in other package and is not imported.
		System.out.println(noModifierFirstSub);
		System.out.println(privateModifierFirstSub);
		System.out.println(protectedModifierFirstSub);
		System.out.println(publicModifierFirstSub);
		
		**/
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SecondBaseClass secondBaseClassObj = new SecondBaseClass();
		secondBaseClassObj.printSecondBaseClassVariables();

	}

}
