package example.collection;

import java.util.ArrayList;

public class ListSample {

	public ListSample() {
	}

	public static void main(String[] args) {
		
		
		ArrayList argsList = new ArrayList();
		for(String str : args) {
			 argsList.add(str);
		}
		if(argsList.contains("Koko")) {
			System.out.println("We have Koko");
		}
		String first = (String)argsList.get(0);
		System.out.println("First: " + first);	

		

	}

}
