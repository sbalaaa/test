package example.collection.set;

import java.util.Collection;
import java.util.HashSet;


public class HashSetSample {

	public HashSetSample() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String args[]){
		HashSet<String> strSet = new HashSet<String>();
		strSet.add("Papaya");strSet.add("Apple");strSet.add("Banana");strSet.add("Apple");strSet.add("Papaya");
		
		for(String obj : strSet){
			System.out.println(obj);
		}
		
		HashSet<Employee> employeeSet = new HashSet<Employee>();
		getEmployees(employeeSet);
		for(Employee obj : employeeSet){
			System.out.println(obj);
		}
	}
	
	
	
	static void getEmployees(Collection<Employee> employees){
		Employee one = new Employee(3,"Martin","Ford",40,1000);
		Employee two = new Employee(2,"Balachandar","Sivalingam",36,5000);
		Employee three = new Employee(1,"Zavin","Soffer",37,6000);
		Employee four = new Employee(1,"Zavin","Soffer",37,6000);
		
		employees.add(one);
		employees.add(two);
		employees.add(three);
		employees.add(four);
		
	}
	

}

/*

class Employee{
	
	int employeeId;
	String firstName;
	String lastName;
	int salary;
	int age;
	
	
	public Employee(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public Employee(int employeeId, String firstName, String lastName,int salary, int age) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.age = age;
		
	}
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employeeId;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId != other.employeeId)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", age=" + age + "]";
	}
	

}*/


class Employee implements Comparable<Employee>{
	
	int employeeId;
	String firstName;
	String lastName;
	int salary;
	int age;
	
	public Employee(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public Employee(int employeeId, String firstName, String lastName,int salary, int age) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.age = age;
		
	}
	
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employeeId;
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId != other.employeeId)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", age=" + age + "]";
	}
	

	@Override
	public int compareTo(Employee o) {
		if(this.getEmployeeId() < o.getEmployeeId()){
			return -1;
		}else if(this.getEmployeeId() > o.getEmployeeId()){
			return 1;
		}else{
			return 0;
		}
	}
	

}