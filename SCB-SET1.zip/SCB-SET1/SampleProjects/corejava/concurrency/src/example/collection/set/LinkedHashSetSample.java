package example.collection.set;

import java.util.Collection;
import java.util.LinkedHashSet;




public class LinkedHashSetSample {

	public LinkedHashSetSample() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String args[]){
		LinkedHashSet<String> strSet = new LinkedHashSet<String>();
		strSet.add("Papaya");strSet.add("Apple");strSet.add("Banana");strSet.add("Apple");strSet.add("Papaya");
		
		for(String obj : strSet){
			System.out.println(obj);
		}
		
		LinkedHashSet<Employee> employeeSet = new LinkedHashSet<Employee>();
		getEmployees(employeeSet);
		for(Employee obj : employeeSet){
			System.out.println(obj);
		}
	}
	
	
	
	static void getEmployees(Collection<Employee> employees){
		Employee one = new Employee(3,"Martin","Ford",40,1000);
		Employee two = new Employee(2,"Balachandar","Sivalingam",36,5000);
		Employee three = new Employee(1,"Zavin","Soffer",37,6000);
		Employee four = new Employee(1,"Zavin","Soffer",37,6000);
		
		employees.add(one);
		employees.add(two);
		employees.add(three);
		employees.add(four);
		
	}
	
}


