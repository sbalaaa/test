package example.collection.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;


public class Employee implements Comparable<Employee>{

	
	int employeeId;
	String firstName;
	String lastName;
	int salary;
	int age;
	
	public Employee(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public Employee(int employeeId, String firstName, String lastName,int salary, int age) {
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.age = age;
		
	}

	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", salary=" + salary
				+ ", age=" + age + "]";
	}
	
	
	public static void main(String[] args) {
		ArrayList<Employee> employees = new ArrayList<Employee>();
		getEmployees(employees);

		System.out.println("----Before Sort----");
		for(Employee obj : employees){
			System.out.println(obj);
		}
		
		System.out.println("----After Sort--using Default Comparable--");
		Collections.sort(employees);
		for(Employee obj : employees){
			System.out.println(obj);
		}
		
		
		System.out.println("----After Sort--using Employee Salary Comparator--");
		Collections.sort(employees,new EmployeeSalaryComparator());
		for(Employee obj : employees){
			System.out.println(obj);
		}
		
		System.out.println("----After Sort--using Employee Age Comparator--");
		Collections.sort(employees,new EmployeeAgeComparator());
		for(Employee obj : employees){
			System.out.println(obj);
		}

	}


	@Override
	public int compareTo(Employee arg0) {
		if(this.getEmployeeId() < arg0.getEmployeeId()){
			return -1;
		}else if(this.getEmployeeId() > arg0.getEmployeeId()){
			return 1;
		}else{
			return 0;
		}
	}
	
	
	static void getEmployees(Collection<Employee> employees){
		Employee one = new Employee(3,"Martin","Ford",40,1000);
		Employee two = new Employee(2,"Balachandar","Sivalingam",36,5000);
		Employee three = new Employee(1,"Zavin","Soffer",35,6000);
		
		employees.add(one);
		employees.add(two);
		employees.add(three);
		
	}
	
	static class EmployeeSalaryComparator implements Comparator<Employee>{

		@Override
		public int compare(Employee arg0, Employee arg1) {
			if(arg0.getSalary() < arg1.getSalary()){
				return -1;
			}else if(arg0.getSalary() > arg1.getSalary()){
				return 1;
			}else{
				return 0;
			}
		}
		
	}
	
	
	static class EmployeeAgeComparator implements Comparator<Employee>{

		@Override
		public int compare(Employee arg0, Employee arg1) {
			if(arg0.getAge() < arg1.getAge()){
				return -1;
			}else if(arg0.getAge() > arg1.getAge()){
				return 1;
			}else{
				return 0;
			}
		}
		
	}

}
