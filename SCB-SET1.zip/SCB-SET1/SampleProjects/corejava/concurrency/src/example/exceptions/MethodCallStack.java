package example.exceptions;

public class MethodCallStack {

	
	static void function(){
		System.out.println("I am function > going to raise exception");
		String s = null;
		s.length();
		System.out.println("function end");
	}
	
	
	static void method(){
		System.out.println("I am method -> going to call function");
		function();
		System.out.println("method end");
	}
	
	public static void main(String args[]){
		System.out.println("I am main method > executon starts");
		method();
		System.out.println("main and execution end");
	}
	
}
