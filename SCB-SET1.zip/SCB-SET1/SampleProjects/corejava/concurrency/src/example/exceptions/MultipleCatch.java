package example.exceptions;

public class MultipleCatch {

	static void function(){
		System.out.println("I am function > going to raise exception");
		//String s = null;
		String s = "Welcome";
		try{
			System.out.println("Length is: " + s.length());
			System.out.println("First Three chacracter of welcome is: " + s.substring(0,8));
		}catch(NullPointerException e){
			System.out.println("I am inside NullPointerException");
		}catch(IndexOutOfBoundsException e){
			System.out.println("I am inside IndexOutOfBoundsException");
		}catch(Exception e){
			System.out.println("I am inside Exception. I will catch most of the exception");
		}catch(Throwable e){
			System.out.println("I am inside Throwable. I do not leave any exceptions and error");
		}
		System.out.println("function end");
	}
	
	
	static void method(){
		System.out.println("I am method -> going to call function");
		function();
		System.out.println("method end");
	}
	
	public static void main(String args[]){
		System.out.println("I am main method > executon starts");
		method();
		System.out.println("main and execution end");
	}
	
	
}
