package example.exceptions;

public class Try {

	
	static void function(){
		System.out.println("I am function > going to raise exception");
		String s = null;
		try{
			s.length();
		}catch(Exception e){
			// Bad way of exception handling without anything in the catch block
			// what is the proper way handling the exception?
		}
		System.out.println("function end");
	}
	
	
	static void method(){
		System.out.println("I am method -> going to call function");
		function();
		System.out.println("method end");
	}
	
	public static void main(String args[]){
		System.out.println("I am main method > executon starts");
		method();
		System.out.println("main and execution end");
	}
	
}
