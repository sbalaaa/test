package example.exceptions.throwss;

public class MainPrograme {

	public MainPrograme() {
	}

	
	static void readDevelopers(){
		ReadFile rf = new ReadFile();
		rf.readDeveloper();
	}
	
	public static void main(String[] args) {
		readDevelopers();
	}

}
