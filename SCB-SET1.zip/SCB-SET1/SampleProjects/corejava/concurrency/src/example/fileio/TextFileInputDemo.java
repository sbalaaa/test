package example.fileio;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TextFileInputDemo {

	public TextFileInputDemo() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args)
	   {
	      String fileName = "C://balachandar//workspace-new//concurrent//simple//out.txt"; 
	      try
	      { 
	         BufferedReader inputStream =
	            new BufferedReader(new FileReader(fileName));
	         String line = null;
	         line = inputStream.readLine();
	         System.out.println("The first line in " + fileName + " is:");
	         System.out.println(line);
		     inputStream.close();         
	      }
	      catch(FileNotFoundException e)
	      {
		System.out.println("File " + fileName + " not found.");
	      }
	      catch(IOException e)
	      {
	         System.out.println("Error reading from file " + fileName);
	      }
	   }


}
