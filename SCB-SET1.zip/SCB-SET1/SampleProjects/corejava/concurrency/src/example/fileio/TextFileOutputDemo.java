package example.fileio;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class TextFileOutputDemo {

	public TextFileOutputDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		PrintWriter outputStream = null;
		   try
		   {
		       outputStream =
		            new PrintWriter(new FileOutputStream("out.txt"));
		       outputStream.println("Balachandar");
		       outputStream.println("RaviShankar");
		       outputStream.close();
		       System.out.println("File Created Successfully");
		   }
		   catch(FileNotFoundException e)
		   {
		       System.out.println("Error opening the file out.txt. "
		                          + e.getMessage());
		       System.exit(0);
		   }


	}

}
