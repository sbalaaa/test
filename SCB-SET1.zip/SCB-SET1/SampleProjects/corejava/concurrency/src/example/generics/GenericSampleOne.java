package example.generics;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class GenericSampleOne {

	public GenericSampleOne() {
		// TODO Auto-generated constructor stub
	}
	
	
    public static void main(String args[]){
    	/*1 Piece*/
    	
    	List<String> ls = new ArrayList<String>();
    	List<Object> lo = new ArrayList<Object>();
    	//lo = ls;  //-> remove the comment and check

    	lo.add(0, new Object()); // legal?!
    	//ls.get(0); // Not a string?!
    	
    	/*1 Piece*/  //------------------->
    	
    	/*2 Piece*/
    	ls.add("one");ls.add("two");
    	printCollection(ls);
    	
    	
    	/*2 Piece*///------------------->

    }
    
    
   /* void printCollection(Collection<Object> c) {
    	for (Object e: c){
    		System.out.println(e);
    	}
    }*/
    
    static void printCollection(Collection<?> c) {
    	for (Object e: c){
    		System.out.println(e);
    	}
    }

	
	
}
