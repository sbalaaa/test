package example.interfaces;

public interface AbstractDAO {
	void save();
	void update();
	void delete();
}
