package sample;

public class Car extends Vechile {

	private int carNo = 10;
	public void printCarInfo() {
		System.out.println("Car number: " + carNo);
		System.out.println("No of Tyres: " + noOfTyres); // Inherited.
		System.out.println("Brand: " + brand); // Inherited.
		getNoOfVehicles(); // Inherited.
	}

}


// http://www.javabeginner.com/learn-java/java-inheritance