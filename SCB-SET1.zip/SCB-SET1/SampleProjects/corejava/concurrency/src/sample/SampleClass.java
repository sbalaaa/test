package sample;

public class SampleClass {
		
		
		
		public static void main(String args[]){
			 
		}
	
	
		

}
