package sample;

public class Vechile {

	// Instance fields
	int noOfTyres = 2; // no of tyres
	protected String brand = "Ford"; // Brand of the car
	// Static fields
	private static int counter; // No of Vehicle objects created
	
	
	
	public void getBrand() {
		System.out.println("Vehicle Brand: " + brand);
	}
	// Static methods
	public static void getNoOfVehicles() {
		System.out.println("Number of Vehicles: " + counter);
	}
	
	public void getNoOfTyres() {
		System.out.println("Number of Tyres: " + brand);
	}



}
