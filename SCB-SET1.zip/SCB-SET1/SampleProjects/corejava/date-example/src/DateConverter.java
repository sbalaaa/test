import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateConverter { 
	public static void main(String args[]) throws ParseException { 
		// contains both date and time information 
		java.util.Date utilDate = new java.util.Date(); 
		System.out.println("Util date in Java : " + utilDate); // contains only date information without time 
		java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime()); 
		System.out.println("SQL date in Java : " + sqlDate); 
		System.out.printf("Time : %s:%s:%s", sqlDate.getHours(), sqlDate.getMinutes(), sqlDate.getSeconds()); 
		
		
		
		
		 //string containing date
		 String strDate = "2011-12-31 00:00:00";
		 /*
		  * To convert String to java.sql.Date, use
		  * Date (long date) constructor.
		  * 
		  * It creates java.sql.Date object from the milliseconds provided.
		  */
		 
		//first convert string to java.util.Date object using SimpleDateFormat
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		 java.util.Date date = sdf.parse(strDate);
		 
		 java.sql.Date sqlDatee = new Date(date.getTime());
		 System.out.println("String converted to java.sql.Date :" + sqlDate);
		
	} 
}

