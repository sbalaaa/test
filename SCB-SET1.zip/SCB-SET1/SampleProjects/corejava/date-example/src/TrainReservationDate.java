import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class TrainReservationDate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			bookingDate("10/10/2013"); // -> // dd/MM/yyyy date format for example "14/09/2011"
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private static void bookingDate(String travelDate) throws ParseException{
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		
    	System.out.println("Travel Date is : " + dateFormat.parse(travelDate));
    	
    	Calendar cal = Calendar.getInstance();
    	cal.setTime(dateFormat.parse(travelDate));
    	
    	cal.add(Calendar.DATE, -60);
    	
    	System.out.println("Booking Date is : " + dateFormat.format(cal.getTime()));
		
		//Calendar cal = Calendar.getInstance();
		//System.out.println("Current Date Time : " + dateFormat.format(cal.getTime()));
	}
	
}


// http://javarevisited.blogspot.in/2011/09/step-by-step-guide-to-convert-string-to.html