
public class ArrayExample {

	public static void main(String[] args) {
		
		int[] i = new int[3];
		i[0] = 10;
		i[1] = 20;
		i[2] = 30;
		
		int[] j = {100,200,300};
		
		System.out.println("Printing Array I");
		System.out.println("Length of Array I is " + i.length);
		
		for(int k =0 ; k < i.length ; k++) {
			System.out.println("i @ " + k + " is ->  " + i[k]);
		}
		
		
		System.out.println("Printing Array J");
		
		for(int k =0 ; k < i.length ; k++) {
			System.out.println("j @ " + k + " is ->  " + j[k]);
		}
	}
	
	
}
