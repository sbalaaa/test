package example.exceptions;

import java.util.Arrays;
import java.util.Scanner;

public class Throw {

	static String[] developers = {"Teja","SivaRanjani","MarySopna"};
	
	public Throw() {
		// TODO Auto-generated constructor stub
	}
	
	private static boolean isDeveloperExist(String developerName) throws UserNotFoundException{
		if(Arrays.asList(developers).contains(developerName)){
			return true;
		}else{
			throw new UserNotFoundException();
		}
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Please Enter the Name:");
		String developerName = sc.nextLine();
		try {
			if(isDeveloperExist(developerName)){
				System.out.println("Developer Found");
			}else{
				System.out.println("Developer Not Found");
			}
		} catch (UserNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}


/*
Assignment 1: What are the ways we have remove the compile time error.
Assignment 2: What we should do to print Developer Not Found in case developers is not found.


*/