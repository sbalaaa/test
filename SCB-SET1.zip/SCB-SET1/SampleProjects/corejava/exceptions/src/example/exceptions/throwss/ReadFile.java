package example.exceptions.throwss;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile {

	public ReadFile() {
		// TODO Auto-generated constructor stub
	}
	
	public void readDeveloper(){
		BufferedReader br = null;
		 
		try {
 			String sCurrentLine;
 			br = new BufferedReader(new FileReader("javadevelopers.txt"));
 			while ((sCurrentLine = br.readLine()) != null) {
				System.out.println(sCurrentLine);
			}
 		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	@SuppressWarnings("resource")
	public void readDeveloperAnother() throws IOException{
		BufferedReader br = null;
		String sCurrentLine;
		br = new BufferedReader(new FileReader("javadevelopers.txt"));
		while ((sCurrentLine = br.readLine()) != null) {
			System.out.println(sCurrentLine);
		}	
 	
	}

}
