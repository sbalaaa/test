public class OuterClass {

	int outer_x = 100;
	static int static_outer_x = 200;

	class InnerClass {
		void display() {
			System.out.println("display: outer_x = " + outer_x);
			System.out.println("display: static_outer_x = " + static_outer_x);
		}
	}

	static class StaticInnerClass {
		void display() {
			// System.out.println("display: outer_x = " + outer_x);
			System.out.println("display: static_outer_x = " + static_outer_x);
		}
	}

	void localTest() {
		class MethodInnerClass {
			void display() {
				System.out.println("display from method local inner class: outer_x = " + outer_x);
			}
		}
		MethodInnerClass inner = new MethodInnerClass();
		inner.display();

	}

	public void show() {
		System.out.println("Display from show method");
	}
	
	public static void main(String[] args) {
		OuterClass outer = new OuterClass();
		InnerClass inner = outer.new InnerClass();
		inner.display();
		
		
		OuterClass.StaticInnerClass staticInner = new OuterClass.StaticInnerClass();
		staticInner.display();
		
		outer.localTest();

		
		OuterClass annonyMouseouter = new OuterClass() {
			public void show() {
				System.out.println("Display from show method ---Annonymous Class");
			}
		};
		
		annonyMouseouter.show();
	}

}
