package exercise;

public class Count {

	public static int words = 1, characters = 0, vowels = 0;
	
	public static void main (String args[]){
		
		
		int i = 0;
		try {
			String str = "santhosh good boy";
			int length = str.length() -1;
			while (i <=  length) {

				if (str.charAt(i) == 'a' || str.charAt(i) == 'e'
						|| str.charAt(i) == 'i' || str.charAt(i) == 'o'
						|| str.charAt(i) == 'u' || str.charAt(i) == 'A'
						|| str.charAt(i) == 'E' || str.charAt(i) == 'I'
						|| str.charAt(i) == 'O' || str.charAt(i) == 'U') {
					vowels++;
				}
				if (str.charAt(i) == ' ') {
					words++;

				}
				if (str.charAt(i) != ' ') {
					characters++;
				}
				i++;
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		System.out.println("no of words are:" + words);
		System.out.println("no of vowels are:" + vowels);
		System.out.println("no of characters are:" + characters);

		
		
	}

	
	
}
