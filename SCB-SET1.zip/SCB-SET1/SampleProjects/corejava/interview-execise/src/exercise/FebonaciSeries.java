package exercise;

public class FebonaciSeries {
	int a = 0, b = 1, c;

	public void feboNaci(int num) {

		if (num == 0) {
			System.out.println(a);
		}
		if (num == 1) {
			System.out.println(a);
			System.out.println(b);
		}

		System.out.println(a);
		System.out.println(b);

		do {
			c = a + b;
			a = b;
			b = c;
			System.out.println(c);

		} while (c <= num);
	}

	public static void main(String[] args) {
		FebonaciSeries obj = new FebonaciSeries();
		obj.feboNaci(10);

	}
}
