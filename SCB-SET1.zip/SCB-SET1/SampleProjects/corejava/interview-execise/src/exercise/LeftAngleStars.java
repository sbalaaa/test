package exercise;

public class LeftAngleStars {

	public static void main(String[] args) {
		int n = 5;
		int i, k;
		for (i = 1; i <= n; i++) {
			
			for (k = 1; k <= i; k++) {
				System.out.print("*");
				// System.out.print(" ");
			}

			System.out.println();
		}
	}
	
	
}
