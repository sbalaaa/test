package exercise;

import java.io.*;

public class OccurancesInArray {
	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("How many elements you want to enter in the array: ");
		int num = 0;
		try {
			num = Integer.parseInt(in.readLine());
		} catch (NumberFormatException ne) {
			System.out.println(ne.getMessage() + " is not a number!");
			System.exit(0);
		}
		String[] elements = new String[num];
		int checking;
		int no_of_occurences;
		for (int i = 0; i < num; i++) {
			elements[i] = in.readLine();
		}
		for (int i = 0; i < elements.length; i++) {
			checking = 0;
			no_of_occurences = 1;
			for (int j = 0; j < elements.length; j++) {
				//System.out.println("I =: " + i  + "	J =: " + j  );
				if (j >= i) {
					if (elements[i].equals(elements[j]) && j != i) {
						no_of_occurences++;
					}
				} else if (elements[i].equals(elements[j])) {
					//System.out.println("I is: " + i  + "	J is: " + j  );
					checking = 1;

				}

			}// inner for loop

			if (checking != 1) {
				System.out.println("Occurance of \'" + elements[i] + "\' : "
						+ no_of_occurences);
			}
		}// outer for loop
	}// method close
}// class close

