package exercise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class PrimeNumber {
	
	public static void main(String[] args) throws NumberFormatException,
			IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("enter number to check for primary or not");
		int count = 0;
		int num = Integer.parseInt(br.readLine());

		if (num == 0 || num == 1)
			System.out.println("please enter number greater then 2");

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				count++;
			}
			if (count == 1) {
				System.out.println("given number is not a prime");
				break;
			}
		}
		if (count == 0) {
			System.out.println("given number is prime");
		}

	}

}

