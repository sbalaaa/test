package exercise;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class ReverseNumber {

	public static int finding_number_length(int number) {
		int length = 0;

		while (number > 0) {
			number = number / 10;
			length++;
		}

		return length;
	}

	public static void display(int num, int length) {

		int temp = 1;
		for (int i = 1; i <= length - 1; i++) {
			temp = temp * 10;
		}
		System.out.println(num * temp);
		return;
	}

	public static void main(String args[]) {
		int count = 0;
		try {
			BufferedReader object = new BufferedReader(new InputStreamReader(
					System.in));
			System.out.println("Enter number");
			int num = Integer.parseInt(object.readLine());
			int n = num;
			int rev = 0;

			System.out.println("Number: ");
			System.out.println(" " + num);
			count = finding_number_length(num);

			while (num > 0) {
				int r = num % 10;
				display(r, count);
				count = count - 1;
				num = num / 10;
				rev = rev * 10 + r;

			}

			 System.out.println("After reversing the number: " + " ");
			 System.out.println(" " + rev); System.out.println(count); 
			 if (n == rev) { System.out.print("Number is palindrome!"); 
			 } else {
			  System.out.println("Number is not palindrome!"); 
			 }
			
			} catch (Exception e) {
			System.out.println("Out of range!");
			}
	}
}

