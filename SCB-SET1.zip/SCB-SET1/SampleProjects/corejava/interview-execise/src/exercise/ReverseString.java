package exercise;

class ReverseString {
	public static String reverseIt(String source) {
		int i, len = source.length();
		StringBuilder dest = new StringBuilder(len);

		for (i = (len - 1); i >= 0; i--)
			dest.append(source.charAt(i));
		return dest.toString();
	}
	
	public static void main(String[] args) {
		String str = "santhu ";
		System.out.println(reverseIt(str));
	}
	
	public static String reverseOpproachTwo(String source) {
		
		byte [] strAsByteArray = source.getBytes();
		 
        byte [] result = 
                   new byte [strAsByteArray.length];
 
        // Store result in reverse order into the
        // result byte[]
        for (int i = 0; i<strAsByteArray.length; i++)
            result[i] = 
             strAsByteArray[strAsByteArray.length-i-1];
 
        String resultStr = new String(result);
        
        System.out.println(new String(result));
        
        return resultStr;
		
	}
	
	public static String reverseOpproachThree(String source) {
		
		byte [] strAsByteArray = source.getBytes();
		 
        byte [] result = 
                   new byte [strAsByteArray.length];
 
        // Store result in reverse order into the
        // result byte[]
        for (int i = 0; i<strAsByteArray.length; i++)
            result[i] = 
             strAsByteArray[strAsByteArray.length-i-1];
 
        String resultStr = new String(result);
        
        System.out.println(new String(result));
       
        return resultStr;
		
	}
	
	
	public static void  reverseOpproachFour(String source) {
		
		char[] try1 = source.toCharArray();
        for (int i = try1.length-1; i>=0; i--)
            System.out.print(try1[i]);
	}

}

