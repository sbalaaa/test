package exercise;

public class Sorting {
	public static void bubbleSort(int[] x) {
		int n = x.length;
		for (int pass = 1; pass < n; pass++) { // count how many times
			// This next loop becomes shorter and shorter
			for (int i = 0; i < n - pass; i++) {
				if (x[i] > x[i + 1]) {
					// exchange elements
					int temp = x[i];
					x[i] = x[i + 1];
					x[i + 1] = temp;
				}
			}
			
			System.out.println(); // 
			
			for(int i=0;i<x.length;i++){ // 
				System.out.print(x[i]+" "); //
			} //
		}
		
		System.out.println(); //
		
		for(int i=0;i<x.length;i++){
			System.out.print(x[i]+" ");
		}
	}
	
	public static void main(String[] args) {
		int a[]={10,32,43,25,3};
		bubbleSort(a);
	}

}
