package exercise;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StackExample {
	Object array[];
	int index;

	public StackExample() {
		this.array = new Object[120];
		this.index = 0;
	}

	public boolean isEmpty() {
		boolean result = false;

		if (index < array.length - 1) {
			result = true;
		}
		if (index == array.length - 1) {
			result = false;
		}
		return result;
	}

	public void push(Object item) {

		if (isEmpty()) {
			array[index] = item;
			index++;
		} else {
			System.out.println("stack is full");
			System.exit(0);
		}
	}

	public Object pop() {
		index--;
		return array[index];
	}

	public static void main(String args[]) throws NumberFormatException,
			IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		StackExample object = new StackExample();

		int choice;
		System.out.println("for push operation enter 1");
		System.out.println("for pop operation press 2");

		choice = Integer.parseInt(br.readLine());

		while (choice <= 2) {

			switch (choice) {

			case 1:
				Integer element;
				System.out.println("enter element to store in stack");
				element = Integer.parseInt(br.readLine());
				object.push(element);
				break;

			case 2:

				System.out.println("poped element is" + object.pop());
				break;

			case 3:
				System.exit(0);
				break;

			default:
				System.exit(0);
				break;
			}
			System.out.println("for push operation enter 1");
			System.out.println("for pop operation press 2");
			System.out.println("to come out of program press 3");
			choice = Integer.parseInt(br.readLine());
		}

	}
}

