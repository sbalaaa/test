package exercise;

public class StringLength {

	public static int finding_length(String str) {
		int length = 0;
		try {
			char temp[] = str.toCharArray();

			int i = 0;
			while (temp[i] != '\0') {
				length++;
				i++;
			}
		} catch (Exception e) {

		}
		return length;

	}
	
	
	public static int findingStringlength(String str) {
		int length = 0;
		try {
		    int i = 0;
			while (str.charAt(i)!='\0') {
				length++;
				i++;
			}
		} catch (Exception e) {

		}
		return length;

	}

	public static void main(String[] args) {
		String str = "santhu";

		System.out.println();
		System.out.println(findingStringlength(str));
	}
}

