package exercise;

import java.util.ArrayList;

public class StringOccurance {
	public static void main(String[] args) {
		int count = 0;
		String s1 = "ab";
		String s2 = "ababbbabab";

		char one[] = s1.toCharArray();
		char two[] = s2.toCharArray();
		ArrayList<Integer> al = new ArrayList<Integer>();
		int i = 0;
		for (int j = 0; j <= two.length; j++) {
			try {
				if (one[i] == two[j] && one[i + 1] == two[j + 1]) {
					count++;
					al.add(j);
				}
			} catch (Exception e) {

			}

		}
		System.out.println(count);
		System.out.println(al);
		System.out.println("size of the array list is" + al.size());
		System.out.println("last occurance of givenstring position is"
				+ al.get(al.size() - 2));
	}
}

