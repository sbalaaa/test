package exercise;

public class StringOpen {

	public static int index_of_lastoccurence_of_open_brase(char[] str) {
		int count = 0;
		for (int i = 0; i < str.length; i++) {
			if (str[i] == '{')
				count = i;
		}
		return count;
	}

	public static void checking(String str) {

		char[] temp = str.toCharArray();
		int startingpoint = index_of_lastoccurence_of_open_brase(temp);
		for (int j = startingpoint; j >= 0; j--) {

			if (temp[j] == '{') {
				for (int i = j + 1; i < temp.length; i++) {
					if (temp[i] == '}') {
						temp[j] = '*';
						temp[i] = '*';
						break;
					}
				}

			}

		}
		startingpoint = index_of_lastoccurence_of_open_brase(temp);
		System.out.println(startingpoint);
		System.out.println(temp);
		boolean check = false;
		for (int i = 0; i < temp.length; i++) {
			if (temp[i] == '{' || temp[i] == '}') {

				check = true;
				break;
			}
		}
		if (check == true) {
			System.out.println("given string is invalid");
		} else
			System.out.println("given string is valid");

	}

	public static void main(String[] args) {
		String str = "{{}}{}{{}}{{}}";
		char[] temp = str.toCharArray();

		if (temp[temp.length - 1] == '{') {
			System.out.println("given string is invalid");

		} else if (temp[0] == '}') {
			System.out.println("given string is invalid");

		} else if (str.length() % 2 != 0) {

			System.out.println("given string is invalid");

		} else {

			checking(str);
		}
	}
}
