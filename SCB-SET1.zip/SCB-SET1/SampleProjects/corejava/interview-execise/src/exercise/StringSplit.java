package exercise;

public class StringSplit {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sentence = "hai balachandar how are you";
		String[] words = sentence.split(" ");
		
		for(String obj : words){
			System.out.println(obj);
		}
	}

}
