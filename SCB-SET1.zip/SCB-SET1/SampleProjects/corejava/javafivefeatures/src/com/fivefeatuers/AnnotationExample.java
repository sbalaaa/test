package com.fivefeatuers;

public class AnnotationExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class Animal {
	void eatSomething() {
		System.out.println("eating something");
	}
}

class Dog extends Animal {
	//@Override
	void eatsomething() {
		System.out.println("eating foods");
	}// should be eatSomething
}
