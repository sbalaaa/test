package com.fivefeatuers;

public class BoxingExample {

	public static void main(String[] args) {
		int a=50;  
		//Integer a2=new Integer(a);  // Before Java 5 
		Integer a2=a;  //Boxing  

		//int a3 = a2.intValue();  // Before Java 5 
		int a3 = a2;  //UnBoxing 
		
		System.out.println(a3);
		
	}

}
