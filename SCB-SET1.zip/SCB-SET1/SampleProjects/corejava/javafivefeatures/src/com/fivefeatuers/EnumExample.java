package com.fivefeatuers;

public class EnumExample {

	public static void main(String[] args) {
		
		for (Color c : Color.values())
			System.out.println(c);

		System.out.println();
		System.out.println();
		
		Season s = Season.WINTER;
		System.out.println(s);
		System.out.println(s.ordinal());
		System.out.println(s.getValue());
		
	}

}

enum Color {
	WHITE, BLOCK, BLUE, GREEN
}

enum Season {
	WINTER(5), SPRING(10), SUMMER(15), FALL(20);

	private int value;

	private Season(int value) {
		this.value = value;
	}
	
	public int getValue(){
		return value;
	}
}