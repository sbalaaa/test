package com.fivefeatuers;

import java.util.ArrayList;

public class ForEachExample {

	public static void main(String[] args) {
	   
	   System.out.println("Array Iteration");	
	   int array[]={12,13,14,44};  
		  
	   for(int i:array){  
	     System.out.println(i);  
	   }  
	   System.out.println();
	   System.out.println("Collection Iteration");
	   
	   ArrayList<String> list=new ArrayList<String>();  
	   list.add("vimal");  
	   list.add("sonoo");  
	   list.add("ratan");  
	  
	   for(String s:list){  
	     System.out.println(s);  
	   }  

	}

}
