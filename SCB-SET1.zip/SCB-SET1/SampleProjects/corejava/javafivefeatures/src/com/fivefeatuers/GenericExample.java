package com.fivefeatuers;

public class GenericExample<T> {
	
	T obj;
	
	void add(T obj) {
		this.obj = obj;
	}
	
	T get() {
		return this.obj;
	}
	
	public static void main(String[] args) {
		GenericExample<Integer> myObj = new GenericExample<>();
		myObj.add(2);
		//myObj.add("vivek");
		
		System.out.println(myObj.get());

	}

}
