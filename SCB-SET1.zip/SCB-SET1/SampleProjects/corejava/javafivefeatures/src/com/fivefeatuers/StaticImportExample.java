package com.fivefeatuers;

import static java.lang.System.*;
//import java.lang.Math;
import static java.lang.Math.*;

public class StaticImportExample {

	public static void main(String args[]) {

		out.println("Hello");// Now no need of System.out
		out.println("Java");
		
		int bigNumber = max(10, 20);
		out.println(bigNumber);
		
		System.out.println();
		
		System.out.println("Hello");
		System.out.println("Java");
		
		bigNumber = max(10, 20);
		System.out.println(bigNumber);
		

	}

}
