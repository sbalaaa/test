package javafive.enums;

public enum ConstructorEnum {
	BLACK(0,"B"),WHITE(1,"W"),RED(2,"R"),GREEN(3,"G");
	
	private int id;
	private String label;
	private static int count = 0;
	
	ConstructorEnum(int id, String label){
		this.id = id;
		this.label = label;
	}
	
	public int getId(){
		return this.id;
	}
	
	
	public String getLabel(){
		return this.label;
	}
	
	public static void main(String[] args){
		for (ConstructorEnum p : ConstructorEnum.values()) {			
			System.out.println("Constructor color value." + p.name());
			count++;
		}
		
		System.out.println("Get Parameter Count is	: " + ConstructorEnum.count);
		System.out.println("Value of RED " + ConstructorEnum.valueOf("RED"));
		
	}
	
	
}
