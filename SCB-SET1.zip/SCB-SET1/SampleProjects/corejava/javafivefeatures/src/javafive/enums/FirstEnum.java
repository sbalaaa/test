package javafive.enums;

public class FirstEnum {

	public enum Colors{BLACK,WHITE,RED,GREEN};
	
	
	static int getIndex(Colors color){
		switch(color){
			case BLACK:
				return 1;
			case WHITE:
				return 2;
			case RED:
				return 3;
			case GREEN:
				return 4;
		}
		return 0;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Get the color index:	" + getIndex(Colors.BLACK));
		
		System.out.println("Get the white label:	" + ConstructorEnum.WHITE); 
		
		System.out.println("Get the white char:		" + ConstructorEnum.WHITE.getLabel()); 
		
		System.out.println("Get the white id:		" + ConstructorEnum.WHITE.getId()); 
		
		
		for(Colors obj :Colors.values()){
			System.out.println("Color value is : " + obj.name());
		}
	}

}
//BusinessConfigurationParametersEnum.java