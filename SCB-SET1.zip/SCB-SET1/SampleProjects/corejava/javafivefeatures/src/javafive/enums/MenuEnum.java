/**
 * 
 */
package javafive.enums;

import java.awt.MenuItem;
import java.util.ArrayList;
import java.util.List;


public enum MenuEnum {
	PORTAL {
		@Override
		public String getLabel() {
			return "Home";
		}
		@Override
		public String getRef() {
			return "index.jsp";
		}
		@Override
		public String getType() {
			return "zone";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			return true; 
		}
		@Override
		public String getPageType() {
			return "home";
		}
	},
	PRODUCT{
		@Override
		public String getLabel() {
			return "Product";
		}
		@Override
		public String getRef() {
			return "ZoneAction_page?pageType=product";
		}
		@Override
		public String getType() {
			return "zone";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(FXDEAL);
			childList.add(SUBSCRIBEDNOTES);
			return childList;
		}
		public boolean isPermissioned(String userType){

			return true; 

		}
		@Override
		public String getPageType() {
			// TODO Auto-generated method stub
			return "product";
		}
	},
	CONFIGURATION{
		@Override
		public String getLabel() {
			return "Configuration";
		}
		@Override
		public String getRef() {
			return "ZoneAction_page?pageType=configuration";
		}
		@Override
		public String getType() {
			return "zone";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(PORTFOLIOSETUP);
			childList.add(MARKETDATA);
			return childList;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
		@Override
		public String getPageType() {
			// TODO Auto-generated method stub
			return "configuration";
		}
	},	
	CLIENT{
		@Override
		public String getLabel() {
			return "Client";
		}
		@Override
		public String getRef() {
			return "ZoneAction_page?pageType=client";
		}
		@Override
		public String getType() {
			return "zone";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(DEALSEARCH);
			return childList;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return true; 
			}else{
				return false;
			}
		}
		@Override
		public String getPageType() {
			// TODO Auto-generated method stub
			return "client";
		}
	},	

	FXDEAL {
		public String getLabel(){
			return "FX Deal";
		};
		public String getRef(){
			return "json/system/orderentry/fx-deals-scb.json";
		};
		public String getType(){
			return "menu";
		};
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return true; 
			}else{
				return false;
			}
		}
		
	},
	SUBSCRIBEDNOTES{
		public String getLabel(){
			return "Structure Note Subscription";
		};
		public String getRef(){
			return "json/system/orderentry/structured-note-subscription-scb.json";
		};
		public String getType(){
			return "menu";
		};
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},
	DEALSEARCH{
		public String getLabel(){
			return "Client Search";
		};
		public String getRef(){
			return "json/system/orderentry/structured-note-subscription-scb.json";
		};
		public String getType(){
			return "widget";
		};
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return true; 
			}else{
				return false;
			}
		}
	},
	PORTFOLIOSETUP{
		@Override
		public String getLabel() {
			return "Portfolio Setup";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(SELECTIONRULE);
			childList.add(PORTFOLIOCONSTRUCTOR);
			return childList;
		}
		@Override
		public String getRef() {
			return "#";
		}
		@Override
		public String getType() {
			return "menu";
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},
	SELECTIONRULE{
		@Override
		public String getLabel() {
			return "Selection Rule";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(test1);
			childList.add(test2);
			return childList;
		}
		@Override
		public String getRef() {
			return "#";//json/system/portfolio/portfolio-selection-rules.json";
		}
		@Override
		public String getType() {
			return "menu";
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},
	PORTFOLIOCONSTRUCTOR{
		@Override
		public String getLabel() {
			return "Portfolio Constructor";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		@Override
		public String getRef() {
			return "json/system/portfolio/portfolio-constructor.json";
		}
		@Override
		public String getType() {
			return "menu";
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},
	MARKETDATA{
		@Override
		public String getLabel() {
			return "Market Data";
		}
		@Override
		public List<MenuEnum> getChildList() {
			List<MenuEnum> childList=new ArrayList<MenuEnum>();
			childList.add(PRICINGRULE);
			childList.add(FXSPOTPRICE);
			return childList;
		}
		@Override
		public String getRef() {
			return "#";
		}
		@Override
		public String getType() {
			return "menu";
		}
		@Override
		public boolean isPermissioned(String userType) {
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},
	PRICINGRULE{
		@Override
		public String getLabel() {
			return "Pricing Rule";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		@Override
		public String getRef() {
			return "json/system/marketdata/pricing-rule.json";
		}
		@Override
		public String getType() {
			return "menu";
		}
		@Override
		public boolean isPermissioned(String userType) {
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}

	},
	FXSPOTPRICE{
		@Override
		public String getLabel() {
			return "FX Spot Price";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		@Override
		public String getRef() {
			return "json/system/marketdata/fx-spot-price.json";
		}
		@Override
		public String getType() {
			return "menu";
		}
		@Override
		public boolean isPermissioned(String userType) {
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
	},test1{
		@Override
		public String getLabel() {
			return "etst1";
		}
		@Override
		public String getRef() {
			return "ZoneAction_page?pageType=client";
		}
		@Override
		public String getType() {
			return "menu";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
		
	},test2{
		@Override
		public String getLabel() {
			return "test2";
		}
		@Override
		public String getRef() {
			return "ZoneAction_page?pageType=client";
		}
		@Override
		public String getType() {
			return "menu";
		}
		@Override
		public List<MenuEnum> getChildList() {
			return null;
		}
		public boolean isPermissioned(String userType){
			if("RM".equalsIgnoreCase(userType)){
				return false; 
			}else{
				return true;
			}
		}
		
	}	
;

	public abstract String getLabel();
	public abstract String getRef();
	public abstract String getType();
	public abstract List<MenuEnum> getChildList();
	public abstract boolean isPermissioned(String userType);
	public  String getPageType(){return "";}
	
	
	public static List<MenuEnum> getZones(String userType) {
		List<MenuEnum> list=new ArrayList<MenuEnum>();
		for(MenuEnum item:MenuEnum.values()){
			if("zone".equalsIgnoreCase(item.getType()) && item.isPermissioned(userType))
				list.add(item);
			
		}
		return list;
	}

}
