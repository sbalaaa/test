package javafive.generics;

public class GenericClassTest {
	public static void main(String args[]) throws InstantiationException, IllegalAccessException{
		GenericFactory<A> obj = new GenericFactory<A>();
		A objA = obj.createInstance();
		
		GenericFactory<B> objTwo = new GenericFactory<B>(B.class);
		B objB = objTwo.createInstance();
		
		if(objA instanceof A){
			System.out.println("objA is instanceof A");
		}else {
			System.out.println("objA is not instanceof A");
		}
		
		if (objB instanceof B) {
			System.out.println("objB is instanceof B");
		} else {
			System.out.println("objB is not instanceof B");
		}
	}
}
