package javafive.generics;

class GenericFactory<E> {
	
	Class classObj;
	
	GenericFactory(Class classObj){
		this.classObj =  classObj;
	}
	
	GenericFactory(){
		
	}
	
	public E createInstance() throws InstantiationException, IllegalAccessException{
		return (E)this.classObj.newInstance();
	}
}


class A{}
class B{}

