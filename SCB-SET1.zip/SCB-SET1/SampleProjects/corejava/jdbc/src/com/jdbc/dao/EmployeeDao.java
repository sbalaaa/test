package com.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.jdbc.entity.Employee;

public class EmployeeDao {

	
	
	public List<Employee> getAllEmployees(){
		
		List<Employee> empList = new ArrayList<Employee>();
		Statement st = null;
		ResultSet rs = null;
		Connection con = null;
		
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			con = 
					DriverManager.getConnection("jdbc:derby://localhost:1527/testdb", "root", "root");
			st = con.createStatement();
			rs = st.executeQuery("SELECT * FROM EMPLOYEES");
			Employee obj = null;
			while(rs.next()){
				obj = new Employee();
				obj.setEmployeeNo(rs.getInt("EMPLOYEE_ID"));
				obj.setFirstName(rs.getString("FIRST_NAME"));
				obj.setLastName(rs.getString("LAST_NAME"));
				obj.setEmail(rs.getString("EMAIL"));
				obj.setPhoneNumber(rs.getString("PHONE_NUMBER"));
				obj.setSalary(rs.getInt("SALARY"));
				empList.add(obj);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				st.close();
				rs.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		return empList;
	}
	
	
	public void addEmployee(Employee obj){
		
		PreparedStatement st = null;
		int  count = 0;
		Connection con = null;
		String query = "INSERT INTO EMPLOYEES(FIRST_NAME,LAST_NAME,EMAIL,PHONE_NUMBER,SALARY)VALUES(?,?,?,?,?)";
		
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			con = 
					DriverManager.getConnection("jdbc:derby://localhost:1527/testdb", "root", "root");
			st = con.prepareStatement(query);
			st.setString(1, obj.getFirstName());
			st.setString(2, obj.getLastName());
			st.setString(3, obj.getEmail());
			st.setString(4, obj.getPhoneNumber());
			st.setInt(5, obj.getSalary());
			count = st.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				st.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	public void updateEmployee(int employeeId, int salary){
		
		PreparedStatement st = null;
		int  count = 0;
		Connection con = null;
		String query = "UPDATE EMPLOYEES SET SALARY = ? WHERE EMPLOYEE_ID = ? ";
		
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			con = DriverManager.getConnection("jdbc:derby://localhost:1527/testdb", "root", "root");
			st = con.prepareStatement(query);
			st.setInt(1, salary);
			st.setInt(2, employeeId);
			count = st.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				st.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	
	public void deleteEmployee(int employeeId){
		
		PreparedStatement st = null;
		int  count = 0;
		Connection con = null;
		String query = "DELETE FROM EMPLOYEES  WHERE EMPLOYEE_ID = ? ";
		
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			con = 
					DriverManager.getConnection("jdbc:derby://localhost:1527/testdb", "root", "root");
			st = con.prepareStatement(query);
			st.setInt(1, employeeId);
			count = st.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				st.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
