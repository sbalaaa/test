package com.jdbc.dao;

import java.util.List;

import com.jdbc.entity.Employee;

public class EmployeeDaoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		listEmployee();
		//createEmployee();
		//modidyEmployeeSalary();
		//removeEmployee();
	}
	
	public static void listEmployee() {
		EmployeeDao dao = new EmployeeDao();
		List<Employee> employees = dao.getAllEmployees();
		for(Employee emp:employees)
		{
			System.out.println(emp);
		}
	}
	
	
	public static void createEmployee() {
		EmployeeDao dao = new EmployeeDao();
		Employee employee = new Employee("Balachandar","Sivalingam","sbalaaa@gmail.com","9095205004",12000);
		dao.addEmployee(employee);
	}
	
	public static void modidyEmployeeSalary() {
		EmployeeDao dao = new EmployeeDao();
		dao.updateEmployee(1,20000);
	}
	
	public static void removeEmployee() {
		EmployeeDao dao = new EmployeeDao();
		dao.deleteEmployee(1);
	}

}
