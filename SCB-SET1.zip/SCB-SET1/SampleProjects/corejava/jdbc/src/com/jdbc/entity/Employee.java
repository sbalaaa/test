package com.jdbc.entity;

public class Employee {

	private int employeeNo;
	private String firstName;
	private String lastName;
	private String email;
	private String phoneNumber;
	private int salary;

	
	public Employee() {
		
	}
	
	public Employee(int id, String fname, String lname, String email, String phoneNumber , int salary) {
		this.employeeNo = id;
		this.firstName = fname;
		this.lastName = lname;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.salary = salary;
	}
	
	public Employee(String fname, String lname, String email, String phoneNumber , int salary) {
		this.firstName = fname;
		this.lastName = lname;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.salary = salary;
	}
	
	public int getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", firstName="
				+ firstName + ", lastName=" + lastName + ", email=" + email
				+ ", phoneNumber=" + phoneNumber + ", salary=" + salary + "]";
	}
	
	
	
	

}
