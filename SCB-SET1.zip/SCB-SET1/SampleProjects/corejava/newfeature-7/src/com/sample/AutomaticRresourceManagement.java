package com.sample;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
//Any resource that implements AutoCloseble interface can be a candidate for automatic resource management. 
//The AutoCloseable is the parent of java.io.Closeable interface and has just one method close() that would be called by the JVM when the control comes out of the try block
public class AutomaticRresourceManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AutomaticRresourceManagement obj = new AutomaticRresourceManagement();
		obj.oldTry();
		obj.newTry();

	}

	public void oldTry() {
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try {
			fos = new FileOutputStream("movies.txt");
			dos = new DataOutputStream(fos);
			dos.writeUTF("Java 7 Block Buster");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}//oldTry end
	
	
	public void newTry() {
		
		try(FileOutputStream fos = new FileOutputStream("moviess.txt"); DataOutputStream dos = new DataOutputStream(fos); ) {
			dos.writeUTF("Java 7 Block Buster");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}//oldTry end

	
	public void NumericLiteralsWithUnderscores() {
		int thousand =  1_000;
		int million  =  1_000_000;
	}

}
