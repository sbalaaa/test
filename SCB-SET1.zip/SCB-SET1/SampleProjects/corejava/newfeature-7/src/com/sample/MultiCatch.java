package com.sample;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MultiCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void oldMultiCatch() {

		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try {
			fos = new FileOutputStream("movies.txt");
			dos = new DataOutputStream(fos);
			Class.forName("com.sample"); // Just for sample
			dos.writeUTF("Java 7 Block Buster");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public void newMultiCatch() {

		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try {
			fos = new FileOutputStream("movies.txt");
			dos = new DataOutputStream(fos);
			Class.forName("com.sample"); // Just for sample
			dos.writeUTF("Java 7 Block Buster");
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				fos.close();
				dos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
}
