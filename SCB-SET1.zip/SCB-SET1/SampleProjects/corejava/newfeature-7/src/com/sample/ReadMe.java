package com.sample;

public class ReadMe {

	/*
	 * NIO
	 * It was never easy to work across operating systems or multi-file systems using java io.
	 * 
	 * NIO introduced new classes to ease the life of a developer when working with multiple file systems.
	 */
	
	
	 /*
	 * Fork and Join
	 */
	
}


/*Links
https://www.oreilly.com/learning/java7-features

*
*
*/	
