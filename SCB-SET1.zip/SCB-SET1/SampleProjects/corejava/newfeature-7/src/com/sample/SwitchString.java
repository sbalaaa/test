package com.sample;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SwitchString {


	public static void main(String args[]) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Please give your input:  ");
		String input = scan.next();
		
		switch(input) {
		case "COFFEE":
			System.out.println("You like coffee");
			break;
		case "TEA":
			System.out.println("You like tea");
			break;
		default:
			System.out.println("You like ....");
			break;
		}
		
	}
	
	
	private void genericDiamondOperatorImprovement(){
		List<String> five = new ArrayList<String>();
		List<String> seven = new ArrayList<>();
	}
	
}
