package lamda;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

//  http://stackoverflow.com/questions/24378646/finding-max-with-lambda-expression-in-java

public class FirstLamda {

	public static void main(String[] args) {
		List<Student> students = Student.getStudents();
		Optional<Integer> maxScore = students.stream()
				.filter( s -> s.getGradeYear() == 2015)
				.map(s -> s.getScore())
				.max(Comparator.comparing(i -> i));
		
		System.out.println("Get the maximum of 2015	:	" + maxScore.get());
		
		students.forEach(student -> System.out.println(student.getGradeYear()));
		
	}

	
	
}
