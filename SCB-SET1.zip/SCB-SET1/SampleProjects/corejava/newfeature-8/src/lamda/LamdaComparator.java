package lamda;

import java.util.List;

public class LamdaComparator {
	
	public static void main(String args[]){
		
		List<Student> students = Student.getStudents();
		students.sort((s1,s2) -> s1.getScore() - s2.getScore());
		students.forEach(s -> System.out.println(s));
		System.out.println();
		students.forEach(System.out::println);
	}

}
