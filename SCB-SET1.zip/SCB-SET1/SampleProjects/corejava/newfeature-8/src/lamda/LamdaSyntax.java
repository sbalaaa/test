package lamda;

public class LamdaSyntax {

	public static void main(String args[]){
		//() -> System.out.println("Hello Lamda")	
	}
	
}
