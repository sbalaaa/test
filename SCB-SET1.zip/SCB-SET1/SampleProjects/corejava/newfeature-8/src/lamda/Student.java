package lamda;

import java.util.ArrayList;
import java.util.List;

public class Student {

	private int gradeYear;
	private int score;
	
	public int getGradeYear() {
		return gradeYear;
	}
	public void setGradeYear(int gradeYear) {
		this.gradeYear = gradeYear;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	
	public static List<Student> getStudents(){
		List<Student> students = new ArrayList<>();
		
		Student student1 = new Student();
		student1.setGradeYear(2015);
		student1.setScore(450);
		
		Student student2 = new Student();
		student2.setGradeYear(2015);
		student2.setScore(490);
		
		Student student3 = new Student();
		student3.setGradeYear(2014);
		student3.setScore(400);
		
		students.add(student1);
		students.add(student2);
		students.add(student3);
		
		return students;
	}
	
	@Override
	public String toString() {
		return "Student [gradeYear=" + gradeYear + ", score=" + score + "]";
	}
	
}
