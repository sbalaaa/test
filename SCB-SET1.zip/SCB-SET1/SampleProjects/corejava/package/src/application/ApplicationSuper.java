package application;

import service.ServiceSuper;

public class ApplicationSuper extends ServiceSuper {

	private void getProtectedFromSuper() {
		printSuperSeviceProtected();
	}
	
	public static void main(String[] args) {
		ServiceSuper obj = new ServiceSuper();
		//obj.printSuperSeviceDefault();
		//obj.printSuperSevicePrivate();
		//obj.printSuperSeviceProtected();
		ApplicationSuper applicationSuper = new ApplicationSuper();
		applicationSuper.getProtectedFromSuper();
		obj.printSuperSevicePublic();

	}
	
}
