package application;

//import service.*;
//import service.MyService;

public class Demo {

	public static void main(String[] args) {
		//MyService obj = new MyService();
		service.MyService obj = new service.MyService();
		obj.show();
		
	}

}
