package application;

public class StringExample {
	
	public static void main(String args[]) {
		String hello = "Hello How are you";
		String obj = new String("Welcome to India");
		
		int length = hello.length();
		System.out.println("Length of Hello is ->>>	" + length);
		
		char c = hello.charAt(3);
		System.out.println("Char at 4 th location of Hello is ->>>	" + c);
		
		String part = hello.substring(5, 10);
		System.out.println("Part of hello object is 5,10 ->>>	" + part);
		
		String upper = hello.toUpperCase();
		System.out.println("Upper Case of  hello object is ->>>	" + upper);

		
	}

}
