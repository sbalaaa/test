package service;

public class MyService {

	public void show() {
		System.out.println("Show From MyService");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
