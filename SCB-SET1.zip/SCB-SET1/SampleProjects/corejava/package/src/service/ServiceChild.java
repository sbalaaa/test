package service;

public class ServiceChild extends ServiceSuper{

	public static void main(String[] args) {
		ServiceSuper obj = new ServiceSuper();
		obj.printSuperSeviceDefault();
		//obj.printSuperSevicePrivate();
		obj.printSuperSeviceProtected();
		obj.printSuperSevicePublic();

	}

}
