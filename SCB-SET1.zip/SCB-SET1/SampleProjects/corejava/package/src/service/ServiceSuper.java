package service;

public class ServiceSuper {

	int service_super_default = 10; // default 
	private int service_super_private = 20;
	protected int service_super_protected = 30;
	public int service_super_public = 40;
	
	void printSuperSeviceDefault() {
		System.out.println("service_super_default is : " + service_super_default);
	}
	
	private void printSuperSevicePrivate() {
		System.out.println("service_super_private is : " + service_super_private);
	}
	
	
	protected void printSuperSeviceProtected() {
		System.out.println("service_super_protected is : " + service_super_protected);
	}
	
	public void printSuperSevicePublic() {
		System.out.println("service_super_public is : " + service_super_public);
	}
	

	
	public static void main(String[] args) {
		ServiceSuper obj = new ServiceSuper();
		obj.printSuperSeviceDefault();
		obj.printSuperSevicePrivate();
		obj.printSuperSeviceProtected();
		obj.printSuperSevicePublic();

	}

}
