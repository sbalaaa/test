package testdome;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Entry {

	private List<String> passportList = new LinkedList<>();

	public void enter(String passportNumber) {
		passportList.add(passportNumber);
	}

	public String exit() {

		if (passportList.size() != 0) {

			String firstElement = passportList.get(0);
			passportList.remove(0);
			return firstElement;

		} else {
			return null;
		}
	}

	public static void main(String[] args) {
		Entry entry = new Entry();
		entry.enter("AB54321");
		entry.enter("UK32032");
		System.out.println(entry.exit());
		System.out.println(entry.exit());
		System.out.println(entry.exit());
	}
}