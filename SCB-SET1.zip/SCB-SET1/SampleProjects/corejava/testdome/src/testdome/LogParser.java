package testdome;

import java.io.StringReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;

public class LogParser {
    public static Collection<Integer> getIdsByMessage(String xml, String message) throws Exception {
        
    	Map<String,Collection<Integer>> obj = new HashMap<>();
    	
    	int start = 0;
    	int end = 0;
    	String key = "";
    	while(true) {
    		
    		System.out.println(xml);
    		
    		start = xml.indexOf("<message>");
    		end = xml.indexOf("</message>");
    		
    		System.out.println("Start " + start + " end " + end);
    		
    		if(start == -1 ) {
    			break;
    		} else {
    			key = xml.substring(start+"<message>".length(), end);
    			System.out.println(key);
    		}
    		
    		xml = xml.substring(end);
    	}
    	
    	
    	
    	return obj.get(message);
    }
    
    public static void main(String[] args) throws Exception {
        String xml = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<log>\n" + 
                "    <entry id=\"1\">\n" + 
                "        <message>Application started</message>\n" + 
                "    </entry>\n" + 
                "    <entry id=\"2\">\n" + 
                "        <message>Application ended</message>\n" + 
                "    </entry>\n" + 
                "</log>";
        
        Collection<Integer> ids = getIdsByMessage(xml, "Application ended");
        for(int id: ids)
            System.out.println(id); 
    }
    
    public static String getCharacterDataFromElement(Element e) {
        Node child = e.getFirstChild();
        if (child instanceof CharacterData) {
           CharacterData cd = (CharacterData) child;
           return cd.getData();
        }
        return "?";
      }
    
    
}