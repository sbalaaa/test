package testdome;

import java.io.StringReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.*;
import org.xml.sax.InputSource;
import org.w3c.dom.*;

public class LogParser2 {
    public static Collection<Integer> getIdsByMessage(String xml, String message) throws Exception {
        
    	Map<String,Collection<Integer>> obj = new HashMap<>();
    	
    		DocumentBuilderFactory dbf =
                DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(message));

            Document doc = db.parse(is);
            NodeList nodes = doc.getElementsByTagName("log");
            
            
            for (int i = 0; i < nodes.getLength(); i++) {
                Element element = (Element) nodes.item(i);

                NodeList name = element.getElementsByTagName("name");
                Element line = (Element) name.item(0);
                System.out.println("Name: " + getCharacterDataFromElement(line));

                NodeList title = element.getElementsByTagName("title");
                line = (Element) title.item(0);
                System.out.println("Title: " + getCharacterDataFromElement(line));
             }
    	
    	throw new UnsupportedOperationException("Waiting to be implemented.");
    }
    
    public static void main(String[] args) throws Exception {
        String xml = 
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<log>\n" + 
                "    <entry id=\"1\">\n" + 
                "        <message>Application started</message>\n" + 
                "    </entry>\n" + 
                "    <entry id=\"2\">\n" + 
                "        <message>Application ended</message>\n" + 
                "    </entry>\n" + 
                "</log>";
        
        Collection<Integer> ids = getIdsByMessage(xml, "Application ended");
        for(int id: ids)
            System.out.println(id); 
    }
    
    public static String getCharacterDataFromElement(Element e) {
        Node child = e.getFirstChild();
        if (child instanceof CharacterData) {
           CharacterData cd = (CharacterData) child;
           return cd.getData();
        }
        return "?";
      }
    
    
}