package testdome;

public class Palindrome {
    public static boolean isPalindrome(String word) {
        String reverse = new StringBuilder(word).reverse().toString();
        if(word.toLowerCase().equals(reverse.toLowerCase())) {
        	return true;
        }
    	
    	return false;
    }
    
    public static void main(String[] args) {
        System.out.println(Palindrome.isPalindrome("Deleveled"));
    }
}