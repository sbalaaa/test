import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class DateExample {

	public static void main(String[] args) {
		   
		   Date date = new Date();
		   System.out.println("Current Date is : -> " + date);
		   
		   DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		   System.out.println("Today Date is : " + dateFormat.format(date.getTime()));
		   
		   
		   Calendar cal = Calendar.getInstance();
	       cal.setTime(date);
	    	
	       cal.add(Calendar.DATE, -60);
	       
	       System.out.println("Date before 60 day is : " + dateFormat.format(cal.getTime()));

	}

}
