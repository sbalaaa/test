
//final public class FinalClass {
public class FinalClass {

	
	void finalMethod() {	
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int i;
		i = 10;
		//i = 20;
	}

}


class SubClass extends FinalClass {
	
	void finalMethod() {	
		
	}

}