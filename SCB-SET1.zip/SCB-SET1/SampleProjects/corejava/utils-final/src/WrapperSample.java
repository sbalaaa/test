
public class WrapperSample {

	public static void main(String args[]) {
		int i = Integer.parseInt("20");
		System.out.println("i value is : " + i);
		
		String iStr = Integer.toString(i);
		System.out.println("iStr value is : " + iStr);
				
	}
	
}
