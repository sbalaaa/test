package com.crm.config;


import java.beans.PropertyVetoException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
public class DatabaseConfig {

	@Value("${jdbc.driverClass}")
	private String driverClass;
	
	@Value("${jdbc.jdbcUrl}")
	private String jdbcUrl;
	
	@Bean
	public ComboPooledDataSource getDataSource() throws PropertyVetoException {
		ComboPooledDataSource dataSource = new ComboPooledDataSource();
		dataSource.setDriverClass(driverClass);
		dataSource.setJdbcUrl(jdbcUrl);
		// set username and password also
		return dataSource;
	}

}
