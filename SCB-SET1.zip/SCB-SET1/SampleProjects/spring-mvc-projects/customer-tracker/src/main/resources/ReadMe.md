--------------------------- DERBY REFERENCE --------------------------------
PATH C:\Program Files\Java\jdk1.8.0_25\db\bin
DERBY_HOME C:\Program Files\Java\jdk1.8.0_25\db
 
Go to Your Prefered Location using command line:
 
To start the Derby Database Server:
 
cd D:\balachandar\Database\school (Your location)
java -jar "%DERBY_HOME%\lib\derbyrun.jar" server start
 
 
To open client console:
cd D:\balachandar\Database\school (Your location)
>ij
>CONNECT 'jdbc:derby://localhost:1527/training;create=true;user=root;password=root'; (First time)
>CONNECT 'jdbc:derby://localhost:1527/training;user=root;password=root';(Subsequent Time)
'jdbc:derby://localhost:1527/training;user=root;password=root';

>CONNECT 'jdbc:derby://localhost:1527/testdb;user=root;password=root';(Subsequent Time)


-------------------------------------------------------------------------------------

DERBY  SQL :


CREATE TABLE  customer (
  CUSTOMER_ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
  first_name VARCHAR(30) NOT NULL,
  last_name VARCHAR(20) NOT NULL,
  email VARCHAR(20) NOT NULL
);
 
 
 
ALTER TABLE DEPARTMENTS ADD PRIMARY KEY(DEPARTMENT_ID);
ALTER TABLE DEPARTMENTS ADD CONSTRAINT NAME_UNIQUE UNIQUE (DEPARTMENT_NAME);
