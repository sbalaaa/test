package com.example.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.DepartmentService;
import com.example.demo.vo.DepartmentVO;
/*
 * http://localhost:8080/api/departments
 * 
 * 
 * 
 * 
 * 
 */


@RestController
@RequestMapping("/api")
public class DepartmentController {
	
	@Autowired
	DepartmentService departmentService;
	
    @RequestMapping("/")
    String home() {
        return "Hello World!";
    }

    @CrossOrigin(origins="*", maxAge = 3600)
    @GetMapping("/departments")
	public ResponseEntity<List<DepartmentVO>> getAllDepartments() {
		System.out.println("Start - getAllDepartments");
		List<DepartmentVO> departments = departmentService.getAllDepartments();
		return new ResponseEntity(departments, HttpStatus.OK);
	}
	
    @CrossOrigin(origins="*")
    @PostMapping("/departments")
	public DepartmentVO createDepartment(@Valid @RequestBody DepartmentVO department) {
		System.out.println("Start - createDepartment");
		return departmentService.createDepartment(department);
	}
	
    @CrossOrigin(origins="*", maxAge = 3600)
    @RequestMapping("/departments/{id}")
	public ResponseEntity<DepartmentVO> getDepartmentById(@PathVariable(value = "id") Long departmentId) {
		System.out.println("Start - getDepartmentById --> " + departmentId);
		DepartmentVO department = departmentService.getDepartmentById(departmentId);
	    if(department == null) {
	    	System.out.println("Department Not Found");
	       return ResponseEntity.notFound().build();
	    } else {
	    	System.out.println("Department Found Name is:" + department.getName());
	    }
	    return ResponseEntity.ok(department);
	}
	
    @CrossOrigin(origins="*", maxAge = 3600)
    @PutMapping("/departments/{id}")
	public ResponseEntity<DepartmentVO> updateDepartment(@PathVariable(value = "id") Long departmentId, 
	                                       @Valid @RequestBody DepartmentVO departmentDetails) {
		System.out.println("Start - updateDepartment with ID -->" + departmentId);
		DepartmentVO department = departmentService.updateDepartment(departmentId,departmentDetails);
	    if(department == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok(department);
	}
    

    @CrossOrigin(origins="*", maxAge = 3600)
    @DeleteMapping("/departments/{id}")
	public ResponseEntity<DepartmentVO> deleteDepartment(@PathVariable(value = "id") Long departmentId) {
		System.out.println("Start - deleteDepartment with ID -->" + departmentId );
		DepartmentVO department = departmentService.deleteDepartment(departmentId);
	    if(department == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok().build();
	}

}
