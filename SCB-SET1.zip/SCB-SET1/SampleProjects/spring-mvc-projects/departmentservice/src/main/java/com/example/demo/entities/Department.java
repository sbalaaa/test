package com.example.demo.entities;

import javax.persistence.*;

@Entity
@Table(name="departments")

public class Department  {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DEPARTMENT_ID")
	private Long number;

	@Column(name="DEPARTMENT_NAME")
	private String name;

	public Department() {
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

}