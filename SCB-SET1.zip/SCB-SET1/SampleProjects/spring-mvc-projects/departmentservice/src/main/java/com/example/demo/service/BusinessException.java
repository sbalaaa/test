package com.example.demo.service;

public class BusinessException extends Exception {

}
