package com.example.aspect;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.example.dao.CustomerDaoImpl;

@Configuration
@EnableAspectJAutoProxy
public class AspectConfig {
	@Bean("customerDao")
    public CustomerDaoImpl customerDao() {
        return new CustomerDaoImpl();
    }

   /* @Bean
    public LoggingAspect loggingAspect() {
        return new LoggingAspect();
    }*/
    
    @Bean
    public LogTimeTakenAspect logTimeTakenAspect() {
        return new LogTimeTakenAspect();
    }
}
