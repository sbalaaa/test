package com.example.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

@Aspect
public class LogTimeTakenAspect {

	 public static final String LOG_TIME_TAKEN_KEY = "LogTimeTaken";
	
	 @Around("execution(* *(..)) && @annotation(com.example.aspect.LogTimeTaken)")
    public Object logTimeTaken(ProceedingJoinPoint joinPoint) throws Throwable {
    	long start = System.currentTimeMillis();
        Object result = joinPoint.proceed();
        long timeTaken = System.currentTimeMillis() - start;
        
        Method method = MethodSignature.class.cast(joinPoint.getSignature()).getMethod();
        LogTimeTaken annotation = method.getAnnotation(LogTimeTaken.class);
    	String methodSignature = method.getDeclaringClass().getName() + ":" + method.getName();

        logMessage(methodSignature, timeTaken);
        return result;
    }
    
    public static void logMessage(String methodSignature, long timeTaken) {
    	String msg = "Time taken by %s : %d ms [%s]";
         System.out.println(methodSignature);	
         System.out.println(timeTaken);	
        System.out.println(String.format(msg, methodSignature,timeTaken,LOG_TIME_TAKEN_KEY));
            

    }

    
	
}
