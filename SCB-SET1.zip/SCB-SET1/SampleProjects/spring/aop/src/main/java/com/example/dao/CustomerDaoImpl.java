package com.example.dao;

import com.example.aspect.LogTimeTaken;

public class CustomerDaoImpl implements CustomerDaoInterface {

	@LogTimeTaken
	public void addCustomer() {
		System.out.println("addCustomer() is running ");
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String addCustomerReturnValue() {
		System.out.println("addCustomerReturnValue() is running ");
		return "abc";
	}

	public void addCustomerThrowException() throws Exception {
		System.out.println("addCustomerThrowException() is running ");
		throw new Exception("Generic Error");
	}

	public void addCustomerAround(String name) {
		System.out.println("addCustomerAround() is running, args : " + name);
	}

}
