package com.lifecycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
   public static void main(String[] args) {
      ApplicationContext context = new ClassPathXmlApplicationContext("beans-lifecycle.xml");
      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
      obj.getMessage();
      obj.getUsername();
      obj.getPassword();
      System.out.println("HelloWorld obj:" + obj);
      obj = (HelloWorld) context.getBean("helloWorld");
      System.out.println("HelloWorld obj:" + obj);
      ((ConfigurableApplicationContext)context).close();
   }
}