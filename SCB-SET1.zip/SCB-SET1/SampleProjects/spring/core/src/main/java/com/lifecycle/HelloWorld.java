package com.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

@Component
//@Scope("prototype")
public class HelloWorld implements InitializingBean, DisposableBean {
	private String message;
	private String username;
	private String password;
	
	public HelloWorld(){
		System.out.println("Constructor is called..");
	}

	@Value("Welcome")
	public void setMessage(String message) {
		System.out.println("Setter method setMessage is called..");
		this.message = message;
	}
	
	@Value("#{sample.username}")
	public void setUserName(String userName) {
		System.out.println("Setter method for setUserName is called..");
		this.username = userName;
	}
	
	@Value("#{sample.password}")
	public void setPassword(String password) {
		System.out.println("Setter method for setPassword is called..");
		this.password = password;
	}

	public void getMessage() {
		System.out.println("Your Message : " + message);
	}
	
	public void getUsername(){
		System.out.println("Your Username : " + username);
	}
	
	public void getPassword(){
		System.out.println("Your Password : " + password);
	}


	public void afterPropertiesSet() throws Exception {
		System.out.println("This methods is called after the bean is initialized and before dispessed");
	}

	public void destroy() throws Exception {
		System.out.println("This methods is called before the bean is destroyed by the container.");
	}
	
	
	@PostConstruct 
	public void init(){
		System.out.println("init methods is called which is marked by @PostConstruct");
	}
	
	@PreDestroy
	public void destroyObj(){
		System.out.println("destroy methods is called which is marked by @PreDestroy");
	}
	
}