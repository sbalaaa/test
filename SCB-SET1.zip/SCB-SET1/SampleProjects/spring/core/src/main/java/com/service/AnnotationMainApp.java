package com.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AnnotationMainApp {

		public static void main(String[] args) {

		  ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		  MyApplication obj = (MyApplication) context.getBean("myApplication");
		  obj.processMessage("Hello", "Rajesh");
		  UserProperty user = (UserProperty) context.getBean("userProperty");
		  System.out.println(user.getUsername());
		  System.out.println(user.getPassword());
		  ((ConfigurableApplicationContext)context).close();
		  
	   }
}


//http://www.journaldev.com/2410/spring-dependency-injection-example-with-annotations-and-xml-configuration
//https://www.mkyong.com/spring3/spring-3-javaconfig-example/