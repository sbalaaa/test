package com.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.sample.Department;

@Repository
@PropertySource("classpath:query.properties")
public class DepartmentDAOJdbcTemplate implements DepartmentDAOInterface{
	
	@Value("${GET_DEPARTMENTS}")
	private String getDepartments;
	
	@Value("${GET_DEPARTMENT_BY_ID}")
	private String getDepartmentById;
	
	@Value("${GET_DEPARTMENT_BY_NAME}")
	private String getDepartmentByName;
	
	@Value("${INSERT_DEPARTMENT}")
	private String insertDepartmentQuery;
	
	@Value("${UPDATE_DEPARTMENT}")
	private String updateDepartmentQuery;
	
	@Value("${DELETE_DEPARTMENT}")
	private String deleteDepartmentQuery;
	
	private JdbcTemplate jdbcTemplate;
	
	public DepartmentDAOJdbcTemplate(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	private RowMapper<Department> departmentMapper = new RowMapper<Department>() {
        public Department mapRow(ResultSet rs, int rowNum) throws SQLException {
        	Department department = new Department();
        	department.setDepartmentId((rs.getInt("DEPARTMENT_ID")));
        	department.setDepartmentName(rs.getString("DEPARTMENT_NAME"));
        	department.setCreatedBy(rs.getString("CREATED_BY"));
            return department;
        }
    };
	

	public List<Department> listAllDepartments(){
		return jdbcTemplate.query(getDepartments, departmentMapper);
	}
	

	public Department selectDepartmentById(int departmentId){
		return jdbcTemplate.queryForObject(getDepartmentById, departmentMapper,departmentId);
	}
	

	public Department selectDepartmentByName(String departmentName){
		return jdbcTemplate.queryForObject(getDepartmentByName, departmentMapper,departmentName);
	}
	

	public void insertDepartment(final Department department){
		//INSERT INTO DEPARTMENTS (DEPARTMENT_NAME,CREATED_BY)VALUES(?,?)
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
	        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	            PreparedStatement ps =
	                connection.prepareStatement(insertDepartmentQuery, new String[] {"id"});
	            ps.setString(1, department.getDepartmentName());
	            ps.setString(2, "ADMIN");
	            return ps;
	        }
	    },
	    keyHolder);

		System.out.println("Generated Primary Key is :    -> " + keyHolder.getKey());

	}

	public void updateDepartment(Department department){
		jdbcTemplate.update(updateDepartmentQuery,department.getDepartmentName(),department.getDepartmentId());
		//UPDATE DEPARTMENTS SET DEPARTMENT_NAME = ? WHERE DEPARTMENT_ID = ?
	}
	

	public void deleteDepartment(int departmentId){
		jdbcTemplate.update(deleteDepartmentQuery,departmentId);
	}


}
