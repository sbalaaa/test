package com.sample.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.sample.Department;
import com.sample.Employee;

@Repository
@PropertySource("classpath:query.properties")
public class EmployeeDAO implements EmployeeDAOInterface{
	private JdbcTemplate jdbcTemplate;
	@Value("${GET_EMPLOYEES}")
	private String getAllEmployeesQuery;
	@Value("${GET_EMPLOYEE_BY_ID}")
	private String getByEmployeeIdQuery;
	@Value("${GET_EMPLOYEES_BY_DEPARTMENT_ID}")
	private String getByDepartmentIdQuery;
	@Value("${INSERT_EMPLOYEE}")
	private String insertEmployeeQuery;
	@Value("${UPDATE_EMPLOYEE}")
	private String updateEmployeeQuery;
	@Value("${DELETE_EMPLOYEE}")
	private String deleteEmployeeQuery;
	
	EmployeeDAO(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	private RowMapper<Employee> employeeMapper = new RowMapper<Employee>() {
        public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
        	Employee emp = new Employee();
        	emp.setEmployeeId(rs.getInt("EMPLOYEE_ID"));
        	emp.setFirstName(rs.getString("FIRST_NAME"));
        	emp.setLastName(rs.getString("LAST_NAME"));
        	emp.setGender(rs.getString("GENDER"));
        	emp.setAge(rs.getInt("AGE"));
        	emp.setEmail(rs.getString("EMAIL"));
        	emp.setPhoneNumber(rs.getString("PHONE_NUMBER"));
        	emp.setHireDate(rs.getDate("HIRE_DATE"));
        	emp.setSalary(rs.getDouble("SALARY"));
        	emp.setDepartmentId(new Department(rs.getInt("DEPARTMENT_ID_FK")));
            return emp;
        }
    };
	
	
    public List<Employee> listAllEmployees(){
		return jdbcTemplate.query(getAllEmployeesQuery, employeeMapper);
	}
	
	public Employee selectEmployeeById(int employeeId){
		return jdbcTemplate.queryForObject(getByEmployeeIdQuery, employeeMapper,employeeId);
	}
	
	public List<Employee> getEmployeesByDepartment(int departmentId){
		return jdbcTemplate.query(getByDepartmentIdQuery, employeeMapper,departmentId);
	}
	
	/*public void insertEmployee(Employee employee){
		jdbcTemplate.update(insertEmployeeQuery,employee.getFirstName(),employee.getLastName(),employee.getGender(),employee.getAge(),
				employee.getEmail(),employee.getPhoneNumber(),employee.getHireDate(),employee.getSalary(),employee.getDepartmentId().getDepartmentId());
	}*/
	
	
	public void insertEmployee(final Employee employee){
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
	        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	            PreparedStatement ps =
	                connection.prepareStatement(insertEmployeeQuery, new String[] {"id"});
	            ps.setString(1, employee.getFirstName());
	            ps.setString(2, employee.getLastName());
	            ps.setString(3, employee.getGender());
	            ps.setInt(4, employee.getAge());
	            ps.setString(5, employee.getEmail());
	            ps.setString(6, employee.getPhoneNumber());
	            ps.setDate(7, new java.sql.Date(employee.getHireDate().getTime()));
	            ps.setDouble(8, employee.getSalary());
	            ps.setInt(9,employee.getDepartmentId().getDepartmentId());
	            return ps;
	        }
	    },
	    keyHolder);
		System.out.println("Employee Id of new Employee is :    -> " + keyHolder.getKey());
	}
	
	public void updateEmployee(Employee employee){
		jdbcTemplate.update(updateEmployeeQuery,employee.getFirstName(),employee.getLastName(),employee.getSalary(),employee.getPhoneNumber(), employee.getEmployeeId());
	}
	
		
	public void deleteEmployee(int employeeId){
		jdbcTemplate.update(deleteEmployeeQuery,employeeId);
	}

}
