package com.sample.dao;

import java.util.List;

import com.sample.Employee;

public interface EmployeeDAOInterface {

	public List<Employee> listAllEmployees();
	public Employee selectEmployeeById(int employeeId);
	public List<Employee> getEmployeesByDepartment(int departmentId);
	public void insertEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
}
