package com.sample.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.jdbc.core.PreparedStatementSetter;

import com.sample.Employee;

public class EmployeeSetter implements PreparedStatementSetter {
	Employee employee;
	EmployeeSetter(Employee employee){
		this.employee = employee;
	}
	public void setValues(PreparedStatement ps) throws SQLException {
		 ps.setString(1, employee.getFirstName());
         ps.setString(2, employee.getLastName());
         ps.setDouble(3, employee.getSalary());
         ps.setString(4, employee.getPhoneNumber());
         ps.setInt(5,employee.getEmployeeId());
	}
}
