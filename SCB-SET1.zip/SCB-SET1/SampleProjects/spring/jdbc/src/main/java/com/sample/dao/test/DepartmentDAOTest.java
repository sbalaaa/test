package com.sample.dao.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sample.Department;
import com.sample.config.ApplicationConfig;
import com.sample.dao.DepartmentDAOInterface;

public class DepartmentDAOTest {

	private DepartmentDAOInterface departmentDAO = null;
	
	
	public static void main(String args[]) {
		DepartmentDAOTest test = new DepartmentDAOTest();
		//test.testInsertDepartment();
		//test.testGetAllDepartment();
		//test.testGetByDepartmentId();
		//test.testGetByDepartmentName();
		//test.testUpdateByDepartmentId();
		test.testDeleteByDepartmentId();
	}
	

	public void setup(){
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		departmentDAO = (DepartmentDAOInterface) context.getBean("departmentDAOJdbcTemplate");
	}
	

	public void testInsertDepartment(){
		setup();
		Department department = new Department();
		department.setDepartmentName("Sample" + Math.random());
		departmentDAO.insertDepartment(department);
		
		Department obj = departmentDAO.selectDepartmentByName(department.getDepartmentName());
		System.out.println("Department Id is : " + obj.getDepartmentId());
	}
	
	
	public void testGetAllDepartment(){
		setup();
		List<Department> departmentList = departmentDAO.listAllDepartments();
		for( Department obj : departmentList) {
			System.out.println("Department Name is : ->" + obj);
		}
		System.out.println("Department Size is :     -> " + departmentList.size());
	}
	
	public void testGetByDepartmentId(){
		setup();
		Department department = departmentDAO.selectDepartmentById(1);
		System.out.println("Department is : " + department);
	}
	
	public void testGetByDepartmentName(){
		setup();
		Department department = departmentDAO.selectDepartmentByName("PHY");
		System.out.println("Department is : " + department);
	}

	public void testUpdateByDepartmentId(){
		setup();
		Department department = departmentDAO.selectDepartmentById(103);
		String updatedDepartmentName = department.getDepartmentName().substring(0, 10) + "Updated";
		department.setDepartmentName(updatedDepartmentName);
		departmentDAO.updateDepartment(department);
		Department modifiedDepartment = departmentDAO.selectDepartmentById(103);
		System.out.println("Modified Deparment is : -> " + modifiedDepartment);
	}
	
	public void testDeleteByDepartmentId(){
		setup();
		Department beforeDelete = departmentDAO.selectDepartmentById(103);
		System.out.println("Before Delete Deparment is : -> " + beforeDelete);
    	departmentDAO.deleteDepartment(103);
		Department afterDelete = departmentDAO.selectDepartmentById(103);
	}
	
}


