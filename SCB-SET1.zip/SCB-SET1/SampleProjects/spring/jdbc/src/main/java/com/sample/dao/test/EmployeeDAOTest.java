package com.sample.dao.test;

import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.sample.Department;
import com.sample.Employee;
import com.sample.config.ApplicationConfig;
import com.sample.dao.EmployeeDAO;

public class EmployeeDAOTest {
	
	private EmployeeDAO employeeDAO = null;
	
	public static void main(String args[]) {
		EmployeeDAOTest test = new EmployeeDAOTest();
		//test.testInsertEmployee();
		//test.testUpdateEmployee();
		test.testDeleteEmployee();
		//test.getEmployeesByDepartment();
		//test.testGetEmployeeById();
		//test.testGetEmployees();
	}

	public void setup(){
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		employeeDAO = (EmployeeDAO)context.getBean("employeeDAO");;
	}
	

	public void testInsertEmployee(){
		setup();
		Employee employee = new Employee();
		employee.setFirstName("Sample Firstt");
		employee.setLastName("Sample Lastt");
		employee.setGender("M");
		employee.setAge(30);
		employee.setEmail("sample@gmail.com");
		employee.setPhoneNumber("123-4563");
		employee.setHireDate(new Date());
		employee.setSalary(1000.00);
		
		Department department = new Department();
		department.setDepartmentId(2);
		employee.setDepartmentId(department);
	
		employeeDAO.insertEmployee(employee);
		
	}
	

	public void testUpdateEmployee(){
		setup();
		Employee employee = employeeDAO.selectEmployeeById(102);
		employee.setFirstName("FirstUpdateeee");
		employee.setLastName("LastUpdateeee");
		employee.setGender("M");
		employee.setAge(30);
		employee.setEmail("sample@gmail.com");
		employee.setPhoneNumber("123-0000");
		employee.setHireDate(new Date());
		employee.setSalary(3000.00);
		
		Department department = new Department();
		department.setDepartmentId(2);
		employee.setDepartmentId(department);
	
		employeeDAO.updateEmployee(employee);
		
		employee = employeeDAO.selectEmployeeById(102);
		System.out.println("Employee is : " + employee);
	}
	
	

	public void testDeleteEmployee(){
		setup();
		Employee employee = employeeDAO.selectEmployeeById(102);
		System.out.println("Employee is : " + employee);
		employeeDAO.deleteEmployee(102);
		Employee notExistobj = employeeDAO.selectEmployeeById(102);
	}
	
	

	public void testGetEmployeeById(){
		setup();
		Employee existObj = employeeDAO.selectEmployeeById(5);
		System.out.println("Employee is : " + existObj);
	}
	
	public void getEmployeesByDepartment(){
		setup();
		List<Employee> employeeList = employeeDAO.getEmployeesByDepartment(1);
		employeeList.forEach(System.out::println);
	}
	

	public void testGetEmployees(){
		setup();
		List<Employee> employeeList = employeeDAO.listAllEmployees();
		employeeList.forEach(System.out::println);
	}
}
