package com.sc.csl.retail.core;

import com.sc.csl.retail.core.config.*;
import com.sc.csl.retail.core.endpoint.CacheInvalidateEndpoint;
import com.sc.csl.retail.core.exception.CSLExceptionMapper;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.health.EdmiHealthIndicatorAutoConfiguration;
import com.sc.csl.retail.core.web.CSLContextFilter;
import com.sc.csl.retail.core.web.CSLRequestFilter;
import com.sc.csl.retail.core.web.RequestContextConfig;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Slf4j
@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableHystrixDashboard
@EnableEncryptableProperties
@EnableHystrix
@Import({
	AsyncConfig.class,
	CSLExceptionMapper.class,
	BasePropertyConfig.class,
	CSLRequestFilter.class,
	CSLContextFilter.class,
	RequestContextConfig.class,
	CSLCrnkConfigV3.class,
	JacksonConfig.class,
	EdmiHealthIndicatorAutoConfiguration.class,
	HystrixConfig.class,
	CacheInvalidateEndpoint.class,
	AuthConfig.class
})
public abstract class CSLSpringBootApplication extends SpringBootServletInitializer {

	private static final Map<String, Object> defaultProperties = new HashMap<>();
	private static String[] applicationNamePrefixes =  new String[] {"csl-","adc-"} ;

	public CSLSpringBootApplication() {
		setRegisterErrorPageFilter(false);
	}

	protected static void initBase(SpringApplicationBuilder builder, String applicationName) {

		if(isBlank(applicationName)) {
			throw new TechnicalException("Please specify a proper application name like csl-svc-sample.");
		}

		Map<String, Object> baseProperties = loadBaseProperties();
		defaultProperties.putAll(baseProperties);
		defaultProperties.put("spring.application.name", applicationName);
		defaultProperties.put("csl.cache.instanceName", applicationName);
		defaultProperties.put("flyway.enabled", false);

		setUpJMX(applicationName);
		setUpActuator(applicationName);
		setConfigLocation(applicationName);
		setServiceNameInMDC(applicationName);

		builder.properties(defaultProperties);
	}

	private static void setServiceNameInMDC(String applicationName) {
		MDC.put("serviceName", applicationName);
	}

	private static void setUpJMX(String applicationName) {
		defaultProperties.put("spring.jmx.default-domain", applicationName);
	}

	private static void setUpActuator(String applicationName) {
		defaultProperties.put("info.app.name", applicationName);
		defaultProperties.put("info.app.start-time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("E dd-MMM-yyyy HH:mm:ss")));
        setHostInfo();
	}

    private static void setHostInfo() {
        try {
			InetAddress localHost = InetAddress.getLocalHost();
            defaultProperties.put("info.app.host-name", localHost.getHostName());
            defaultProperties.put("info.app.host-ip", localHost.getHostAddress());
        }
        catch (UnknownHostException e) {
            log.warn("Error getting host info", e);
        }
    }

    private static void setConfigLocation(String applicationName) {
		String cslConfigPath = System.getProperty("csl.config.path");
		log.info("Trying to loading csl.config.path in java system properties");

		if(isNotEmpty(cslConfigPath)) {
			log.info("csl.config.path specified as java property : {}", cslConfigPath);
			Path path = Paths.get(cslConfigPath, applicationName, "latest");
			String configPath = path.toString() + "/";

			log.info("Adding spring.config.location : {}", configPath);
			System.setProperty("spring.config.location", configPath);
		}
		else {
			log.info("csl.config.path not found in System properties, so using the packaged application.yml");
		}
	}

	static Map<String, Object> loadBaseProperties() {
		try {
			YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
			MapPropertySource propertySource = (MapPropertySource) loader.load("baseProperties", new ClassPathResource("/config/base-application.yaml"), null);
			return propertySource.getSource();
		} catch (IOException e) {
			throw new TechnicalException("Error loading base-application.yaml", e);
		}
	}

}
