package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.log.LogTimeTaken.Level;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;

import javax.ws.rs.core.Response;
import java.lang.reflect.Method;

import static com.sc.csl.retail.core.util.CSLLogConstants.REST_TIME_TAKEN_KEY;
import static com.sc.csl.retail.core.web.HttpUtil.isErrorResponse;

@Aspect
@Slf4j
public class CSLRestGatewayAspect {
	
	@Pointcut("call(javax.ws.rs.core.Response+ org.apache.cxf.jaxrs.client.WebClient .*(..))" +
              " && this(com.sc.csl.retail.core.gateway.CSLRestGateway+)")
    public void callWebClient() {
    }

    /**
     * Look for all public WebClient method calls which return Response and
     * subclasses within class CSLRestGateway and all subclasses.
     * Logs response code.
     */
    @Around("callWebClient()")
    public Object aroundRest(ProceedingJoinPoint joinPoint) throws Throwable {
        Method method = MethodSignature.class.cast(joinPoint.getSignature()).getMethod();
        String className = joinPoint.getThis().getClass().getSimpleName();
        String methodSignature = className + ":" + method.getName();
        log.debug("HTTP operation : {}", methodSignature);

        long start = System.currentTimeMillis();
        Response response = (Response) joinPoint.proceed();
        long timeTaken = System.currentTimeMillis() - start;
        
        LogTimeTakenAspect.logMessage(Level.INFO,  methodSignature , timeTaken, REST_TIME_TAKEN_KEY);
        if(response != null) {
            int status = response.getStatus();
            if(isErrorResponse(status)) {
                log.info("Unsuccessful HTTP Response for {}, Status : {}", methodSignature, status);
            }
        }
        return response;
    }
}