package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.log.LogTimeTaken.Level;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

import static com.sc.csl.retail.core.util.CSLLogConstants.SOAP_TIME_TAKEN_KEY;

@Aspect
@Slf4j
public class CSLSoapGatewayAspect {

	@Pointcut("withincode(public * com.sc.csl.retail.core.gateway.CSLSoapGateway+ .*(..))")
	public void cslSoapGatewayPublicMethod() {
	}

	@Pointcut("call(@javax.jws.WebMethod * *(..))")
	public void webMethod() {
	}

	/**
	 * Look for all method calls annotated with @WebMethod within class
	 * CSLSoapGateway and all subclasses.
	 */
	@Around("cslSoapGatewayPublicMethod() && webMethod()")
	public Object aroundSoap(ProceedingJoinPoint joinPoint) throws Throwable {
        Method method = MethodSignature.class.cast(joinPoint.getSignature()).getMethod();
        String className = joinPoint.getThis().getClass().getSimpleName();
        String methodSignature = className + ":" + method.getName();
        log.debug("SOAP operation : {}", methodSignature);

        long start = System.currentTimeMillis();
		Object response = joinPoint.proceed();
        long timeTaken = System.currentTimeMillis() - start;

        LogTimeTakenAspect.logMessage(Level.INFO, methodSignature, timeTaken, SOAP_TIME_TAKEN_KEY);
        return response;
	}
}
