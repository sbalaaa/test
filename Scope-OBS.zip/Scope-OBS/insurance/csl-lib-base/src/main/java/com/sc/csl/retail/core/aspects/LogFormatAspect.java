package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.mask.LogArguments;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Marker;

@Aspect
public class LogFormatAspect {
	@Around("call(public void org.slf4j.Logger.*(String)) && args(message)")
	public Object logMessage(String message, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 0);
	}

	@Around("call(public void org.slf4j.Logger.*(String, Object)) && args(message, object)")
	public Object logFormat(String message, Object object, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 0);
	}

	@Around("call(public void org.slf4j.Logger.*(String, Object, Object)) && args(message, obj1, obj2)")
	public Object logFormat2(String message, Object obj1, Object obj2, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 0);
	}

	@Around("call(public void org.slf4j.Logger.*(String, Object...)) && args(message, objects)")
	public Object logFormat3(String message, Object[] objects, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 0);
	}

	@Around("call(public void org.slf4j.Logger.*(String, Throwable)) && args(message, throwable)")
	public Object logException(String message, Throwable throwable, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 0);
	}

	@Around("call(public void org.slf4j.Logger.*(org.slf4j.Marker, String)) && args(marker, message)")
	public Object logWithMarker(Marker marker, String message, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 1);
	}

	@Around("call(public void org.slf4j.Logger.*(org.slf4j.Marker, String, Object)) && args(marker, message, object)")
	public Object logMarkerFormat(Marker marker, String message, Object object, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 1);
	}

	@Around("call(public void org.slf4j.Logger.*(org.slf4j.Marker, String, Object, Object))" + " && args(marker, message, obj1, obj2)")
	public Object logMarkerFormat2(Marker marker, String message, Object obj1, Object obj2, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 1);
	}

	@Around("call(public void org.slf4j.Logger.*(org.slf4j.Marker, String, Object...))" + " && args(marker, message, objects)")
	public Object logMarkerFormat3(Marker marker, String message, Object[] objects, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 1);
	}

	@Around("call(public void org.slf4j.Logger.*(org.slf4j.Marker, String, Throwable))" + " && args(marker, message, throwable)")
	public Object logWithMarkerAndException(Marker marker, String message, Throwable throwable, ProceedingJoinPoint joinPoint) throws Throwable {
		return process(message, joinPoint, 1);
	}

	private Object process(String message, ProceedingJoinPoint joinPoint, int argPosition) throws Throwable {
		Object[] args = joinPoint.getArgs();

		LogArguments logArguments = new LogArguments(args);
		logArguments.mask();

		args[argPosition] = message;
		return joinPoint.proceed(args);
	}
}
