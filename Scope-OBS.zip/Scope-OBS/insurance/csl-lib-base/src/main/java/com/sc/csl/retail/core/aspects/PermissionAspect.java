package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.exception.ForbiddenException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.fap.FapGateway;
import com.sc.csl.retail.core.fap.annotation.Permission;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Map;

import static org.apache.commons.lang3.BooleanUtils.toBoolean;
import static org.apache.commons.lang3.StringUtils.isBlank;


@Aspect
@Slf4j
public class PermissionAspect {
    private static final String CSL_USER_INFO = "CSL-USER-INFO";

    @Around("execution(* *(..)) && @annotation(com.sc.csl.retail.core.fap.annotation.Permission)")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        FapGateway fapGateway = getFapGateway();

        if (!fapGateway.isEnabled()) {
            return joinPoint.proceed();
        }

        String userInfo = this.getCurrentHttpServletRequest().getHeader(CSL_USER_INFO);
        log.info("User info {} ", userInfo);

        if (userInfo != null) {
            MethodSignature sig = (MethodSignature) joinPoint.getSignature();
            Method method = sig.getMethod();

            Permission permission = method.getAnnotation(Permission.class);
            String action = permission.requiredAction();
            String perm = permission.permissionName();
            String appName = permission.appName();

            Class target = joinPoint.getTarget().getClass();
            Permission targetAnnotation = (Permission) target.getAnnotation(Permission.class);
            appName = firstNonEmptyString(appName, targetAnnotation.appName());
            action = firstNonEmptyString(action, targetAnnotation.requiredAction());
            perm = firstNonEmptyString(perm, targetAnnotation.permissionName());

            if (isBlank(appName) || isBlank(perm) || isBlank(action)) {
                throw new TechnicalException("Permission attributes not properly configured");
            }

            Map<String, Object> permInfo = fapGateway.hasPermission(userInfo, appName, perm, action);
            String hasAccess = permInfo.get("hasPermission").toString();

            if (toBoolean(hasAccess)) {
                return joinPoint.proceed();
            }
        }

        throw new ForbiddenException();
    }

    HttpServletRequest getCurrentHttpServletRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
    }

    FapGateway getFapGateway() {
        return FapGateway.getInstance();
    }

    private String firstNonEmptyString(String first, String second) {
        return StringUtils.isNoneEmpty(first) ? first : second;
    }
}

