package com.sc.csl.retail.core.auth;

public enum AccessLevel {
	NO_AUTHENTICATION(-1),
	REGISTERED_DEVICE(0),
	ONE_FACTOR(1),

	TWO_FACTOR(2),
	TWO_FACTOR_PLUS(2),

	HIGH_RISK(4);
	
	int authLevel;

	AccessLevel(int authLevel) {
		this.authLevel = authLevel;
	}

	public int authLevel() {
		return authLevel;
	}
}
