package com.sc.csl.retail.core.auth;

public enum TokenType {
	USER_PREFERRED,
	SMS,
	SOFT_TOKEN
}
