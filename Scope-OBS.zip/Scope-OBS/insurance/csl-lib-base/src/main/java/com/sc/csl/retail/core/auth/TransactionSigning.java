package com.sc.csl.retail.core.auth;

import java.lang.annotation.*;

import static com.sc.csl.retail.core.auth.AccessLevel.TWO_FACTOR;
import static com.sc.csl.retail.core.auth.TokenType.USER_PREFERRED;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface TransactionSigning {
	AccessLevel accessLevel() default TWO_FACTOR;
	TokenType tokenType() default USER_PREFERRED;
	String actionName();
	boolean riskAssessmentRequired() default true;
	String riskAssessmentId() default "CSL";
	String txnType() default "";
	String mpinPurpose() default "";
}
