package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.config.helper.CxfAsyncProperties;
import com.sc.csl.retail.core.web.CSLTaskDecorator;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.transport.http.asyncclient.AsyncHTTPConduit;
import org.apache.cxf.transport.http.asyncclient.AsyncHTTPConduitFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.annotation.PostConstruct;
import java.util.concurrent.Executor;

@Slf4j
@Setter
@Configuration
@EnableAsync(proxyTargetClass = true)
public class AsyncConfig {
	private static final int DEFAULT_CORE_POOL_SIZE = 5;
	private static final int DEFAULT_MAX_POOL_SIZE = 10;

	@Bean
	public Executor executor(@Autowired Executor threadPoolTaskExecutor) {
		return threadPoolTaskExecutor;
	}

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "csl.thread.pool.async.config")
	public Executor threadPoolTaskExecutor(CSLTaskDecorator taskDecorator) {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskDecorator.setTaskExecutor(taskExecutor);
		taskExecutor.setTaskDecorator(taskDecorator);
		taskExecutor.setCorePoolSize(DEFAULT_CORE_POOL_SIZE);
		taskExecutor.setMaxPoolSize(DEFAULT_MAX_POOL_SIZE);
		taskExecutor.setThreadNamePrefix("CSL-TP-ASYNC");
		return taskExecutor;
	}

	@Bean
	public CSLTaskDecorator taskDecorator() {
		return new CSLTaskDecorator();
	}

	@PostConstruct
	public void forceAsyncHttpConduit() {
		Bus bus = BusFactory.getDefaultBus();
		bus.setProperty(AsyncHTTPConduit.USE_ASYNC, Boolean.TRUE);
		bus.setProperty(AsyncHTTPConduitFactory.CONNECTION_TTL, cxfAsyncProperties.getConnectionTTL());
		bus.setProperty(AsyncHTTPConduitFactory.MAX_CONNECTIONS, cxfAsyncProperties.getMaxConnections());
		bus.setProperty(AsyncHTTPConduitFactory.MAX_PER_HOST_CONNECTIONS, cxfAsyncProperties.getMaxPerHostConnections());
		bus.setProperty(AsyncHTTPConduitFactory.THREAD_COUNT, cxfAsyncProperties.getThreadCount());
		log.info("Forcing AsyncHttpConduit : {}", cxfAsyncProperties);
	}

	@Bean
	@ConfigurationProperties(prefix = "csl.cxf.async.properties")
	public CxfAsyncProperties cxfAsyncProperties() {
		return new CxfAsyncProperties();
	}

	@Bean
	public AsyncUncaughtExceptionHandler asyncUncaughtExceptionHandler() {
		return (ex, method, params) -> log.error("Exception occurred in async thread", ex);
	}

	@Autowired
	private CxfAsyncProperties cxfAsyncProperties;
}