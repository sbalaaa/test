package com.sc.csl.retail.core.config;


import com.sc.csl.retail.core.web.AuthGateway;
import com.sc.csl.retail.core.web.CSLAuthFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;

@Slf4j
public class AuthConfig {
    @Bean
    @ConfigurationProperties("csl.auth.gateway")
    public AuthGateway authGateway() {
        return AuthGateway.getInstance();
    }

    @Bean
    @ConditionalOnMissingBean(CSLAuthFilter.class)
    public CSLAuthFilter cslAuthFilter() {
        return new CSLAuthFilter();
    }
}
