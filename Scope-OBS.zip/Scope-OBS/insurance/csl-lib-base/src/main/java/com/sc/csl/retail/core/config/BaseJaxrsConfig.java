package com.sc.csl.retail.core.config;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.sc.csl.retail.core.exception.CSLExceptionMapper;
import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxrs.swagger.Swagger2Feature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;

@Configuration
public abstract class BaseJaxrsConfig {
	@Autowired
	private Bus bus;

	@Autowired
	private JacksonJsonProvider jacksonJsonProvider;

	@Autowired
	private CSLExceptionMapper cslExceptionMapper;

	@Bean
	@Autowired
	public Server jaxrsEndpoint(Swagger2Feature swagger2Feature) {
		JAXRSServerFactoryBean endpoint = new JAXRSServerFactoryBean();
		endpoint.setBus(bus);
		endpoint.setFeatures(Arrays.asList(
			swagger2Feature
		));
		endpoint.setProviders(Arrays.asList(
			cslExceptionMapper,
			jacksonJsonProvider
		));

		configureEndpoint(endpoint);
		return endpoint.create();
	}

	protected abstract void configureEndpoint(JAXRSServerFactoryBean endpoint);

	@Bean
	public Swagger2Feature swagger2Feature() {
		Swagger2Feature feature = new Swagger2Feature();
		return feature;
	}
}
