package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.model.CSLApplicationConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class BasePropertyConfig {

	@Value("${spring.application.name}")
	private String applicationName;

	@Bean
	public CSLApplicationConfig cslApplicationConfig() {
		CSLApplicationConfig appConfig = new CSLApplicationConfig();
		log.info("spring.application.name : {}", applicationName);
		CSLApplicationConfig.setApplicationName(applicationName);

		return appConfig;
	}
}
