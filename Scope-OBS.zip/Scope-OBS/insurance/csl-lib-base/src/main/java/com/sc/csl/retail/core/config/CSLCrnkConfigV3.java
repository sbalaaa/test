package com.sc.csl.retail.core.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.crnk.CSLCrnkBoot;
import com.sc.csl.retail.core.web.CSLCrnkFilter;
import io.crnk.core.boot.CrnkBoot;
import io.crnk.core.engine.url.ConstantServiceUrlProvider;
import io.crnk.servlet.internal.ServletModule;
import io.crnk.spring.boot.CrnkSpringBootProperties;
import io.crnk.spring.boot.v3.CrnkConfigV3;
import io.crnk.spring.internal.SpringServiceDiscovery;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import javax.servlet.Filter;


public class CSLCrnkConfigV3  extends CrnkConfigV3 {

	@Setter
	private ApplicationContext applicationContext;

	private CrnkSpringBootProperties properties;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	public CSLCrnkConfigV3(CrnkSpringBootProperties properties, ObjectMapper objectMapper) {
		super(properties, objectMapper);
		this.properties = properties;
	}

    @Override
    public Filter springBootSampleCrnkFilter(CrnkBoot boot) {
        return new CSLCrnkFilter(boot, properties);
    }


	@Bean
	@Override
	public CrnkBoot crnkBoot(SpringServiceDiscovery serviceDiscovery) {
		CSLCrnkBoot boot = new CSLCrnkBoot();
		boot.setObjectMapper(this.objectMapper);
		if(this.properties.getDomainName() != null && this.properties.getPathPrefix() != null) {
			String baseUrl = this.properties.getDomainName() + this.properties.getPathPrefix();
			boot.setServiceUrlProvider(new ConstantServiceUrlProvider(baseUrl));
		}

		boot.setServiceDiscovery(serviceDiscovery);
		boot.setDefaultPageLimit(this.properties.getDefaultPageLimit());
		boot.setMaxPageLimit(this.properties.getMaxPageLimit());
		boot.setPropertiesProvider(key -> "crnk.config.core.resource.package".equals(key) ?
                CSLCrnkConfigV3.this.properties.getResourcePackage() :
                ("crnk.config.core.resource.domain".equals(key) ?
                        CSLCrnkConfigV3.this.properties.getDomainName() :
                        ("crnk.config.web.path.prefix".equals(key) ?
                                CSLCrnkConfigV3.this.properties.getPathPrefix() :
                                ("crnk.config.resource.request.allowUnknownAttributes".equals(key) ?
                                        String.valueOf(CSLCrnkConfigV3.this.properties.getAllowUnknownAttributes()) :
                                        ("crnk.config.resource.response.return_404".equals(key) ?
                                                String.valueOf(CSLCrnkConfigV3.this.properties.getReturn404OnNull()) :
                                                CSLCrnkConfigV3.this.applicationContext.getEnvironment().getProperty(key))))));
		boot.setAllowUnknownAttributes();
		boot.addModule(new ServletModule(boot.getModuleRegistry().getHttpRequestContextProvider()));
		boot.boot();

		return boot;
	}

}
