package com.sc.csl.retail.core.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class DB2DataSourceConfig {
	private static final int IDLE_CONNECTION_TEST_PERIOD = 30;

	@Bean
	@ConfigurationProperties(prefix = "db2.datasource")
	public DataSource db2DataSource() {
		ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
		comboPooledDataSource.setTestConnectionOnCheckin(true);
		comboPooledDataSource.setPreferredTestQuery("SELECT 1 FROM SYSIBM.SYSDUMMY1");
		comboPooledDataSource.setIdleConnectionTestPeriod(IDLE_CONNECTION_TEST_PERIOD);

		return comboPooledDataSource;
	}
}
