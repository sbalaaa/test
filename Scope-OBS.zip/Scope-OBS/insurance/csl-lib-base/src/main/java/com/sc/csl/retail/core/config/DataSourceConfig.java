package com.sc.csl.retail.core.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {
	private static final int IDLE_CONNECTION_TEST_PERIOD = 30;

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "oracle.datasource")
	public DataSource cslDataSource() {
		ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
		comboPooledDataSource.setTestConnectionOnCheckin(true);
		comboPooledDataSource.setPreferredTestQuery("SELECT 1 FROM DUAL");
		comboPooledDataSource.setIdleConnectionTestPeriod(IDLE_CONNECTION_TEST_PERIOD);

		return comboPooledDataSource;
	}
}
