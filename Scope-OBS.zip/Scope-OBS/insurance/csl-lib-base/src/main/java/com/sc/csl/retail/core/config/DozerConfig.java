package com.sc.csl.retail.core.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class DozerConfig {

	@Bean
	@ConfigurationProperties(prefix = "dozer")
	public DozerMappingFiles dozerMappingFiles() {
		return new DozerMappingFiles();
	}

	@Bean
	public DozerBeanMapper dozerBeanMapper(DozerMappingFiles dozerMappingFiles) {
		return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFiles {
		private List<String> mappingFiles = new ArrayList<>();
	}
}
