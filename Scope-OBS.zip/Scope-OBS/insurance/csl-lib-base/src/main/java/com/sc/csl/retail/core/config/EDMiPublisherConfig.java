package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.edmi.EDMiConnectionFactory;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class EDMiPublisherConfig {

	@Bean
	@ConfigurationProperties(prefix = "edmi.publisher.connection")
	public EDMiConnectionFactory edmiPubConnectionFactory() {
		return new EDMiConnectionFactory();
	}

	@Bean(destroyMethod = "stop", initMethod = "start")
	@ConfigurationProperties(prefix = "edmi.publisher.connection.pool")
	public PooledConnectionFactory edmiPubPooledConnectionFactory(EDMiConnectionFactory edmiPubConnectionFactory) {
		PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory();
		pooledConnectionFactory.setConnectionFactory(edmiPubConnectionFactory);
		return pooledConnectionFactory;
	}

	@Bean
	@ConfigurationProperties(prefix = "edmi.publisher.template")
	public JmsTemplate edmiPubJmsTemplate(PooledConnectionFactory edmiPubPooledConnectionFactory){
		JmsTemplate template = new JmsTemplate();
		template.setConnectionFactory(edmiPubPooledConnectionFactory);
		return template;
	}
}
