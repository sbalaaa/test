package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.edmi.EDMiConnectionFactory;
import com.sc.csl.retail.core.jms.CSLJmsListenerContainerFactory;
import com.sc.csl.retail.core.util.CSLConstants;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class EDMiSubscriberConfig {

	@Bean
	@ConfigurationProperties(prefix = "edmi.subscriber.connection")
	public EDMiConnectionFactory edmiSubConnectionFactory() {
		return new EDMiConnectionFactory();
	}

	@Bean(destroyMethod = "stop", initMethod = "start")
	@ConfigurationProperties(prefix = "edmi.subscriber.connection.pool")
	public PooledConnectionFactory edmiSubPooledConnectionFactory(EDMiConnectionFactory edmiSubConnectionFactory) {
		PooledConnectionFactory pooledConnectionFactory = new PooledConnectionFactory();
		pooledConnectionFactory.setConnectionFactory(edmiSubConnectionFactory);
		return pooledConnectionFactory;
	}

	@Bean
	@ConfigurationProperties(prefix = "edmi.subscriber.template")
	public JmsTemplate edmiSubJmsTemplate(PooledConnectionFactory edmiSubPooledConnectionFactory){
		JmsTemplate template = new JmsTemplate();
		template.setConnectionFactory(edmiSubPooledConnectionFactory);
		return template;
	}

	@Bean
	@ConfigurationProperties(prefix = "edmi.subscriber.listener")
	public DefaultJmsListenerContainerFactory edmiSubListenerContainerFactory(
			PooledConnectionFactory edmiSubPooledConnectionFactory) {
		DefaultJmsListenerContainerFactory factory = new CSLJmsListenerContainerFactory();
		factory.setConnectionFactory(edmiSubPooledConnectionFactory);
		factory.setBackOff(CSLConstants.DEFAULT_BACK_OFF);
		return factory;
	}
}
