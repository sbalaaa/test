package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.fap.FapGateway;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FapConfig {
    @Bean
    @ConfigurationProperties(prefix = "csl.fap")
    public FapGateway fapGateway() {
        return FapGateway.getInstance();
    }
}
