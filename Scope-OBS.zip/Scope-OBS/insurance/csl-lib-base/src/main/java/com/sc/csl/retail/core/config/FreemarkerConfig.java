package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.render.FreemarkerRenderer;
import freemarker.cache.ClassTemplateLoader;
import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FreemarkerConfig {

    @Value(value = "${freemarker.templatePath}")
    private String templatePath ="/templates/freemarker/";

    @Bean
    @ConfigurationProperties(prefix = "freemarker")
    public freemarker.template.Configuration freemarkerConfiguration() {
        // Create your Configuration instance, and specify if up to what FreeMarker
        // version (here 2.3.25) do you want to apply the fixes that are not 100%
        // backward-compatible. See the Configuration JavaDoc for details.
        freemarker.template.Configuration cfg = new freemarker.template.Configuration(freemarker.template.Configuration.VERSION_2_3_26);

        ClassTemplateLoader loader = new ClassTemplateLoader(this.getClass(), templatePath);
        cfg.setTemplateLoader(loader);
        cfg.setDefaultEncoding("UTF-8");

        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

        return cfg;
    }

    @Bean
    public FreemarkerRenderer freemarkerRenderer(freemarker.template.Configuration freemarkerConfiguration) {
        return new FreemarkerRenderer(freemarkerConfiguration);
    }
}
