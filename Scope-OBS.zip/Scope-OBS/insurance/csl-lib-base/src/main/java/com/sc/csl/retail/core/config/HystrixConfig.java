package com.sc.csl.retail.core.config;

import com.netflix.hystrix.strategy.HystrixPlugins;
import com.sc.csl.retail.core.web.CSLHystrixExecutionHook;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
@Slf4j
public class HystrixConfig {

    @PostConstruct
    public void configureHystrix() {
    	log.info("Configuring hystrix settings");
		HystrixPlugins plugins = HystrixPlugins.getInstance();
		CSLHystrixExecutionHook executionHook = new CSLHystrixExecutionHook();
		plugins.registerCommandExecutionHook(executionHook);
    }
}
