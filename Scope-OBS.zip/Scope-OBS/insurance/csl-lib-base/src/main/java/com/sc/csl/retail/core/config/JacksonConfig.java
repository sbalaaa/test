package com.sc.csl.retail.core.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {
	private static ObjectMapper objectMapper = CSLJsonUtils.newObjectMapper();
	private static JacksonJsonProvider jsonProvider = new JacksonJsonProvider(objectMapper);

	@Bean
	public ObjectMapper objectMapper() {
		return objectMapper;
	}

	@Bean
	public JacksonJsonProvider jacksonJsonProvider(ObjectMapper objectMapper) {
		return jsonProvider;
	}

	public static JacksonJsonProvider jacksonJsonProvider() {
		return jsonProvider;
	}
}
