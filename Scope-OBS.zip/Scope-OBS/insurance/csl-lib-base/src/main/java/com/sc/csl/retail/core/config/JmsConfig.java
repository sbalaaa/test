package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.jms.CSLJmsListenerContainerFactory;
import com.sc.csl.retail.core.util.CSLConstants;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;

@Configuration
public class JmsConfig {
	@Value("${jms.connection.brokerUrl}")
	private String brokerUrl;

	@Bean
	@ConfigurationProperties(prefix = "jms.connection")
	public ActiveMQConnectionFactory connectionFactory() {
		return new ActiveMQConnectionFactory(brokerUrl);
	}

	@Bean(destroyMethod = "stop", initMethod = "start")
	@ConfigurationProperties(prefix = "jms.connection.pool")
	public PooledConnectionFactory pooledConnectionFactory(ActiveMQConnectionFactory connectionFactory) {
		return new PooledConnectionFactory(connectionFactory);
	}

	@Bean
	@ConfigurationProperties(prefix = "jms.template")
	public JmsTemplate jmsTemplate(PooledConnectionFactory pooledConnectionFactory){
		JmsTemplate template = new JmsTemplate();
		template.setConnectionFactory(pooledConnectionFactory);
		return template;
	}

	@Bean
	@ConfigurationProperties(prefix = "jms.listener")
	public DefaultJmsListenerContainerFactory jmsListenerContainerFactory(PooledConnectionFactory pooledConnectionFactory) {
		DefaultJmsListenerContainerFactory factory = new CSLJmsListenerContainerFactory();
		factory.setConnectionFactory(pooledConnectionFactory);
		factory.setBackOff(CSLConstants.DEFAULT_BACK_OFF);
		return factory;
	}
}
