package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.render.ThymeleafRenderer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.spring4.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.templateresolver.TemplateResolver;

@Configuration
public class ThymeleafConfig {

    @Bean
    @ConfigurationProperties(prefix = "thymeleaf")
    public TemplateResolver templateResolver() {
        return new SpringResourceTemplateResolver();
    }

    @Bean
    public TemplateEngine templateEngine(TemplateResolver templateResolver) {
        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);
        return templateEngine;
    }

    @Bean
    public ThymeleafRenderer thymeleafRenderer(TemplateEngine templateEngine) {
        return new ThymeleafRenderer(templateEngine);
    }
}
