package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.tmx.gateway.TmxEdmiGatewayImpl;
import com.sc.csl.retail.core.tmx.gateway.TmxGateway;
import com.sc.csl.retail.core.tmx.service.TmxProcessorService;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.core.web.TmxEnabledAspect;
import lombok.Data;
import org.apache.commons.codec.binary.Base64;
import org.aspectj.lang.Aspects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.BASIC_SCHEME;

@Configuration
@Data
public class TmxConfig {

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private FreemarkerRenderer freemarkerRenderer;

    @Bean
    @ConfigurationProperties(prefix = "tmx.common")
    public CommonConfig tmxCommonConfiguration() {
        return new CommonConfig();
    }

    @Bean
    @ConfigurationProperties(prefix = "tmx.countries")
    public Map<String, Map<String, String>> tmxCountriesConfigurationRawMap() {
        return new HashMap<String, Map<String, String>>();
    }

    @Bean
    public TmxEnabledAspect tmxEnabledAspect()
    {
        final TmxEnabledAspect tmxEnabledAspect = Aspects.aspectOf(TmxEnabledAspect.class);
        return tmxEnabledAspect;
    }

    @Bean
    public Map<String, TmxCountryConfig> tmxCountriesConfigurationMap(Map<String, Map<String, String>> tmxCountriesConfigurationRawMap) {
        return tmxCountriesConfigurationRawMap.entrySet().stream().collect( Collectors.toMap( e -> e.getKey().toUpperCase(), e -> {
            TmxCountryConfig tmxCountryConfig = new TmxCountryConfig();
            tmxCountryConfig.setPassword(e.getValue().get("password"));
            tmxCountryConfig.setUsername(e.getValue().get("username"));
            tmxCountryConfig.setApiKey(e.getValue().get("apiKey"));
            tmxCountryConfig.setOrgId(e.getValue().get("orgId"));
            return tmxCountryConfig;
        }));
    }

    @Bean(name = "tmxGateway")
    @ConfigurationProperties(prefix = "tmx.gateway")
    public TmxGateway tmxGateway(Map<String, TmxCountryConfig> tmxCountriesConfigurationMap) {

        TmxEdmiGatewayImpl tmxEdmiGateway = new TmxEdmiGatewayImpl();
        tmxEdmiGateway.setCslRequestContext(cslRequestContext);
        tmxEdmiGateway.setFreemarkerRenderer(freemarkerRenderer);

        Map<String, String> tmxBasicAuthMap = tmxCountriesConfigurationMap.entrySet().stream().
                collect(Collectors.toMap(e -> e.getKey(), e -> createAuthSchemeString(e.getValue())));

        tmxEdmiGateway.setTmxBasicAuthMap(tmxBasicAuthMap);

        return tmxEdmiGateway;
    }

    private String createAuthSchemeString(TmxCountryConfig tmxConfiguration) {
        String rawLine = String.format("%s:%s", tmxConfiguration.getUsername(), tmxConfiguration.getPassword());
        String encodedLine = new String(Base64.encodeBase64(rawLine.getBytes()));
        return String.format("%s %s", BASIC_SCHEME, encodedLine);
    }

    @Bean
    public TmxProcessorService tmxProcessorService(TmxGateway tmxGateway,
                                                   CommonConfig tmxCommonConfiguration,
                                                   Map<String, TmxCountryConfig> tmxCountriesConfigurationMap) {

        TmxProcessorService tmxProcessorService = TmxProcessorService.getInstance();

        tmxProcessorService.setTmxGateway(tmxGateway);
        tmxProcessorService.setCslRequestContext(cslRequestContext);
        tmxProcessorService.setTmxCommonConfig(tmxCommonConfiguration);
        tmxProcessorService.setCountryConfigMap(tmxCountriesConfigurationMap);

        return tmxProcessorService;
    }

    @Data
    public static class TmxCountryConfig {
        private String username;
        private String password;
        private String orgId;
        private String apiKey;
        private String lineOfBusiness;
    }

    @Data
    public static class CommonConfig {
        private  String messageVersion;
        private  String messageTypeName;
        private  String messageSenderBody;
        private  String messageSenderDomainName;
        private  String messageSenderSubDomainNameType;
        private  String originationCountryCode;
        private  String captureSystem;
        private  String applicationName;
        private  String requestPayloadFormat;
        private  String possibleDuplicate;
        private  String requestPayloadVersion;
        private  String requestServiceTypeTMX;
        private  String requestOutputFormat;
    }
}


