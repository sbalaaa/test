package com.sc.csl.retail.core.config;

import com.sc.csl.retail.core.tsp.gateway.ChallengeCodeGateway;
import com.sc.csl.retail.core.tsp.gateway.ChallengeCodeGatewayImpl;
import com.sc.csl.retail.core.tsp.gateway.RiskAssessmentGateway;
import com.sc.csl.retail.core.tsp.gateway.RiskAssessmentGatewayImpl;
import com.sc.csl.retail.core.tsp.service.ChallengeCodeService;
import com.sc.csl.retail.core.tsp.service.RiskAssessmentService;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Data
public class TransactionSigningConfig {

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Bean(name = "riskAssessmentGateway")
    @ConfigurationProperties(prefix = "csl.rest.tsp.risk-assessment-gateway")
    public RiskAssessmentGateway riskAssessmentGateway() {
        RiskAssessmentGatewayImpl riskAssessmentGateway = new RiskAssessmentGatewayImpl();
        return riskAssessmentGateway;
    }

    @Bean
    public RiskAssessmentService riskAssessmentService(RiskAssessmentGateway riskAssessmentGateway) {
        RiskAssessmentService riskAssessmentService = RiskAssessmentService.getInstance();
        riskAssessmentService.setRiskAssessmentGateway(riskAssessmentGateway);
        riskAssessmentService.setCslRequestContext(cslRequestContext);
        return riskAssessmentService;
    }

    @Bean(name = "challengeCodeGateway")
    @ConfigurationProperties(prefix = "csl.rest.tsp.challenge-code-gateway")
    public ChallengeCodeGateway challengeCodeGateway() {
        ChallengeCodeGatewayImpl challengeCodeGatewayImpl = new ChallengeCodeGatewayImpl();
        return challengeCodeGatewayImpl;
    }

    @Bean
    public ChallengeCodeService challengeCodeService(ChallengeCodeGateway challengeCodeGateway) {
        ChallengeCodeService challengeCodeService = ChallengeCodeService.getInstance();
        challengeCodeService.setChallengeCodeGateway(challengeCodeGateway);
        challengeCodeService.setCslRequestContext(cslRequestContext);
        return challengeCodeService;
    }
}


