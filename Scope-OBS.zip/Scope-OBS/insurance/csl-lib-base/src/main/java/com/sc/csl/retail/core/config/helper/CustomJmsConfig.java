package com.sc.csl.retail.core.config.helper;

import com.sc.csl.retail.core.util.CSLConstants;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.pool.PooledConnectionFactory;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;

public class CustomJmsConfig {
	protected ActiveMQConnectionFactory connection;
	protected PooledConnectionFactory pool;
	protected JmsTemplate template;
	protected DefaultJmsListenerContainerFactory listener;

	public CustomJmsConfig(String brokerUrl) {
		connection = new ActiveMQConnectionFactory(brokerUrl);
		pool = new PooledConnectionFactory(connection);

		template = new JmsTemplate();
		template.setConnectionFactory(pool);

		listener = new DefaultJmsListenerContainerFactory();
		listener.setConnectionFactory(pool);
		listener.setBackOff(CSLConstants.DEFAULT_BACK_OFF);
	}
}
