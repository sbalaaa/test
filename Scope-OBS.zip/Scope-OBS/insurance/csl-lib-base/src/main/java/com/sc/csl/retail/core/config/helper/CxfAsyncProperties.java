package com.sc.csl.retail.core.config.helper;

import lombok.Data;

@Data
public class CxfAsyncProperties {
	private Integer maxConnections = 5000;
	private Integer maxPerHostConnections = 1000;
	private Integer connectionTTL = 60000;
	private Integer threadCount = -1;
}
