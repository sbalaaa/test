package com.sc.csl.retail.core.config.helper;

import lombok.Getter;

@Getter
public class EDMiPublisher extends EdmiConnectionBase {
	public EDMiPublisher() {
		pool.setConnectionFactory(connection);
		template.setConnectionFactory(pool);
	}
}
