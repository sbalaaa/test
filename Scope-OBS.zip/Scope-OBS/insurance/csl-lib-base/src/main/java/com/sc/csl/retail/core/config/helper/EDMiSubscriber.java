package com.sc.csl.retail.core.config.helper;

import com.sc.csl.retail.core.util.CSLConstants;
import lombok.Getter;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;

@Getter
public class EDMiSubscriber extends EdmiConnectionBase {
	protected DefaultJmsListenerContainerFactory listener = new DefaultJmsListenerContainerFactory();

	public EDMiSubscriber() {
		pool.setConnectionFactory(connection);
		template.setConnectionFactory(pool);

		listener.setConnectionFactory(pool);
		listener.setBackOff(CSLConstants.DEFAULT_BACK_OFF);
	}
}
