package com.sc.csl.retail.core.config.helper;

import com.sc.csl.retail.core.edmi.EDMiConnectionFactory;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

@Getter
@Setter(value = AccessLevel.PROTECTED)
public class EdmiConnectionBase {
	protected EDMiConnectionFactory connection = new EDMiConnectionFactory();
	protected PooledConnectionFactory pool = new PooledConnectionFactory();
	protected JmsTemplate template = new JmsTemplate();
}
