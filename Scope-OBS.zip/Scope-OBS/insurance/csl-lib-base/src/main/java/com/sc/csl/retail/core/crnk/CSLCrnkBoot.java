package com.sc.csl.retail.core.crnk;

import com.sc.csl.retail.core.crnk.action.CSLResourcePatch;
import com.sc.csl.retail.core.crnk.action.CSLResourcePost;
import com.sc.csl.retail.core.exception.TechnicalException;
import io.crnk.core.boot.CrnkBoot;
import io.crnk.core.engine.dispatcher.RequestDispatcher;
import io.crnk.core.engine.internal.dispatcher.ControllerRegistry;
import io.crnk.core.engine.internal.dispatcher.controller.BaseController;
import io.crnk.core.engine.internal.dispatcher.controller.ResourcePatch;
import io.crnk.core.engine.internal.dispatcher.controller.ResourcePost;
import io.crnk.core.engine.parser.TypeParser;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.reflect.FieldUtils;

import java.util.List;

@Slf4j
public class CSLCrnkBoot extends CrnkBoot {

    @Override
    public void boot() {
        super.boot();
        registerSidePosting();
    }

    private void registerSidePosting() {
        log.info("Registering custom Crnk ResourcePost and ResourcePatch for side posting support");
        RequestDispatcher requestDispatcher = this.getRequestDispatcher();

        try {
            ControllerRegistry controllerRegistry = (ControllerRegistry) FieldUtils.readField(requestDispatcher, "controllerRegistry", true);
            List<BaseController> controllers = (List<BaseController>) FieldUtils.readField(controllerRegistry, "controllers", true);

            controllers.removeIf(c -> c instanceof ResourcePost);
            CSLResourcePost resourcePost = new CSLResourcePost(this.getResourceRegistry(),
                    this.getPropertiesProvider(),
                    new TypeParser(),
                    this.getObjectMapper(),
                    this.getDocumentMapper(),
                    this.getModuleRegistry().getResourceModificationFilters());
            controllers.add(resourcePost);

            controllers.removeIf(c -> c instanceof ResourcePatch);
            CSLResourcePatch resourcePatch = new CSLResourcePatch(this.getResourceRegistry(),
                    this.getPropertiesProvider(),
                    new TypeParser(),
                    this.getObjectMapper(),
                    this.getDocumentMapper(),
                    this.getModuleRegistry().getResourceModificationFilters());
            controllers.add(resourcePatch);
        }
        catch (Exception e) {
            log.error("Error registering custom ResourcePost for side posting", e);
            throw new TechnicalException(e);
        }
    }
}