package com.sc.csl.retail.core.crnk;

import com.sc.csl.retail.core.crnk.helper.CSLClientDocumentMapper;
import com.sc.csl.retail.core.crnk.helper.CSLHttpAdapter;
import com.sc.csl.retail.core.exception.CSLCrnkClientExceptionMapper;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import io.crnk.client.CrnkClient;
import io.crnk.client.internal.proxy.BasicProxyFactory;
import io.crnk.core.engine.error.ExceptionMapper;
import io.crnk.core.engine.error.JsonApiExceptionMapper;
import io.crnk.core.engine.internal.exception.ExceptionMapperRegistry;
import io.crnk.core.engine.properties.NullPropertiesProvider;
import io.crnk.core.exception.CrnkMappableException;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Set;

public class CSLCrnkClient extends CrnkClient {

	private static ExceptionMapper exceptionMapper;
    private boolean alreadyInitialized = false;

    static {
        exceptionMapper = new CSLCrnkClientExceptionMapper();
    }
    
	public CSLCrnkClient(String baseUrl, String serviceUrl) {
		super(serviceUrl);
		this.setHttpAdapter(new CSLHttpAdapter(baseUrl));
		super.getModuleRegistry().setObjectMapper(this.getObjectMapper());
		CSLJsonUtils.setDefaultObjectMapperProperties (this.getObjectMapper());
		setClientDocumentMapper();
    }

    private void setClientDocumentMapper() {
        CSLClientDocumentMapper cslDocumentMapper = new CSLClientDocumentMapper(getModuleRegistry(), getObjectMapper(), new NullPropertiesProvider());
        Field documentMapperField = FieldUtils.getField(this.getClass(), "documentMapper", true);
        ReflectionUtils.setField(documentMapperField, this, cslDocumentMapper);
        this.setProxyFactory(new BasicProxyFactory());
    }

    @Override
    protected void init() {
        if (alreadyInitialized) return;

        super.init();
        //Dirty hack to set the exception handler to crnk client
        try {
            Field registryField = FieldUtils.getField(this.getClass(), "exceptionMapperRegistry", true);
            ExceptionMapperRegistry registry = (ExceptionMapperRegistry) ReflectionUtils.getField(registryField, this);
            Field mappersField = FieldUtils.getField(ExceptionMapperRegistry.class, "exceptionMappers", true);
            Set exceptionMappers = (Set) ReflectionUtils.getField(mappersField, registry);
            Object defaultMapper = exceptionMappers.iterator().next();
            Class clazz = Class.forName("io.crnk.core.engine.internal.exception.ExceptionMapperType");
            Constructor constructor = clazz.getDeclaredConstructor(Class.class, JsonApiExceptionMapper.class);
            constructor.setAccessible(true);
            Object newInstance = constructor.newInstance(CrnkMappableException.class, exceptionMapper);

            exceptionMappers.clear();
            exceptionMappers.add(newInstance);
            alreadyInitialized = true;
        }
        catch (Exception ex) {
            throw new TechnicalException(ex);
        }
    }

}
