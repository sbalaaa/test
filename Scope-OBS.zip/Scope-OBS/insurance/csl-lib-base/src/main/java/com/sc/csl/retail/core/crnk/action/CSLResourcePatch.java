package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.crnk.core.engine.dispatcher.Response;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.filter.ResourceModificationFilter;
import io.crnk.core.engine.internal.dispatcher.controller.ResourcePatch;
import io.crnk.core.engine.internal.dispatcher.path.JsonPath;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.internal.repository.ResourceRepositoryAdapter;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.PropertiesProvider;
import io.crnk.core.engine.query.QueryAdapter;
import io.crnk.core.engine.registry.RegistryEntry;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.repository.response.JsonApiResponse;
import io.crnk.legacy.internal.RepositoryMethodParameterProvider;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Set;

@Slf4j
public class CSLResourcePatch extends ResourcePatch {

    private static final int CREATED_STATUS_CODE = 201;
    private SidePostDocumentMapper sidePostDocumentMapper;

    public CSLResourcePatch(ResourceRegistry resourceRegistry,
                            PropertiesProvider propertiesProvider,
                            TypeParser typeParser,
                            ObjectMapper objectMapper,
                            DocumentMapper documentMapper,
                            List<ResourceModificationFilter> modificationFilters) {

        super(resourceRegistry, propertiesProvider, typeParser, objectMapper, documentMapper, modificationFilters);
        this.sidePostDocumentMapper = new SidePostDocumentMapper(
                resourceRegistry,
                objectMapper,
                propertiesProvider,
                typeParser,
                documentMapper);
    }

    public Response handle(JsonPath jsonPath, QueryAdapter queryAdapter, RepositoryMethodParameterProvider parameterProvider, Document document) {
        log.debug("Custom Resource Patch with side posting support");
        Object object = sidePostDocumentMapper.fromDocument(document, false);

        String resourceEndpointName = jsonPath.getResourceType();
        RegistryEntry endpointRegistryEntry = this.resourceRegistry.getEntry(resourceEndpointName);
        ResourceRepositoryAdapter resourceRepository = endpointRegistryEntry.getResourceRepository(parameterProvider);

        JsonApiResponse apiResponse = resourceRepository.update(object, queryAdapter);
        if(apiResponse.getEntity() == null) {
            throw new IllegalStateException("repository did not return the created resource");
        } else {
            Resource resourceBody = (Resource)document.getData().get();
            Set loadedRelationshipNames = this.getLoadedRelationshipNames(resourceBody);
            Document responseDocument = this.documentMapper.toDocument(apiResponse, queryAdapter, parameterProvider, loadedRelationshipNames);
            return new Response(responseDocument, CREATED_STATUS_CODE);
        }
    }

}
