package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.crnk.core.engine.dispatcher.Response;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.document.ResourceIdentifier;
import io.crnk.core.engine.filter.ResourceModificationFilter;
import io.crnk.core.engine.http.HttpMethod;
import io.crnk.core.engine.information.resource.ResourceInformation;
import io.crnk.core.engine.internal.dispatcher.controller.ResourceUpsert;
import io.crnk.core.engine.internal.dispatcher.path.JsonPath;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.PropertiesProvider;
import io.crnk.core.engine.query.QueryAdapter;
import io.crnk.core.engine.registry.RegistryEntry;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.exception.RepositoryNotFoundException;
import io.crnk.legacy.internal.RepositoryMethodParameterProvider;

import java.io.Serializable;
import java.util.*;

public class CSLResourceUpsert extends ResourceUpsert {

    private Map<String, Object> resourceMap = new HashMap();

    public CSLResourceUpsert(ResourceRegistry resourceRegistry,
                             PropertiesProvider propertiesProvider,
                             TypeParser typeParser,
                             ObjectMapper objectMapper,
                             DocumentMapper documentMapper,
                             List<ResourceModificationFilter> modificationFilters) {

        super(resourceRegistry, propertiesProvider, typeParser, objectMapper, documentMapper, modificationFilters);
    }

    @Override
    protected HttpMethod getHttpMethod() {
        return HttpMethod.POST;
    }

    @Override
    public boolean isAcceptable(JsonPath jsonPath, String s) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Response handle(JsonPath jsonPath, QueryAdapter queryAdapter, RepositoryMethodParameterProvider repositoryMethodParameterProvider, Document document) {
        throw new UnsupportedOperationException();
    }

    protected Object fetchRelatedObject(RegistryEntry entry, Serializable relationId, RepositoryMethodParameterProvider parameterProvider, QueryAdapter queryAdapter) {
        String uid = entry.getResourceInformation().getResourceType() + "#" + relationId;
        Object relatedResource = this.resourceMap.get(uid);

        if(relatedResource != null) {
            return relatedResource;
        }else {
            return entry.getResourceRepository(parameterProvider).findOne(relationId, queryAdapter).getEntity();
        }
    }

    public Object fromDocument(Document document) {
        if(!document.getData().isPresent()) {
            return null;
        } else {
            List included = document.getIncluded();
            List data = (List)document.getCollectionData().get();
            List dataObjects = allocateResources(data);
            if(included != null) {
                allocateResources(included);
            }

            setRelations(data);
            if(included != null) {
                setRelations(included);
            }

            if(dataObjects.isEmpty()) {
                return null;
            } else {
                return dataObjects.get(0);
            }
        }
    }

    public List<Object> allocateResources(List<Resource> resources) {
        ArrayList objects = new ArrayList();
        Iterator var3 = resources.iterator();

        while(var3.hasNext()) {
            Resource resource = (Resource)var3.next();
            RegistryEntry registryEntry = this.resourceRegistry.getEntry(resource.getType());
            if(registryEntry == null) {
                throw new RepositoryNotFoundException(resource.getType());
            }
            ResourceInformation resourceInformation = registryEntry.getResourceInformation();

            Object object = this.newResource(resourceInformation, resource);
            this.setId(resource, object, resourceInformation);
            this.setAttributes(resource, object, resourceInformation);
            objects.add(object);

            String uid = this.getUID(resource);
            this.resourceMap.put(uid, object);
        }
        return objects;
    }

    public void setRelations(List<Resource> resources) {
        Iterator var2 = resources.iterator();

        while(var2.hasNext()) {
            Resource resource = (Resource)var2.next();
            String uid = this.getUID(resource);
            Object object = this.resourceMap.get(uid);
            RegistryEntry registryEntry = this.resourceRegistry.getEntry(resource.getType());
            this.setRelations(object, registryEntry, resource, null, null, true);
        }

    }

    public String getUID(ResourceIdentifier id) {
        return id.getType() + "#" + id.getId();
    }
}
