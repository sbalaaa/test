package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.crnk.client.response.JsonLinksInformation;
import io.crnk.client.response.JsonMetaInformation;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.PropertiesProvider;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.resource.list.DefaultResourceList;

import java.util.Collections;
import java.util.List;

public class SidePostDocumentMapper extends DocumentMapper {

    private ResourceRegistry resourceRegistry;

    private ObjectMapper objectMapper;
    private TypeParser typeParser;
    private DocumentMapper  documentMapper;

    public SidePostDocumentMapper(ResourceRegistry resourceRegistry,
                                  ObjectMapper objectMapper,
                                  PropertiesProvider propertiesProvider,
                                  TypeParser typeParser,
                                  DocumentMapper  documentMapper) {
        super(resourceRegistry, objectMapper, propertiesProvider, documentMapper != null ? documentMapper.getFilterBehaviorManager() : null);
        this.typeParser = typeParser;
        this.objectMapper = objectMapper;
        this.resourceRegistry = resourceRegistry;
        this.documentMapper = documentMapper;
    }

    public Object fromDocument(Document document, boolean getList) {
        CSLResourceUpsert upsert = new CSLResourceUpsert(this.resourceRegistry, propertiesProvider, typeParser, this.objectMapper, documentMapper, Collections.emptyList());

        if(document.getErrors() != null && !document.getErrors().isEmpty()) {
            throw new IllegalStateException("document contains json api errors and cannot be processed");
        } else if(!document.getData().isPresent()) {
            return null;
        } else {
            List<Resource> included = document.getIncluded();
            List<Resource> data = (List)document.getCollectionData().get();
            List<Object> dataObjects = upsert.allocateResources(data);
            if(included != null) {
                upsert.allocateResources(included);
            }

            upsert.setRelations(data);
            if(included != null) {
                upsert.setRelations(included);
            }

            if(getList) {
                DefaultResourceList<Object> resourceList = new DefaultResourceList();
                resourceList.addAll(dataObjects);
                if(document.getLinks() != null) {
                    resourceList.setLinks(new JsonLinksInformation(document.getLinks(), this.objectMapper));
                }

                if(document.getMeta() != null) {
                    resourceList.setMeta(new JsonMetaInformation(document.getMeta(), this.objectMapper));
                }

                return resourceList;
            } else if(dataObjects.isEmpty()) {
                return null;
            } else if(dataObjects.size() > 1) {
                throw new IllegalStateException("expected unique result " + dataObjects);
            } else {
                return dataObjects.get(0);
            }
        }
    }

}
