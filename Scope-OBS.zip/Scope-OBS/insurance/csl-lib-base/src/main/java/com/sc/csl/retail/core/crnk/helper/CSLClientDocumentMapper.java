package com.sc.csl.retail.core.crnk.helper;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import io.crnk.client.internal.ClientDocumentMapper;
import io.crnk.client.internal.proxy.ClientProxyFactory;
import io.crnk.client.response.JsonLinksInformation;
import io.crnk.client.response.JsonMetaInformation;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.internal.utils.PreconditionUtil;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.PropertiesProvider;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.module.ModuleRegistry;
import io.crnk.core.resource.list.DefaultResourceList;

public class CSLClientDocumentMapper extends ClientDocumentMapper {
	private final ResourceRegistry resourceRegistry;
	private final TypeParser typeParser;
	private final ObjectMapper objectMapper;
	private ClientProxyFactory proxyFactory;

	public CSLClientDocumentMapper(ModuleRegistry moduleRegistry, ObjectMapper objectMapper, PropertiesProvider propertiesProvider) {
		super(moduleRegistry, objectMapper, propertiesProvider);
		this.resourceRegistry = moduleRegistry.getResourceRegistry();
		this.typeParser = moduleRegistry.getTypeParser();
		this.objectMapper = objectMapper;
	}

	@Override
	public Object fromDocument(Document document, boolean getList) {
		CSLClientResourceUpsert upsert =
				new CSLClientResourceUpsert(resourceRegistry, propertiesProvider, typeParser, objectMapper, null, proxyFactory);

		PreconditionUtil.assertFalse("document contains json api errors and cannot be processed",
				document.getErrors() != null && !document.getErrors().isEmpty());

		if (!document.getData().isPresent()) {
			return null;
		}

		List<Resource> included = document.getIncluded();
		List<Resource> data = document.getCollectionData().get();

		List<Object> dataObjects = upsert.allocateResources(data);
		if (included != null) {
			upsert.allocateResources(included);
		}

		upsert.setRelations(data);
		if (included != null) {
			upsert.setRelations(included);
		}

		if (getList) {
			DefaultResourceList<Object> resourceList = new DefaultResourceList();
			resourceList.addAll(dataObjects);
			if (document.getLinks() != null) {
				resourceList.setLinks(new JsonLinksInformation(document.getLinks(), objectMapper));
			}
			if (document.getMeta() != null) {
				resourceList.setMeta(new JsonMetaInformation(document.getMeta(), objectMapper));
			}
			return resourceList;
		}
		else {
			if (dataObjects.isEmpty()) {
				return null;
			}
			PreconditionUtil.assertFalse("expected unique result", dataObjects.size() > 1);
			return dataObjects.get(0);
		}
	}

	public void setProxyFactory(ClientProxyFactory proxyFactory) {
		super.setProxyFactory(proxyFactory);
		this.proxyFactory = proxyFactory;
	}

}
