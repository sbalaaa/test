package com.sc.csl.retail.core.crnk.helper;

import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.substringBefore;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status.Family;

import static javax.ws.rs.core.HttpHeaders.CONTENT_TYPE;
import static org.apache.commons.lang3.StringUtils.isBlank;
import org.apache.cxf.jaxrs.client.WebClient;

import com.sc.csl.retail.core.gateway.CSLRestGateway;

import io.crnk.client.http.HttpAdapter;
import io.crnk.client.http.HttpAdapterRequest;
import io.crnk.client.http.HttpAdapterResponse;
import io.crnk.core.engine.http.HttpMethod;

public class CSLHttpAdapter extends CSLRestGateway implements HttpAdapter {

    public CSLHttpAdapter(String baseUrl) {
        setBaseUrl(baseUrl);
    }

    @Override
    public HttpAdapterRequest newRequest(String url, HttpMethod method, String requestBody) {
        WebClient webClient = webClient(url);
        return httpAdapterRequest(webClient, method, requestBody);
    }

    private HttpAdapterRequest httpAdapterRequest(WebClient webClient, HttpMethod method, String requestBody) {
        return new HttpAdapterRequest() {
            @Override
            public void header(String name, String value) {
                webClient.header(name, value);
            }

            @Override
            public HttpAdapterResponse execute() throws IOException {
            	Response response = webClient.invoke(method.toString(), requestBody);
                return httpAdapterResponse(response);
            }
        };
    }

    private HttpAdapterResponse httpAdapterResponse(Response response) {
        return new HttpAdapterResponse() {
            @Override
            public boolean isSuccessful() {
                int status = response.getStatus();
                return Family.familyOf(status).equals(Family.SUCCESSFUL);
            }

            @Override
            public String body() throws IOException {
                return response.readEntity(String.class);
            }

            @Override
            public int code() {
                return response.getStatus();
            }

            @Override
            public String message() {
                return response.getStatusInfo().getReasonPhrase();
            }

            @Override
            public String getResponseHeader(String name) {
                MultivaluedMap<String, String> headers = response.getStringHeaders();
                String header = headers.getFirst(name);

                //Type header can be either 'content-type' or 'Content-Type'. So, trying both.
                if(isBlank(header) &&  CONTENT_TYPE.equalsIgnoreCase(name)) {
                    header = headers.getFirst(CONTENT_TYPE);
                }

                if(isNotBlank(header) && CONTENT_TYPE.equalsIgnoreCase(name) && header.contains(";")) {
                    return substringBefore(header,";").trim();
                }

                return header;
            }
        };
    }

    @Override
    public void setReceiveTimeout(int timeout, TimeUnit unit) {

    }

}
