package com.sc.csl.retail.core.edmi;

import com.webmethods.jms.impl.WmConnectionFactoryImpl;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.ResourceUtils;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.FileNotFoundException;
import java.util.Properties;

import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Getter
@Setter
@Slf4j
public class EDMiConnectionFactory implements ConnectionFactory {
    private String brokerUrl;
    private String jndiName;

    private String userName;
    private String password;
    private String sslTrustStore;

    private String clientIdSharing = "true";
    private String clientGroup;
    private String clientId;

    public Connection createConnection(String userName, String password) throws JMSException {
        try {
            Connection connection;
            ConnectionFactory connectionFactory = getConnectionFactory();
            if (isNotBlank(userName) && isNotBlank(password)) {
                connection = connectionFactory.createConnection(userName, password);

            } else {
                connection = connectionFactory.createConnection();
            }

            if (isNotBlank(clientId)) {
                connection.setClientID(clientId);
                log.info("[createConnection: clientId]={}", clientId);
            }

            log.info("[createConnection: connection]={}", connection);
            return connection;
        }
        catch (JMSException | NamingException ex) {
            log.error("Error in create EDMi Connection : ", ex);
            throw new JMSException(ex.getMessage());
        }
    }

    private ConnectionFactory getConnectionFactory() throws JMSException, NamingException {
        InitialContext context = null;

        try {
            context = createInitialContext();
            return lookupConnectionFactory(context);
        }
        finally {
            releaseContext(context);
        }
    }

    public Connection createConnection() throws JMSException {
        return createConnection(userName, password);
    }

    InitialContext createInitialContext() throws NamingException {
        Properties props = new Properties();
        props.setProperty(Context.INITIAL_CONTEXT_FACTORY, EDMiConstants.EDMI_CONNECTION_FACTORY);
        props.setProperty(Context.PROVIDER_URL, brokerUrl);
        props.put(Context.OBJECT_FACTORIES, "com.webmethods.jms.impl.ObjectFactory");

        if (isNotBlank(clientGroup)) {
            props.setProperty("com.webmethods.jms.naming.clientgroup", clientGroup);
        }

        String sysClientIdSharing = System.getProperty("com.webmethods.jms.clientIDSharing");
        log.info("[constructInitialContext: sysClientIdSharing, clientIdSharing]={},{}", sysClientIdSharing, clientIdSharing);

        if (StringUtils.equals("true", clientIdSharing)) {
            System.setProperty("com.webmethods.jms.clientIDSharing", clientIdSharing);
        }
        return new InitialContext(props);
    }

    ConnectionFactory lookupConnectionFactory(InitialContext context) throws NamingException, JMSException {
        ConnectionFactory connectionFactory = (ConnectionFactory) context.lookup(jndiName);

        if (isNotBlank(sslTrustStore)) {
            setupSslTrustStore(connectionFactory);
        }

        log.info("[lookupConnectionFactory: jndiName]={},{}", jndiName, connectionFactory);
        return connectionFactory;
    }

    void setupSslTrustStore(ConnectionFactory connectionFactory) throws JMSException {
        try {
            String trustStoreFilePath = sslTrustStore;
            if (sslTrustStore.startsWith(ResourceUtils.CLASSPATH_URL_PREFIX)) {
                trustStoreFilePath = ResourceUtils.getFile(sslTrustStore).getPath();
                log.info("Transformed ssl truststore: {} -> {}", sslTrustStore, trustStoreFilePath);
            }
            ((WmConnectionFactoryImpl) connectionFactory).setSSLTruststore(trustStoreFilePath);
        } catch (FileNotFoundException e) {
            log.error("Error in create EDMi Connection : ", e);
            throw new JMSException("TrustStore file can not be found : " + sslTrustStore);
        }
    }

    void releaseContext(InitialContext context) {
        try {
            if (nonNull(context)) {
                context.close();
            }
        } catch(NamingException ex) {
            log.error("[releaseContext]", ex);
        }
    }
}
