package com.sc.csl.retail.core.edmi;

public interface EDMiConstants {
    public static String EDMI_CONNECTION_FACTORY = "com.webmethods.jms.naming.WmJmsNamingCtxFactory";
    public static int RECONNECTCOUNT = 3;
    public static int SLEEP_BEFORE_RECONNECT = 3; // Seconds
    public static String CONNECTION_ID_SHARING = "true";
    public static int RECEIVE_TIMEOUT = 10000;
}