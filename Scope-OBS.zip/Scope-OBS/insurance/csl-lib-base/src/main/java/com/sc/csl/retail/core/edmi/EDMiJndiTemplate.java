package com.sc.csl.retail.core.edmi;

import org.springframework.jndi.JndiTemplate;

import javax.naming.Context;
import javax.naming.NamingException;
import java.util.Properties;

public class EDMiJndiTemplate extends JndiTemplate {
    @Override
    protected Context createInitialContext() throws NamingException {
        Properties env = this.getEnvironment();
        if(env != null) {
            env.put(Context.INITIAL_CONTEXT_FACTORY, EDMiConstants.EDMI_CONNECTION_FACTORY);
            env.put(Context.OBJECT_FACTORIES, "com.webmethods.jms.impl.ObjectFactory");
        }

        return super.createInitialContext();
    }}
