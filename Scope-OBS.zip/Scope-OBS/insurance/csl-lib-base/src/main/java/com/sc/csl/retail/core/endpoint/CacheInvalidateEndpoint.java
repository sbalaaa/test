package com.sc.csl.retail.core.endpoint;

import com.sc.csl.retail.cache.api.CSLCacheService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.mvc.AbstractMvcEndpoint;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Slf4j
@Component
@ConditionalOnBean(CSLCacheService.class)
public class CacheInvalidateEndpoint extends AbstractMvcEndpoint {

	@Autowired
	private CSLCacheService cacheService;

	public CacheInvalidateEndpoint() {
		super("/cache_invalidate", false, true);
	}

	@RequestMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public CacheInvalidateResponse invalidate(@RequestParam(required = false) String cacheName) {
		if(StringUtils.isNotBlank(cacheName)) {
			cacheService.clearAll(cacheName);
			log.info("Cache `{}` cleared", cacheName);
			return new CacheInvalidateResponse(cacheName,  "cleared");
		}

		cacheService.clearAllCache();
		log.info("All cache cleared");
		return new CacheInvalidateResponse("ALL",  "cleared");
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class CacheInvalidateResponse {
		private String cacheName;
		private String status;
	}
}