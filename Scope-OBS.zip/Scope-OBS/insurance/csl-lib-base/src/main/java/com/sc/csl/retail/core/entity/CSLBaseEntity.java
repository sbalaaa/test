package com.sc.csl.retail.core.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@MappedSuperclass
public class CSLBaseEntity implements Serializable, Cloneable {

    private static final long serialVersionUID = 1L;

    @Column(name = "CREATED_TIMESTAMP", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdTimestamp;

    @Column(name = "CREATED_BY", nullable = false)
    private String createdBy;

    @Column(name = "UPDATED_TIMESTAMP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTimestamp;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @PrePersist
    void preInsert() {
        if (createdTimestamp == null)
            createdTimestamp = new Date();
        if (createdBy == null)
            createdBy = "SYSTEM";
    }

    @PreUpdate()
    void PreUpdate() {
        if (updatedTimestamp == null)
            updatedTimestamp = new Date();
        if (updatedBy == null)
            updatedBy = "SYSTEM";
    }

}
