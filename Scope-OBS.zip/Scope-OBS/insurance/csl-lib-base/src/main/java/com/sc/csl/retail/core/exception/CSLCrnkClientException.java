package com.sc.csl.retail.core.exception;

import io.crnk.core.engine.document.ErrorData;
import io.crnk.core.exception.CrnkMappableException;
import lombok.Getter;

@Getter
public class CSLCrnkClientException extends CrnkMappableException {
	private ErrorCode errorCode;

	public CSLCrnkClientException(ErrorData errorData) {
		super(Integer.parseInt(errorData.getStatus()), errorData);
		this.errorCode = new CrnkClientErrorCode(errorData);
	}
}
