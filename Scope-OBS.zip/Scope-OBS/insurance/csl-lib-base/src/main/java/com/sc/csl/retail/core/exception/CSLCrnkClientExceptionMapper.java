package com.sc.csl.retail.core.exception;

import java.util.Iterator;

import org.springframework.stereotype.Component;

import io.crnk.core.engine.document.ErrorData;
import io.crnk.core.engine.error.ErrorResponse;
import io.crnk.core.engine.error.ExceptionMapper;
import io.crnk.core.exception.CrnkMappableException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CSLCrnkClientExceptionMapper implements ExceptionMapper<CrnkMappableException> {

    @Override
    public ErrorResponse toErrorResponse(CrnkMappableException exception) {
        throw new UnsupportedOperationException();
    }

    @Override
    public CrnkMappableException fromErrorResponse(ErrorResponse errorResponse) {
        Iterator<ErrorData> errorDataIterator = errorResponse.getErrors().iterator();
        ErrorData errorData = errorDataIterator.next();
        return new CSLCrnkClientException(errorData);
    }

    @Override
    public boolean accepts(ErrorResponse errorResponse) {
        Iterator<ErrorData> errorDataIterator = errorResponse.getErrors().iterator();
        return errorDataIterator.hasNext();
    }
}
