package com.sc.csl.retail.core.exception;

import lombok.Getter;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
public enum CSLErrorCodes implements ErrorCode {
    DEFAULT_ERROR_CODE("CSL-100", "Error Occurred", "An error occurred. Please contact support with the error ID"),

    CACHE_NOT_FOUND("CSL-200", "Cache not found", "Cache with name %s not found"),

    UN_AUTHORIZED("CSL-300", "Unauthorized", "Not authorized to access the resource"),
    NO_AUTH_SCHEME("CSL-301", "Unauthorized", "Auth Scheme not specified"),

    TOKEN_TYPE_NOT_SUPPORTED("CSL-302", "Unauthorized", "Auth token type not supported"),
    INVALID_JWT("CSL-303", "Unauthorized", "Not a valid JWT"),

    TOKEN_INVALID("CSL-304", "Unauthorized", "Token invalid or expired"),
    TOKEN_NOT_FOUND("CSL-305", "Unauthorized", "Token not found"),

    FORBIDDEN("CSL-400", "Forbidden", "Forbidden to access the resource"),
    OTP_REQUIRED("CSL-401", "OTP Required", "Forbidden to access the resource"),
    SOFT_TOKEN_OTP_REQUIRED("CSL-ST-401", "SoftToken OTP Required", "Forbidden to access the resource"),
    OTP_MPIN_REQUIRED("CSL-402", "OTP and MPIN Required", "Forbidden to access the resource"),

    OTP_VALIDATION_FAILED("CSL-OTP-1311", "OTP Validation Failed", "Error while validating OTP"),
    OTP_SEND_FAILED("CSL-OTP-400", "Send OTP Failed", "Error while sending OTP"),
    TMX_STATUS_HIGH("CSL-TMX-666","TMX HIGH Status", "ThreatMetrix returned red status."),
    //TSP related Error Code
    SOFT_TOKEN_OTP_REQUIRED_ONLINE("CSL-ST-1527", "SoftToken OTP Required", "Forbidden to access the resource"),
    SOFT_TOKEN_OTP_REQUIRED_OFFLINE("CSL-ST-1528", "SoftToken OTP Required", "Forbidden to access the resource"),
    SOFT_TOKEN_OTP_REQUIRED_PRIMARY("CSL-ST-1529", "SoftToken OTP Required", "Forbidden to access the resource"),
    PUSH_SENDING_FAILED("CSL-ST-2662", "Push Sending Failed", "Forbidden to access the resource"),
    SOFT_TOKEN_OTP_INVALID("CSL-ST-2658", "Invalid OTP", "Forbidden to access the resource"),
    SOFT_TOKEN_LICENSE_ISSUE("CSL-ST-2661", "SoftToken License Issue", "Forbidden to access the resource"),
    SOFT_TOKEN_INTERFACE_GENERIC_ERROR("CSL-ST-2656", "SoftToken Interface error", "Error from Interface during generation or validation"),
    SOFT_TOKEN_EXCEED_MAX_RETRY("CSL-ST-2663", "Exceed Max Retry", "Exceed Max Retry"),
    SOFT_TOKEN_GENERIC_EXCEPTION("CSL-ST-2655", "SoftToken Generic Exception", "SoftToken Generic Exception"),
    RISK_ASSESSMENT_DATA_NOT_FOUND("CSL-ST-2664", "Risk Assessment Not Found", "Risk Assessment Data Not Found"),
    SOFT_TOKEN_CHALLENGE_OBJECT_REQUIRED("CSL-ST-2665", "Challenge Object Required", "Challenge Object Required"),
    TSP_REQUIRED_AUTH_LEVEL("CSL-ST-2666", "Auth Level Check Failed", "TSP required parent auth level is %s but found %s "),
    TRANSACTION_MISMATCH("CSL-ST-2667", "Transaction Mismatch", "transaction does not match high risk token");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    CSLErrorCodes(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }
}
