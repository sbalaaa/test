package com.sc.csl.retail.core.exception;

import com.sc.csl.retail.core.model.SmsOtp;
import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.ErrorData;
import io.crnk.core.engine.document.ErrorDataBuilder;
import io.crnk.core.engine.error.ErrorResponse;
import io.crnk.core.engine.error.ErrorResponseBuilder;
import io.crnk.core.engine.error.ExceptionMapper;
import io.crnk.core.engine.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.auth.TokenType.SMS;
import static com.sc.csl.retail.core.auth.TokenType.SOFT_TOKEN;
import static com.sc.csl.retail.core.util.CSLLogConstants.CSL_ERROR_RESPONSE;
import static com.sc.csl.retail.core.util.CSLLogConstants.HTTP_STATUS;
import static com.sc.csl.retail.core.web.RequestContextConfig.getRequestId;
import static io.crnk.rs.type.JsonApiMediaType.APPLICATION_JSON_API;
import static java.lang.Integer.parseInt;
import static java.lang.String.valueOf;
import static net.logstash.logback.argument.StructuredArguments.kv;
import static net.logstash.logback.argument.StructuredArguments.raw;

@Slf4j
@Component
public class CSLExceptionMapper implements ExceptionMapper<Exception>, javax.ws.rs.ext.ExceptionMapper<Exception> {
    @Autowired(required = false)
    private ErrorCode defaultErrorCode;

    @Override
    public ErrorResponse toErrorResponse(Exception exception) {
        if(exception instanceof BusinessException) {
            log.error("Exception occurred : {} : {}", exception.getClass().getName(), exception.getMessage());
        }
        else {
            log.error("Exception occurred : " + exception.getMessage(),  exception);
        }
        ErrorCode errorCode = (defaultErrorCode == null) ? CSLErrorCodes.DEFAULT_ERROR_CODE : defaultErrorCode;
        String status = valueOf(HttpStatus.INTERNAL_SERVER_ERROR_500);
        Map<String, Object> errorMeta = new HashMap<>();

        if(exception instanceof OTPRequiredException) {
            OTPRequiredException otpRequiredException = (OTPRequiredException) exception;
            if(SMS.equals(otpRequiredException.getTokenType())) {
                errorMeta.putAll(smsMeta(otpRequiredException.getSmsResponse()));
            }
        }

        if(exception instanceof TspRequiredException) {
            TspRequiredException otpRequiredException = (TspRequiredException) exception;
            if(SOFT_TOKEN.equals(otpRequiredException.getTokenType())) {
                errorMeta.putAll(challengeCodeMeta(otpRequiredException.getChallengeCodeResponse()));
            }
        }

        if (exception instanceof BusinessException) {
            BusinessException businessException = (BusinessException) exception;
            errorCode = businessException.getErrorCode();
            if (exception instanceof UnauthorizedException) {
                status = valueOf(HttpStatus.UNAUTHORIZED_401);
            } else if (exception instanceof ForbiddenException) {
                status = valueOf(HttpStatus.FORBIDDEN_403);
            } else {
                status = valueOf(HttpStatus.BAD_REQUEST_400);
            }
        }
        else if (isTechnicalExceptionWithCode(exception)) {
            TechnicalException technicalException = (TechnicalException) exception;
            errorCode = technicalException.getErrorCode();
        }
        else if (exception instanceof CSLCrnkClientException) {
            CSLCrnkClientException clientException = (CSLCrnkClientException) exception;
            errorCode = clientException.getErrorCode();
        }

        ErrorDataBuilder errorDataBuilder = ErrorData.builder()
                .setId(getRequestId())
                .setCode(errorCode.getCode())
                .setTitle(errorCode.getTitle())
                .setDetail(errorCode.getDescription())
                .setStatus(status);

        if(!errorMeta.isEmpty()) {
            errorDataBuilder.setMeta(errorMeta);
        }

        ErrorData errorData = errorDataBuilder.build();
        int statusCode = parseInt(status);
        ErrorResponseBuilder errorResponseBuilder = ErrorResponse.builder()
                .setStatus(statusCode)
                .setSingleErrorData(errorData);

        log.error("{}",
                raw(CSL_ERROR_RESPONSE, CSLJsonUtils.toJson(errorData)),
                kv(HTTP_STATUS, statusCode));
        return errorResponseBuilder.build();
    }

    private boolean isTechnicalExceptionWithCode(Exception exception) {
        return exception instanceof TechnicalException && ((TechnicalException) exception).getErrorCode() != null;
    }

    private Map<String, Object> smsMeta(SmsOtp smsOtpResponse) {
        Map<String, Object> smsAttributes = new HashMap<>();
        smsAttributes.put("mobile", smsOtpResponse.getMobile());

        smsAttributes.put("otpSn", smsOtpResponse.getOtpSn());
        smsAttributes.put("otpPrefix", smsOtpResponse.getOtpPrefix());
        smsAttributes.put("base64Challenge", smsOtpResponse.getBase64Challenge());
        smsAttributes.put("keyIndex", smsOtpResponse.getKeyIndex());
        smsAttributes.put("exponent", smsOtpResponse.getExponent());
        smsAttributes.put("modulus", smsOtpResponse.getModulus());
        smsAttributes.put("type", smsOtpResponse.getType());
        smsAttributes.put("purpose", smsOtpResponse.getPurpose());

        return smsAttributes;
    }

    private Map<String, Object> challengeCodeMeta(ChallengeCode challengeCode) {
        Map<String, Object> challengeAttributes = new HashMap<>();
        challengeAttributes.put("tx-ref-num", challengeCode.getTxRefNo());
        challengeAttributes.put("tx-hash", challengeCode.getTransactionHash());
        challengeAttributes.put("challenge-code", challengeCode.getChallengeCode());
        challengeAttributes.put("random-num", challengeCode.getRandomNum());
        challengeAttributes.put("push-required", challengeCode.getPushRequired());
        challengeAttributes.put("encrypted-challenge", challengeCode.getEncryptedChallenge());
        challengeAttributes.put("isOffline", challengeCode.getIsOffline());
        return challengeAttributes;
    }

    @Override
    public Exception fromErrorResponse(ErrorResponse errorResponse) {
        return null;
    }

    @Override
    public boolean accepts(ErrorResponse errorResponse) {
        return false;
    }

    @Override
    public Response toResponse(Exception exception) {
        ErrorResponse errorResponse = toErrorResponse(exception);
        Response.ResponseBuilder responseBuilder = Response.status(errorResponse.getHttpStatus());
        responseBuilder.type(APPLICATION_JSON_API);
        Document errorDocument = errorResponse.toResponse().getDocument();
        responseBuilder.entity(CSLJsonUtils.toPrettyJson(errorDocument));

        return responseBuilder.build();
    }
}
