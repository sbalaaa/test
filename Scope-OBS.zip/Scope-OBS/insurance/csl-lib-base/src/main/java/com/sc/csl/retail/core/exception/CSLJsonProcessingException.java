package com.sc.csl.retail.core.exception;

public class CSLJsonProcessingException extends RuntimeException {
	public CSLJsonProcessingException(String message) {
		super(message);
	}

	public CSLJsonProcessingException(String message, Throwable cause) {
		super(message, cause);
	}

	public CSLJsonProcessingException(Throwable cause) {
		super(cause);
	}
}
