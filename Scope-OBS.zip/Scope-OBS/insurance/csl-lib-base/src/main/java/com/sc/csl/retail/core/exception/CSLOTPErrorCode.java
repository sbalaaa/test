package com.sc.csl.retail.core.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@AllArgsConstructor
@Getter
public class CSLOTPErrorCode implements ErrorCode {
    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    public String getCode() {
        if (code.startsWith(CSL_PREFIX)) return code;
        return CSL_OTP_PREFIX + code;
    }

    private static final String CSL_OTP_PREFIX = "CSL-OTP-";
    private static final String CSL_PREFIX = "CSL-";
}
