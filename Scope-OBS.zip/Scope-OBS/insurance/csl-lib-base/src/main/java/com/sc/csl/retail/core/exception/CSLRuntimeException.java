package com.sc.csl.retail.core.exception;

public abstract class CSLRuntimeException extends RuntimeException {
	public abstract ErrorCode getErrorCode();

	public CSLRuntimeException() {
		super();
	}

	public CSLRuntimeException(String message) {
		super(message);
	}

	public CSLRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public CSLRuntimeException(Throwable cause) {
		super(cause);
	}
}
