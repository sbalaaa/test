package com.sc.csl.retail.core.exception;

public class CSLXmlProcessingException extends RuntimeException {
	public CSLXmlProcessingException(String message) {
		super(message);
	}

	public CSLXmlProcessingException(String message, Throwable cause) {
		super(message, cause);
	}

	public CSLXmlProcessingException(Throwable cause) {
		super(cause);
	}
}
