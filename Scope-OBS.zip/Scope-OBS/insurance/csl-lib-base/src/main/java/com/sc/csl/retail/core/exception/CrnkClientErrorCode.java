package com.sc.csl.retail.core.exception;

import io.crnk.core.engine.document.ErrorData;

public class CrnkClientErrorCode implements ErrorCode {
	private ErrorData errorData;

	public CrnkClientErrorCode(ErrorData errorData) {
		this.errorData = errorData;
	}

	@Override
	public String getCode() {
		return errorData.getCode();
	}

	@Override
	public String getTitle() {
		return errorData.getTitle();
	}

	@Override
	public String getDescription() {
		return errorData.getDetail();
	}
}
