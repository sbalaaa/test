package com.sc.csl.retail.core.exception;

public interface ErrorCode {
    String getCode();
    String getTitle();
    String getDescription();
}
