package com.sc.csl.retail.core.exception;

import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.model.SmsOtp;
import com.sc.csl.retail.core.util.CSLConstants;

import lombok.Getter;
import lombok.Setter;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.OTP_REQUIRED;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.OTP_MPIN_REQUIRED;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.SOFT_TOKEN_OTP_REQUIRED;

@Getter
@Setter
public class OTPRequiredException extends UnauthorizedException {
	private TokenType tokenType;
	private ErrorCode errorCode;
	private SmsOtp smsResponse;

	public OTPRequiredException(SmsOtp smsResponse) {
		this.errorCode = OTP_REQUIRED;
		this.tokenType = TokenType.SMS;
		this.smsResponse = smsResponse;
	}

	public OTPRequiredException(TokenType tokenType) {
		this.errorCode = (TokenType.SMS.equals(tokenType)) ? OTP_REQUIRED : SOFT_TOKEN_OTP_REQUIRED;
		this.tokenType = tokenType;
	}
	
	public OTPRequiredException(SmsOtp smsResponse, String mpinPurpose) {
		this.errorCode = OTP_MPIN_REQUIRED;
		smsResponse.setType(CSLConstants.MPIN_PASSWORD_TYPE);
		smsResponse.setPurpose(mpinPurpose);

		this.tokenType = TokenType.SMS;
		this.smsResponse = smsResponse;
	}
}
