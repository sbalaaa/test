package com.sc.csl.retail.core.exception;

import lombok.Getter;

@Getter
public class RestrictedAccessException extends UnauthorizedException {
	private ErrorCode errorCode;
	private Exception exception;

	public RestrictedAccessException(ErrorCode errorCode, Exception exception) {
		super();
		this.errorCode = errorCode;
		this.exception = exception;
	}
}
