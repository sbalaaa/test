package com.sc.csl.retail.core.exception;

import lombok.Getter;

@Getter
public class TechnicalException extends CSLRuntimeException {
    private ErrorCode errorCode;
    private Throwable cause;

    public TechnicalException(ErrorCode errorCode) {
        super(errorCode.getDescription());
        this.errorCode = errorCode;
    }

    public TechnicalException(ErrorCode errorCode, Throwable cause) {
        super(errorCode.getDescription());
        this.errorCode = errorCode;
        this.cause = cause;
    }

    public TechnicalException(ErrorCode errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public TechnicalException(Throwable cause) {
        super(cause.getMessage());
        this.errorCode = CSLErrorCodes.DEFAULT_ERROR_CODE;
        this.cause = cause;
    }

    public TechnicalException(String message) {
        super(message);
        this.errorCode = CSLErrorCodes.DEFAULT_ERROR_CODE;
    }

    public TechnicalException(String message, Throwable cause) {
        super(message);
        this.errorCode = CSLErrorCodes.DEFAULT_ERROR_CODE;
        this.cause = cause;
    }
}
