package com.sc.csl.retail.core.exception;

import java.util.MissingFormatArgumentException;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

public final class TemplateErrorCode implements ErrorCode {
    private ErrorCode errorCode;
    private Object[] params;

    public static TemplateErrorCode create(ErrorCode errorCode, Object... params) {
        return new TemplateErrorCode(errorCode, params);
    }

    private TemplateErrorCode(ErrorCode errorCode, Object... params) {
        this.errorCode = errorCode;
        this.params = params;
    }

    @Override
    public String getCode() {
        return errorCode.getCode();
    }

    @Override
    public String getTitle() {
        return errorCode.getTitle();
    }

    @Override
    public String getDescription() {
        try {
            String template = errorCode.getDescription();
            return String.format(template, params);
        }
        catch (MissingFormatArgumentException ex) {
            throw new RuntimeException("TemplateErrorCode : Provide all required param substitutions", ex);
        }
    }

    public String toString() {
        return convertToString(this);
    }
}
