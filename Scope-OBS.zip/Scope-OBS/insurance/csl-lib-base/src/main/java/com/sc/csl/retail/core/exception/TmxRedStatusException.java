package com.sc.csl.retail.core.exception;

public class TmxRedStatusException extends ForbiddenException {
    public TmxRedStatusException(ErrorCode errorCode) {
        super(errorCode);
    }
}
