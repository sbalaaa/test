package com.sc.csl.retail.core.exception;

import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TspRequiredException extends ForbiddenException {

	private TokenType tokenType;
	private ErrorCode errorCode;
	private ChallengeCode challengeCodeResponse;

	public TspRequiredException(ErrorCode errorCode) {
		this.errorCode = errorCode;
	}


	public TspRequiredException(ChallengeCode challengeCodeResponse, ErrorCode errorCode) {
		this.errorCode = errorCode;
		this.tokenType = TokenType.SOFT_TOKEN;
		this.challengeCodeResponse = challengeCodeResponse;
	}
}
