package com.sc.csl.retail.core.exception;

public class UnauthorizedException extends BusinessException {
	public UnauthorizedException() {
		super(CSLErrorCodes.UN_AUTHORIZED);
	}

	public UnauthorizedException(ErrorCode errorCode) {
		super(errorCode);
	}

	public UnauthorizedException(ErrorCode errorCode, Throwable cause) {
		super(errorCode, cause);
	}
}
