package com.sc.csl.retail.core.fap;

import com.sc.csl.retail.cache.annotations.CacheResult;
import com.sc.csl.retail.core.gateway.CSLRestGateway;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import javax.ws.rs.core.Response;
import java.util.Map;

@Slf4j
@Setter
@Getter
@ToString
public class FapGateway extends CSLRestGateway {
    private static FapGateway fapGateway = new FapGateway();
    private boolean enabled = true;
    private String hasPermissionEndPoint;
    private String baseUrl;

    public static FapGateway getInstance() {
        return fapGateway;
    }

    @CacheResult(cacheName = "fap-gateway")
    public Map<String, Object> hasPermission(String jsonUserInput, String appName, String permissionName, String requiredAction) {
        String endPoint =  hasPermissionEndPoint + "/" + appName + "/" + permissionName + "/" + requiredAction;
        Response response = this.post(jsonUserInput, endPoint);
        return response.readEntity(Map.class);
    }
}
