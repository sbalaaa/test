package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.gateway.properties.OAuth2ClientProperties;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.configuration.security.AuthorizationPolicy;
import org.apache.cxf.message.Message;
import org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier;
import org.apache.cxf.rs.security.oauth2.client.Consumer;
import org.apache.cxf.rs.security.oauth2.common.ClientAccessToken;
import org.apache.cxf.rs.security.oauth2.utils.OAuthUtils;

import java.net.URI;

@Slf4j
public class CSLBearerAuthSupplier extends BearerAuthSupplier {
    private OAuth2TokenProvider oAuth2TokenProvider;
    private OAuth2ClientProperties oAuth2ClientProperties;

    public CSLBearerAuthSupplier(OAuth2ClientProperties oAuth2ClientProperties) {
        super();
        this.oAuth2TokenProvider = new OAuth2TokenProvider(oAuth2ClientProperties);
        this.oAuth2ClientProperties = oAuth2ClientProperties;
        Consumer consumer = new Consumer(oAuth2ClientProperties.getClientId(), oAuth2ClientProperties.getClientSecret());

        setConsumer(consumer);
        fetchAccessToken();
    }

    @Override
    public String getAuthorization(AuthorizationPolicy authPolicy,
                                   URI currentURI,
                                   Message message,
                                   String fullHeader) {
        final ClientAccessToken clientAccessToken = getClientAccessToken();
        if (clientAccessToken == null ||
            clientAccessToken.getTokenKey() == null ||
            accessTokenExpired() ||
            aboutToExpire()) {
            fetchAccessToken();
        }

        return createAuthorizationHeader();
    }

    private boolean aboutToExpire() {
        ClientAccessToken at = getClientAccessToken();
        Long earlyRefreshInSeconds = oAuth2ClientProperties.getEarlyRefreshInSeconds();
        boolean aboutToExpire = OAuthUtils.isExpired(at.getIssuedAt(), (at.getExpiresIn() - earlyRefreshInSeconds));
        if(aboutToExpire) {
            log.info("AccessToken about to expire within the next {} seconds", earlyRefreshInSeconds);
        }
        return aboutToExpire;
    }

    private boolean accessTokenExpired() {
        ClientAccessToken at = getClientAccessToken();
        boolean expired = OAuthUtils.isExpired(at.getIssuedAt(), at.getExpiresIn());
        if(expired) {
            log.info("AccessToken expired");
        }
        return expired;
    }

    private void fetchAccessToken() {
        final ClientAccessToken clientAccessToken = oAuth2TokenProvider.getAccessToken();
        setClientAccessToken(clientAccessToken);
    }

    @Override
    public boolean requiresRequestCaching() {
        return false;
    }

    @Override
    protected void setClientAccessToken(ClientAccessToken clientAccessToken) {
        super.setClientAccessToken(clientAccessToken);
    }
}
