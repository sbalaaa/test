package com.sc.csl.retail.core.gateway;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.support.converter.MessageConversionException;

import javax.jms.*;

@Slf4j
@Getter
@Setter
public class CSLJmsGateway {
    private JmsTemplate jmsTemplate;
    private String destinationName;

    private String responseName;
    private String responseSelector;

    public CSLJmsGateway(JmsTemplate jmsTemplate, String destinationName) {
        this.jmsTemplate = jmsTemplate;
        this.destinationName = destinationName;
    }

    public CSLJmsGateway(JmsTemplate jmsTemplate, String destinationName, String responseName, String responseSelector) {
        this.jmsTemplate = jmsTemplate;
        this.destinationName = destinationName;

        this.responseName = responseName;
        this.responseSelector = responseSelector;
    }

    public void post(String destination, String data) {
        post(destination, data, false);
    }

    public void post(String data) {
        post(destinationName, data, false);
    }

    public void post(String data, boolean ignoreError) {
        post(destinationName, data, ignoreError);
    }

    public void post(String destination, final String data, boolean ignoreError) {
        try {
            log.info("About to publish message to destination : {}, ignoreError flag : {}", destination, ignoreError);
            jmsTemplate.send(destination, new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    return session.createTextMessage(data);
                }
            });
            log.info("Message published to destination : {}", destination);
        } catch (JmsException ex) {
            log.warn("JMSException occurred", ex);
            if(!ignoreError) {
                throw ex;
            }
        }
    }
    
    public Object postAndReceive(String data) {
    	return postAndReceive(destinationName, data, false, responseSelector);
    }

    public Object postAndReceive(String data, boolean ignoreError) {
    	return postAndReceive(destinationName, data, ignoreError, responseSelector);
    }

    public Object postAndReceive(String destination, String data, String selector) {
    	return postAndReceive(destination, data, false, selector);
    }

    public Object postAndReceive(String destination, String data, boolean ignoreError, String selector) {
        try {
            log.info("About to publish message to destination : {}, ignoreError flag : {}", destination, ignoreError);
            jmsTemplate.send(destination, new MessageCreator() {
                public Message createMessage(Session session) throws JMSException {
                    return session.createTextMessage(data);
                }
            });
            log.info("Message published to destination : {} ", destination);
            
            log.info("About to receive message from responseName : {} , responseSelector : {}", responseName, selector);
            Message message = jmsTemplate.receiveSelected(responseName, selector);
            log.info("Message received from responseName : {}", responseName);
            
            return processResponseMessage(message);
        }
        catch (JmsException ex) {
            log.error("JmsException occurred ", ex);
            if(!ignoreError) {
                throw ex;
            }
        }
        catch (JMSException ex) {
            log.error("JMSException occurred ", ex);
            if(!ignoreError) {
                throw new MessageConversionException(ex.getMessage(), ex);
            }
        }

        return null;
    }

    private Object processResponseMessage(Message message) throws JMSException {
        if (message == null)
            return null;

        if (message instanceof TextMessage) {
            TextMessage textMessage = (TextMessage) message;
            return textMessage.getText();
        }

        if (message instanceof BytesMessage) {
            BytesMessage bytesMessage = (BytesMessage) message;
            byte[] bytes = new byte[(int) bytesMessage.getBodyLength()];
            bytesMessage.readBytes(bytes);
            return bytes;
        }

        if (message instanceof ObjectMessage) {
            ObjectMessage objectMessage = (ObjectMessage) message;
            return objectMessage.getObject();
        }

		return message;
    }
}
