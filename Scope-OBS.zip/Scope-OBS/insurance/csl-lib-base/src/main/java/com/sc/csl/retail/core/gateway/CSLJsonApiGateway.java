package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.crnk.CSLCrnkClient;
import com.sc.csl.retail.core.crnk.helper.CSLHttpAdapter;
import com.sc.csl.retail.core.gateway.properties.OAuth2ClientProperties;
import io.crnk.client.CrnkClient;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
@Setter
@Getter
public abstract class CSLJsonApiGateway {
    private String baseUrl = CSLRestGateway.DEFAULT_BASE_URL;
    private String serviceUrl;
    private CSLCrnkClient cslCrnkClient;
    private boolean isScbInternal = false;

    protected List<String> proxies;

    protected Long timeout;
    protected Long connectionTimeout;
    protected String sslTrustStore;
    protected String sslTrustStorePassword;
    protected OAuth2ClientProperties oAuth2ClientProperties;

    protected CrnkClient getCrnkClient() {
        if(cslCrnkClient == null) {
        	cslCrnkClient = new CSLCrnkClient (baseUrl, serviceUrl);
            CSLHttpAdapter httpAdapter = (CSLHttpAdapter) cslCrnkClient.getHttpAdapter();
            httpAdapter.setTimeout(timeout);
            httpAdapter.setConnectionTimeout(connectionTimeout);
            httpAdapter.setSslTrustStore(sslTrustStore);
            httpAdapter.setSslTrustStorePassword(sslTrustStorePassword);
            httpAdapter.setProxies(proxies);
            httpAdapter.setScbInternal(isScbInternal);
            httpAdapter.setOAuth2ClientProperties(oAuth2ClientProperties);
         }
        return cslCrnkClient;
    }
}
