package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.gateway.properties.HttpClientProperties;
import com.sc.csl.retail.core.gateway.properties.OAuth2ClientProperties;
import com.sc.csl.retail.core.util.Proxies;
import com.sc.csl.retail.core.web.CSLWebClient;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.rs.security.oauth2.client.BearerAuthSupplier;
import org.springframework.util.ObjectUtils;

import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import static javax.ws.rs.core.MediaType.*;

@Slf4j
@Setter
@Getter
public abstract class CSLRestGateway {
    public static final String DEFAULT_BASE_URL = "http://localhost:9000";

    private String baseUrl = DEFAULT_BASE_URL;
    protected Long timeout;
    protected Long connectionTimeout;

    protected String userName;
    protected String password;

    protected List<String> proxies;
    protected Proxies proxiesObj;

    protected String sslTrustStore;
    protected String sslTrustStorePassword;

    protected OAuth2ClientProperties oAuth2ClientProperties;
    protected boolean isScbInternal = false;
    private CSLBearerAuthSupplier authSupplier;

    protected String url(String endpoint) {
        String constructedUrl = getBaseUrl() + endpoint;
        log.debug("URL constructed : {}", constructedUrl);
        return constructedUrl;
    }

    protected WebClient webClient(String path) {
        return webClient(path, APPLICATION_JSON);
    }

    protected WebClient webClient(String path, String mediaType) {
        HttpClientProperties clientProperties = HttpClientProperties.builder()
                .timeout(timeout)
                .connectionTimeout(connectionTimeout)
                .proxies(proxies)
                .sslTrustStore(sslTrustStore)
                .sslTrustStorePassword(sslTrustStorePassword).build();

        WebClient client = CSLWebClient.create(url(path), userName, password, isScbInternal, clientProperties);
        client.type(mediaType);
        client.accept(APPLICATION_JSON, MEDIA_TYPE_WILDCARD);

        if(oAuth2ClientProperties != null) {
            BearerAuthSupplier bearerAuthSupplier = getBearerAuthSupplier(oAuth2ClientProperties);
            CSLWebClient.setAuthSupplier(client, bearerAuthSupplier);
        }

        return client;
    }

    private BearerAuthSupplier getBearerAuthSupplier(OAuth2ClientProperties oAuth2ClientProperties) {
        if(authSupplier != null) {
            return authSupplier;
        }

        authSupplier = new CSLBearerAuthSupplier(oAuth2ClientProperties);
        return authSupplier;
    }

    public void setProxies(List<String> proxies) {
        this.proxies = proxies;

        if (proxies != null && !proxies.isEmpty()) {
            proxiesObj = new Proxies(proxies);
        }
    }

    protected WebClient webClient(String path, Map<String, String> queryParams) {
        return webClient(path, queryParams, APPLICATION_JSON);
    }

    protected WebClient webClient(String path, Map<String, String> queryParams, String mediaType) {
        WebClient client = webClient(path, mediaType);
        
        if(!ObjectUtils.isEmpty(queryParams)) {
            for (Entry<String, String> entry : queryParams.entrySet()) {
                client.query(entry.getKey(), entry.getValue());
            }
        }
        return client;
    }

    protected Response post(Object body, String endPoint, String mediaType) {
        WebClient client = webClient(endPoint, mediaType);
        return client.post(body);
    }

    protected Response post(Object request, String endPoint) {
        return post(request, endPoint, APPLICATION_JSON);
    }

    protected Response post(String requestJson, String endPoint) {
        return post(requestJson, endPoint, APPLICATION_JSON);
    }

    protected Response postForm(Form form, String endPoint) {
        WebClient client = webClient(endPoint, APPLICATION_FORM_URLENCODED);
        return client.form(form);
    }

    protected Response get(String serviceEndPoint, String mediaType) {
        WebClient client = webClient(serviceEndPoint, mediaType);
        return client.get();
    }

    protected Response get(String serviceEndPoint) {
        return get(serviceEndPoint, APPLICATION_JSON);
    }

    protected Response get(String serviceEndPoint, Map<String, String> queryParams) {
        WebClient client = webClient(serviceEndPoint, queryParams); 
        return client.get();
    }

    protected Response get(String serviceEndPoint, Map<String, String> queryParams, String mediaType) {
        WebClient client = webClient(serviceEndPoint, queryParams, mediaType);
        return client.get();
    }

    protected Response put(String requestJson, String serviceEndPoint, String mediaType) {
        WebClient client = webClient(serviceEndPoint, mediaType);
        return client.put(requestJson);
    }

    protected Response put(String requestJson, String serviceEndPoint) {
        return put(requestJson, serviceEndPoint, APPLICATION_JSON);
    }

    protected Response patch(String requestJson, String serviceEndPoint, String mediaType) {
        WebClient client = webClient(serviceEndPoint, mediaType);
        return client.invoke("PATCH", requestJson);
    }

    protected Response patch(String requestJson, String serviceEndPoint) {
        return patch(requestJson, serviceEndPoint, APPLICATION_JSON);
    }

    protected Response delete(String serviceEndPoint) {
        WebClient client = webClient(serviceEndPoint);
        return client.delete();
    }

    @Deprecated
    protected String getRequest(String serviceEndPoint) {
        WebClient client = webClient(serviceEndPoint, APPLICATION_JSON);
        return client.get().readEntity(String.class);
    }

    @Deprecated
    protected String putRequest(String requestJson, String serviceEndPoint) {
        Response response = put(requestJson, serviceEndPoint);
        return response.readEntity(String.class);
    }

    @Deprecated
    protected String getRequest(String serviceEndPoint, String mediaType) {
        WebClient client = webClient(serviceEndPoint, mediaType);
        return client.get().readEntity(String.class);
    }

    @Deprecated
    protected String postRequest(String requestJson, String endPoint, String mediaType) {
        WebClient client = webClient(endPoint, mediaType);
        Response response = client.post(requestJson);
        return response.readEntity(String.class);
    }

    @Deprecated
    protected String postRequest(String requestJson, String endPoint) {
        WebClient client = webClient(endPoint, APPLICATION_JSON);
        Response response = client.post(requestJson);
        return response.readEntity(String.class);
    }
}
