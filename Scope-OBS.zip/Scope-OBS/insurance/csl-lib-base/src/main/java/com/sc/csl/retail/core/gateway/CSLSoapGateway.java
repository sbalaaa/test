package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLLoggingInInterceptor;
import com.sc.csl.retail.core.util.CSLLoggingOutInterceptor;
import com.sc.csl.retail.core.web.CSLWebClient;
import lombok.AccessLevel;
import lombok.Getter;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.security.ProxyAuthorizationPolicy;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import static org.apache.commons.lang3.StringUtils.isBlank;

public abstract class CSLSoapGateway<T> {

    @Getter(AccessLevel.PROTECTED)
    private T proxyClient;

    public CSLSoapGateway(Service service, Class<T> wsClazz) {
        this.proxyClient = service.getPort(wsClazz);
    }

    public CSLSoapGateway(Service service, Class<T> wsClazz, CSLSoapGatewayProperties properties) {
        this(service, wsClazz);
        try {
            if (properties.getEndpointUrl() != null) {
                setupEndpoint(properties.getEndpointUrl());
            }

            if ( properties.getUserName() != null && properties.getPassword() != null ) {
                setupAuthorization(properties.getUserName(), properties.getPassword());
            }

            if ( properties.getSslTrustStore() != null && properties.getSslTrustStorePassword() != null ) {
                setupSslTrustStore(properties.getSslTrustStore(), properties.getSslTrustStorePassword());
            }

            if (properties.getProxyAddress() != null) {
                setupProxy(properties.getProxyAddress(), properties.getProxyPort());
                if ( properties.getProxyUserName() != null && properties.getProxyPassword() != null ) {
                    setupProxyAuthorization(properties.getProxyUserName(), properties.getProxyPassword());
                }
            }

            if (properties.getTimeout() != null) {
                setupClientTimeout(properties.getTimeout());
            }

            if (properties.getConnectionTimeout() != null) {
                setupConnectionTimeout(properties.getConnectionTimeout());
            }

            setupInterceptors();
        } catch (KeyStoreException | IOException | CertificateException | NoSuchAlgorithmException e) {
            throw new TechnicalException("SOAP Gateway creation failed.", e);
        }
    }

    void setupProxy(String proxyAddress, Integer proxyPort) {
        HTTPConduit httpConduit = getHttpConduit();
        HTTPClientPolicy httpClientPolicy = httpConduit.getClient();

        httpClientPolicy.setProxyServer(proxyAddress);
        if (proxyPort != null) {
            httpClientPolicy.setProxyServerPort(proxyPort);
        }
    }

    void setupProxyAuthorization(String user, String password) {
        HTTPConduit httpConduit = getHttpConduit();
        ProxyAuthorizationPolicy proxyAuthorization = httpConduit.getProxyAuthorization();

        proxyAuthorization.setUserName(user);
        proxyAuthorization.setPassword(password);
    }

    HTTPConduit getHttpConduit() {
        Client client = ClientProxy.getClient(proxyClient);
        return (HTTPConduit) client.getConduit();
    }

    void setupEndpoint(String endpointUrl) {
        final BindingProvider provider = (BindingProvider) proxyClient;
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
    }

    public void setupClientTimeout(Long timeout) {
        HTTPClientPolicy httpClientPolicy = getHttpConduit().getClient();
        httpClientPolicy.setReceiveTimeout(timeout);
        httpClientPolicy.setConnectionTimeout(timeout);
    }

    public void setupConnectionTimeout(Long timeout) {
        HTTPClientPolicy httpClientPolicy = getHttpConduit().getClient();
        httpClientPolicy.setConnectionTimeout(timeout);
    }

    void setupAuthorization(String username, String password) {
        final BindingProvider provider = (BindingProvider) proxyClient;
        provider.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, username);
        provider.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);
    }

    void setupSslTrustStore(String trustStoreLocation, String trustStorePassword)
            throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException {

        if (!isBlank(trustStoreLocation) && !isBlank(trustStorePassword)) {
            final HTTPConduit httpConduit = getHttpConduit();
            final TLSClientParameters tlsCP = CSLWebClient.getTLSClientParameters(trustStoreLocation, trustStorePassword);
            httpConduit.setTlsClientParameters(tlsCP);
        }
    }

    protected void setupInterceptors() {
        ClientProxy.getClient(proxyClient).getInInterceptors().add(new CSLLoggingInInterceptor());
        ClientProxy.getClient(proxyClient).getOutInterceptors().add(new CSLLoggingOutInterceptor());
    }
}
