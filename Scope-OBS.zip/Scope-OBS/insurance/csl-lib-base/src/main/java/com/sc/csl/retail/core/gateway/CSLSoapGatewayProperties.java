package com.sc.csl.retail.core.gateway;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSLSoapGatewayProperties {
    private String userName;
    private String password;
    private String endpointUrl;
    private String sslTrustStore;
    private String sslTrustStorePassword;
    private String proxyAddress;
    private Integer proxyPort;
    private String proxyUserName;
    private String proxyPassword;
    /**
     * Value in millis
     */
    private Long timeout;
    private Long connectionTimeout;
}
