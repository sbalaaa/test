package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.gateway.properties.OAuth2ClientProperties;
import com.sc.csl.retail.core.web.CSLWebClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.rs.security.oauth2.client.Consumer;
import org.apache.cxf.rs.security.oauth2.client.OAuthClientUtils;
import org.apache.cxf.rs.security.oauth2.common.ClientAccessToken;
import org.apache.cxf.rs.security.oauth2.grants.clientcred.ClientCredentialsGrant;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.MEDIA_TYPE_WILDCARD;

@Slf4j
public class OAuth2TokenProvider {
	private OAuth2ClientProperties properties;

	public OAuth2TokenProvider(OAuth2ClientProperties properties) {
		this.properties = properties;
	}

	public ClientAccessToken getAccessToken() {
		Consumer consumer = new Consumer(properties.getClientId(), properties.getClientSecret());
		ClientCredentialsGrant clientCredentialsGrant = new ClientCredentialsGrant(properties.getScope());
		return OAuthClientUtils.getAccessToken(webClient(), consumer, clientCredentialsGrant, false);
	}

	private WebClient webClient() {
		WebClient client = CSLWebClient.create(properties);
		client.type(APPLICATION_JSON);
		client.accept(APPLICATION_JSON, MEDIA_TYPE_WILDCARD);
		return client;
	}
}
