package com.sc.csl.retail.core.gateway.properties;

import com.sc.csl.retail.core.util.Proxies;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HttpClientProperties {
    private Long timeout;
    private Long connectionTimeout;
    private String sslTrustStore;
    private String sslTrustStorePassword;
    private List<String> proxies;
    private Proxies proxiesObj;

    public Proxies getProxiesObj() {
        if(proxiesObj != null) {
            return proxiesObj;
        }

        if (proxies != null && !proxies.isEmpty()) {
            proxiesObj = new Proxies(proxies);
        }

        return proxiesObj;
    }
}
