package com.sc.csl.retail.core.gateway.properties;

import lombok.Data;
@Data
public class OAuth2ClientProperties {
	private static final long TEN_SECONDS = 10L;

	private String accessTokenUri;
	private String clientId;
	private String clientSecret;
	private String scope;
	private Long earlyRefreshInSeconds = TEN_SECONDS;

	private HttpClientProperties httpClientProperties;
}
