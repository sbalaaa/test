package com.sc.csl.retail.core.health;

import com.sc.csl.retail.core.config.helper.EdmiConnectionBase;
import com.sc.csl.retail.core.edmi.EDMiConnectionFactory;
import org.springframework.boot.actuate.health.AbstractHealthIndicator;
import org.springframework.boot.actuate.health.Health;

import javax.jms.Connection;

public class EdmiHealthIndicator extends AbstractHealthIndicator {
	private final EdmiConnectionBase connectionBase;

	public EdmiHealthIndicator(EdmiConnectionBase connectionBase) {
		this.connectionBase = connectionBase;
	}

	@Override
	protected void doHealthCheck(Health.Builder builder) throws Exception {
		EDMiConnectionFactory connectionFactory = this.connectionBase.getConnection();
		Connection connection = connectionFactory.createConnection();
		try {
			connection.start();
			builder.up().withDetail("provider", connection.getMetaData().getJMSProviderName());
		}
		finally {
			connection.close();
		}
	}

}

