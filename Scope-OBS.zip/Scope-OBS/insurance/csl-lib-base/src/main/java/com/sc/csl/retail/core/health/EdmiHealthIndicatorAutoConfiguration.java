package com.sc.csl.retail.core.health;

import com.sc.csl.retail.core.config.helper.EdmiConnectionBase;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.actuate.autoconfigure.CompositeHealthIndicatorConfiguration;
import org.springframework.boot.actuate.autoconfigure.ConditionalOnEnabledHealthIndicator;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Configuration
@ConditionalOnBean(EdmiConnectionBase.class)
@ConditionalOnEnabledHealthIndicator("jms")
public class EdmiHealthIndicatorAutoConfiguration extends CompositeHealthIndicatorConfiguration<EdmiHealthIndicator, EdmiConnectionBase> {
	private final Map<String, EdmiConnectionBase> connectionDetails;

	public EdmiHealthIndicatorAutoConfiguration(ObjectProvider<Map<String, EdmiConnectionBase>> connectionDetails) {
		this.connectionDetails = connectionDetails.getIfAvailable();
	}

	@Bean
	@ConditionalOnMissingBean(name = "edmiHealthIndicator")
	public HealthIndicator edmiHealthIndicator() {
		return createHealthIndicator(this.connectionDetails);
	}

}
