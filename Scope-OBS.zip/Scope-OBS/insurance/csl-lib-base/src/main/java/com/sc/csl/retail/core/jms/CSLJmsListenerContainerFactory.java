package com.sc.csl.retail.core.jms;

import com.sc.csl.retail.core.web.CSLMessageListenerContainer;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

public class CSLJmsListenerContainerFactory extends DefaultJmsListenerContainerFactory {
	
	@Override
	protected DefaultMessageListenerContainer createContainerInstance() {
		return new CSLMessageListenerContainer();
	}
}
