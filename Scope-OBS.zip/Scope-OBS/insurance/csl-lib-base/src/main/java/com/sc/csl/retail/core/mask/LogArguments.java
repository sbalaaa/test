package com.sc.csl.retail.core.mask;

import java.lang.annotation.Annotation;
import java.util.*;

import static com.sc.csl.retail.core.mask.MaskUtil.maskAndSerializeObject;

public class LogArguments {
    private Object[] args;

    public LogArguments(Object[] args) {
        this.args = args;
    }

    public void mask() {
        for (int i=0; i < args.length; i++) {
            Object arg = args[i];
            args[i] = maskObject(arg);
        }
    }

    Object maskObject(Object arg) {
        if(arg == null) return null;

        if(arg instanceof Collection) {
            return maskCollection(arg);
        }

        if(arg.getClass().isArray()) {
            return maskArray(arg);
        }

        if(arg instanceof Map) {
            return maskMap(arg);
        }

        if(hasMaskAnnotation(arg)) {
            return mask(arg);
        }

        return arg;
    }

    private Object maskMap(Object arg) {
        Map<Object, Object> m = (Map<Object, Object>) arg;
        Set<Map.Entry<Object, Object>> entrySet = m.entrySet();
        Iterator<Map.Entry<Object, Object>> iterator = entrySet.iterator();

        if(iterator.hasNext() && hasMaskAnnotation(iterator.next().getValue())) {
            Map<Object, Object> resultMap = new HashMap<>();
            for(Map.Entry e : entrySet) {
                resultMap.put(e.getKey(), mask(e.getValue()));
            }

            return resultMap;
        }

        return arg;
    }

    private Object maskArray(Object arg) {
        Object[] array = (Object[]) arg;
        if(array.length > 0 && hasMaskAnnotation(array[0])) {
            Object[] resultArray = new Object[array.length];
            int i=0;
            for(Object element : array) {
                String maskedStr = mask(element);
                resultArray[i++] = maskedStr;
            }

            return resultArray;
        }

        return arg;
    }

    String mask(Object obj) {
        return maskAndSerializeObject(obj);
    }

    private Object maskCollection(Object arg) {
        Collection collection = (Collection) arg;
        Iterator iterator = collection.iterator();

        if(iterator.hasNext() && hasMaskAnnotation(iterator.next())) {
            List<Object> maskedCollection = new ArrayList<>();
            for(Object obj : collection) {
                String maskedStr = mask(obj);
                maskedCollection.add(maskedStr);
            }

            return maskedCollection;
        }

        return arg;
    }

    private boolean hasMaskAnnotation(Object arg) {
        if(arg == null) return false;

        for (Annotation annotation : arg.getClass().getAnnotations()) {
            if (annotation instanceof Maskable) {
                return true;
            }
        }

        return false;
    }
}
