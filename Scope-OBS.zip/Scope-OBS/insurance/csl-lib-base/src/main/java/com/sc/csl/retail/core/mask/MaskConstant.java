package com.sc.csl.retail.core.mask;

public class MaskConstant {
	
	public static final String VAR_SERIALVERSIONUID = "serialVersionUID";
	public static final String STRING_PACKAGE = "java.lang.String";
	public static final String SCB_PACKAGE = "com.sc";

	public static final String PATTERN_DIGITS_16 = "\\d{12}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_16 = "************";
    
	public static final String PATTERN_DIGITS_15 = "\\d{11}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_15 = "***********";
    
	public static final String PATTERN_DIGITS_11 = "\\d{7}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_11 = "*******";
    
	public static final String PATTERN_DIGITS_9 = "\\d{5}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_9 = "*****";
    
	public static final String PATTERN_DIGITS_10 = "\\d{6}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_10 = "******";
    
	public static final String PATTERN_DIGITS_23 = "\\d{19}(?=\\d{4})";
	public static final String MASK_PATTERN_DIGITS_23 = "*******************";
    
	public static final String PATTERN_DIGITS_6 = "\\d{6}";
	public static final String MASK_PATTERN_DIGITS_6 = "******";
    
	public static final String PATTERN_DIGITS_4 = "(?<!\\*|\\d)\\d{4}";
	public static final String MASK_PATTERN_DIGITS_4 = "****";
    
	public static final String PATTERN_DIGITS_3 = "(?<!\\*|\\d)\\d{3}$";
	public static final String MASK_PATTERN_DIGITS_3 = "***";
	
	public final static String PATTERN_EMAIL = "(.{1,3})(.+)(@.*)";
	public final static String MASK_EMAIL = "$1****$3" ;
	
	public final static String PATTERN_DISPLAY_LAST_4  ="\\w(?=\\w{4})";
	public final static String MASK_DISPLAY_LAST_4  ="*" ;

}
