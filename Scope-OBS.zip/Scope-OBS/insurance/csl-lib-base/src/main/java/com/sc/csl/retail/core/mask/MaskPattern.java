package com.sc.csl.retail.core.mask;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@AllArgsConstructor
@RequiredArgsConstructor
public class MaskPattern {
	@NotNull
	private final String key;
	private String regex = ".";
	private String replacement = "*";
}
