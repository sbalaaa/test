package com.sc.csl.retail.core.mask;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.exception.CSLJsonProcessingException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.util.*;

@Slf4j
public class MaskUtil {

	private static ObjectMapper customObjectMapper = CSLJsonUtils.newObjectMapper();

	static {
		customObjectMapper.registerModule(new MaskingModule());
	}

	public static String maskAndSerializeObject(Object obj) {
		if(obj == null) return null;

		try {
			return customObjectMapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			throw new CSLJsonProcessingException(e);
		}
	}
	
	public static <T> T maskObject(T object, HashMap<String, ArrayList<String>> mapfields) {
		LinkedList<Field> fields = new LinkedList<>();
		for (Class c = object.getClass(); c != null; c = c.getSuperclass()) {
			List<Field> declared = Arrays.asList(c.getDeclaredFields());
			Collections.reverse(declared);
			for (Field f : declared) {
				if (!f.isSynthetic() && !f.getName().equals(MaskConstant.VAR_SERIALVERSIONUID)) {
					fields.addFirst(f);
				}
			}
		}
			
		for (Field field : fields) {
			field.setAccessible(true);
			try {
				Object obj = field.get(object);
				if (obj != null) {
					Mask mask = field.getDeclaredAnnotation(Mask.class);
					if ( mask != null ) {
						if (!field.getType().isArray() && !field.getType().isPrimitive() 
								&& field.getType().getCanonicalName().startsWith(MaskConstant.STRING_PACKAGE)
								) {
							field.set(object, getValue(mask, obj));
						} else if (field.getType().isArray() 
								&& field.getType().getComponentType().getCanonicalName().startsWith(MaskConstant.STRING_PACKAGE)) {
							handleArrayValueForMasking(field, object, mask);
						}  else if (Map.class.isAssignableFrom(field.getType()) && mapfields != null) {
							handleMapValue(field, object, mask, mapfields );
						} else if (Object.class.isAssignableFrom(field.getType())) {
							maskObject(obj, mapfields);
						} 
					}
				} 
			} catch ( IllegalAccessException e) {
				throw new TechnicalException(e);
			}
		}
		return object;
	}
	
	public static <T> T maskObject(T object) {
		return maskObject( object, null);
	}
	
	private static void handleMapValue(Field field, Object value, Mask mask, HashMap<String, ArrayList<String>> mapfields) {
		try {
			ArrayList<String> keysToMaskList = mapfields.get(field.getName());
			if (keysToMaskList != null && !keysToMaskList.isEmpty()) {
				Map m = (Map) field.get(value);
				for( String key : keysToMaskList) {
					Object mapValue = m.get(key);
					if (mapValue != null)
						m.put(key, getValue(mask,mapValue));
				}
				field.set(value, m);
			}
		} catch( IllegalAccessException e) {
			throw new TechnicalException(e);
		}
	}
	
	public static Map<String, String> maskMap(Map<String, String> mapToMask, List<MaskPattern> maskFieldsWithPatterns ) {
		if (maskFieldsWithPatterns != null ) {
			for( MaskPattern maskMapField : maskFieldsWithPatterns) {
				String keyToMask = maskMapField.getKey();
				Object mapValue = mapToMask.get(keyToMask);
				if( mapValue != null)
				mapToMask.put(keyToMask, getValue(mapValue, maskMapField.getRegex(), maskMapField.getReplacement()));
			}
		}
		return mapToMask;
	}
	
	private static void handleArrayValueForMasking(Field field, Object value, Mask mask) {
		try {
			Object[] collection = getArray(field.get(value));
			if ( collection.length > 0 ) {
				Class cls = Class.forName (MaskConstant.STRING_PACKAGE);
			    Object arr = Array.newInstance(cls, collection.length);
			    int i=0;        
				for (Object object : collection) {
					 Array.set(arr, i++,  getValue(mask, object));
				}
				field.set(value, arr);
			}
		} catch(IllegalAccessException | ClassNotFoundException e) {
			throw new TechnicalException(e);
		}
	}

	static Object[] getArray(Object val) {
		if (val instanceof Object[])
			return (Object[]) val;
		int arrlength = Array.getLength(val);
		Object[] outputArray = new Object[arrlength];
		for (int i = 0; i < arrlength; ++i) {
			outputArray[i] = Array.get(val, i);
		}
		return outputArray;
	}
	
	private static String getValue(Object obj, String regex, String replacement) {
		 if ( obj != null) 
			 return obj.toString().replaceAll(regex, replacement);
		else
			return null;
	}
	
	static String getValue(Mask mask, Object obj, boolean maskable) {
		if ( obj == null ) {
			return null;
		}
		
		if (maskable && mask != null) {
			return obj.toString().replaceAll(mask.regex(), mask.replacement());
		} else
			return obj.toString();
	}
	
	private static String getValue(Mask mask, Object obj) {
		if ( obj == null ) {
			return null;
		}
		if ( mask != null) {
			return obj.toString().replaceAll(mask.regex(), mask.replacement());
		} else
				return obj.toString();
		
	}
}

