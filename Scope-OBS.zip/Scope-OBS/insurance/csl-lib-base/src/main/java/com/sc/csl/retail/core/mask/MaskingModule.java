package com.sc.csl.retail.core.mask;

import com.fasterxml.jackson.core.util.VersionUtil;
import com.fasterxml.jackson.databind.module.SimpleModule;

public class MaskingModule extends SimpleModule {
    private static final String NAME = "CustomMaskingModule";
    private static final VersionUtil VERSION_UTIL = new VersionUtil() {};

    public MaskingModule() {
      super(NAME, VERSION_UTIL.version());
      addSerializer(Object.class, new MaskingSerializer());
    }
}