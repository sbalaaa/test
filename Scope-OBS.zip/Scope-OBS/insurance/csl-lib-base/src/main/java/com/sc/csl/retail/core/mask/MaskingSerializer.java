package com.sc.csl.retail.core.mask;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.*;

import static com.sc.csl.retail.core.mask.MaskConstant.SCB_PACKAGE;

@Slf4j
public class MaskingSerializer extends JsonSerializer<Object> {

	@Override
	public void serialize(Object value, JsonGenerator jGen, SerializerProvider serializers)
			throws IOException, JsonProcessingException {
		jGen.writeStartObject();
		this.writeDocContent(value, jGen, true);
		jGen.writeEndObject();
	}

	public  void writeDocContent(Object value, JsonGenerator jGen, boolean maskable) throws IOException {

		LinkedList<Field> fields = new LinkedList<>();
		for (Class c = value.getClass(); c != null; c = c.getSuperclass()) {
			List<Field> declared = Arrays.asList(c.getDeclaredFields());
			Collections.reverse(declared);
			for (Field f : declared) {
				if (!f.isSynthetic()
						&& !f.getName().equals(MaskConstant.VAR_SERIALVERSIONUID)
				) {
					fields.addFirst(f);
				}
			}
		}

		for (Field field : fields) {
			field.setAccessible(true);
			try {
				Object obj = field.get(value);
				if (obj != null) {
					Mask mask = field.getDeclaredAnnotation(Mask.class);
					if (Collection.class.isAssignableFrom(field.getType())) {
						handleCollectionValue(field, value, jGen, mask, maskable);
					}
					else if (field.getType().isArray()) {
						handleArrayValue(field, value, jGen, mask, maskable);
					}
					else if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) { // don't mask static fields
						jGen.writeStringField(field.getName(), obj.toString());
					}
					else if (field.getType().getCanonicalName().startsWith(SCB_PACKAGE)) { // Process  classes from com.sc* package
						jGen.writeObjectFieldStart(field.getName());
						writeDocContent(obj, jGen, checkMaskable(mask, obj));
						jGen.writeEndObject();
					}
					else { // Mask other classes after toString() if required
						jGen.writeStringField(field.getName(), MaskUtil.getValue(mask, obj, maskable));
					}
				} else {
					jGen.writeStringField(field.getName(), null);
				}
			} catch (IllegalArgumentException | IllegalAccessException e) {
				log.warn("Error in masking : ", e);
			}
		}
	}

	private static boolean checkMaskable(Mask mask, Object obj) {
		if (mask != null) {
			for (Annotation annotation : obj.getClass().getAnnotations()) {
				if (annotation instanceof Maskable) {
					return true;
				}
			}
		}
		return false;
	}

	public void handleCollectionValue(Field field, Object value, JsonGenerator jGen, Mask mask, boolean maskable)
			throws IllegalArgumentException, IllegalAccessException, IOException {
		Collection<?> collection = (Collection<?>) field.get(value);
		
		jGen.writeFieldName(field.getName());
		jGen.writeStartArray();
		for (Object object : collection) {
			if (object.getClass().getCanonicalName().startsWith(MaskConstant.SCB_PACKAGE)) {
				jGen.writeStartObject();
				writeDocContent(object, jGen, checkMaskable(mask, object));
				jGen.writeEndObject();
			} else {
				jGen.writeString(MaskUtil.getValue(mask, object, maskable));
			}
		}
		jGen.writeEndArray();
	}

	public static void handleArrayValue(Field field, Object value, JsonGenerator jGen, Mask mask, boolean maskable)
			throws IllegalArgumentException, IllegalAccessException, IOException {
		jGen.writeFieldName(field.getName());
		jGen.writeStartArray();
		Object[] collection = MaskUtil.getArray(field.get(value));
		for (Object object : collection) {
			jGen.writeString(MaskUtil.getValue(mask, object, maskable));
		}
		jGen.writeEndArray();
	}

}