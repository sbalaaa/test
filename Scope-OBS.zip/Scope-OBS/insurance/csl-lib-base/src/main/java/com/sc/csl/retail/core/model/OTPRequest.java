package com.sc.csl.retail.core.model;

import io.crnk.core.resource.annotations.JsonApiId;
import lombok.Data;

import java.util.Map;

@Data
public class OTPRequest {
    @JsonApiId
    private String requestId;
    private String actionName;

    private Map<String, String> otpParams;
}
