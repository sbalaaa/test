package com.sc.csl.retail.core.model;

import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

@Data
@JsonApiResource(type = "sms-otp")
public class SmsOtp {
    @JsonApiId
    private String requestId;
    private String mobile;
    private String msgTemplate;

    private String statusCode;
    private String otpSn;
    private String otpPrefix;

    private String base64Challenge;
    private String keyIndex;
    private String exponent;
    private String modulus;
    private String relId;
    
    private String type;
    private String purpose;
}
