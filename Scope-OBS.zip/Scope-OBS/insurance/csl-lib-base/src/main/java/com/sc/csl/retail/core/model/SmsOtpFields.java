package com.sc.csl.retail.core.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SmsOtpFields {
    private String requestId;

    private String encOtp;
    private String purpose;
    private String otpSn;
    private String keyIndex;

    private String type;
    private String encValue;
    
    private String relId;
    private String country;
    private String language;
    private String channel;

    private String statusCode;
    private String errorMessage;
}
