package com.sc.csl.retail.core.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SmsOtpValidation {
    private SmsOtpFields smsOtp;

    public String getEncOtp() {
        return smsOtp.getEncOtp();
    }

    public String getPurpose() {
        return smsOtp.getPurpose();
    }

    public String getOtpSn() {
        return smsOtp.getOtpSn();
    }

    public String getKeyIndex() {
        return smsOtp.getKeyIndex();
    }
    
    public String getType() {
        return smsOtp.getType();
    }
    
    public String getEncValue() {
        return smsOtp.getEncValue();
    }
}

