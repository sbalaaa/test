package com.sc.csl.retail.core.render;


import freemarker.template.Configuration;

import java.io.Writer;
import java.util.Map;

public class FreemarkerRenderer extends Renderer<Configuration> {

    private Configuration configuration;

    public FreemarkerRenderer(Configuration configuration) {
        this.configuration = configuration;
    }

    protected void renderInternal(String templatePath, Map<String, Object> values, Writer writer) throws Exception {
        configuration.getTemplate(templatePath).process(values, writer);
    }

}
