package com.sc.csl.retail.core.render;


import com.sc.csl.retail.core.exception.TechnicalException;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Map;

public abstract class Renderer<T> {

    protected abstract void renderInternal(String template, Map<String, Object> values, Writer writer) throws Exception;

    public String render(String template, Map<String, Object> values) {
        try {
            ByteArrayOutputStream ostream = new ByteArrayOutputStream();
            Writer writer = new OutputStreamWriter(ostream);
            renderInternal(template, values, writer);
            ostream.flush();
            String output = new String(ostream.toByteArray(), "UTF-8");
            return output;
        } catch (Exception e) {
            throw new TechnicalException("Template Render Exception", e);
        }
    }
}
