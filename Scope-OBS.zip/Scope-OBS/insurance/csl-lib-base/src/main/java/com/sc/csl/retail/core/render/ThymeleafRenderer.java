package com.sc.csl.retail.core.render;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.Writer;
import java.util.Locale;
import java.util.Map;

public class ThymeleafRenderer extends Renderer<TemplateEngine> {

    private TemplateEngine templateEngine;

    public ThymeleafRenderer(TemplateEngine templateEngine) {
        this.templateEngine = templateEngine;
    }

    protected void renderInternal(String template, Map<String, Object> values, Writer writer) throws Exception {
        templateEngine.process(template, new Context(Locale.getDefault(), values), writer);
    }
}
