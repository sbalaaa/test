package com.sc.csl.retail.core.tmx;

import java.util.Arrays;
import java.util.List;

public class TmxConstants {

    public static final List<String> ERROR_CODES = Arrays.asList(
            "fail_access",
            "fail_incomplete",
            "fail_internal_error",
            "fail_temporarily_unavailable",
            "fail_not_enough_params",
            "fail_duplicate_entities_of_same_type",
            "fail_invalid_sha_hash",
            "fail_invalid_account_number",
            "fail_invalid_email_address",
            "fail_invalid_telephone_number",
            "fail_invalid_parameter",
            "fail_unknown_api",
            "fail_no_policy_configured",
            "fail_invalid_ip_address_parameter",
            "fail_invalid_submitter_id",
            "fail_too_many_instances_of_same_parameter",
            "fail_parameter_overlength",
            "fail_invalid_device_id",
            "fail_invalid_fuzzy_device_id",
            "fail_invalid_currency_code",
            "fail_invalid_currency_format",
            "fail_invalid_charset",
            "fail_invalid_characters",
            "fail_save_in_progress"
    );
}
