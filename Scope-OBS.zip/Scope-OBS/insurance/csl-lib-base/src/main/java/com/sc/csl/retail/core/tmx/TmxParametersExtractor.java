package com.sc.csl.retail.core.tmx;

import java.util.Map;

public interface TmxParametersExtractor {
    Map<String, String> getTmxParams();
}
