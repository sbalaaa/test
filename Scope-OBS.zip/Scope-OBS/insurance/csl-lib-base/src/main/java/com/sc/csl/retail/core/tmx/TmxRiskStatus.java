package com.sc.csl.retail.core.tmx;

public enum TmxRiskStatus {
    LOW,
    MEDIUM,
    HIGH,
    TRUSTED,
    NEUTRAL,
    TIMEOUT;

    public static TmxRiskStatus fromString(String statusString) {
        for (TmxRiskStatus status : values()) {
            if (status.name().equalsIgnoreCase(statusString)) {
                return status;
            }
        }

        return null;
    }

}
