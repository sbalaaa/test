package com.sc.csl.retail.core.tmx.annotations;

import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface TmxEnabled {
    String template() default "";
    String eventType() default "";
    String customerEventType() default "";
    TmxProperty [] tmxProperties() default {};
}
