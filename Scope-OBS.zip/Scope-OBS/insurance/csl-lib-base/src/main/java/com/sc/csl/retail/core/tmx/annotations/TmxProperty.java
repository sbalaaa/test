package com.sc.csl.retail.core.tmx.annotations;

public @interface TmxProperty {
    String field() default "";
    String value() default "";
}
