package com.sc.csl.retail.core.tmx.gateway;

import com.fasterxml.jackson.databind.JsonNode;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLRestGateway;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.tmx.TmxRiskStatus;
import com.sc.csl.retail.core.tmx.model.TmxUserVerificationResponse;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.ws.rs.core.Response;
import java.util.Map;

@Slf4j
public class TmxEdmiGatewayImpl extends CSLRestGateway implements TmxGateway {

    private static final String VERIFY_SESSION_TEMPLATE = "edmiTmxVerifyUserSessionTemplate.ftl";
    private static final String FEEDBACK_TEMPLATE = "edmiTmxFeedbackTemplate.ftl";

    private static final String VERIFY_SESSION_RESPONSE_PAYLOAD_PATH = "verifyUserSessionRes/verifyUserSessionResPayload/sessionQueryRes/responseMessageJSON";
    private static final String VERIFY_SESSION_REQUEST_PAYLOAD_PATH = "verifyUserSessionReq/verifyUserSessionReqPayload/sessionQueryReq";

    @Autowired
    @Setter
    private FreemarkerRenderer freemarkerRenderer;

    @Setter
    private Map<String, String> tmxBasicAuthMap;

    @Autowired
    @Setter
    private CSLRequestContext cslRequestContext;

    @Setter
    private String verifySessionEndpointUrl;

    @Setter
    private String feedbackEndpointUrl;

    @Value("${tmx.gateway.disabled:false}")
    private Boolean disabled;

    @Value("${tmx.gateway.riskRatingWhenDisabled:medium}")
    private String riskRatingWhenDisabled;

    @Override
    protected WebClient webClient(String path, String mediaType) {
        String countryCode = cslRequestContext.getCountry() != null ?  cslRequestContext.getCountry().toUpperCase() : null;
        if (StringUtils.isEmpty(countryCode) || !tmxBasicAuthMap.containsKey(countryCode)) {
            throw new TechnicalException(String.format("Auth for EDMI '%s' is not configured.", countryCode));
        }

        WebClient client = super.webClient(path, mediaType);
        client.authorization(tmxBasicAuthMap.get(countryCode));

        return client;
    }

    @Override
    public TmxUserVerificationResponse verifyUserSession(Map<String, Object> obligatoryParameters,
                                                          Map<String, Object> requestSpecificParameters) {
        if (!disabled) {
            String edmiTmxRequest = prepareVerifySessionRequest(obligatoryParameters, requestSpecificParameters);
            log.info("Prepared EDMI TMX request : {} for {}", verifySessionEndpointUrl, edmiTmxRequest);
            Response response = post(edmiTmxRequest, verifySessionEndpointUrl);
            TmxUserVerificationResponse tmxResponse = processVerifySessionRequest(response);
            log.info("Response from {} : {}", verifySessionEndpointUrl, tmxResponse);
            return  tmxResponse;
        } else {
            TmxUserVerificationResponse tmxResponse = new TmxUserVerificationResponse();
            tmxResponse.setRiskRating(riskRatingWhenDisabled);
            tmxResponse.setTmxRiskStatus(TmxRiskStatus.fromString(riskRatingWhenDisabled));
            log.info("Tmx Gateway disabled, verify session call mocked {} : {}", verifySessionEndpointUrl, tmxResponse);
            return  tmxResponse;
        }
    }

    private String prepareVerifySessionRequest(Map<String, Object> obligatoryParameters,
                                               Map<String, Object> requestSpecificParameters) {
        String template = freemarkerRenderer.render(VERIFY_SESSION_TEMPLATE, obligatoryParameters);
        JsonNode requestRoot = CSLJsonUtils.parseJson(template, JsonNode.class);
        CSLJsonUtils.appendNodeValues(requestRoot, requestSpecificParameters, VERIFY_SESSION_REQUEST_PAYLOAD_PATH);
        return CSLJsonUtils.toJson(requestRoot);
    }

    private TmxUserVerificationResponse processVerifySessionRequest(Response response) {
        String responseStr = response.readEntity(String.class);
        log.info("Response: {}", responseStr);
        JsonNode root = CSLJsonUtils.parseJson(responseStr, JsonNode.class);
        JsonNode responseJson = CSLJsonUtils.getNodeValue(root, VERIFY_SESSION_RESPONSE_PAYLOAD_PATH);
        return CSLJsonUtils.parseJson(responseJson.asText(), TmxUserVerificationResponse.class);
    }

    @Override
    public void sendUserSessionFeedback(Map<String, Object> obligatoryParameters) {
        if (!disabled) {
            String feedbackRequest = freemarkerRenderer.render(FEEDBACK_TEMPLATE, obligatoryParameters);
            log.info("Prepared EDMI TMX request : {} for {}", feedbackEndpointUrl, feedbackRequest);
            Response response = post(feedbackRequest, feedbackEndpointUrl);
            String responseStr = response.readEntity(String.class);
            log.info("Response from {} : {}", feedbackEndpointUrl, responseStr);
        } else {
            log.info("Tmx Gateway disabled, feedback call mocked {}", feedbackEndpointUrl);
        }
    }

}
