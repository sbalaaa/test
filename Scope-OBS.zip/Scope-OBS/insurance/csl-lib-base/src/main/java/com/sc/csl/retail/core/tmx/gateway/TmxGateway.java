package com.sc.csl.retail.core.tmx.gateway;

import com.sc.csl.retail.core.tmx.model.TmxUserVerificationResponse;

import java.util.Map;


public interface TmxGateway {

    TmxUserVerificationResponse verifyUserSession(Map<String,Object> obligatoryParameters, Map<String,Object> requestSpecificParameters);

    void sendUserSessionFeedback(Map<String,Object> obligatoryParameters);
}
