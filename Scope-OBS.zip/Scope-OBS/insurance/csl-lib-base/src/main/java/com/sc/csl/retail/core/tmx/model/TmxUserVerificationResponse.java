package com.sc.csl.retail.core.tmx.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.core.tmx.TmxRiskStatus;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TmxUserVerificationResponse {

    @JsonProperty("policy")
    private String policy;

    @JsonProperty("action")
    private String action;

    @JsonProperty("request_duration")
    private String requestDuration;

    @JsonProperty("request_id")
    private String requestID;

    @JsonProperty("transaction_id")
    private String transactionID;

    @JsonProperty("event_type")
    private String eventType;

    //Possible values: high, medium, low, neutral, trusted
    @JsonProperty("risk_rating")
    private String riskRating;

    @JsonProperty("summary_risk_score")
    private String tmxRiskScore;

    @JsonProperty("application_name")
    private String applicationId;

    @JsonProperty("request_result")
    private String requestResult;

    @JsonProperty("session_id")
    private String sessionId;

    @JsonProperty("true_ip_city")
    private String trueIPCity;

    @JsonProperty("true_ip")
    private String trueIP;

    @JsonProperty("device_id")
    private String deviceID;

    //Status mapped according to policy score. Possible values: reject, review, pass
    @JsonProperty("review_status")
    private String reviewStatus;

    @JsonProperty("unknown_session")
    private String unknownSession;

    @JsonProperty("policy_score")
    private String policyScore;

    //The names of rules that fired for this query. Each rule name is returned as a separate name/value pair (multiple 'reason_code' keys can return in a single response)
    @JsonProperty("reason_code")
    private String [] reasonCode;

    private TmxRiskStatus tmxRiskStatus;
}
