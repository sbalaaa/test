package com.sc.csl.retail.core.tmx.service;

import com.sc.csl.retail.core.config.TmxConfig;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TmxRedStatusException;
import com.sc.csl.retail.core.tmx.TmxConstants;
import com.sc.csl.retail.core.tmx.TmxObligatoryFields;
import com.sc.csl.retail.core.tmx.TmxRiskStatus;
import com.sc.csl.retail.core.tmx.gateway.TmxGateway;
import com.sc.csl.retail.core.tmx.model.TmxUserVerificationResponse;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.TMX_STATUS_HIGH;

/**
 * Class for handling TMX logic
 */
@Slf4j
public class TmxProcessorService {

    private TmxProcessorService() {}

    private static TmxProcessorService _instance = new TmxProcessorService();

    private static final String AGENT_MOBILE = "Agent_Mobile";

    @Setter
    private TmxGateway tmxGateway;

    @Setter
    private CSLRequestContext cslRequestContext;

    @Setter
    private TmxConfig.CommonConfig tmxCommonConfig;

    @Setter
    private Map<String, TmxConfig.TmxCountryConfig> countryConfigMap;

    public static TmxProcessorService getInstance() {
        return _instance;
    }

    /**
     * If TMX response is LOW do nothing, proceed to normal flow.
     * If TMX response is HIGH then throw TmxException.
     * If TMX response is any other then send feedback to TMX and proceed to normal flow.
     */
    public TmxUserVerificationResponse verifySession(Map<String, Object> requestSpecificParameters) {
        if (cslRequestContext.getTmxSessionId() == null) {
            throw new IllegalStateException(CSLConstants.NO_TMX_SESSION_ID_MESSAGE);
        }
        if (requestSpecificParameters == null || requestSpecificParameters.isEmpty()) {
            throw new IllegalArgumentException("TMX Parameters Map should not be empty");
        }

        Map<String, Object> tmxObligatoryParameters = new HashMap<>();
        populateCustomerSpecificConfiguration(tmxObligatoryParameters);
        populateDefaultConfiguration(tmxObligatoryParameters);
        populateCommonConfiguration(tmxObligatoryParameters);

        TmxUserVerificationResponse response = tmxGateway.verifyUserSession(tmxObligatoryParameters, requestSpecificParameters);
        TmxRiskStatus tmxRiskStatus = TmxRiskStatus.fromString(response.getRiskRating());
        response.setTmxRiskStatus(tmxRiskStatus);

        if (!StringUtils.isEmpty(response.getRequestResult()) &&
                TmxConstants.ERROR_CODES.contains(response.getRequestResult())) {
            tmxRiskStatus = TmxRiskStatus.MEDIUM;
            log.error("Error details returned by TMX, hence changing TMX response to MEDIUM to proceeds per BAU. Returned Error detail: {}", response.getRequestResult());
        }

        if (tmxRiskStatus == TmxRiskStatus.HIGH) {
            log.info("HIGH TMX risk status detected, interrupt execution: {}", response.toString());
            throw new TmxRedStatusException(TMX_STATUS_HIGH);
        }

        return response;
    }

    /**
     * Provide feedback to TMX service.
     */
    public void feedback(TmxUserVerificationResponse response) {
        try {
            Map<String, Object> tmxObligatoryParameters = new HashMap<>();
            populateCustomerSpecificConfiguration(tmxObligatoryParameters);
            populateDefaultConfiguration(tmxObligatoryParameters);
            populateCommonConfiguration(tmxObligatoryParameters);

            log.info("MIDDLE TMX risk status detected, provide feedback and return back to normal flow.");
            tmxObligatoryParameters.put(TmxObligatoryFields.uniqueRequestId.name(), response.getRequestID());
            tmxGateway.sendUserSessionFeedback(tmxObligatoryParameters);
        } catch (Exception e) {
            // Do nothing, this exception can be ignored
            log.error("Error during TMX Feedback service call.", e);
        }
    }


    private void populateCustomerSpecificConfiguration(Map<String, Object> tmxParameters) {
        tmxParameters.put(TmxObligatoryFields.messageTimestamp.name(), Calendar.getInstance().getTime());
        tmxParameters.put(TmxObligatoryFields.initiatedTimestamp.name(), Calendar.getInstance().getTime());
        tmxParameters.put(TmxObligatoryFields.requestUID.name(), cslRequestContext.getRequestId());
        tmxParameters.put(TmxObligatoryFields.agentType.name(), AGENT_MOBILE);
        tmxParameters.put(TmxObligatoryFields.webSessionId.name(), cslRequestContext.getJSessionId());
        tmxParameters.put(TmxObligatoryFields.accountLogin.name(), cslRequestContext.getUaas2id());
        tmxParameters.put(TmxObligatoryFields.inputIpAddress.name(), cslRequestContext.getClientIp());
        tmxParameters.put(TmxObligatoryFields.countryCode.name(), cslRequestContext.getCountry());
        tmxParameters.put(TmxObligatoryFields.sessionIdTMX.name(), cslRequestContext.getTmxSessionId());
        tmxParameters.put(TmxObligatoryFields.typeOfAuthUsed.name(), cslRequestContext.getPreferredOtpType());
    }

    private void populateDefaultConfiguration(Map<String, Object> tmxParameters) {
        String country = cslRequestContext.getCountry() != null ? cslRequestContext.getCountry().toUpperCase() : null;
        if (StringUtils.isEmpty(country) || !countryConfigMap.containsKey(country)) {
            throw new TechnicalException(String.format("Country '%s' is not configured.", country.toString()));
        }
        TmxConfig.TmxCountryConfig config = countryConfigMap.get(country);
        tmxParameters.put(TmxObligatoryFields.orgId.name(), config.getOrgId());
        tmxParameters.put(TmxObligatoryFields.apiKey.name(), config.getApiKey());
        tmxParameters.put(TmxObligatoryFields.profileOrgId.name(), config.getOrgId());
        tmxParameters.put(TmxObligatoryFields.transactionId.name(), UUID.randomUUID().toString());
        if(null != config.getLineOfBusiness()) {
            tmxParameters.put(TmxObligatoryFields.lineOfBusiness.name(), config.getLineOfBusiness());
        } else {
            String lineOfBusinessValue = cslRequestContext.getCountry()+"_RETAIL_IBANKING";
            tmxParameters.put(TmxObligatoryFields.lineOfBusiness.name(), lineOfBusinessValue);
        }
    }

    private void populateCommonConfiguration(Map<String, Object> tmxParameters) {
        tmxParameters.put(TmxObligatoryFields.messageVersion.name(), tmxCommonConfig.getMessageVersion());
        tmxParameters.put(TmxObligatoryFields.messageTypeName.name(), tmxCommonConfig.getMessageTypeName());
        tmxParameters.put(TmxObligatoryFields.messageSenderBody.name(), tmxCommonConfig.getMessageSenderBody());
        tmxParameters.put(TmxObligatoryFields.messageSenderDomainName.name(), tmxCommonConfig.getMessageSenderDomainName());
        tmxParameters.put(TmxObligatoryFields.messageSenderSubDomainNameType.name(), tmxCommonConfig.getMessageSenderSubDomainNameType());
        tmxParameters.put(TmxObligatoryFields.originationCountryCode.name(), tmxCommonConfig.getOriginationCountryCode());
        tmxParameters.put(TmxObligatoryFields.captureSystem.name(), tmxCommonConfig.getCaptureSystem());
        tmxParameters.put(TmxObligatoryFields.requestPayloadFormat.name(), tmxCommonConfig.getRequestPayloadFormat());
        tmxParameters.put(TmxObligatoryFields.requestPayloadVersion.name(), tmxCommonConfig.getRequestPayloadVersion());
        tmxParameters.put(TmxObligatoryFields.serviceTypeTMX.name(), tmxCommonConfig.getRequestServiceTypeTMX());
        tmxParameters.put(TmxObligatoryFields.applicationName.name(), tmxCommonConfig.getApplicationName());
        tmxParameters.put(TmxObligatoryFields.possibleDuplicate.name(), tmxCommonConfig.getPossibleDuplicate());
    }

}
