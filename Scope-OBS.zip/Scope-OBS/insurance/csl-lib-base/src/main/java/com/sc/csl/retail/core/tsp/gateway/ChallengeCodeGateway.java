package com.sc.csl.retail.core.tsp.gateway;

import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import com.sc.csl.retail.core.tsp.model.HighRiskTokenValidateDto;
import com.sc.csl.retail.core.tsp.model.SoftTokenValidateDto;


public interface ChallengeCodeGateway {
     ChallengeCode postForChallengeCode(ChallengeCode challengeCode);
     SoftTokenValidateDto postForChallengeCodeValidation(SoftTokenValidateDto softTokenValidateDto);
     HighRiskTokenValidateDto postForHighRiskTransaction(HighRiskTokenValidateDto highRiskTokenValidateDto);
}
