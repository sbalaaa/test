package com.sc.csl.retail.core.tsp.gateway;

import com.sc.csl.retail.core.exception.CSLCrnkClientException;
import com.sc.csl.retail.core.exception.CSLErrorCodes;
import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.core.exception.TspRequiredException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import com.sc.csl.retail.core.tsp.model.HighRiskTokenValidateDto;
import com.sc.csl.retail.core.tsp.model.SoftTokenValidateDto;
import com.sc.csl.retail.core.web.CSLRequestContext;
import io.crnk.core.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;


@Slf4j
public class ChallengeCodeGatewayImpl extends CSLJsonApiGateway implements ChallengeCodeGateway {

    @Autowired
    private CSLRequestContext cslRequestContext;

    Map<String, ErrorCode> map = new HashMap<>();

    @Override
    public ChallengeCode postForChallengeCode(ChallengeCode challengeCode) {
        ResourceRepositoryV2<ChallengeCode, String> challengeCodeRepo = getCrnkClient().getRepositoryForType(ChallengeCode.class);
        try {
            return challengeCodeRepo.create(challengeCode);
        } catch (CSLCrnkClientException ex) {
            handleErrorResponse(ex);
        }
        return null;
    }

    public SoftTokenValidateDto postForChallengeCodeValidation(SoftTokenValidateDto softTokenValidateDto) {
        ResourceRepositoryV2<SoftTokenValidateDto, String> challengeCodeRepo = getCrnkClient().getRepositoryForType(SoftTokenValidateDto.class);
        try {
            return challengeCodeRepo.create(softTokenValidateDto);
        } catch (CSLCrnkClientException ex) {
            handleErrorResponse(ex);
        }
        return null;
    }

    public HighRiskTokenValidateDto postForHighRiskTransaction(HighRiskTokenValidateDto highRiskTokenValidateDto) {
        ResourceRepositoryV2<HighRiskTokenValidateDto, String> challengeCodeRepo = getCrnkClient().getRepositoryForType(HighRiskTokenValidateDto.class);
        try {
            return challengeCodeRepo.create(highRiskTokenValidateDto);
        } catch (CSLCrnkClientException ex) {
            handleErrorResponse(ex);
        }
        return null;
    }

    private void handleErrorResponse(CSLCrnkClientException ex) {
        ErrorCode errorCode =  getErrorCode(ex.getErrorCode().getCode());
        if (errorCode != null) {
            throw new TspRequiredException(errorCode);
        } else {
            throw new TspRequiredException(CSLErrorCodes.SOFT_TOKEN_GENERIC_EXCEPTION);
        }
    }

    private ErrorCode getErrorCode(String errorCode) {
        if (!map.isEmpty()) {
            return map.get(errorCode);
        }
        map.put("CSL-SEC-509", CSLErrorCodes.PUSH_SENDING_FAILED);
        map.put("CSL-SEC-504", CSLErrorCodes.SOFT_TOKEN_LICENSE_ISSUE);
        map.put("CSL-SEC-508", CSLErrorCodes.SOFT_TOKEN_LICENSE_ISSUE);
        map.put("CSL-SEC-507", CSLErrorCodes.SOFT_TOKEN_LICENSE_ISSUE);
        map.put("CSL-STOKEN-504", CSLErrorCodes.SOFT_TOKEN_LICENSE_ISSUE);
        map.put("CSL-SEC-506", CSLErrorCodes.SOFT_TOKEN_INTERFACE_GENERIC_ERROR);
        map.put("CSL-SEC-502", CSLErrorCodes.SOFT_TOKEN_INTERFACE_GENERIC_ERROR);
        map.put("CSL-OTP-AUTH-602", CSLErrorCodes.SOFT_TOKEN_INTERFACE_GENERIC_ERROR);
        map.put("CSL-SEC-503", CSLErrorCodes.SOFT_TOKEN_OTP_INVALID);
        map.put("CSL-SEC-514", CSLErrorCodes.SOFT_TOKEN_EXCEED_MAX_RETRY);
        map.put("CSL-SEC-512", CSLErrorCodes.TRANSACTION_MISMATCH);
        map.put("CSL-304", CSLErrorCodes.TOKEN_INVALID);
        return map.get(errorCode);
    }

}
