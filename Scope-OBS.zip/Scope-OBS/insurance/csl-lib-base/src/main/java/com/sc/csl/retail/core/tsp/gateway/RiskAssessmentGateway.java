package com.sc.csl.retail.core.tsp.gateway;


import com.sc.csl.retail.core.tsp.model.RiskAssessmentDto;

public interface RiskAssessmentGateway {
     RiskAssessmentDto getRiskAssessmentAuthLevel(String riskId);
}
