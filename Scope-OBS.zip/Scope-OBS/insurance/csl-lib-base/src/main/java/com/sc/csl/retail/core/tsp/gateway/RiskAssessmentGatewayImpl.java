package com.sc.csl.retail.core.tsp.gateway;


import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLRestGateway;
import com.sc.csl.retail.core.tsp.model.RiskAssessmentDto;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.util.CSLJsonApiUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import io.crnk.core.resource.list.DefaultResourceList;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.springframework.beans.factory.annotation.Autowired;

import javax.ws.rs.core.Response;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.RISK_ASSESSMENT_DATA_NOT_FOUND;


@Data
@Slf4j
public class RiskAssessmentGatewayImpl extends CSLRestGateway implements RiskAssessmentGateway {

    public static final String CONTENT_TYPE = "application/vnd.api+json";

    private String serviceUrl;

    private String baseUrl;
    @Autowired
    private CSLRequestContext cslRequestContext;

    public RiskAssessmentDto getRiskAssessmentAuthLevel(String riskCode) {
        setBaseUrl(baseUrl);
        WebClient webClient = webClient(serviceUrl);
        prepareQueryParam(webClient,riskCode);
        Response response = webClient.get();
        String jsonApi = response.readEntity(String.class);
        DefaultResourceList<RiskAssessmentDto> riskObject = CSLJsonApiUtils.toObject(jsonApi, RiskAssessmentDto.class);
        if(CollectionUtils.isEmpty(riskObject) || riskObject.get(0).getAuthLevelConfiguration()== null ){
           throw new TechnicalException(RISK_ASSESSMENT_DATA_NOT_FOUND);
        }
        return riskObject.get(0);
    }

    private void prepareQueryParam(WebClient webClient, String riskCode) {
        webClient.query("filter[application.applicationCode]", CSLConstants.APPLICATION_CODE)
                .query("filter[country.countryCode]",cslRequestContext.getCountry())
                .query("filter[code]",riskCode);
        webClient.header("Accept", CONTENT_TYPE);
        webClient.header("Content-Type", CONTENT_TYPE);
    }

}
