package com.sc.csl.retail.core.tsp.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class AuthLevelConfiguration  implements Serializable {
    @JsonProperty("configuration-id")
    private Integer configurationId;
    @JsonProperty("auth-upgrade-check-required")
    private Boolean authUpgradeCheckRequired;
    @JsonProperty("auth-level")
    private RiskAuthLevel riskAuthLevel;
}
