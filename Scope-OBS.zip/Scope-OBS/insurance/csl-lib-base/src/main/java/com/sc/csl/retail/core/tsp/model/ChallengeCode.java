package com.sc.csl.retail.core.tsp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

@JsonApiResource(type = ChallengeCode.RESOURCE_NAME)
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChallengeCode implements Serializable {

    @JsonIgnore
    public static final String RESOURCE_NAME = "challenge-codes";
    @JsonIgnore
    private static final long serialVersionUID = 1L;
    @JsonApiId
    private String oid;
    @JsonProperty("tx-data")
    private List<String> txData;
    @JsonProperty("push-tx-data")
    private Map<String,String> pushTxData;
    @NotNull
    @JsonProperty("push-required")
    private Boolean pushRequired;
    @JsonProperty("ext-ref-id")
    private String externalReferenceId;

    @JsonProperty("tx-ref-num")
    private String txRefNo;

    /**
     * output
     */
    @JsonProperty("challenge-code")
    private String challengeCode;

    @JsonProperty("random-num")
    private String randomNum;

    @JsonProperty("notification-id")
    private String notificationId;

    @JsonProperty("encrypted-challenge")
    private String encryptedChallenge;

    @JsonProperty("tx-hash")
    private String transactionHash;

    private Boolean isOffline;

}
