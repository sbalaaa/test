package com.sc.csl.retail.core.tsp.model;

import lombok.Data;

@Data
public class ErrorResponse {
    private String code ;
    private String title ;
    private String details ;
    private String status;
}
