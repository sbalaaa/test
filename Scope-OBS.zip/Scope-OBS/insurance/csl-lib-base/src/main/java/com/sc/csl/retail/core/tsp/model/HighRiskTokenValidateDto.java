package com.sc.csl.retail.core.tsp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@JsonApiResource(type = HighRiskTokenValidateDto.RESOURCE_NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HighRiskTokenValidateDto implements Serializable {

    @JsonIgnore
    private static final long serialVersionUID = 1L;

    @JsonIgnore
    public static final String RESOURCE_NAME = "transaction-token-validations";

    @JsonApiId
    private String oid;

    @JsonProperty("tx-ref-num")
    private String txRefNo;

    @JsonProperty("tx-data")
    private List<String> txData;

    @JsonProperty("push-tx-data")
    private Map<String,String> pushTxData;

    @JsonProperty("high-risk-token")
    private String accessToken;

}

