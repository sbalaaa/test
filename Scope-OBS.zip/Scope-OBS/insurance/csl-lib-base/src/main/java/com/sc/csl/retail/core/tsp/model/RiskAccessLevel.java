package com.sc.csl.retail.core.tsp.model;

import lombok.Data;

@Data
public class RiskAccessLevel {
   private RiskAccessLevelAdopter requiredAccessLevel;
   private RiskAccessLevelAdopter parentAccessLevel;
}
