package com.sc.csl.retail.core.tsp.model;

import java.util.HashMap;
import java.util.Map;

public enum RiskAccessLevelAdopter {
	NO_AUTHENTICATION(-1),
	REGISTERED_DEVICE(0),
	ONE_FACTOR(1),
	TWO_FACTOR(2),
	TWO_FACTOR_PLUS(2),
 	HIGH_RISK(4),
	TRANSACTION_SIGNING(4);
    int authLevel;

	private static Map<Integer, RiskAccessLevelAdopter> map = new HashMap<Integer, RiskAccessLevelAdopter>();

	static {
		for (RiskAccessLevelAdopter accessLevel : RiskAccessLevelAdopter.values()) {
			map.put(accessLevel.authLevel, accessLevel);
		}
	}
	public static RiskAccessLevelAdopter valueOfLevel(int level) {
		return map.get(level);
	}

	RiskAccessLevelAdopter(int authLevel) {
		this.authLevel = authLevel;
	}
	public int authLevel() {
		return authLevel;
	}
}
