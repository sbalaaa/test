package com.sc.csl.retail.core.tsp.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class RiskApplication  implements Serializable {
    private String applicationCode;
}
