package com.sc.csl.retail.core.tsp.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@JsonApiResource(type = RiskAssessmentDto.RESOURCE_NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RiskAssessmentDto implements Serializable {

    public static final String RESOURCE_NAME = "risk-assessment-features";

    @JsonApiId
    private String id;
    @JsonProperty("authLevel-configuration")
    private List<AuthLevelConfiguration> authLevelConfiguration;
    @JsonProperty("code")
    private String code;
    @JsonProperty("api-endpoint")
    private String apiEndpoint;
    @JsonProperty("application-code")
    private String applicationCode;
    @JsonProperty("category")
    private String category;
    @JsonProperty("application")
    private RiskApplication application;
    @JsonProperty("country")
    private RiskCountry country;
}



