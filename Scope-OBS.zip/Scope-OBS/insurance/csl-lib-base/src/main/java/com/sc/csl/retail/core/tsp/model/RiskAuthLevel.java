package com.sc.csl.retail.core.tsp.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class RiskAuthLevel implements Serializable {
  @JsonProperty("level")
  private String requiredAuthLevel;
  @JsonProperty("parent-auth-level")
  private String parentAuthLevel;
  @JsonProperty("preferred-auth-level")
  private Boolean preferredAuthLevel;
}
