package com.sc.csl.retail.core.tsp.model;


import lombok.Data;

import java.io.Serializable;

@Data
public class RiskCountry implements Serializable {
    private String countryCode;

}
