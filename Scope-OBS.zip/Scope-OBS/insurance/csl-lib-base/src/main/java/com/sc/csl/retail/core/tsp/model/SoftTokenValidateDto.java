package com.sc.csl.retail.core.tsp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@JsonApiResource(type = SoftTokenValidateDto.RESOURCE_NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SoftTokenValidateDto implements Serializable {

    @JsonIgnore
    private static final long serialVersionUID = 1L;

    @JsonIgnore
    public static final String RESOURCE_NAME = "challenge-otp-validations";

    @JsonApiId
    private String oid;

    @JsonProperty("tx-ref-num")
    private String txRefNo;

    @JsonProperty("tx-data")
    private List<String> txData;

    @JsonProperty("push-tx-data")
    private Map<String,String> pushTxData;

    @JsonProperty("challenge-otp")
    private String response;

    @JsonProperty("random-num")
    private String randomNum;

    @JsonProperty("token-serial-number")
    private String tokenSerialNumber;

    @JsonProperty("sequence-number")
    private Integer sequenceNumber;

    @JsonProperty("validation-status")
    private String validationStatus;

    @JsonProperty("ext-ref-id")
    private String externalReferenceId;

    @JsonProperty("tx-hash")
    private String transactionHash;

    @JsonProperty("access-level-required")
    private String accesLevelRequired;

    @JsonProperty("high-risk-token")
    private String accessToken;

}
