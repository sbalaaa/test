package com.sc.csl.retail.core.tsp.service;

import com.sc.csl.retail.core.tsp.gateway.ChallengeCodeGateway;
import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import com.sc.csl.retail.core.tsp.model.HighRiskTokenValidateDto;
import com.sc.csl.retail.core.tsp.model.SoftTokenValidateDto;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Data;

@Data
public class ChallengeCodeService {

    private static ChallengeCodeService _challengeCodeService = new ChallengeCodeService();

    private CSLRequestContext cslRequestContext;

    private ChallengeCodeGateway challengeCodeGateway;

    private ChallengeCodeService(){};

    public static ChallengeCodeService getInstance() {
         return _challengeCodeService;
    }


   public ChallengeCode postForChallengeCode(ChallengeCode challengeCode){
        return challengeCodeGateway.postForChallengeCode(challengeCode);
    }
    public SoftTokenValidateDto postForChallengeCodeValidation(SoftTokenValidateDto softTokenValidateDto){
        return challengeCodeGateway.postForChallengeCodeValidation(softTokenValidateDto);
    }
    public HighRiskTokenValidateDto postForHighRiskTransaction(HighRiskTokenValidateDto highRiskTokenValidateDto){
        return challengeCodeGateway.postForHighRiskTransaction(highRiskTokenValidateDto);
    }

}
