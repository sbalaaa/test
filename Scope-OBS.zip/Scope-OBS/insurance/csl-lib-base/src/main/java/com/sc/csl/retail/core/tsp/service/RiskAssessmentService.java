package com.sc.csl.retail.core.tsp.service;

import com.sc.csl.retail.core.tsp.gateway.RiskAssessmentGateway;
import com.sc.csl.retail.core.tsp.model.RiskAssessmentDto;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Data;

@Data
public class RiskAssessmentService  {

    private static RiskAssessmentService _riskAssessmentService = new RiskAssessmentService();

    private CSLRequestContext cslRequestContext;

    private RiskAssessmentGateway riskAssessmentGateway;

    private RiskAssessmentService(){};

    public static RiskAssessmentService getInstance() {
         return _riskAssessmentService;
    }

    public RiskAssessmentDto getRiskAssessmentAuthLevel(String riskCode){
       return riskAssessmentGateway.getRiskAssessmentAuthLevel(riskCode);
    }
}
