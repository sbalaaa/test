package com.sc.csl.retail.core.util;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.ErrorCode;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.Map;

public abstract class CSLAssert {

    public static void isTrue(boolean expression, ErrorCode errorCode) {
        if (!expression) {
            throw new BusinessException(errorCode);
        }
    }

    public static void isNull(Object object, ErrorCode errorCode) {
        if (object != null) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notNull(Object object, ErrorCode errorCode) {
        if (object == null) {
            throw new BusinessException(errorCode);
        }
    }

    public static void hasLength(String text, ErrorCode errorCode) {
        if (!StringUtils.hasLength(text)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void hasText(String text, ErrorCode errorCode) {
        if (!StringUtils.hasText(text)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void doesNotContain(String textToSearch, String substring, ErrorCode errorCode) {
        if (StringUtils.hasLength(textToSearch) && StringUtils.hasLength(substring) &&
                textToSearch.contains(substring)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void doesContain(String textToSearch, String substring, ErrorCode errorCode) {
        if (!(StringUtils.hasLength(textToSearch) && StringUtils.hasLength(substring) &&
                textToSearch.matches(substring))) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notEmpty(Object[] array, ErrorCode errorCode) {
        if (ObjectUtils.isEmpty(array)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notEmpty(Collection<?> collection, ErrorCode errorCode) {
        if (CollectionUtils.isEmpty(collection)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void notEmpty(Map<?, ?> map, ErrorCode errorCode) {
        if (CollectionUtils.isEmpty(map)) {
            throw new BusinessException(errorCode);
        }
    }

    public static void regexMatcher(String value, String regex, ErrorCode errorCode) {
        if(!value.matches(regex)){
            throw new BusinessException(errorCode);
        }
    }

}
