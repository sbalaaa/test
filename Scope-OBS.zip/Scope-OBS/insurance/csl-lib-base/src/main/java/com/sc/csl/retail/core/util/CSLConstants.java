package com.sc.csl.retail.core.util;

import org.springframework.util.backoff.FixedBackOff;

import static java.lang.Integer.MIN_VALUE;

public class CSLConstants {
    public static final String CSL_REQUEST_ID = "requestId";
    public static final String CSL_SESSION_ID = "sessionId";

    public static final String CSL_USER = "csl_user";
    public static final String CSL_HEADER = "csl_header";
    public static final String CSL_USER_INFO = "csl-user-info";
    public static final String TRUE_CLIENT_IP = "True-Client-IP";
    public static final String SC_CLIENT_CONTEXT = "SC-CLIENT-CONTEXT";
    public static final String CALLER_SERVICE_NAME = "CALLER-SERVICE-NAME";
    public static final String CSL_TRACKING_ID_HEADER = "CSL-TRACKING-ID";
    public static final String CSL_SOFTTOKEN = "csl-softToken";

    public static final String CSL_REQUEST_CONTEXT = "CSL-REQUEST-CONTEXT";
    public static final String CSL_CORRELATION_ID = "CSL-CORRELATION-ID";

    public static final String CSL_INTERNAL_ACCESS_TOKEN = "csl_iat";
    public static final String CSL_INTERNAL_ACCESS_TOKEN_STRING = "csl_iat_str";

    public static final String OTP_HEADER = "OTP";
    public static final String TMX_SESSION_ID_HEADER = "TMX-SESSION-ID";
    public static final String NO_TMX_SESSION_ID_MESSAGE = "TMX Session ID should not be empty.";
    public static final String OBJECT_FACTORY_CLASS ="ObjectFactory";
    public static final FixedBackOff DEFAULT_BACK_OFF = new FixedBackOff(15000L, 100);

    public static final String CSL_ACCESS_TOKEN = "CSL-ACCESS-TOKEN";
    public static final String CSL_REFRESH_TOKEN = "CSL-REFRESH-TOKEN";
    public static final String OTP_ENCODED = "encoded_otp";
    public static final String OTP_SERIAL_NUMBER = "otp_sn";
    public static final String OTP_PURPOSE = "purpose";
    public static final String OTP_KEY_INDEX = "key_index";
    public static final String VAL_ENCODED = "encoded_val";
    public static final String OTP_TYPE_PARAM = "otp_type";
    public static final String MPIN_OTP_TYPE = "MPIN_OTP_TYPE";
    public static final String TYPE = "type";

    //Claims
    public static final String OPERATOR_ID_CLAIM = "operator_id";
    public static final String OPERATOR_TYPE_CLAIM = "operator_type";
    public static final String REL_ID_CLAIM = "rel_id";
    public static final String UAAS2_ID_CLAIM = "uaas2_id";
    public static final String CHANNEL_CLAIM = "channel";
    public static final String COUNTRY_CLAIM = "country";
    public static final String LANGUAGE_CLAIM = "language";
    public static final String LANGUAGE_HEADER = "Language";
    public static final String LOCALE = "Locale";
    public static final String SEGMENT_CODE_CLAIM = "segment_code";
    public static final String AUTH_LEVEL_CLAIM = "auth_level";
    public static final String AUTH_LEVEL_NAME_CLAIM = "auth_level_name";
    public static final String JSESSION_ID_CLAIM = "jsession_id";
    public static final String PREFERRED_OTP_TYPE_CLAIM = "preferred_otp_type";
    public static final String IS_CC_LOGIN_CLAIM = "isCCLogin";
    public static final String CSL_TRACKING_ID_CLAIM = "csl_tracking_id";

    //Filter priorities
    public static final int REQUEST_FILTER_PRIORITY = MIN_VALUE;
    public static final int AUTH_FILTER_PRIORITY = MIN_VALUE + 1;
    public static final int CONTEXT_FILTER_PRIORITY = MIN_VALUE + 2;

    //Revocation
    public static final String TOKEN_KEY = "token";
    public static final String SUBJECT_ID_TOKEN_HINT = "subject_id";

    //OTP types
    public static final String PREFERRED_TYPE_SOFT_TOKEN = "ST";
    public static final String PREFERRED_TYPE_SMS = "SMS";

    //Others
    public static final String CSL_TRACKING_ID_MDC =  "cslTrackingId";

    //MPIN related
    public static final String MPIN_REGISTER_PURPOSE = "8";
    public static final String MPIN_RESET_PURPOSE = "9";
    public static final String MPIN_PASSWORD_TYPE = "2";

    public static final String COUNTRY_CODE_SG = "SG";
    public static final String COUNTRY_CODE_HK = "HK";
    public static final String COUNTRY_CODE_MY = "MY";
    //TSP related constants
    public static final String OFFLINE = "OFFLINE";
    public static final String ONLINE = "ONLINE";
    public static final String PRIMARY_DEVICE  = "PRIMARY_DEVICE";
    public static final String APPLICATION_CODE = "CSL";
    public static final String VALIDATED = "VALIDATED";
    public static final String UTF_8 = "UTF-8";
    public static final String DEVICE_MODE = "device_mode";
    public static final String CHALLENGE_CODE = "challenge_code";
}
