package com.sc.csl.retail.core.util;

import com.sc.csl.retail.core.exception.TechnicalException;
import lombok.AccessLevel;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import static org.apache.commons.lang3.StringUtils.isBlank;

public class CSLDateTimeUtils {
	private static final DateTimeFormatter DEFAULT_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private static final String DEFAULT_COUNTRY_DATE_TIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
	private static final String DEFAULT_TIME_STRING = "00:00:00";
	private static final String SINGLE_SPACE = " ";

	private static final Map<String, ZoneId> countryZoneIdMap = new HashMap<>();
	private static CSLDateTime cslDateTime = new CSLDateTime();

	public static class CSLDateTime {
		CSLDateTime() {
		}

		String dateTimeAsString(String countryCode) {
			return dateTimeAsString(countryCode, DEFAULT_FORMATTER);
		}

		String dateTimeAsString(String countryCode, DateTimeFormatter formatter) {
			LocalDateTime localDateTime = localDateTime(countryCode);
			return formatter.format(localDateTime);
		}

		Timestamp timestamp(String countryCode) {
			LocalDateTime localDateTime = localDateTime(countryCode);
			return Timestamp.valueOf(localDateTime);
		}

		LocalDateTime localDateTime(String countryCode) {
			ZoneId zoneId = zoneId(countryCode);
			Clock clock = clock(zoneId);
			return LocalDateTime.now(clock);
		}

		Clock clock(ZoneId zoneId) {
			return Clock.system(zoneId);
		}

		ZoneId zoneId(String countryCode) {
			if(!countryZoneIdMap.containsKey(countryCode))
				throw new TechnicalException("Country mapping not available for DateTime conversion");

			return countryZoneIdMap.get(countryCode);
		}

		Date countrySpecificDate(String dateString, String timeString, String countryCode) {
			try {
				if(isBlank(timeString)) {
					timeString = DEFAULT_TIME_STRING;
				}
				SimpleDateFormat dateFormatter = new SimpleDateFormat(DEFAULT_COUNTRY_DATE_TIME_FORMAT);
				TimeZone timeZone = TimeZone.getTimeZone(zoneId(countryCode));
				dateFormatter.setTimeZone(timeZone);
				return dateFormatter.parse(dateString.concat(SINGLE_SPACE).concat(timeString));
			}
			catch (ParseException pe) {
				throw new TechnicalException("Exception in Parsing the Date : Expected Date format yyyy/MM/dd and Time format HH:mm:ss");
			}
		}

		Date countrySpecificDate(String dateString, String countryCode) {
			return countrySpecificDate(dateString, null, countryCode);
		}
	}

	public static class TestCSLDateTime extends CSLDateTime {
		@Override
		protected Clock clock(ZoneId zoneId) {
			return new TestClock(zoneId);
		}
	}

	static class TestClock extends Clock implements Serializable {
		private final ZoneId zone;

		TestClock(ZoneId zone) {
			this.zone = zone;
		}

		@Override
		public ZoneId getZone() {
			return zone;
		}

		@Override
		public Clock withZone(ZoneId zone) {
			if (zone.equals(this.zone)) {  // intentional NPE
				return this;
			}
			return new TestClock(zone);
		}

		@Override
		public long millis() {
			return currentTimeMillis();
		}

		@Override
		public Instant instant() {
			return Instant.ofEpochMilli(millis());
		}
	}

	public static String dateTimeAsString(String countryCode) {
		return cslDateTime.dateTimeAsString(countryCode);
	}

	public static String dateTimeAsString(String countryCode, DateTimeFormatter formatter) {
		return cslDateTime.dateTimeAsString(countryCode, formatter);
	}

	public static Timestamp timestamp(String countryCode) {
		return cslDateTime.timestamp(countryCode);
	}

	public static LocalDateTime localDateTime(String countryCode) {
		return cslDateTime.localDateTime(countryCode);
	}

	public static ZoneId zoneId(String countryCode) {
		return cslDateTime.zoneId(countryCode);
	}

	private static long currentTimeMillis() {
		return currentTimeMillis;
	}

	public static void freezeTime(Instant instant) {
		setCurrentTimeMillis(instant.toEpochMilli());
		cslDateTime = new TestCSLDateTime();
	}

	public static void unFreezeTime() {
		cslDateTime = new CSLDateTime();
	}

	public static Date countrySpecificDateTime(String dateString, String timeString, String countryCode) {
		return cslDateTime.countrySpecificDate(dateString, timeString, countryCode);
	}

	public static Date countrySpecificDateTime(String dateString, String countryCode) {
		return cslDateTime.countrySpecificDate(dateString, countryCode);
	}

	@Setter(AccessLevel.PRIVATE)
	private static long currentTimeMillis;

	static {
		countryZoneIdMap.put("HK", ZoneId.of("Hongkong"));
		countryZoneIdMap.put("SG", ZoneId.of("Singapore"));

		countryZoneIdMap.put("MY", ZoneId.of("Asia/Kuala_Lumpur"));
		countryZoneIdMap.put("CN", ZoneId.of("Asia/Shanghai"));
		countryZoneIdMap.put("VN", ZoneId.of("Asia/Ho_Chi_Minh"));

		countryZoneIdMap.put("IN", ZoneId.of("Asia/Calcutta"));
		countryZoneIdMap.put("AF", ZoneId.of("Asia/Kabul"));
		countryZoneIdMap.put("PK", ZoneId.of("Asia/Karachi"));
		countryZoneIdMap.put("AE", ZoneId.of("Asia/Dubai"));

		countryZoneIdMap.put("CI", ZoneId.of("Africa/Abidjan"));
		countryZoneIdMap.put("NG", ZoneId.of("Africa/Lagos"));
		countryZoneIdMap.put("KE", ZoneId.of("Africa/Nairobi"));
		countryZoneIdMap.put("GH", ZoneId.of("Africa/Accra"));
		countryZoneIdMap.put("BW", ZoneId.of("Africa/Gaborone"));
		countryZoneIdMap.put("ZM", ZoneId.of("Africa/Harare"));
		
		countryZoneIdMap.put("BD", ZoneId.of("Asia/Dhaka"));
		countryZoneIdMap.put("BH", ZoneId.of("Asia/Bahrain"));
		countryZoneIdMap.put("ID", ZoneId.of("Asia/Jakarta"));
		countryZoneIdMap.put("BN", ZoneId.of("Asia/Brunei"));
		
	}
}
