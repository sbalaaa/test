package com.sc.csl.retail.core.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.crnk.CSLCrnkClient;
import com.sc.csl.retail.core.exception.CSLJsonProcessingException;
import io.crnk.client.internal.ClientDocumentMapper;
import io.crnk.core.engine.document.Document;
import io.crnk.core.repository.response.JsonApiResponse;
import io.crnk.core.resource.list.DefaultResourceList;

import java.io.IOException;

public class CSLJsonApiUtils {

	private static CSLCrnkClient client = new CSLCrnkClient("", "");
	private static ObjectMapper objectMapper = client.getObjectMapper();
	private static ClientDocumentMapper documentMapper = client.getDocumentMapper();

	public static <T> DefaultResourceList<T> toObject(String jsonApiFormat, Class<T> resource) {
		try {
			client.getRepositoryForType(resource);
			Document document = objectMapper.readValue(jsonApiFormat, Document.class);
			return (DefaultResourceList<T>) documentMapper.fromDocument(document, true);

		} catch (IOException e) {
			throw new CSLJsonProcessingException(e);
		}
	}

	public static <T> String toJsonApiFormat(T resource) {
		try {
			JsonApiResponse response = new JsonApiResponse();
			response.setEntity(resource);

			Document requestDocument = documentMapper.toDocument(response, null);
			return objectMapper.writeValueAsString(requestDocument);

		} catch (JsonProcessingException e) {
			throw new CSLJsonProcessingException(e);
		}
	}
	
}