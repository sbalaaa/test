package com.sc.csl.retail.core.util;

import static com.fasterxml.jackson.databind.DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY;
import static com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES;
import static com.fasterxml.jackson.databind.SerializationFeature.FAIL_ON_EMPTY_BEANS;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.boot.jackson.JsonComponentModule;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.sc.csl.retail.core.exception.CSLJsonProcessingException;

import io.crnk.core.engine.document.ErrorData;
import io.crnk.core.engine.document.ErrorDataBuilder;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CSLJsonUtils {
    private static ObjectMapper objectMapper;
    private static ObjectMapper objectMapperIncludeNulls;

    static {
        objectMapper = objectMapper();
        objectMapperIncludeNulls = objectMapperIncludeNulls();
    }

    private static ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        setDefaultObjectMapperProperties(mapper);
        return mapper;
    }

    private static ObjectMapper objectMapperIncludeNulls() {
        ObjectMapper mapper = new ObjectMapper();
        registerModules(mapper);
        mapper.disable(FAIL_ON_UNKNOWN_PROPERTIES)
              .disable(FAIL_ON_EMPTY_BEANS)
              .enable(ACCEPT_SINGLE_VALUE_AS_ARRAY)
              .disable(MapperFeature.DEFAULT_VIEW_INCLUSION);

        return mapper;
    }

    private static void registerModules(ObjectMapper objectMapper) {
        objectMapper.registerModules(
                new JavaTimeModule(),
                new Jdk8Module(),
                new JsonComponentModule(),
                new ParameterNamesModule()
        );
    }

    public static void setDefaultObjectMapperProperties(ObjectMapper mapper) {
        registerModules(mapper);
        mapper.disable(FAIL_ON_UNKNOWN_PROPERTIES)
                .disable(FAIL_ON_EMPTY_BEANS)
                .enable(ACCEPT_SINGLE_VALUE_AS_ARRAY)
                .addMixIn(Resource.class, ResourceIgnoreNullMixin.class)
                .addMixIn(ErrorData.class, ErrorDataMixin.class)
                .addMixIn(ErrorDataBuilder.class, ErrorDataBuilderMixin.class)
                .setSerializationInclusion(Include.NON_EMPTY)
                .setSerializationInclusion(Include.NON_NULL)
                .disable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    }

    public static ObjectMapper newObjectMapper() {
        return objectMapper();
    }

    public static String toJson(Object object) {
        return toJson(object, false);
    }

    public static String toJson(Object object, boolean includeEmptyAttributes) {
        if(includeEmptyAttributes) {
            return toJson(object, objectMapperIncludeNulls.writer());
        }
        return toJson(object, objectMapper.writer());
    }

    public static String toPrettyJson(Object object) {
        return toJson(object, objectMapper.writerWithDefaultPrettyPrinter());
    }

    public static String toJson(Object object, String dateFormat) {
        return toJson(object, dateFormat, false);
    }

    public static String toJson(Object object, String dateFormat, boolean includeEmptyAttributes) {
        if(includeEmptyAttributes) {
            return toJson(objectMapperIncludeNulls.writer(), object, dateFormat);
        }
        return toJson(objectMapper.writer(), object, dateFormat);
    }

    private static String toJson(ObjectWriter writer, Object object, String dateFormat) {
        writer.with(new SimpleDateFormat(dateFormat));
        return toJson(object, writer);
    }

    public static <V> String toJson(Object jsonObject, Class<V> viewClass) {
        ObjectWriter objectWriter = objectMapper.writerWithView(viewClass);
        try {
            return objectWriter.writeValueAsString(jsonObject);
        } catch (JsonProcessingException e) {
            throw new CSLJsonProcessingException(e);
        }
    }

    public static <T> T parseJson(String jsonString, Class<T> clazz) {
        ObjectReader reader = objectMapper.readerFor(clazz);
        return parseJson(jsonString, reader);
    }

    public static <T> T parseJson(String jsonString, TypeReference<T> typeReference) {
        ObjectReader reader = objectMapper.reader().forType(typeReference);
        return parseJson(jsonString, reader);
    }

    public static <T> T parseJson(String jsonString, Class<T> clazz, String dateFormat) {
        ObjectReader reader = objectMapper.readerFor(clazz);
        DeserializationConfig newConfig = reader.getConfig().with(new SimpleDateFormat(dateFormat));
        reader.with(newConfig);

        return parseJson(jsonString, reader);
    }

    private static String toJson(Object object, ObjectWriter writer) {
        try {
            return writer.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new CSLJsonProcessingException(e);
        }
    }

    private static <T> T parseJson(String jsonString, ObjectReader reader) {
        try {
            return reader.readValue(jsonString);
        } catch (IOException e) {
            throw new CSLJsonProcessingException(e);
        }
    }

    public static <T> T convertValue(Map<Object, Object> map, Class<T> clazz) {
        return objectMapper.convertValue(map, clazz);
    }
    
    public static <T> T convertValue(Object fromValue, Class<T> toValueType) {
        return objectMapper.convertValue(fromValue, toValueType);
    }

    public static JsonNode getNodeValue(JsonNode rootNode, String path) {
        if (rootNode == null) return MissingNode.getInstance();
        JsonNode node = rootNode;
        String[] nodes = path.split("/");
        for (int i = 0; i < nodes.length; i++) {
            node = node.findPath(nodes[i]);
            if (node.isMissingNode()) break;
        }

        return node;
    }

    public static void appendNodeValues(JsonNode rootNode, Map<String, Object> valuesMap, String path) {
        JsonNode node = getNodeValue(rootNode, path);
        if (node.isObject()) {
            ObjectNode objectNode = (ObjectNode) node;
            valuesMap.forEach((k, v) -> {
                String value = v != null ? v.toString() : "";
                objectNode.put(k, value);
            });
        }
    }
}