package com.sc.csl.retail.core.util;

public class CSLLogConstants {
    public static final String HTTP_METHOD = "httpMethod";
    public static final String HTTP_STATUS = "httpStatus";
    public static final String REQUEST_URI = "requestURI";
    public static final String QUERY_STRING = "queryString";
    public static final String TIME_TAKEN_IN_MILLIS = "timeTakenInMillis";

    public static final String CSL_ERROR_RESPONSE = "cslErrorResponse";
    public static final String METHOD_SIGNATURE = "methodSignature";
    public static final String PERFORMANCE_METRIC = "performanceMetric";

    public static final String REQUEST_TIME_TAKEN_KEY = "RequestTimeTaken";
    public static final String LOG_TIME_TAKEN_KEY = "LogTimeTaken";
    public static final String SOAP_TIME_TAKEN_KEY = "SoapTimeTaken";
    public static final String REST_TIME_TAKEN_KEY = "RestTimeTaken";
}
