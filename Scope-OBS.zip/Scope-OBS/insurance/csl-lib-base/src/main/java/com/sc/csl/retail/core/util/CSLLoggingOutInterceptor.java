package com.sc.csl.retail.core.util;

import org.apache.cxf.interceptor.LoggingOutInterceptor;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class CSLLoggingOutInterceptor extends LoggingOutInterceptor {
	@Override
	protected void log(Logger logger, String message) {
		message = transform(message);
		if (writer != null) {
			writer.println(message);
			// Flushing the writer to make sure the message is written
			writer.flush();
		} else if (logger.isLoggable(Level.FINE)) {
			LogRecord lr = new LogRecord(Level.FINE, message);
			lr.setSourceClassName(logger.getName());
			lr.setSourceMethodName(null);
			lr.setLoggerName(logger.getName());
			logger.log(lr);
		}
	}
}
