package com.sc.csl.retail.core.util;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.auth.RestrictedAccess;
import com.sc.csl.retail.core.web.RestrictedAccessAspect;
import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import static com.auth0.jwt.JWT.decode;
import static com.sc.csl.retail.core.auth.AccessLevel.NO_AUTHENTICATION;
import static com.sc.csl.retail.core.util.CSLJsonUtils.toJson;

@Slf4j
public class CSLMockTestUtil {
	private static Base64.Encoder encoder = Base64.getEncoder();
	private static Map<String, Object> defaultClaims = new HashMap<>();
	
	static {
		defaultClaims.put("jti", "b66e6299c7beb2fa1998bcfebb9a76");
		defaultClaims.put("client_id", "CEMS");
		final int ISSUED_AT = 1506332125;
		final int EXPIRES_AT = 1506332245;
		defaultClaims.put("iat", ISSUED_AT);
		defaultClaims.put("exp", EXPIRES_AT);
		defaultClaims.put("sub", "1527380");
		defaultClaims.put("username", "1527380");
		defaultClaims.put("iss", "CSL-AUTH");
		defaultClaims.put("aud", "CSL-AUTH");
		defaultClaims.put("grant_type", "client_credentials");
		defaultClaims.put("type", "CSL-IAT");
		defaultClaims.put("auth_level", 1);
		defaultClaims.put("rel_id", "122134138u");
		defaultClaims.put("channel", "CEMS");
		defaultClaims.put("country", "SG");
		defaultClaims.put("language", "en");
		defaultClaims.put("uaas2_id", "user180");
		defaultClaims.put("segment_code", "IT");
		defaultClaims.put("request_id", "7b1ca54e-285a-4ada-b862-f5f75607f578");
	}

	public static RestrictedAccessAspect mockRestrictedAccessAspect() {
		return mockRestrictedAccessAspect(NO_AUTHENTICATION.authLevel());
	}
	
	public static RestrictedAccessAspect mockRestrictedAccessAspect(Map<String, Object> claimsMap) {
		return mockRestrictedAccessAspect(NO_AUTHENTICATION.authLevel(), NO_AUTHENTICATION, "", claimsMap);
	}

	public static RestrictedAccessAspect mockRestrictedAccessAspect(int currentAuthLevel) {
		return mockRestrictedAccessAspect(currentAuthLevel, NO_AUTHENTICATION);
	}
	
	public static RestrictedAccessAspect mockRestrictedAccessAspect(int currentAuthLevel, AccessLevel requiredAccessLevel) {
		return mockRestrictedAccessAspect(currentAuthLevel, requiredAccessLevel, "", null);
	}

	public static RestrictedAccessAspect mockRestrictedAccessAspect(int currentAuthLevel,
																	AccessLevel requiredAccessLevel,
																	String mpinPurpose,
																	Map<String, Object> customClaimsMap) {
		return new RestrictedAccessAspect() {
			@Override
			public DecodedJWT getInternalAccessToken() {
				Map<String, Object> claimsMap = customClaimsMap;
				if(claimsMap == null) {
					claimsMap = new HashMap<>(defaultClaims);
				}
				claimsMap.put("auth_level", currentAuthLevel);
				return decode(jwtStr(claimsMap));
			}

			@Override
			public AccessLevel requiredAccessLevel(RestrictedAccess annotation) {
				return requiredAccessLevel;
			}

			@Override
			public String mpinPurpose(RestrictedAccess annotation) {
				return mpinPurpose;
			}
		};
	}

	public static Instant dateTimeInstant(LocalDate date, int hour, int minute) {
		return instant(defaultTimeZone(), hour, minute, date);
	}

	public static Instant timeInstant(int hour, int minute) {
		return instant(defaultTimeZone(), hour, minute, LocalDate.now());
	}

	private static Instant instant(TimeZone timeZone, int hour, int minute, LocalDate date) {
		LocalTime currentTime = LocalTime.of(hour, minute, 0);
		ZonedDateTime dateTime = ZonedDateTime.of(date, currentTime, timeZone.toZoneId());

		log.info("Freezing time at : {}", dateTime);
		return dateTime.toInstant();
	}

	private static TimeZone defaultTimeZone() {
		return TimeZone.getTimeZone("Singapore");
	}

	private static String jwtStr(Map<String, Object> claimsMap) {
		return TEST_TOKEN_HEADER
				+ "." + (claimsMap.isEmpty()  ?  encodeJWT(defaultClaims) : encodeJWT(claimsMap))
				+ "." + TEST_TOKEN_SIGNATURE;
	}
	
	private static String encodeJWT(Map<String, Object> claimsMap) {
		String json = toJson(claimsMap);
		return encoder.encodeToString(json.getBytes());
	}

	private static String TEST_TOKEN_HEADER = "eyJhbGciOiJSUzI1NiJ9";
	private static String TEST_TOKEN_SIGNATURE = "pPH4IzLCHKleSwD7P_y5_n1ryAr6MNS1-xHdm2mlGtzuyyDFQ4EFtZJ0lQ"
			+ "WDIgyuNS7aX5uF6z-Q6nTXLxIlf_m0FfQ9yh"
			+ "asc--2GjVPLTknK-pJDK0-bcFUbz2D-YU53lv8SGFDF3UH7kDb1GKqschD1oQf1Ocws9OyH71e678G7fPmrfCRgKFo1Ir4p"
			+ "X1JYUtYnsMepUl2J9yQOaq_4advcDXfqGpqX3TVUymTzXQNRO5TgpTV6qpc9zOJ86gPXZ_YzRBXJ7EvkhEVxX8DKwRpbwFs"
			+ "JfuRRFPz01hZJbCkVHDUh21rRtXJrpTFfPTzNRW0KH1iYcQ538C7j5v07w";
}
