package com.sc.csl.retail.core.util;

import com.sc.csl.retail.core.exception.CSLXmlProcessingException;

import javax.xml.bind.*;
import javax.xml.transform.stream.StreamSource;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

public class CSLXmlUtils {
	private static Map<String, JAXBContext> jaxbContextCache = new HashMap<>();

	public static <T> T toObject(String xml, Class<T> clazz) {
		try {
			JAXBContext jc = jaxbContext(clazz);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			StreamSource streamSource = new StreamSource(new StringReader(xml));
			JAXBElement<T> jaxbElement = unmarshaller.unmarshal(streamSource, clazz);
			return jaxbElement.getValue();
		}
	 	catch (JAXBException ex) {
			throw new CSLXmlProcessingException(ex);
		}
	}

	public static <T> String toXml(T object) {
		try {
			JAXBContext jc = jaxbContext(object.getClass());
			Marshaller marshaller = jc.createMarshaller();
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(object, stringWriter);

			return stringWriter.toString();
		}
	 	catch (JAXBException ex) {
			throw new CSLXmlProcessingException(ex);
		}
	}

	public static <T> JAXBContext jaxbContext(Class<T> clazz) {
		try {
			JAXBContext jaxbContext = jaxbContextFromCache(clazz);
			if(jaxbContext == null) {
				jaxbContext = createJaxbContext(clazz);
			}
			return jaxbContext;
		}
		catch (JAXBException ex) {
			throw new CSLXmlProcessingException(ex);
		}
	}

	static <T> JAXBContext createJaxbContext(Class<T> clazz) throws JAXBException {
		JAXBContext jaxbContext;
		try{
			String contextPath = clazz.getPackage().getName();
			Class.forName(contextPath + "." + CSLConstants.OBJECT_FACTORY_CLASS);
			jaxbContext = jaxbContextForPackage(contextPath);
		}
		catch(ClassNotFoundException cnf) {
			jaxbContext = jaxbContextForClass(clazz);
		}
		return jaxbContext;
	}

	static <T> JAXBContext jaxbContextForClass(Class<T> clazz) throws JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
		jaxbContextCache.put(clazz.getName(), jaxbContext);
		return jaxbContext;
	}

	static <T> JAXBContext jaxbContextForPackage(String contextPath) throws ClassNotFoundException, JAXBException {
		JAXBContext jaxbContext = JAXBContext.newInstance(contextPath);
		jaxbContextCache.put(contextPath, jaxbContext);
		return jaxbContext;
	}

	static <T> JAXBContext jaxbContextFromCache(Class<T> clazz) {
		JAXBContext jaxbContext = jaxbContextCache.get(clazz.getPackage().getName());
		if( jaxbContext == null) {
			jaxbContext = jaxbContextCache.get(clazz.getName());
		}
		return jaxbContext;
	}
}