package com.sc.csl.retail.core.util;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;

import io.crnk.core.engine.document.ErrorDataBuilder;

@JsonDeserialize(builder = ErrorDataBuilder.class)
interface ErrorDataMixin {}

@JsonPOJOBuilder(withPrefix = "set")
interface ErrorDataBuilderMixin {}
