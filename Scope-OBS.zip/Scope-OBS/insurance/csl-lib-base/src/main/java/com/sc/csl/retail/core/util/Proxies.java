package com.sc.csl.retail.core.util;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;

@Slf4j
public class Proxies {
    private static final int DEFAULT_TIMEOUT = 5000;

    @Setter
    private int timeoutInMillis = DEFAULT_TIMEOUT;
    private List<Proxy> proxyList = new ArrayList<>();
    private Proxy lastKnow;

    public Proxies(List<String> proxies) {
        try {
            proxies.forEach(proxyStr -> {
                log.info("Adding {} to proxy list", proxyStr);
                String[] splits = proxyStr.split(":");
                InetSocketAddress inetSocketAddress = new InetSocketAddress(splits[0], parseInt(splits[1]));
                proxyList.add(new Proxy(Proxy.Type.HTTP, inetSocketAddress));
            });

            if(proxyList.isEmpty()) {
                throw new IllegalArgumentException("Specify at least one proxy in the format 'ip_address:port', ex: 10.65.1.33:8080");
            }
            lastKnow = proxyList.get(0);
        } catch (Exception e) {
            log.error("Failed to initialize proxy list with input {}", proxies);
            throw new IllegalArgumentException("Proxies must be in the format 'ip_address:port', ex: 10.65.1.33:8080");
        }
    }

    public Proxy nextAvailableProxy() {
        if(isAvailable(lastKnow)) {
            return lastKnow;
        }

        for (Proxy proxy: proxyList) {
            if(!proxy.equals(lastKnow) && isAvailable(proxy)) {
                return proxy;
            }
        }

        throw new RuntimeException("Not able to connect to any of the proxy in the list : " + proxyList);
    }

    boolean isAvailable(Proxy proxy) {
        SocketAddress socketAddress = proxy.address();
        try (Socket socket = new Socket()) {
			log.warn("Testing proxy : {}", socketAddress);
			socket.connect(socketAddress, timeoutInMillis);
			return true;
		} catch (Exception e) {
            log.warn("Proxy {} is not reachable. Error : {}", proxy, e.getMessage());
            return false;
		}
    }
}