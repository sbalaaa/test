package com.sc.csl.retail.core.util;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;

import io.crnk.core.engine.document.Relationship;

public interface ResourceIgnoreNullMixin {
	@JsonInclude(value = JsonInclude.Include.NON_NULL, content = JsonInclude.Include.NON_NULL)
	Map<String, JsonNode> getAttributes();

	@JsonInclude(value = JsonInclude.Include.NON_NULL, content = JsonInclude.Include.NON_NULL)
	Map<String, Relationship> getRelationships();
}
