package com.sc.csl.retail.core.util;

import javax.transaction.Transactional;

import org.springframework.scheduling.annotation.Async;

public class TaskRepository {
	
	@Async
	@Transactional
	public void methodAsync() {
		
	}

}
