package com.sc.csl.retail.core.web;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.DeclarePrecedence;

@Aspect
@DeclarePrecedence("RestrictedAccessAspect, TmxEnabledAspect, *")
public class AspectProcessingOrder {
}
