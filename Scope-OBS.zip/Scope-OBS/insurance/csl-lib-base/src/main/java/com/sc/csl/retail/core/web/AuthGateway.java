package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.core.exception.CSLOTPErrorCode;
import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.UnauthorizedException;
import com.sc.csl.retail.core.gateway.CSLRestGateway;
import com.sc.csl.retail.core.model.*;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.ErrorData;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import sun.security.rsa.RSAPublicKeyImpl;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.Response;
import java.security.InvalidKeyException;
import java.security.interfaces.RSAPublicKey;
import java.util.List;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.OTP_SEND_FAILED;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.OTP_VALIDATION_FAILED;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.TOKEN_INVALID;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static com.sc.csl.retail.core.web.HttpUtil.isErrorResponse;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Slf4j
public class AuthGateway extends CSLRestGateway {
    private final static AuthGateway instance = new AuthGateway();

    private final static String INTROSPECT_ENDPOINT = "/oauth2/introspect";
    private final static String TOKEN_ENDPOINT = "/oauth2/token";
    private final static String REVOKE_ENDPOINT = "/oauth2/revoke";

    private final static String PUBLIC_KEY_ENDPOINT = "/auth/keys/public";
    private final static String SEND_SMS_OTP_ENDPOINT = "/auth/otp/sms";
    private static final String VALIDATE_OTP_ENDPOINT = "/auth/otp/validate";
    private static final String VALIDATE_OTP_MANAGE_MPIN_ENDPOINT = "/auth/otp/validate-otp-mpin";

    private final static String CLIENT_ID = "MOBILE_BANKING";
    private AuthPublicKey authPublicKey;

    private AuthGateway() {
        this.isScbInternal = true;
    }

    public Response revokeTokens(String subjectId) {
        log.info("About to revoke tokens for subjectId : {}", subjectId);
        Form form = new Form();
        
        if(isNotBlank(subjectId)) form.param(CSLConstants.TOKEN_KEY, subjectId);
        form.param(OAuthConstants.CLIENT_ID, CLIENT_ID);
        form.param(OAuthConstants.TOKEN_TYPE_HINT, SUBJECT_ID_TOKEN_HINT);

        return postForm(form, REVOKE_ENDPOINT);
    }
    
    CSLTokenResponse validateOtp(SmsOtpValidation smsOtpValidation) {
        ThreadLocalStore localStore = ThreadLocalStore.getInstance();
        CSLRequestContext requestContext = localStore.getRequestContext();

        Form form = new Form();
        form.param(OTP_ENCODED, smsOtpValidation.getEncOtp());
        form.param(OTP_SERIAL_NUMBER, smsOtpValidation.getOtpSn());
        form.param(OTP_PURPOSE, smsOtpValidation.getPurpose());
        form.param(OTP_KEY_INDEX, smsOtpValidation.getKeyIndex());

        form.param(REL_ID_CLAIM, requestContext.getRelId());
        form.param(UAAS2_ID_CLAIM, requestContext.getUaas2id());
        form.param(COUNTRY_CLAIM, requestContext.getCountry());
        form.param(LANGUAGE_CLAIM, requestContext.getLanguage());
        form.param(CHANNEL_CLAIM, requestContext.getChannel());
        form.param(SEGMENT_CODE_CLAIM, requestContext.getSegmentCode());
        String jSessionId = localStore.getJSessionId();
        if(jSessionId != null) form.param(JSESSION_ID_CLAIM, jSessionId);

        form.param(OAuthConstants.CLIENT_ID, CLIENT_ID);
        form.param(OAuthConstants.GRANT_TYPE, "otp");
        form.param(OAuthConstants.SCOPE, OAuthConstants.REFRESH_TOKEN_SCOPE);
        Response response = postForm(form, TOKEN_ENDPOINT);
        throwExceptionOnOAuthError(response, OTP_VALIDATION_FAILED);

        return response.readEntity(CSLTokenResponse.class);
    }

    CSLTokenResponse validateOtpAndMpin(SmsOtpValidation smsOtpValidation) {
        ThreadLocalStore localStore = ThreadLocalStore.getInstance();
        CSLRequestContext requestContext = localStore.getRequestContext();

        Form form = new Form();
        form.param(OTP_ENCODED, smsOtpValidation.getEncOtp());
        form.param(OTP_SERIAL_NUMBER, smsOtpValidation.getOtpSn());
        form.param(OTP_PURPOSE, smsOtpValidation.getPurpose());
        form.param(OTP_KEY_INDEX, smsOtpValidation.getKeyIndex());
        form.param(VAL_ENCODED,smsOtpValidation.getEncValue());
        form.param(OTP_TYPE_PARAM,MPIN_OTP_TYPE);
        form.param(TYPE,smsOtpValidation.getType());
        form.param(REL_ID_CLAIM, requestContext.getRelId());
        form.param(UAAS2_ID_CLAIM, requestContext.getUaas2id());
        form.param(COUNTRY_CLAIM, requestContext.getCountry());
        form.param(LANGUAGE_CLAIM, requestContext.getLanguage());
        form.param(CHANNEL_CLAIM, requestContext.getChannel());
        form.param(SEGMENT_CODE_CLAIM, requestContext.getSegmentCode());
        String jSessionId = localStore.getJSessionId();
        if(jSessionId != null) form.param(JSESSION_ID_CLAIM, jSessionId);

        form.param(OAuthConstants.CLIENT_ID, CLIENT_ID);
        form.param(OAuthConstants.GRANT_TYPE, "otp");
        form.param(OAuthConstants.SCOPE, OAuthConstants.REFRESH_TOKEN_SCOPE);
        Response response = postForm(form, TOKEN_ENDPOINT);
        throwExceptionOnOAuthError(response, OTP_VALIDATION_FAILED);

        return response.readEntity(CSLTokenResponse.class);
    }
    
    private void throwExceptionOnOAuthError(Response response, ErrorCode defaultErrorCode) {
        if (isErrorResponse(response.getStatus())) {
            String errorDescription;
            String errorCode;
            try {
                CSLOAuthError oAuthError = response.readEntity(CSLOAuthError.class);
                errorCode = oAuthError.getError();
                errorDescription = oAuthError.getErrorDescription();
            }
            catch (ProcessingException ex) {
                errorCode = defaultErrorCode.getCode();
                errorDescription = defaultErrorCode.getDescription();
            }

            log.error("OTP validation failed : response status: {}, errorCode: {}, errorDescription: {}", response.getStatus(), errorCode, errorDescription);
            CSLOTPErrorCode otpErrorCode = new CSLOTPErrorCode(errorCode, errorDescription, errorDescription);
            throw new UnauthorizedException(otpErrorCode);
        }
    }

    SmsOtpFields validateOtpWithoutToken(SmsOtpFields smsOtpFields) {
        Response response = this.post(smsOtpFields, VALIDATE_OTP_ENDPOINT);
        throwExceptionOnHttpError(response, OTP_VALIDATION_FAILED);

        return response.readEntity(SmsOtpFields.class);
    }
    
    SmsOtpFields validateOtpAndMpinWithoutToken(SmsOtpFields mobilePin) {
        Response response = this.post(mobilePin, VALIDATE_OTP_MANAGE_MPIN_ENDPOINT);
        throwExceptionOnHttpError(response, OTP_VALIDATION_FAILED);

        return response.readEntity(SmsOtpFields.class);
    }

    String getInternalAccessToken(String accessToken) {
        Form form = new Form();
        form.param(OAuthConstants.TOKEN_ID, accessToken);
        Response response = postForm(form, INTROSPECT_ENDPOINT);

        if (isErrorResponse(response.getStatus())) {
            log.warn("GetInternalAccessToken failed : {} : {}", response.getStatus(), response.readEntity(String.class));
            throw new TechnicalException("GetInternalAccessToken failed");
        }

        CSLTokenIntrospection tokenIntrospection = response.readEntity(CSLTokenIntrospection.class);

        if (!tokenIntrospection.isActive()) {
            throw new UnauthorizedException(TOKEN_INVALID);
        }

        log.info("Internal access token successfully obtained from auth-service");
        return tokenIntrospection.getInternalAccessToken();
    }

    SmsOtp sendOtp(OTPRequest otpRequest) {
        Response response = post(otpRequest, SEND_SMS_OTP_ENDPOINT);
        throwExceptionOnHttpError(response, OTP_SEND_FAILED);

        SmsOtp smsOTP = response.readEntity(SmsOtp.class);
        if (!SUCCESS_CODE.equalsIgnoreCase(smsOTP.getStatusCode())) {
            log.warn("Send OTP failed : {}", CSLJsonUtils.toJson(smsOTP));
            throw new UnauthorizedException(OTP_SEND_FAILED);
        }

        log.info("SMS OTP sent successfully");
        return smsOTP;
    }

    private void throwExceptionOnHttpError(Response response, ErrorCode defaultErrorCode) {
        if (isErrorResponse(response.getStatus())) {
            String responseStr = response.readEntity(String.class);
            log.warn("Send OTP failed : Status Code {} : {}", response.getStatus(), responseStr);

            ErrorCode errorCode = defaultErrorCode;
            try {
                Document errorDocument = CSLJsonUtils.parseJson(responseStr, Document.class);
                List<ErrorData> errors = errorDocument.getErrors();
                ErrorData errorData = errors.get(0);
                errorCode = new CSLOTPErrorCode(errorData.getCode(), errorData.getTitle(), errorData.getDetail());
            }
            catch (Exception ex) {
                log.warn("Error determining the ErrorCode : {}", ex.getMessage());
            }

            throw new UnauthorizedException(errorCode);
        }
    }

    public DecodedJWT validateInternalAccessToken(String accessToken) {
        try {
            byte[] keyBytes = getPublicKey();
            RSAPublicKey publicKey = new RSAPublicKeyImpl(keyBytes);
            return HttpUtil.validateInternalAccessToken(accessToken, publicKey);
        }
        catch (InvalidKeyException e) {
            throw new TechnicalException("Invalid RSA public key for Internal Token Validation", e);
        }
    }

    public byte[] getPublicKey() {
        if(authPublicKey != null) {
            return authPublicKey.getEncoded();
        }

        Response response = get(PUBLIC_KEY_ENDPOINT);
        if (isErrorResponse(response.getStatus())) {
            throw new TechnicalException("Error getting the auth-service public key");
        }

        authPublicKey = response.readEntity(AuthPublicKey.class);
        return authPublicKey.getEncoded();
    }

    private static String SUCCESS_CODE = "100";

    public static AuthGateway getInstance() {
        return instance;
    }
}

@Data
@NoArgsConstructor
class AuthPublicKey {
    private String algorithm;
    private String format;
    private byte[] encoded;
}

@Data
class CSLTokenIntrospection {
    private boolean active;
    private String scope;
    @JsonProperty("client_id")
    private String clientId;
    private String username;
    @JsonProperty("token_type")
    private String tokenType;
    private Long iat;
    private Long exp;
    private Long nbf;
    private String sub;
    private List<String> aud;
    private String iss;
    private String jti;

    @JsonProperty("csl_iat")
    private String internalAccessToken;
}

@Data
class CSLTokenResponse {

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("token_type")
    private String tokenType;

    @JsonProperty("expires_in")
    private Long expiry;

    private String scope;

    @JsonProperty("refresh_token")
    private String refreshToken;
}
