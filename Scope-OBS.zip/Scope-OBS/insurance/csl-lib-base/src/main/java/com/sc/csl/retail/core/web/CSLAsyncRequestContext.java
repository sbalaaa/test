package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLUser;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
public class CSLAsyncRequestContext {
	private static ThreadLocalStore threadlocalstore = ThreadLocalStore.getInstance();

	private CSLRequestContext requestContext() {
		return threadlocalstore.getRequestContext();
	}

	public void setRelId(String relId) {
		CSLRequestContext requestContext = requestContext();
		requestContext.setRelId(relId);
		CSLUser cslUser = threadlocalstore.getCslUser();
		cslUser.setRelId(relId);
		requestContext.populateCustomerId();
	}

	public void setCountry(String country) {
		CSLRequestContext requestContext = requestContext();
		requestContext.setCountry(country);
		CSLUser cslUser = threadlocalstore.getCslUser();
		cslUser.setCountry(country);
		requestContext.populateCustomerId();
	}

	public void setLanguage(String language) {
		requestContext().setLanguage(language);
		CSLUser cslUser = threadlocalstore.getCslUser();
		cslUser.setLanguage(language);
	}

	public void setUaas2id(String uaas2id) {
		requestContext().setUaas2id(uaas2id);
		CSLUser cslUser = threadlocalstore.getCslUser();
		cslUser.setUaas2id(uaas2id);
	}

	public void setSegmentCode(String segmentCode) {
		requestContext().setSegmentCode(segmentCode);
		CSLUser cslUser = threadlocalstore.getCslUser();
		cslUser.setSegCd(segmentCode);
	}

	public void setChannel(String channel) {
		requestContext().setChannel(channel);
		CSLClient cslClient = threadlocalstore.getCslHeader().getClient();
		cslClient.setChannel(channel);
	}

	public void setRequestId(String requestId) {
		requestContext().setRequestId(requestId);
		threadlocalstore.setRequestId(requestId);
		CSLClient cslClient = threadlocalstore.getCslHeader().getClient();
		cslClient.setClientRequestId(requestId);
	}

	public String getOperatorId() {
		return requestContext().getOperatorId();
	}
	public String getOperatorType() {
		return requestContext().getOperatorType();
	}
	public String getCustomerId() {
		return requestContext().getCustomerId();
	}
	public String getCustomerType() {
		return requestContext().getCustomerType();
	}
	public String getRelId() {
		return requestContext().getRelId();
	}
	public String getUaas2id() {
		return requestContext().getUaas2id();
	}
	public String getCountry() {
		return requestContext().getCountry();
	}
	public String getChannel() {
		return requestContext().getChannel();
	}
	public String getLanguage() {
		return requestContext().getLanguage();
	}
	public String getSegmentCode() {
		return requestContext().getSegmentCode();
	}
	public String getRequestId() {
		return requestContext().getRequestId();
	}
	public String getSessionId() {
		return requestContext().getSessionId();
	}
	public String getClientId() {
		return requestContext().getClientId();
	}
	public String getPreferredOtpType() {
		return requestContext().getPreferredOtpType();
	}
	public AccessLevel getCurrentAuthLevel() {
		return requestContext().getCurrentAuthLevel();
	}
	public List<String> getRoles() {
		return requestContext().getRoles();
	}
	public String getClientIp() {
		return requestContext().getClientIp();
	}
	public String getRemoteAddress() {
		return requestContext().getRemoteAddress();
	}
	public String getOtpHeader() {
		return requestContext().getOtpHeader();
	}
	public String getTmxSessionId() {
		return requestContext().getTmxSessionId();
	}
	public String getChallengeCodeHeader(){ return requestContext().getChallengeCodeHeader();}
	public String getDeviceMode() {return requestContext().getDeviceMode();}
	@Override
	public String toString() {
		return requestContext().toString();
	}
}
