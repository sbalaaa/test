package com.sc.csl.retail.core.web;

import com.auth0.jwt.exceptions.InvalidClaimException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.UnauthorizedException;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.filter.OncePerRequestFilter;
import sun.security.rsa.RSAPublicKeyImpl;

import javax.annotation.Priority;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.interfaces.RSAPublicKey;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.*;
import static com.sc.csl.retail.core.util.CSLConstants.AUTH_FILTER_PRIORITY;
import static com.sc.csl.retail.core.web.HttpUtil.accessTokenHeader;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.BEARER_TOKEN_TYPE;

@Slf4j
@Priority(AUTH_FILTER_PRIORITY)
public class CSLAuthFilter extends OncePerRequestFilter {
	private ThreadLocalStore threadLocalStore = ThreadLocalStore.getInstance();
	
    @Setter
    @Autowired
    private AuthGateway authGateway;

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        String authHeader = accessTokenHeader(request);

        if(isBlank(authHeader)) {
            chain.doFilter(request, response);
            return;
        }

        String accessToken = accessToken(authHeader);
        String internalAccessToken;
        DecodedJWT iatJwt;
        try {
            iatJwt = validateInternalAccessToken(accessToken);
            internalAccessToken = accessToken;
        }
        catch (InvalidClaimException e) {
            log.debug("Claim mismatch : {}", e.getMessage());
            log.info("Trying to fetch new internal access token");
            internalAccessToken = getInternalAccessToken(accessToken);
            iatJwt = validateInternalAccessToken(internalAccessToken);
        }
        catch (JWTVerificationException e) {
            log.warn("Invalid internal access token : {}", e.getMessage());
            throw new UnauthorizedException(TOKEN_INVALID);
        }

        threadLocalStore.setInternalAccessTokenString(internalAccessToken);
        threadLocalStore.setInternalAccessToken(iatJwt);

        chain.doFilter(request, response);
    }

    private String accessToken(String authHeader) {
        String[] authValues = StringUtils.split(authHeader, " ");

        if(authValues.length < 2) {
            throw new UnauthorizedException(NO_AUTH_SCHEME);
        }

        String tokenType = authValues[0];
        if(!BEARER_TOKEN_TYPE.equalsIgnoreCase(tokenType)) {
            throw new UnauthorizedException(TOKEN_TYPE_NOT_SUPPORTED);
        }
        String accessToken = authValues[1];

        if (isBlank(accessToken)) {
            throw new UnauthorizedException(TOKEN_NOT_FOUND);
        }

        return accessToken;
    }

    protected DecodedJWT validateInternalAccessToken(String accessToken) {
        try {
            byte[] keyBytes = getPublicKey();
            RSAPublicKey publicKey = new RSAPublicKeyImpl(keyBytes);
            return HttpUtil.validateInternalAccessToken(accessToken, publicKey);
        }
        catch (InvalidKeyException e) {
            throw new TechnicalException("Invalid RSA public key for Internal Token Validation", e);
        }
    }

    protected byte[] getPublicKey() {
        return authGateway.getPublicKey();
    }

    protected String getInternalAccessToken(String accessToken) {
        return authGateway.getInternalAccessToken(accessToken);
    }
}