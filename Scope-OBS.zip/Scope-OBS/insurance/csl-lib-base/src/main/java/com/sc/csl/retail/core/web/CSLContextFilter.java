package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.net.HttpHeaders;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLSoftTokenHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.core.web.header.CSLUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.annotation.Priority;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static com.sc.csl.retail.core.util.CSLConstants.CHALLENGE_CODE;
import static com.sc.csl.retail.core.util.CSLConstants.DEVICE_MODE;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Slf4j
@Priority(CONTEXT_FILTER_PRIORITY)
@Component
public class CSLContextFilter extends OncePerRequestFilter {
	private ThreadLocalStore threadLocalStore = ThreadLocalStore.getInstance();

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		HystrixRequestContext hystrixRequestContext = HystrixRequestContext.initializeContext();
		try {
			populateUserContext(request);
			filterChain.doFilter(request, response);
		}
		finally {
			hystrixRequestContext.shutdown();
		}
	}

	void populateUserContext(HttpServletRequest request) {
		DecodedJWT iatJwt = threadLocalStore.getInternalAccessToken();
		CSLRequestContext requestContext;
		String requestId = threadLocalStore.getRequestId();

		if(iatJwt != null) {
			requestContext = new CSLRequestContext(iatJwt, requestId);
			Claim jSessionClaim = iatJwt.getClaim(JSESSION_ID_CLAIM);
			if(!jSessionClaim.isNull()) threadLocalStore.setJSessionId(jSessionClaim.asString());
		}
		else {
			String cslUserStr = request.getHeader(CSL_USER);
			String cslHeaderStr = request.getHeader(CSL_HEADER);
			String sessionId = request.getHeader(CSL_SESSION_ID);
			String cslUserInfoStr = request.getHeader(CSL_USER_INFO);
			String scClientContextStr = request.getHeader(SC_CLIENT_CONTEXT);
			String languageHeader = request.getHeader(LANGUAGE_HEADER);
			String tmxSessionId = request.getHeader(TMX_SESSION_ID_HEADER);
			String cslSoftTokenHeaderStr = request.getHeader(CSL_SOFTTOKEN);
			String locale = request.getHeader(LOCALE);

			CSLUser cslUser = null;
			CSLHeader cslHeader = null;
			CSLUserInfo cslUserInfo = null;
			CSLSoftTokenHeader cslSoftTokenHeader = null;
			if(isNotEmpty(cslUserStr)) cslUser = CSLJsonUtils.parseJson(cslUserStr, CSLUser.class);
			if(isNotEmpty(cslHeaderStr)) cslHeader = CSLJsonUtils.parseJson(cslHeaderStr, CSLHeader.class);
			if(isNotEmpty(cslUserInfoStr)) cslUserInfo = CSLJsonUtils.parseJson(cslUserInfoStr, CSLUserInfo.class);
			if(isNotEmpty(cslSoftTokenHeaderStr)) cslSoftTokenHeader = CSLJsonUtils.parseJson(cslSoftTokenHeaderStr, CSLSoftTokenHeader.class);

			requestContext = new CSLRequestContext(sessionId, requestId, cslUser, cslHeader, languageHeader, cslSoftTokenHeader, locale);
			if (cslUserInfo != null) requestContext.setRoles(cslUserInfo.getRoles());

			threadLocalStore.setLanguageHeader(languageHeader);
			threadLocalStore.setSessionId(sessionId);
			threadLocalStore.setCslUser(cslUser);
			threadLocalStore.setCslHeader(cslHeader);
			threadLocalStore.setCslUserInfo(cslUserInfo);
			threadLocalStore.setSCClientContext(scClientContextStr);
			threadLocalStore.setCSLSoftTokenHeader(cslSoftTokenHeader);
		}

		List<String> xForwardedForList = getXForwardedForList(request);
		requestContext.setClientIp(clientIp(request, xForwardedForList));
		requestContext.setRemoteAddress(remoteAddress(request, xForwardedForList));
		requestContext.setOtpHeader(request.getHeader(OTP_HEADER));
		requestContext.setTmxSessionId(request.getHeader(TMX_SESSION_ID_HEADER));
		requestContext.setChallengeCodeHeader(request.getHeader(CHALLENGE_CODE));
		requestContext.setDeviceMode(request.getHeader(DEVICE_MODE));
		threadLocalStore.setRequestContext(requestContext);
	}

	String clientIp(HttpServletRequest request, List<String> xForwardedForList) {
		String clientIp = request.getHeader(TRUE_CLIENT_IP);

		if (isBlank(clientIp) && xForwardedForList.size() > 0) {
			clientIp = xForwardedForList.get(0);
		}

		return isBlank(clientIp) ? request.getRemoteAddr() : clientIp;
	}

	String remoteAddress(HttpServletRequest request, List<String> xForwardedForList) {
		String remoteAddress = null;

		if(xForwardedForList.size() > 0) {
			remoteAddress = xForwardedForList.get(xForwardedForList.size() - 1);
		}

		return isNotBlank(remoteAddress) ? remoteAddress : request.getRemoteAddr();
	}

	private List<String> getXForwardedForList(HttpServletRequest request) {
		String xForwardedFor = request.getHeader(HttpHeaders.X_FORWARDED_FOR);
		if(isNotBlank(xForwardedFor)) {
			threadLocalStore.setXForwardedFor(xForwardedFor);
			return asList(xForwardedFor.split(","));
		}

		return emptyList();
	}

}
