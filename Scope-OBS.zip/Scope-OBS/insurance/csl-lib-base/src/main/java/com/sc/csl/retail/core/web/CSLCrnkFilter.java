package com.sc.csl.retail.core.web;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.http.entity.ContentType.MULTIPART_FORM_DATA;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import io.crnk.spring.boot.CrnkSpringBootProperties;
import org.springframework.http.HttpHeaders;

import io.crnk.core.boot.CrnkBoot;
import io.crnk.spring.SpringCrnkFilter;

public class CSLCrnkFilter extends SpringCrnkFilter {

    public CSLCrnkFilter(CrnkBoot boot, CrnkSpringBootProperties properties) {
		super(boot, properties);
	}

	@Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        if (req instanceof HttpServletRequest &&
            isExcludedContentType((HttpServletRequest) req)) {
            chain.doFilter(req, res);
            return;
        }

        superDoFilter(req, res, chain);
    }

    void superDoFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        super.doFilter(req, res, chain);
    }

    private boolean isExcludedContentType(HttpServletRequest servletRequest) {
        String contentTypeStr = servletRequest.getHeader(HttpHeaders.CONTENT_TYPE);
        if (isBlank(contentTypeStr)) {
            return false;
        }

        if(MULTIPART_FORM_DATA.getMimeType().equals(contentTypeStr)) {
            return true;
        }
        return false;
    }
}
