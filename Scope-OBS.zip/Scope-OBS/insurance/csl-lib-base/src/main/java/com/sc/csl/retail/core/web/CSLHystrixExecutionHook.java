package com.sc.csl.retail.core.web;

import com.netflix.hystrix.HystrixInvokable;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestContext;
import com.netflix.hystrix.strategy.concurrency.HystrixRequestVariableDefault;
import com.netflix.hystrix.strategy.executionhook.HystrixCommandExecutionHook;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@Slf4j
public class CSLHystrixExecutionHook extends HystrixCommandExecutionHook {
	private static HystrixRequestVariableDefault<Map<String, Object>> hystrixRequestVariable = new HystrixRequestVariableDefault<>();

	static void setHystrixRequestMap(Map<String, Object> objectMap) {
		if(HystrixRequestContext.isCurrentThreadInitialized()) {
			hystrixRequestVariable.set(objectMap);
		}
	}

	@Override
	public <T> void onExecutionStart(HystrixInvokable<T> commandInstance) {
		replaceLocalStore();
		log.debug("onExecutionStart : LocalStore replaced");
	}

	@Override
	public <T> void onFallbackStart(HystrixInvokable<T> commandInstance) {
		replaceLocalStore();
		log.debug("onFallbackStart : LocalStore replaced");
	}

	private void replaceLocalStore() {
		ThreadLocalStore localStore = ThreadLocalStore.getInstance();
		Map<String, Object> objectMap = hystrixRequestVariable.get();
		if(objectMap == null || objectMap.isEmpty()) {
			return;
		}

		localStore.replaceThreadLocalMap(objectMap);
	}
}
