package com.sc.csl.retail.core.web;

import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

import javax.jms.Session;

@Slf4j
public class CSLMessageListenerContainer extends DefaultMessageListenerContainer {

	@Override
	protected void messageReceived(Object invoker, Session session) {
		clearThreadLocal();
		super.messageReceived(invoker, session);
	}

	private void clearThreadLocal() {
		final ThreadLocalStore localStore = ThreadLocalStore.getInstance();
		localStore.clearThreadLocalStore();
		log.debug("ThreadLocalStore cleared");
	}
}
