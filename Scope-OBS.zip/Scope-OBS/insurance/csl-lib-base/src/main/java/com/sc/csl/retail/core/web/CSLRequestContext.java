package com.sc.csl.retail.core.web;

import com.auth0.jwt.impl.NullClaim;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLSoftTokenHeader;
import com.sc.csl.retail.core.web.header.CSLUser;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.ws.rs.core.MultivaluedMap;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.CLIENT_ID;

@NoArgsConstructor
@ToString
@Getter
@Setter(lombok.AccessLevel.PACKAGE)
public class CSLRequestContext implements Serializable {
	protected String operatorId;
	protected String operatorType;
	protected String customerId;
	protected String customerType;

	protected String relId;
	protected String uaas2id;

	protected String country;
	protected String channel;

	protected String language;
	protected String segmentCode;
	protected String locale;

	protected String requestId;
	protected String sessionId;
	protected String clientId;
	protected String preferredOtpType;
	protected AccessLevel currentAuthLevel;
	protected String jSessionId;

	protected boolean softTokenRegistered;
	protected boolean deviceRegistered;

	@Setter(lombok.AccessLevel.PACKAGE)
	protected List<String> roles;

	@Setter(lombok.AccessLevel.PACKAGE)
	protected String clientIp;

	@Setter(lombok.AccessLevel.PACKAGE)
	protected String remoteAddress;

	@Getter(lombok.AccessLevel.NONE)
	@Setter(lombok.AccessLevel.NONE)
	private String otpHeader;
 
	private String userAgent;
	
	private String trackingId;

	protected String tmxSessionId;

	private boolean isCCLogin;

	protected String deviceMode;
	private String challengeCodeHeader;

	public CSLRequestContext(String sessionId, String requestId, CSLUser cslUser, CSLHeader cslHeader) {
		populateFromHeaders(sessionId, requestId, cslUser, cslHeader, null,null, null);
		populateCustomerId();
	}

	public CSLRequestContext(String sessionId, String requestId, CSLUser cslUser, CSLHeader cslHeader, String languageHeader) {
		populateFromHeaders(sessionId, requestId, cslUser, cslHeader, languageHeader,null, null);
		populateCustomerId();
	}

	public CSLRequestContext(String sessionId, String requestId, CSLUser cslUser, CSLHeader cslHeader, String languageHeader, CSLSoftTokenHeader cslSoftTokenHeader, String locale) {
		populateFromHeaders(sessionId, requestId, cslUser, cslHeader, languageHeader,cslSoftTokenHeader, locale);
		populateCustomerId();
	}

	public CSLRequestContext(DecodedJWT internalAccessToken, String requestId) {
		populateFromJwt(internalAccessToken, requestId);
		populateCustomerId();
	}

	public CSLRequestContext(MultivaluedMap<String, String> params) {
		populateFromHttpParams(params);
		populateCustomerId();
	}

	public CSLRequestContext(String relId, String uaas2id, String country, String channel,
							 String language, String segmentCode) {
		this.relId = relId;
		this.uaas2id = uaas2id;
		this.country = country;
		this.channel = channel;
		this.language = language;
		this.segmentCode = segmentCode;
		populateCustomerId();
	}
	
	public CSLRequestContext(String operatorId, String operatorType, String relId, String uaas2id,
							 String country, String channel, String language, String segmentCode) {
		this(relId, uaas2id, country, channel, language, segmentCode);
		this.operatorId = operatorId;
		this.operatorType = operatorType;
	}

	public CSLRequestContext(String requestId, String sessionId, String operatorId, String operatorType,
							 String relId, String uaas2id, String country, String channel,
							 String language, String segmentCode) {
		this(operatorId, operatorType, relId, uaas2id, country, channel, language, segmentCode);
		this.requestId = requestId;
		this.sessionId = sessionId;
	}

	private void populateFromHttpParams(MultivaluedMap<String, String> params) {
		operatorId = params.getFirst(CSLConstants.OPERATOR_ID_CLAIM);
		operatorType = params.getFirst(CSLConstants.OPERATOR_TYPE_CLAIM);
		relId = params.getFirst(CSLConstants.REL_ID_CLAIM);
		uaas2id = params.getFirst(CSLConstants.UAAS2_ID_CLAIM);

		channel = params.getFirst(CSLConstants.CHANNEL_CLAIM);
		country = params.getFirst(CSLConstants.COUNTRY_CLAIM);
		language = params.getFirst(CSLConstants.LANGUAGE_CLAIM);

		segmentCode = params.getFirst(CSLConstants.SEGMENT_CODE_CLAIM);
	}

	private void populateFromHeaders(String sessionId, String requestId, CSLUser cslUser, CSLHeader cslHeader, String languageHeader,CSLSoftTokenHeader cslSoftTokenHeader, String locale) {
		this.sessionId = sessionId;
		this.locale = locale;
		if (requestId == null) {
			if (cslHeader != null && cslHeader.getClient() != null) {
				this.requestId = cslHeader.getClient().getClientRequestId();
			}
		}
		else {
			this.requestId = requestId;
		}

		if (cslUser != null) {
			this.uaas2id = cslUser.getUaas2id();
			this.country = cslUser.getCountry();
			this.language = cslUser.getLanguage();

			this.relId = cslUser.getRelId();
			this.compositeRelId = cslUser.getRelId();
			this.operatorId = cslUser.getRelId();
			this.segmentCode = cslUser.getSegCd();
			this.clientId = cslUser.getClientId();
		}

		if (cslHeader != null && cslHeader.getClient() != null) {
			CSLClient client = cslHeader.getClient();
			this.channel = client.getChannel();
			this.userAgent = client.getUserAgent();
		}

		if(isBlank(this.language)) {
			this.language = languageHeader;
		}

        //  Added for Soft Token Changes identifying whether customer is softToken Registered or not
		if(cslSoftTokenHeader != null) {
			this.softTokenRegistered = cslSoftTokenHeader.isSoftTokenRegistered();
			this.deviceRegistered = cslSoftTokenHeader.isDeviceRegistered();
		}

	}

	void populateCustomerId() {
		if (isNotEmpty(this.relId) && isNotEmpty(country)) {
			this.compositeRelId = this.relId;
			int relIdLength = relId.trim().length();

			if (countriesWithNoCustomerType.contains(country)) {
				this.customerId = this.relId;
			}
			else if (countriesWithOneCharCustomerType.contains(country) && relIdLength > 1) {
				this.customerType = this.relId.substring(0, 1);
				this.customerId = this.relId.substring(1);
			}
			else if(relIdLength > 2) {
				this.customerType = this.relId.substring(0, 2);
				this.customerId = this.relId.substring(2);
			}
		}
	}

	private void populateFromJwt(DecodedJWT internalAccessToken, String requestId) {
		Map<String, Claim> claims = internalAccessToken.getClaims();

		operatorId = claims.getOrDefault(OPERATOR_ID_CLAIM, nullClaim).asString();
		operatorType = claims.getOrDefault(OPERATOR_TYPE_CLAIM, nullClaim).asString();

		relId = claims.getOrDefault(REL_ID_CLAIM, nullClaim).asString();
		uaas2id = claims.getOrDefault(UAAS2_ID_CLAIM, nullClaim).asString();

		channel = claims.getOrDefault(CHANNEL_CLAIM, nullClaim).asString();
		country = claims.getOrDefault(COUNTRY_CLAIM, nullClaim).asString();
		language = claims.getOrDefault(LANGUAGE_CLAIM, nullClaim).asString();
		currentAuthLevel = claims.getOrDefault(AUTH_LEVEL_NAME_CLAIM, nullClaim).as(AccessLevel.class);

		segmentCode = claims.getOrDefault(SEGMENT_CODE_CLAIM, nullClaim).asString();
		clientId = claims.getOrDefault(CLIENT_ID, nullClaim).asString();
		preferredOtpType = claims.getOrDefault(PREFERRED_OTP_TYPE_CLAIM, nullClaim).asString();
		isCCLogin = Boolean.valueOf(claims.getOrDefault(IS_CC_LOGIN_CLAIM, nullClaim).asString());

		this.requestId = requestId;
		this.jSessionId = claims.getOrDefault(JSESSION_ID_CLAIM, nullClaim).asString();

		this.trackingId = claims.getOrDefault(CSL_TRACKING_ID_CLAIM, nullClaim).asString();
	}

	void setOtpHeader(String otpHeader) {
		this.otpHeader = otpHeader;
	}

	String getOtpHeader() {
		return this.otpHeader;
	}

	public Claim getClaim(String key) {
		ThreadLocalStore localStore = ThreadLocalStore.getInstance();
		return localStore.getClaim(key);
	}

	/**
	 * @deprecated
	 * Use the @RestrictedAccess annotation
	 */
	@Deprecated
	public String _otpToken() {
		return otpHeader;
	}

	private static final List<String> countriesWithNoCustomerType = asList("CI","CN","AE","PK","KE","NG","GH","ZM","BW","UG","ZW","TZ","BD","BH","VN","BN");   
	private static final List<String> countriesWithOneCharCustomerType = emptyList();
	private static final List<String> countriesWithTwoCharCustomerType = asList("HK","SG","ID","IN","MY","AF");

	/**
	 * @deprecated As of release 7.1, replaced by {@link #getRelId()} </br>
	 *             For the type and id part, use {@link #getCustomerId()} and
	 *             {@link #getCustomerType()} respectively
	 */
	@Deprecated
	protected String compositeRelId;

	private static Claim nullClaim = new NullClaim();
}
