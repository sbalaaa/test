package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.exception.CSLExceptionMapper;
import com.sc.csl.retail.core.web.log.RequestLog;
import com.sc.csl.retail.core.web.log.ResponseLog;
import com.sc.csl.retail.core.web.request.ClonedBodyRequestWrapper;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.error.ErrorResponse;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.annotation.Priority;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.util.UUID;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static com.sc.csl.retail.core.util.CSLLogConstants.*;
import static net.logstash.logback.argument.StructuredArguments.kv;
import static io.crnk.rs.type.JsonApiMediaType.APPLICATION_JSON_API;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Slf4j
@Priority(REQUEST_FILTER_PRIORITY)
@Component
public class CSLRequestFilter extends OncePerRequestFilter {
	private ThreadLocalStore threadLocalStore = ThreadLocalStore.getInstance();

	@Autowired
	private CSLExceptionMapper cslExceptionMapper;

	@Setter
	@Autowired
	private ObjectMapper objectMapper;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		Long startTime = System.currentTimeMillis();
		threadLocalStore.clearThreadLocalStore();
		ContentCachingResponseWrapper wrappedResponse = null;

		try {
			populateBasicAttributes(request);

			if(isDebugEnabled()) {
				ClonedBodyRequestWrapper wrappedRequest = new ClonedBodyRequestWrapper(request);
				wrappedResponse = new ContentCachingResponseWrapper(response);
				logRequestOnDebugMode(wrappedRequest);
				filterChain.doFilter(wrappedRequest, wrappedResponse);
				logResponseOnDebugMode(wrappedRequest, wrappedResponse);
			}
			else {
				logRequest(request);
				filterChain.doFilter(request, response);
				logResponse(request, response);
			}
		}
		catch (Exception exception) {
			setErrorResponse(response, exception);
		}
		finally {
			String queryString = request.getQueryString();
			log.info("Request time taken : {} {} {} {} ms {}",
					kv(HTTP_METHOD,request.getMethod()),
					kv(REQUEST_URI, request.getRequestURI()),
					(queryString == null) ? "" : kv(QUERY_STRING, queryString),
					kv(TIME_TAKEN_IN_MILLIS, (System.currentTimeMillis() - startTime)),
					kv(HTTP_STATUS,response.getStatus()),
					kv(PERFORMANCE_METRIC, REQUEST_TIME_TAKEN_KEY)
			);

			threadLocalStore.clearThreadLocalStore();
			if(wrappedResponse != null) {
				wrappedResponse.copyBodyToResponse(); 
			}
		}
	}

	public boolean isDebugEnabled() {
		return log.isDebugEnabled();
	}
	
	private void populateBasicAttributes(HttpServletRequest request) {
		populateRequestId(request);
		populateCallerName(request);
		populateTrackingId(request);

		threadLocalStore.updateBaseAttributesInMDC();
	}

	private void populateCallerName(HttpServletRequest request) {
		String callerServiceName = request.getHeader(CALLER_SERVICE_NAME);
		if (isNotBlank(callerServiceName)) {
			threadLocalStore.setCallerServiceName(callerServiceName);
		}
	}

	private void populateRequestId(HttpServletRequest request) {
		String requestId = request.getHeader(CSL_REQUEST_ID);
		if(isBlank(requestId)) {
			log.debug("RequestId not found in header, generating new UUID");
			requestId = UUID.randomUUID().toString();
		}
		threadLocalStore.setRequestId(requestId);
	}

	private void populateTrackingId(HttpServletRequest request) {
		String trackingId = null;
		DecodedJWT authTokenJWT = HttpUtil.authTokenJWT(request);
		if (authTokenJWT != null) {
			Claim claim = authTokenJWT.getClaim(CSL_TRACKING_ID_CLAIM);
			trackingId = claim.asString();
		}

		if(isBlank(trackingId)) {
			trackingId = request.getHeader(CSL_TRACKING_ID_HEADER);
		}

		threadLocalStore.setTrackingId(trackingId);
	}

	private void setErrorResponse(HttpServletResponse response, Exception exception) throws IOException {
		ErrorResponse errorResponse = cslExceptionMapper.toErrorResponse(exception);
		response.setStatus(errorResponse.getHttpStatus());
		response.setContentType(APPLICATION_JSON_API);

		ServletOutputStream outputStream = response.getOutputStream();
		ByteArrayOutputStream stream = new ByteArrayOutputStream(4096);
		Document document = errorResponse.toResponse().getDocument();

		try {
			objectMapper.writeValue(stream, document);

			outputStream = response.getOutputStream();
			outputStream.write(stream.toByteArray());
			outputStream.flush();
		}
		catch (Exception ignore) {
			log.info("Ignoring exception in error conversion : {}", ignore.getMessage());
		}
		finally {
			closeQuietly(stream);
			closeQuietly(outputStream);
		}
	}

	private void closeQuietly(Closeable closeable) {
		if (closeable != null) {
			try { closeable.close(); }
			catch (IOException ignore) {
				log.info("Ignoring exception in error conversion : {}", ignore.getMessage());
			}
		}
	}

	void logRequest(HttpServletRequest request) {
		RequestLog requestLog = new RequestLog(request);
		log.info(requestLog.toString());
	}

	void logResponse(HttpServletRequest request, HttpServletResponse response) {
		ResponseLog responseLog = new ResponseLog(request, response);
		log.info(responseLog.toString());
	}
	
	void logRequestOnDebugMode(HttpServletRequest request) throws IOException {
 		RequestLog requestLog = new RequestLog(request);
		log.debug(requestLog.debugString());
 	}
 
	void logResponseOnDebugMode(HttpServletRequest request, ContentCachingResponseWrapper responseWrapper) throws IOException {
		ResponseLog responseLog = new ResponseLog(request, responseWrapper);
		log.debug(responseLog.debugString());
	}
}
