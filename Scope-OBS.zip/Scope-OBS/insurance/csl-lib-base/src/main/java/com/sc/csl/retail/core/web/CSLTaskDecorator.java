package com.sc.csl.retail.core.web;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

@Slf4j
public class CSLTaskDecorator implements TaskDecorator {
	@Setter
	private ThreadPoolTaskExecutor taskExecutor;

	@Override
	public Runnable decorate(Runnable runnable) {
		// Right now: In current thread context !
		ThreadLocalStore localStore = ThreadLocalStore.getInstance();
		Map<String, Object> localStoreMap = localStore.getMap();
		ThreadPoolExecutor threadPoolExecutor = taskExecutor.getThreadPoolExecutor();
		log.debug("ThreadPool state on submit : {}", threadPoolExecutor.toString());

		return () -> {
			// Right now: In async thread context !
			ThreadLocalStore asyncLocalStore = ThreadLocalStore.getInstance();
			try {
				asyncLocalStore.replaceThreadLocalMap(localStoreMap);
				log.debug("Replaced the threadStoreMap of Async thread");
				runnable.run();
			} finally {
				log.debug("Clearing threadStoreMap of Async thread");
				asyncLocalStore.clearThreadLocalStore();
				log.debug("ThreadPool state on exit : {}", threadPoolExecutor.toString());
			}
		};
	}
}
