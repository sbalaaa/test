package com.sc.csl.retail.core.web;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.sc.csl.retail.core.config.JacksonConfig;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.properties.HttpClientProperties;
import com.sc.csl.retail.core.gateway.properties.OAuth2ClientProperties;
import com.sc.csl.retail.core.model.CSLApplicationConfig;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.util.CSLLoggingInInterceptor;
import com.sc.csl.retail.core.util.CSLLoggingOutInterceptor;
import com.sc.csl.retail.core.util.Proxies;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.core.web.header.CSLUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transport.http.auth.HttpAuthSupplier;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.ResourceUtils;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.ws.rs.core.HttpHeaders;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.util.List;

import static com.google.common.net.HttpHeaders.X_FORWARDED_FOR;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static com.sc.csl.retail.core.web.HttpUtil.setHeader;
import static java.util.Collections.singletonList;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.BEARER_AUTHORIZATION_SCHEME;

@Slf4j
public class CSLWebClient {
    private static final String TRUST_STORE_TYPE = "jks";
    static final String DISABLE_CNC_CHECK_KEY = "csl.cnc.disable";
    static final String DISABLE_CNC_CHECK_ENV_KEY = "csl_cnc_disable";

    private static List<JacksonJsonProvider> providerList = singletonList(JacksonConfig.jacksonJsonProvider());

	static ThreadLocalStore threadLocalStore() {
        return ThreadLocalStore.getInstance();
    }

    public static WebClient create(String baseUrl) {
        return getWebClient(baseUrl, null, null, null, false);
    }

    public static WebClient create(OAuth2ClientProperties properties) {
        final WebClient webClient = getWebClient(properties.getAccessTokenUri(), null, null, null, false);
        setClientProperties(webClient, properties.getHttpClientProperties());

        return webClient;
	}

	public static WebClient create(String baseUrl, String userName, String password, boolean isScbInternal, HttpClientProperties properties) {
        final WebClient webClient = getWebClient(baseUrl, userName, password, null, isScbInternal);
        setClientProperties(webClient, properties);

        return webClient;
    }

    public static WebClient create(String baseUrl, String userName,
                                   String password, String configLocation) {
        return getWebClient(baseUrl, userName, password, configLocation, false);
    }

    public static WebClient create(String baseUrl, String userName,
            String password, String configLocation, boolean isScbInternal) {
    	return getWebClient(baseUrl, userName, password, configLocation, isScbInternal);
	}

    private static void setClientProperties(WebClient client, HttpClientProperties clientProperties) {
	    if(clientProperties == null) {
	        return;
        }

        setTimeout(client, clientProperties.getTimeout());
        setConnectionTimeout(client, clientProperties.getConnectionTimeout());
        setupSslTrustStore(client, clientProperties.getSslTrustStore(), clientProperties.getSslTrustStorePassword());

        final Proxies proxiesObj = clientProperties.getProxiesObj();
        if (proxiesObj != null) {
            CSLWebClient.setProxy(client, proxiesObj.nextAvailableProxy());
        }
    }

    private static void setProxy(WebClient webClient, Proxy proxy) {
        if(proxy != null) {
            HTTPClientPolicy clientPolicy = WebClient.getConfig(webClient).getHttpConduit().getClient();
            InetSocketAddress socketAddress = (InetSocketAddress) proxy.address();
            String proxyIp = socketAddress.getAddress().getHostAddress();
            int proxyPort = socketAddress.getPort();

            log.info("Setting proxy IP : {}, Port : {}", proxyIp, proxyPort);

            clientPolicy.setProxyServer(proxyIp);
            clientPolicy.setProxyServerPort(proxyPort);
        }
    }

    public static void setAuthSupplier(WebClient webClient, HttpAuthSupplier httpAuthSupplier) {
        final HTTPConduit httpConduit = WebClient.getConfig(webClient).getHttpConduit();
        httpConduit.setAuthSupplier(httpAuthSupplier);
    }

    private static void setTimeout(WebClient webClient, Long timeout) {
        if(timeout != null) {
            ClientConfiguration clientConfiguration = WebClient.getConfig(webClient);
            HTTPClientPolicy clientPolicy = clientConfiguration.getHttpConduit().getClient();
            clientPolicy.setReceiveTimeout(timeout);
            clientPolicy.setConnectionTimeout(timeout);
        }
    }

    private static void setConnectionTimeout(WebClient webClient, Long timeout) {
        if(timeout != null) {
            ClientConfiguration clientConfiguration = WebClient.getConfig(webClient);
            HTTPClientPolicy clientPolicy = clientConfiguration.getHttpConduit().getClient();
            clientPolicy.setConnectionTimeout(timeout);
        }
    }
    
    private static WebClient getWebClient(String baseUrl,
                                          String userName, String password,
                                          String configLocation,
                                          boolean isScbInternal) {
        WebClient client = WebClient.create(baseUrl, providerList, userName, password, configLocation);
        ClientConfiguration config = WebClient.getConfig(client);
        config.getInInterceptors().add(new CSLLoggingInInterceptor());
        config.getOutInterceptors().add(new CSLLoggingOutInterceptor());

        if (isScbInternal) {
            ThreadLocalStore threadLocalStore = threadLocalStore();

            String iatString = threadLocalStore.getInternalAccessTokenString();
            if(isNotBlank(iatString)) setHeader(client, HttpHeaders.AUTHORIZATION, BEARER_AUTHORIZATION_SCHEME + " " + iatString);
            setHeader(client, CSL_REQUEST_ID, threadLocalStore.getRequestId());
            setHeader(client, CSL_SESSION_ID, threadLocalStore.getSessionId());
            setHeader(client, LANGUAGE_HEADER, threadLocalStore.getLanguageHeader());

            CSLUser cslUser = threadLocalStore.getCslUser();
            CSLHeader cslHeader = threadLocalStore.getCslHeader();
            CSLUserInfo cslUserInfo = threadLocalStore.getCslUserInfo();

            setHeader(client, CSL_USER, CSLJsonUtils.toJson(cslUser));
            setHeader(client, CSL_HEADER, CSLJsonUtils.toJson(cslHeader));
            setHeader(client, CSL_USER_INFO, CSLJsonUtils.toJson(cslUserInfo));
            setHeader(client, SC_CLIENT_CONTEXT, threadLocalStore.getSCClientContext());

            CSLRequestContext cslRequestContext = threadLocalStore.getRequestContext();
            if(cslRequestContext != null) {
                setHeader(client, TRUE_CLIENT_IP, cslRequestContext.getClientIp());
                setHeader(client, OTP_HEADER, cslRequestContext.getOtpHeader());
            }
            setHeader(client, X_FORWARDED_FOR, threadLocalStore.getXForwardedFor());
            setHeader(client, CALLER_SERVICE_NAME, CSLApplicationConfig.getApplicationName());
            setHeader(client, CSL_TRACKING_ID_HEADER, threadLocalStore.getTrackingId());
            if (cslRequestContext.getTmxSessionId() != null) {
                setHeader(client, TMX_SESSION_ID_HEADER, cslRequestContext.getTmxSessionId());
            }
        }

        HTTPConduit httpConduit = WebClient.getConfig(client).getHttpConduit();
        log.debug("Using conduit : {}", httpConduit.getClass().getName());
        TLSClientParameters tlsCP = httpConduit.getTlsClientParameters();
        if (isDisableCncConfigured()) {
            tlsCP = tlsCP != null ? tlsCP : new TLSClientParameters();
            tlsCP.setDisableCNCheck(true);
            httpConduit.setTlsClientParameters(tlsCP);
        }
        return client;
    }

    static void setupSslTrustStore(WebClient webClient, String trustStoreLocation, String trustStorePassword) {
        try {
            if (!isBlank(trustStoreLocation) && !isBlank(trustStorePassword)) {
                final HTTPConduit httpConduit = WebClient.getConfig(webClient).getHttpConduit();
                final TLSClientParameters tlsCP = getTLSClientParameters(trustStoreLocation, trustStorePassword);
                httpConduit.setTlsClientParameters(tlsCP);
            }
        } catch (KeyStoreException | IOException | CertificateException | NoSuchAlgorithmException e) {
            throw new TechnicalException("SSL Trust store setup failed", e);
        }
    }

    static boolean isDisableCncConfigured() {
        String disableFlag = System.getProperty(DISABLE_CNC_CHECK_KEY, System.getenv(DISABLE_CNC_CHECK_ENV_KEY));
        return Boolean.valueOf(disableFlag);
    }

    public static TLSClientParameters getTLSClientParameters(String trustStoreLocation, String trustStorePassword)
            throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException {

        if (isBlank(trustStoreLocation) || isBlank(trustStorePassword) ) {
            throw new IllegalArgumentException(
                    String.format("Not valid parameters: trustStoreLocation=%s, trustStorePassword=%s",
                            trustStoreLocation,
                            trustStorePassword)
            );
        }
        final TLSClientParameters tlsCP = new TLSClientParameters();
        final KeyStore trustStore = KeyStore.getInstance(TRUST_STORE_TYPE);

        if (trustStoreLocation.startsWith(ResourceUtils.CLASSPATH_URL_PREFIX)) {
            String classPathLocation = trustStoreLocation.substring(ResourceUtils.CLASSPATH_URL_PREFIX.length());
            ClassPathResource resource = new ClassPathResource(classPathLocation);
            InputStream inputStream = resource.getInputStream();
            trustStore.load(inputStream, trustStorePassword.toCharArray());
            inputStream.close();
        } else {
            FileInputStream fileInputStream = new FileInputStream(trustStoreLocation);
            trustStore.load(fileInputStream, trustStorePassword.toCharArray());
            fileInputStream.close();
        }

        final TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trustStore);

        final TrustManager[] myTrustStoreKeyManagers = tmf.getTrustManagers();
        tlsCP.setTrustManagers(myTrustStoreKeyManagers);

        if (isDisableCncConfigured()) {
            tlsCP.setDisableCNCheck(true);
        }

        return tlsCP;
    }

}
