package com.sc.csl.retail.core.web;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.client.WebClient;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response.Status;
import java.io.IOException;
import java.security.interfaces.RSAPublicKey;
import java.util.List;

import static io.crnk.rs.type.JsonApiMediaType.APPLICATION_JSON_API;
import static com.sc.csl.retail.core.util.CSLConstants.TMX_SESSION_ID_HEADER;
import static java.util.Arrays.asList;
import static javax.ws.rs.core.Response.Status.Family.CLIENT_ERROR;
import static javax.ws.rs.core.Response.Status.Family.SERVER_ERROR;
import static org.apache.commons.lang3.StringUtils.*;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.BEARER_TOKEN_TYPE;
import static org.springframework.http.MediaType.*;

@Slf4j
public class HttpUtil {
	static void setHeader(WebClient client, String key, String value) {
		if (isNotBlank(value)) {
			client.header(key, value);
		}
	}

	static void setHeader(ContainerResponseContext responseContext, String key, String value) {
		MultivaluedMap<String, Object> headers = responseContext.getHeaders();
		headers.putSingle(key, value);
	}

	static String accessTokenHeader(HttpServletRequest request) {
		return request.getHeader(HttpHeaders.AUTHORIZATION);
	}

	static String tmxSessionIdHeader(HttpServletRequest request) {
		return request.getHeader(TMX_SESSION_ID_HEADER);
	}

	static DecodedJWT authTokenJWT(HttpServletRequest request) {
		final String authHeader = accessTokenHeader(request);
		if(isNoneEmpty(authHeader)) {
			String[] authValues = StringUtils.split(authHeader, " ");

			if(authValues.length < 2) {
				return null;
			}

			String tokenType = authValues[0];
			if(!BEARER_TOKEN_TYPE.equalsIgnoreCase(tokenType)) {
				return null;
			}

			String accessToken = authValues[1];
			try {
				return JWT.decode(accessToken);
			}
			catch (JWTDecodeException ex) {
				log.warn("Not a valid JWT token : {}, Error : {}", authHeader, ex.getMessage());
				return null;
			}
		}

		return null;
	}

	public static String requestUrl(HttpServletRequest request) {
		StringBuffer requestURL = request.getRequestURL();
		String queryString = request.getQueryString();
		if (isNotEmpty(queryString)) {
			requestURL.append("?").append(queryString);
		}

		return requestURL.toString();
	}

	public static boolean isErrorResponse(int statusCode) {
		Status httpStatus = httpStatus(statusCode);
		if(httpStatus == null) return true;

		Status.Family family = httpStatus.getFamily();
		return (family == SERVER_ERROR || family == CLIENT_ERROR);
	}

	public static Status httpStatus(int statusCode) {
		return Status.fromStatusCode(statusCode);
	}

	static DecodedJWT validateInternalAccessToken(String accessToken, RSAPublicKey publicKey) {
		final int ACCEPT_10_SECS = 10;
		JWTVerifier verifier = JWT.require(Algorithm.RSA256(publicKey))
				.withIssuer("CSL-AUTH")
				.withClaim("type", "CSL-IAT")
				.acceptLeeway(ACCEPT_10_SECS)
				.build();
		return verifier.verify(accessToken);
	}

	public static String getPayloadToLog(HttpServletRequest request) throws IOException {
		String payload;
		String contentType = defaultString(request.getContentType(), "-");
		int contentLength = request.getContentLength();
		long count = contentTypesToLog.stream().filter(c -> contentType.startsWith(c)).count();
		if(count > 0) {
			payload = IOUtils.toString(request.getInputStream(), request.getCharacterEncoding());
			payload = defaultIfBlank(payload, "-");
		}
		else {
			payload = (contentLength <= 0) ? "-" : "<payload-not-logged>";
		}
		return payload;
	}

	public static String getPayloadToLog(ContentCachingResponseWrapper response) throws IOException {
		String payload;
		String contentType = defaultString(response.getContentType(), "-");
		int contentLength = response.getContentSize();
		long count = contentTypesToLog.stream().filter(c -> contentType.startsWith(c)).count();
		if(count > 0) {
			payload = IOUtils.toString(response.getContentAsByteArray(), response.getCharacterEncoding());
			payload = defaultIfBlank(payload, "-");
		}
		else {
			payload = (contentLength <= 0) ? "-" : "<payload-not-logged>";
		}
		return payload;
	}

	private static final List<String> contentTypesToLog = asList(
			APPLICATION_JSON_VALUE,
			APPLICATION_XML_VALUE,
			APPLICATION_JSON_API,
			APPLICATION_FORM_URLENCODED_VALUE,
			TEXT_HTML_VALUE,
			TEXT_MARKDOWN_VALUE,
			TEXT_PLAIN_VALUE,
			TEXT_XML_VALUE
	);
}
