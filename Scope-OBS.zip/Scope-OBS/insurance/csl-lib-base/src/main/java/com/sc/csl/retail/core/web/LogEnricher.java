package com.sc.csl.retail.core.web;

import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.*;

/**
 * Use MDC instead of prefixing the log message
 */
@Deprecated
public class LogEnricher {

    public static String getCorrelationId() {
        ThreadLocalStore localStore = threadLocalStore();

        String cslCorrelationId = localStore.getCslCorrelationId();
        if(isNotEmpty(cslCorrelationId)) {
            return cslCorrelationId;
        }

        CSLRequestContext requestContext = localStore.getRequestContext();

        StringBuilder result = new StringBuilder();
        result.append("[");

        if(!ObjectUtils.isEmpty(requestContext)) {
            List<String> values = new ArrayList<>();
            values.add(defaultString(localStore.getRequestId()));
            values.add(defaultString(requestContext.getSessionId()));
            values.add(defaultString(requestContext.getRelId()));
            values.add(defaultString(requestContext.getChannel()));
            values.add(defaultString(requestContext.getCountry()));

            result.append(join(values, ":"));
        }

        result.append("]");
        cslCorrelationId = result.toString();
        localStore.setCslCorrelationId(cslCorrelationId);

        return cslCorrelationId;
    }

    static ThreadLocalStore threadLocalStore() {
        return ThreadLocalStore.getInstance();
    }
}
