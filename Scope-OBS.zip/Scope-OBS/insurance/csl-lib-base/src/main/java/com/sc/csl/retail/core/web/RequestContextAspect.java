package com.sc.csl.retail.core.web;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
@Slf4j
public class RequestContextAspect {
	@After("call(* com.sc.csl.retail.core.web.CSLAsyncRequestContext.set*(..))")
	public void afterRequestContextUpdated(JoinPoint joinPoint) {
		log.debug("CSLRequestContext updated. Clearing correlationId");
		ThreadLocalStore localStore = ThreadLocalStore.getInstance();
		localStore.onContextUpdated();
	}
}
