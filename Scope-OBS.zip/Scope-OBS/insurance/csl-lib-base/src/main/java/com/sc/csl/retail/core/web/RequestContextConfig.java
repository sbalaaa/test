package com.sc.csl.retail.core.web;

import org.springframework.beans.factory.config.CustomScopeConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.context.support.SimpleThreadScope;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class RequestContextConfig {
	private static ThreadLocalStore threadLocalStore = ThreadLocalStore.getInstance();
	private static final String THREAD_SCOPE = "thread";
	private static final String PROTOTYPE_SCOPE = "prototype";

	@Bean
	public CustomScopeConfigurer customScopeConfigurer() {
		CustomScopeConfigurer customScopeConfigurer = new CustomScopeConfigurer();
		SimpleThreadScope simpleThreadScope = new SimpleThreadScope();
		customScopeConfigurer.addScope(THREAD_SCOPE, simpleThreadScope);
		return customScopeConfigurer;
	}

	@Bean
	@Scope(scopeName = WebApplicationContext.SCOPE_REQUEST,
			proxyMode = ScopedProxyMode.TARGET_CLASS)
	public CSLRequestContext cslRequestContext() {
		return threadLocalStore.getRequestContext();
	}

	@Bean
	@Scope(scopeName = THREAD_SCOPE,
			proxyMode = ScopedProxyMode.TARGET_CLASS)
	public CSLAsyncRequestContext cslAsyncRequestContext() {
		return threadLocalStore.getAsyncRequestContext();
	}

	@Bean
	public CommonsRequestLoggingFilter requestLoggingFilter() {
		CommonsRequestLoggingFilter loggingFilter = new CommonsRequestLoggingFilter();
		loggingFilter.setIncludeClientInfo(true);
		loggingFilter.setIncludeQueryString(true);
		loggingFilter.setIncludePayload(true);
		return loggingFilter;
	}

	public static String getRequestId() {
		return threadLocalStore.getRequestId();
	}
}
