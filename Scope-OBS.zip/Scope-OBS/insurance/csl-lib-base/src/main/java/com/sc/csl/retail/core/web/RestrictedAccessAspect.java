package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.auth.OTPParam;
import com.sc.csl.retail.core.auth.RestrictedAccess;
import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.exception.*;
import com.sc.csl.retail.core.model.OTPRequest;
import com.sc.csl.retail.core.model.SmsOtp;
import com.sc.csl.retail.core.model.SmsOtpValidation;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletResponse;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.auth.AccessLevel.TWO_FACTOR;
import static com.sc.csl.retail.core.auth.AccessLevel.TWO_FACTOR_PLUS;
import static com.sc.csl.retail.core.auth.TokenType.*;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.*;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Aspect
@Slf4j
public class RestrictedAccessAspect {

	@Around("execution(* *(..)) && " +
			"(@annotation(com.sc.csl.retail.core.auth.RestrictedAccess) " +
			"|| @within(com.sc.csl.retail.core.auth.RestrictedAccess) )")
	public Object checkRestrictedAccess(ProceedingJoinPoint joinPoint) throws Throwable {
		RestrictedAccess annotation = restrictedAccessAnnotation(joinPoint);
		CSLRequestContext requestContext = requestContext();
		String otpHeader = requestContext.getOtpHeader();
		AccessLevel requiredLevel = requiredAccessLevel(annotation);
		boolean otpValidated = false;
		String mpinPurpose = mpinPurpose(annotation);
		boolean mpinRequired = isNotBlank(mpinPurpose);

		if(isNotBlank(otpHeader)) {
			log.info("OTP found in header. About to validate OTP");
			try {
				DecodedJWT iat = getInternalAccessToken();
				int currentAuthLevel = authLevel(iat);

				if(requiredLevel.equals(TWO_FACTOR_PLUS) && (currentAuthLevel >= TWO_FACTOR.authLevel())) {
					log.info("Required level 2FA-Plus and the user is already >= 2FA level, just validating the OTP");
					if (mpinRequired) {
						validateOtpAndMpinWithoutToken(otpHeader);
					}else {
						validateOtpWithoutToken(otpHeader);
					}
				}
				else {
					if (mpinRequired) {
						validateOtpAndMpin(otpHeader);
					}else {
						validateOtp(otpHeader);
					}
				}
				otpValidated = true;
			}
			catch (CSLRuntimeException ex) {
				log.error("Exception in OTP validation : {} ", ex.getMessage());
				throw new RestrictedAccessException(ex.getErrorCode(), ex);
			}
			catch (Exception ex) {
				log.error("Exception in OTP validation : {} ", ex.getMessage());
				throw new RestrictedAccessException(OTP_VALIDATION_FAILED, ex);
			}
		}

		DecodedJWT internalAccessToken = getInternalAccessToken();
		int authLevel = authLevel(internalAccessToken);

		if(requiredLevel.equals(TWO_FACTOR_PLUS) && !otpValidated) {
			log.info("Required access level {}, so triggering OTP flow, regardless of the current auth level {}", TWO_FACTOR_PLUS, authLevel);
		}
		else if (authLevel >= requiredLevel.authLevel()) {
			log.info("Required access level matches the current access level");
			return joinPoint.proceed();
		}

		if(isSmsOtpRequired(annotation)) {
			try {
				log.info("SMS OTP required to perform the operation. Triggering SMS");
				Map<String, String> otpParams = otpParams(joinPoint);
				OTPRequest otpRequest = otpRequest(requestContext, annotation, otpParams);
				SmsOtp smsOtp = authGateway().sendOtp(otpRequest);

				if (mpinRequired) {
					throw new OTPRequiredException(smsOtp, mpinPurpose);
				}else {
					throw new OTPRequiredException(smsOtp);
				}
			}
			catch (OTPRequiredException otpRequiredEx) {
			    //Catch and throw to avoid the exception being caught by the below generic handlers.
				throw otpRequiredEx;
			}
			catch (CSLRuntimeException ex) {
				log.error("Exception while sending SMS OTP : {} ", ex.getMessage());
				throw new RestrictedAccessException(ex.getErrorCode(), ex);
			}
			catch(Exception ex) {
				log.error("Exception while sending SMS OTP : {} ", ex.getMessage());
				throw new RestrictedAccessException(OTP_SEND_FAILED, ex);
			}
		}

		if(isSoftTokenRequired(annotation)) {
			log.info("SoftToken OTP required");
			throw new OTPRequiredException(SOFT_TOKEN);
		}

		log.warn("Not able to determine the OTP type required");
		throw new TechnicalException("Not able to determine the OTP type required");
	}

	public String mpinPurpose(RestrictedAccess annotation) {
		return annotation.mpinPurpose();
	}

	public AccessLevel requiredAccessLevel(RestrictedAccess annotation) {
		if (annotation.riskAssessmentRequired()) {
			return fetchRiskAssessment(annotation.riskAssessmentId());
		}
		return  annotation.accessLevel();
	}

	private Integer authLevel(DecodedJWT internalAccessToken) {
		if(internalAccessToken == null) throw new UnauthorizedException(TOKEN_NOT_FOUND);
		return internalAccessToken.getClaim(AUTH_LEVEL_CLAIM).asInt();
	}

	void validateOtpWithoutToken(String otpHeader) {
		AuthGateway authGateway = authGateway();
		SmsOtpValidation smsOtpValidation = CSLJsonUtils.parseJson(otpHeader, SmsOtpValidation.class);
		authGateway.validateOtpWithoutToken(smsOtpValidation.getSmsOtp());
	}

	void validateOtpAndMpinWithoutToken(String otpHeader) {
		AuthGateway authGateway = authGateway();
		SmsOtpValidation smsOtpValidation = CSLJsonUtils.parseJson(otpHeader, SmsOtpValidation.class);
		authGateway.validateOtpAndMpinWithoutToken(smsOtpValidation.getSmsOtp());
	}
	
	void validateOtp(String otpHeader) {
		ThreadLocalStore localStore = threadLocalStore();
		AuthGateway authGateway = authGateway();

		SmsOtpValidation smsOtpValidation = CSLJsonUtils.parseJson(otpHeader, SmsOtpValidation.class);
		CSLTokenResponse cslTokenResponse = authGateway.validateOtp(smsOtpValidation);
		log.info("OTP validation successful. Setting tokens in header");

		String accessToken = cslTokenResponse.getAccessToken();
		String internalAccessToken = authGateway.getInternalAccessToken(accessToken);
		DecodedJWT iatJwt = authGateway.validateInternalAccessToken(internalAccessToken);

		localStore.setInternalAccessToken(iatJwt);
		localStore.setInternalAccessTokenString(internalAccessToken);

		HttpServletResponse httpServletResponse = httpServletResponse();

		String refreshToken = cslTokenResponse.getRefreshToken();
		if(isNotBlank(refreshToken)) httpServletResponse.setHeader(CSL_REFRESH_TOKEN, refreshToken);
		httpServletResponse.setHeader(CSL_ACCESS_TOKEN, accessToken);
	}

	void validateOtpAndMpin(String otpHeader) {
		ThreadLocalStore localStore = threadLocalStore();
		AuthGateway authGateway = authGateway();

		SmsOtpValidation smsOtpValidation = CSLJsonUtils.parseJson(otpHeader, SmsOtpValidation.class);
		CSLTokenResponse cslTokenResponse = authGateway.validateOtpAndMpin(smsOtpValidation);
		log.info("OTP and MPIN validation successful. Setting tokens in header");

		String accessToken = cslTokenResponse.getAccessToken();
		String internalAccessToken = authGateway.getInternalAccessToken(accessToken);
		DecodedJWT iatJwt = authGateway.validateInternalAccessToken(internalAccessToken);

		localStore.setInternalAccessToken(iatJwt);
		localStore.setInternalAccessTokenString(internalAccessToken);

		HttpServletResponse httpServletResponse = httpServletResponse();

		String refreshToken = cslTokenResponse.getRefreshToken();
		if(isNotBlank(refreshToken)) httpServletResponse.setHeader(CSL_REFRESH_TOKEN, refreshToken);
		httpServletResponse.setHeader(CSL_ACCESS_TOKEN, accessToken);
	}
	
	HttpServletResponse httpServletResponse() {
		RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
		 return  ((ServletRequestAttributes) requestAttributes).getResponse();
	}

	RestrictedAccess restrictedAccessAnnotation(ProceedingJoinPoint joinPoint) {
		return methodObject(joinPoint).getAnnotation(RestrictedAccess.class);
	}

	Annotation[][] parameterAnnotations(ProceedingJoinPoint joinPoint) {
		return methodObject(joinPoint).getParameterAnnotations();
	}

	private Method methodObject(ProceedingJoinPoint joinPoint) {
		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		return methodSignature.getMethod();
	}

	private boolean isSmsOtpRequired(RestrictedAccess annotation) {
		TokenType tokenType = annotation.tokenType();

		if(SMS.equals(tokenType)) {
			log.debug("TokenType is enforced as SMS");
			return true;
		}

		if(USER_PREFERRED.equals(tokenType)) {
			CSLRequestContext requestContext = requestContext();
			String preferredOtpType = requestContext.getPreferredOtpType();
			log.debug("TokenType configured : Type : {}, value : {}", tokenType, preferredOtpType);

			if(isBlank(preferredOtpType)) {
				log.debug("User preferred type blank, fall back to SMS");
				return true;
			}

			if(PREFERRED_TYPE_SMS.equals(preferredOtpType)) {
				return true;
			}
		}

		return false;
	}

	private boolean isSoftTokenRequired(RestrictedAccess annotation) {
		TokenType tokenType = annotation.tokenType();

		if(USER_PREFERRED.equals(tokenType)) {
			CSLRequestContext requestContext = requestContext();
			String preferredOtpType = requestContext.getPreferredOtpType();

			if(PREFERRED_TYPE_SOFT_TOKEN.equals(preferredOtpType)) {
				return true;
			}
		}

		return false;
	}

	private OTPRequest otpRequest(CSLRequestContext context, RestrictedAccess annotation, Map<String, String> otpParams) {
		OTPRequest otpRequest = new OTPRequest();
		otpRequest.setRequestId(context.getRequestId());
		otpRequest.setActionName(annotation.actionName());
		otpRequest.setOtpParams(otpParams);
		return otpRequest;
	}

	protected Map<String, String> otpParams(ProceedingJoinPoint joinPoint) {
		Map<String, String> otpParamsMap = new HashMap<String, String>();
		Annotation[][] parameterAnnotations = parameterAnnotations(joinPoint);
		Object[] methodArgs = joinPoint.getArgs();

		int argIndex = 0;
		for(Annotation[] annotations : parameterAnnotations) {
			for(Annotation annotation : annotations) {
				if(annotation instanceof OTPParam) {
					OTPParam otpParam = (OTPParam) annotation;
					String argValue = methodArgs[argIndex].toString();
					otpParamsMap.put(otpParam.value(), argValue);
                }
		  	}
            argIndex++;
		}
		return otpParamsMap;
	}

	CSLRequestContext requestContext() {
		return threadLocalStore().getRequestContext();
	}

	public DecodedJWT getInternalAccessToken() {
		return threadLocalStore().getInternalAccessToken();
	}

	ThreadLocalStore threadLocalStore() {
		return ThreadLocalStore.getInstance();
	}

	AuthGateway authGateway() {
		return AuthGateway.getInstance();
	}

	private AccessLevel fetchRiskAssessment(String assessmentId) {
		throw new NotImplementedException("Fetch RiskAssessment not implemented");
	}
}
