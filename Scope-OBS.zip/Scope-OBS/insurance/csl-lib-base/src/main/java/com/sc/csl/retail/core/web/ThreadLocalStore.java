package com.sc.csl.retail.core.web;

import com.auth0.jwt.impl.NullClaim;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.model.CSLApplicationConfig;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLSoftTokenHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.core.web.header.CSLUserInfo;

import org.slf4j.MDC;

import java.util.HashMap;
import java.util.Map;

import static com.google.common.net.HttpHeaders.X_FORWARDED_FOR;
import static com.sc.csl.retail.core.util.CSLConstants.*;

class ThreadLocalStore {
    private static ThreadLocalStore threadLocalStore = new ThreadLocalStore();
    private static ThreadLocal<Map<String, Object>> threadLocalMap = new InheritableThreadLocal<>();

    private ThreadLocalStore() {
    }

    static ThreadLocalStore getInstance() {
        return threadLocalStore;
    }

	void setInternalAccessToken(DecodedJWT iat) {
		setValue(CSL_INTERNAL_ACCESS_TOKEN, iat);
	}

    DecodedJWT getInternalAccessToken() {
		return (DecodedJWT) getValue(CSL_INTERNAL_ACCESS_TOKEN);
	}

	Claim getClaim(String key) {
        DecodedJWT decodedJWT = getInternalAccessToken();
        if(decodedJWT == null) return new NullClaim();

        return decodedJWT.getClaim(key);
    }

	void setInternalAccessTokenString(String iat) {
		setValue(CSL_INTERNAL_ACCESS_TOKEN_STRING, iat);
	}

	String getInternalAccessTokenString() {
		return (String) getValue(CSL_INTERNAL_ACCESS_TOKEN_STRING);
	}

    void setRequestId(String requestId) {
        setValue(CSL_REQUEST_ID, requestId);
        onContextUpdated();
    }

    String getRequestId() {
        return (String) getValue(CSL_REQUEST_ID);
    }

    void setSessionId(String sessionId) {
        setValue(CSL_SESSION_ID, sessionId);
    }

    String getSessionId() {
        return (String) getValue(CSL_SESSION_ID);
    }

    void setTrackingId(String trackingId) {
        setValue(CSL_TRACKING_ID_CLAIM, trackingId);
    }

    String getTrackingId() {
        return (String) getValue(CSL_TRACKING_ID_CLAIM);
    }

    void setCallerServiceName(String callerServiceName) {
        setValue(CALLER_SERVICE_NAME, callerServiceName);
    }

    String getCallerServiceName() {
        return (String) getValue(CALLER_SERVICE_NAME);
    }

    void setJSessionId(String jSessionId) {
        setValue(JSESSION_ID_CLAIM, jSessionId);
    }

    String getJSessionId() {
        return (String) getValue(JSESSION_ID_CLAIM);
    }

    void setCslUser(CSLUser cslUser) {
        setValue(CSL_USER, cslUser);
    }

    CSLUser getCslUser() {
        CSLUser cslUser = (CSLUser) getValue(CSL_USER);
        if(cslUser == null) {
            cslUser = new CSLUser();
            setCslUser(cslUser);
        }

        return cslUser;
    }

    void setCslHeader(CSLHeader cslHeader) {
        setValue(CSL_HEADER, cslHeader);
    }

    String getLanguageHeader() {
        return (String) getValue(LANGUAGE_HEADER);
    }

    void setLanguageHeader(String languageHeader) {
        setValue(LANGUAGE_HEADER, languageHeader);
    }

    String getSCClientContext() {
    	return (String) getValue(SC_CLIENT_CONTEXT);
    }
    
    void setSCClientContext(String scClientContext) {
        setValue(SC_CLIENT_CONTEXT, scClientContext);
    }
    
    CSLHeader getCslHeader() {
        CSLHeader cslHeader = (CSLHeader) getValue(CSL_HEADER);
        if(cslHeader == null) {
            cslHeader = new CSLHeader();
            setCslHeader(cslHeader);
        }

        return cslHeader;
    }

    void setCslUserInfo(CSLUserInfo cslUserInfo) {
        setValue(CSL_USER_INFO, cslUserInfo);
    }

    CSLUserInfo getCslUserInfo() {
        CSLUserInfo cslUserInfo = (CSLUserInfo) getValue(CSL_USER_INFO);
        if(cslUserInfo == null) {
            cslUserInfo = new CSLUserInfo();
            setCslUserInfo(cslUserInfo);
        }

        return cslUserInfo;
    }

    @Deprecated
    void setCslCorrelationId(String cslCorrelationId) {
        setValue(CSL_CORRELATION_ID, cslCorrelationId);
    }

    @Deprecated
    String getCslCorrelationId() {
        return (String) getValue(CSL_CORRELATION_ID);
    }

    void setXForwardedFor(String xForwardedFor) {
        setValue(X_FORWARDED_FOR, xForwardedFor);
    }

    String getXForwardedFor() {
        return (String) getValue(X_FORWARDED_FOR);
    }

    void setRequestContext(CSLRequestContext requestContext) {
        setValue(CSL_REQUEST_CONTEXT, requestContext);
        onContextUpdated();
    }

    void clearRequestContext() {
        setValue(CSL_REQUEST_CONTEXT, new CSLRequestContext());
        onContextUpdated();
    }

    CSLRequestContext getRequestContext() {
        CSLRequestContext requestContext = (CSLRequestContext) getValue(CSL_REQUEST_CONTEXT);
        if(requestContext == null) {
            requestContext = new CSLRequestContext();
            setRequestContext(requestContext);
        }
        return requestContext;
    }

    CSLAsyncRequestContext getAsyncRequestContext() {
        clearRequestContext();
        return new CSLAsyncRequestContext();
    }

    private void setValue(String key, Object value) {
        if (value != null) {
            getMap().put(key, value);
        }
    }

    private Object getValue(String key) {
        return getMap().get(key);
    }

    private void clearValue(String key) {
        getMap().remove(key);
    }

    void clearThreadLocalStore() {
        threadLocalMap.remove();
        MDC.clear();
        setServiceNameInMDC();
    }

    void onContextUpdated() {
        clearValue(CSL_CORRELATION_ID);
        updateMDC();
        CSLHystrixExecutionHook.setHystrixRequestMap(getMap());
    }

    Map<String, Object> getMap() {
        Map<String, Object> objMap = threadLocalMap.get();

        if (objMap == null) {
            objMap = new HashMap<>();
            threadLocalMap.set(objMap);
        }
        return objMap;
    }

    void replaceThreadLocalMap(Map<String, Object> objMap) {
        clearThreadLocalStore();
        threadLocalMap.set(objMap);
        updateMDC();
    }

    private void updateMDC() {
        CSLRequestContext requestContext = this.getRequestContext();
        MDC.put("sessionId", requestContext.getSessionId());
        MDC.put("relId", requestContext.getRelId());
        MDC.put("uaas2id", requestContext.getUaas2id());
        MDC.put("operatorId", requestContext.getOperatorId());
        MDC.put("operatorType", requestContext.getOperatorType());
        MDC.put("customerId", requestContext.getCustomerId());
        MDC.put("customerType", requestContext.getCustomerType());
        MDC.put("country", requestContext.getCountry());
        MDC.put("channel", requestContext.getChannel());
        MDC.put("language", requestContext.getLanguage());
        MDC.put("segmentCode", requestContext.getSegmentCode());
        MDC.put("clientIp", requestContext.getClientIp());

        updateBaseAttributesInMDC();
    }

    void updateBaseAttributesInMDC() {
        MDC.put("requestId", this.getRequestId());
        MDC.put(CSL_TRACKING_ID_MDC, this.getTrackingId());
        MDC.put("callerServiceName", this.getCallerServiceName());
        setServiceNameInMDC();
    }

    private void setServiceNameInMDC() {
        MDC.put("serviceName", CSLApplicationConfig.getApplicationName());
    }

    void setCSLSoftTokenHeader(CSLSoftTokenHeader cslSoftTokenHeader) {
        setValue(CSL_SOFTTOKEN, cslSoftTokenHeader);
    }

    CSLSoftTokenHeader getCSLSoftTokenHeader() {
    	CSLSoftTokenHeader cslSoftTokenHeader = (CSLSoftTokenHeader) getValue(CSL_SOFTTOKEN);
        if(cslSoftTokenHeader == null) {
        	cslSoftTokenHeader = new CSLSoftTokenHeader();
        	setCSLSoftTokenHeader(cslSoftTokenHeader);
        }
        return cslSoftTokenHeader;
    }
}
