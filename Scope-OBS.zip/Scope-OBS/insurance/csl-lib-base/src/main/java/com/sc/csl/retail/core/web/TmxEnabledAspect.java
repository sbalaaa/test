package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.exception.CSLRuntimeException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TmxRedStatusException;
import com.sc.csl.retail.core.tmx.TmxObligatoryFields;
import com.sc.csl.retail.core.tmx.TmxParametersExtractor;
import com.sc.csl.retail.core.tmx.annotations.TmxEnabled;
import com.sc.csl.retail.core.tmx.annotations.TmxParam;
import com.sc.csl.retail.core.tmx.model.TmxUserVerificationResponse;
import com.sc.csl.retail.core.tmx.service.TmxProcessorService;
import com.sc.csl.retail.core.util.CSLConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Aspect
@Slf4j
public class TmxEnabledAspect {

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Value("#{'${tmx.disabled.countries:,}'.split(',')}")
    private List<String> tmxEnabledCountryList;

    @Around("execution(* *(..)) && " +
            "(@annotation(com.sc.csl.retail.core.tmx.annotations.TmxEnabled) " +
            "|| @within(com.sc.csl.retail.core.tmx.annotations.TmxEnabled) )")
    public Object checkTmxStatus(ProceedingJoinPoint joinPoint) throws Throwable {
        if(null != tmxEnabledCountryList && tmxEnabledCountryList.contains(cslRequestContext.getCountry())) {
            return joinPoint.proceed();
        }

        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        TmxEnabled tmxEnabled =  methodSignature.getMethod().getAnnotation(TmxEnabled.class);
        Map<String, Object> tmxParameters = prepareTmxParameters(tmxEnabled, joinPoint);
        TmxProcessorService tmxProcessorService = getTmxProcessorService();
        try {
            log.info("TMX verify session started");
            TmxUserVerificationResponse tmxUserVerificationResponse = tmxProcessorService.verifySession(tmxParameters);
            Object joinPointExecutionResult = joinPoint.proceed();
            log.info("Proceeding to tmx feedback");
            tmxProcessorService.feedback(tmxUserVerificationResponse);
            return joinPointExecutionResult;
        } catch (TmxRedStatusException e) {
            throw e;
        } catch (CSLRuntimeException ex) {
            throw ex;
        } catch (Exception e) {
            /**
             * If there's no response from tmx profile call in 3 sec, Mobile app skip and not pass the value to CSL.
             * So we added this code to skip the tmx flow, if there's no tmx session id
             * TODO:We have to remove this, Once TMX integration is stable
             **/
            if(e.getMessage().equals(CSLConstants.NO_TMX_SESSION_ID_MESSAGE)) {
                log.warn("Tmx Session ID is empty");
                return joinPoint.proceed();
            } else {
                throw new TechnicalException("Error during TMX Gateway call.", e);
            }
       }
    }

    private Map<String, Object> prepareTmxParameters(TmxEnabled tmxEnabledAnnotation, ProceedingJoinPoint joinPoint) {
        Map<String, Object> tmxParameters = new HashMap<>();
        if (!StringUtils.isEmpty(tmxEnabledAnnotation.eventType())) {
            tmxParameters.put(TmxObligatoryFields.eventType.name(), tmxEnabledAnnotation.eventType());
            String country = threadLocalStore().getRequestContext().getCountry();
            country = country == null ? "" : country.toUpperCase();
            tmxParameters.put(TmxObligatoryFields.policy.name(), String.format("%s_%s", country, tmxEnabledAnnotation.eventType()));
        }

        if (!StringUtils.isEmpty(tmxEnabledAnnotation.customerEventType())) {
            tmxParameters.put(TmxObligatoryFields.customerEventType.name(), tmxEnabledAnnotation.customerEventType());
        }

        populateTmxExtractorParameters(tmxParameters, joinPoint);
        populatePlainTmxArgumentParameters(tmxParameters, joinPoint);
        return tmxParameters;
    }

    /**
     * Get all TMX parameters from method arguments.
     * @param joinPoint
     * @return
     */
    private void populateTmxExtractorParameters(Map<String, Object> tmxParameters, ProceedingJoinPoint joinPoint) {
        extractRiskAssessmentParameters(joinPoint).stream().
                flatMap(e -> e.getTmxParams().entrySet().stream()).
                forEach(e -> tmxParameters.put(e.getKey(), e.getValue()));
        if (tmxParameters.isEmpty()) {
            throw new IllegalArgumentException("No TMX parameters defined in method arguments.");
        }
        log.info("TMX parameters keys for : {}", tmxParameters.keySet());
    }

    /**
     * Extract all method arguments which are implementing @TmxParametersExtractor and annotated with @TmxParam into list.
     * If list is not empty then return it, otherwise return all method arguments implementing @TmxParametersExtractor.
     * @param joinPoint
     * @return
     */
    private List<TmxParametersExtractor> extractRiskAssessmentParameters(ProceedingJoinPoint joinPoint) {
        Object [] arguments = joinPoint.getArgs();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Annotation[][] parameterAnnotations = methodSignature.getMethod().getParameterAnnotations();

        Predicate<Integer> isTmxExtractor = i -> arguments.length > i && arguments[i] instanceof TmxParametersExtractor;
        Predicate<Integer> isAnnotatedTmxExtractor = i -> Stream.of(parameterAnnotations[i]).anyMatch(a -> a.annotationType() == TmxParam.class);
        Function<Integer, TmxParametersExtractor> toTmxResponseMapper = i -> TmxParametersExtractor.class.cast(arguments[i]);
        Supplier<Stream<Integer>> argIndexStream = () -> IntStream.range(0, parameterAnnotations.length).boxed();

        List<TmxParametersExtractor> annotatedTmxExtractors  = argIndexStream.get().
                filter(isTmxExtractor).
                filter(isAnnotatedTmxExtractor).
                map(toTmxResponseMapper).
                collect(Collectors.toList());

        if (!annotatedTmxExtractors.isEmpty()) {
            log.info("Return @TmxParam annotated Data Extractor arguments.");
            return annotatedTmxExtractors;
        } else {
            log.info("No @TmxParam annotated Data Extractor arguments found, proceed with arguments implementing TmxDataExtractor.");
            return argIndexStream.get().
                    filter(isTmxExtractor).
                    map(toTmxResponseMapper).
                    collect(Collectors.toList());
        }
    }

    /**
     * Extract all method arguments which don't @TmxParametersExtractor and annotated with @TmxParam and put them in @tmxParameters.
     * @param tmxParameters
     * @param joinPoint
     */
    private void populatePlainTmxArgumentParameters(Map<String, Object> tmxParameters, ProceedingJoinPoint joinPoint) {
        Object [] arguments = joinPoint.getArgs();
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        Annotation[][] parameterAnnotations = methodSignature.getMethod().getParameterAnnotations();

        for (int i = 0; i < arguments.length; i++ ) {
            final Object argument = arguments[i];
            if (!(argument instanceof TmxParametersExtractor)) {
                Optional<Annotation> tmxParameterAnnotation = Stream.of(parameterAnnotations[i]).
                        filter(a -> a.annotationType() == TmxParam.class).
                        findFirst();

                tmxParameterAnnotation.ifPresent(a -> {
                    TmxParam tmxParam = (TmxParam) a;
                    if (!StringUtils.isEmpty(tmxParam.key())) {
                        tmxParameters.put(tmxParam.key(), argument.toString());
                    }
                });
            }
        }
    }

    protected TmxProcessorService getTmxProcessorService() {
        return TmxProcessorService.getInstance();
    }
    protected ThreadLocalStore threadLocalStore() {
        return ThreadLocalStore.getInstance();
    }

}
