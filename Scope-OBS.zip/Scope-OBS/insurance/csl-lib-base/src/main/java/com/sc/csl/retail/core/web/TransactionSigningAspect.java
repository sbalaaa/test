package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.auth.TransactionSigning;
import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TspRequiredException;
import com.sc.csl.retail.core.exception.UnauthorizedException;
import com.sc.csl.retail.core.tsp.model.*;
import com.sc.csl.retail.core.tsp.service.ChallengeCodeService;
import com.sc.csl.retail.core.tsp.service.RiskAssessmentService;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;

import static com.sc.csl.retail.core.auth.TokenType.USER_PREFERRED;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.*;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Aspect
@Slf4j
public class TransactionSigningAspect {

    @Around("execution(* *(..)) && " +
            "(@annotation(com.sc.csl.retail.core.auth.TransactionSigning) " +
            "|| @within(com.sc.csl.retail.core.auth.TransactionSigning) )")
    public Object transactionSigning(ProceedingJoinPoint joinPoint) throws Throwable {

        TransactionSigning annotation = restrictedAccessAnnotation(joinPoint);
        CSLRequestContext requestContext = requestContext();
        ChallengeCode challengeCode = getChallengeCodeObject(joinPoint);
        //if the user is not ST user then SKIP this TSP flow
        if (isSoftTokenRequired(annotation)) {
            String challengeCodeHeader = requestContext.getChallengeCodeHeader();
            if (isNotBlank(challengeCodeHeader)) {
                String jsonString = new String(Base64.decodeBase64(challengeCodeHeader), UTF_8);
                if (isPrimaryOrOffline()) {
                    SoftTokenValidateDto softTokenValidateDto = CSLJsonUtils.parseJson(jsonString, SoftTokenValidateDto.class);
                    prepareOnlineOrOfflineTxnData(challengeCode, softTokenValidateDto);
                        softTokenValidateDto = postForChallengeCodeValidation(softTokenValidateDto);
                        if (softTokenValidateDto != null && StringUtils.equals(softTokenValidateDto.getValidationStatus(), VALIDATED)) {
                            return joinPoint.proceed();
                        } else if (StringUtils.equals(OFFLINE, requestContext.getDeviceMode())) {
                            return new TspRequiredException(postForChallengeCode(challengeCode),getErrorCode());
                        }
                } else {
                    HighRiskTokenValidateDto highRiskTokenValidateDto = CSLJsonUtils.parseJson(jsonString, HighRiskTokenValidateDto.class);
                    highRiskTokenValidateDto.setPushTxData(challengeCode.getPushTxData());
                    highRiskTokenValidateDto = postForHiRiskTransactionValidation(highRiskTokenValidateDto);
                    return joinPoint.proceed();
                }
            }
            //Call risk assessment API to know parent and required auth level
            RiskAccessLevel riskAccessLevel = requiredAccessLevel(annotation);
            if ((riskAccessLevel == null || riskAccessLevel.getRequiredAccessLevel() == null)) {
                log.info("Risk assessment data Not Found");
                throw new TechnicalException(RISK_ASSESSMENT_DATA_NOT_FOUND);
            }
            // Current auth level should be <=  required auth level, if not throw exception to caller and break the flow
            DecodedJWT internalAccessToken = getInternalAccessToken();
            int currentAuthLevel = authLevel(internalAccessToken);
            // TODO uncomment while commit code
            /*if (currentAuthLevel < riskAccessLevel.getParentAccessLevel().authLevel()) {
                log.info("Cannot perform TSP with current auth level {0}");
                throw new TechnicalException(TemplateErrorCode.create(TSP_REQUIRED_AUTH_LEVEL,
                        riskAccessLevel.getParentAccessLevel().name(), RiskAccessLevelAdopter.valueOfLevel(currentAuthLevel)));
            } */

            if (currentAuthLevel < riskAccessLevel.getRequiredAccessLevel().authLevel()) {
                throw new TspRequiredException(postForChallengeCode(challengeCode),getErrorCode());
            }
        }
        log.info("Logged in user is not a ST user..Skipping TSP..Allow txn to submit");
        return joinPoint.proceed();
    }

    public RiskAccessLevel requiredAccessLevel(TransactionSigning annotation) {
        if (annotation.riskAssessmentRequired()) {
            return fetchRiskAssessment(annotation.riskAssessmentId());
        }
        RiskAccessLevel riskAccessLevel = new RiskAccessLevel();
        riskAccessLevel.setRequiredAccessLevel(RiskAccessLevelAdopter.TRANSACTION_SIGNING);
        riskAccessLevel.setParentAccessLevel(RiskAccessLevelAdopter.TWO_FACTOR);
        return riskAccessLevel;
    }

    public void prepareOnlineOrOfflineTxnData(ChallengeCode challengeCode, SoftTokenValidateDto softTokenValidateDto) {
        if (challengeCode.getTxData() == null) {
            softTokenValidateDto.setPushTxData(challengeCode.getPushTxData());
        } else {
            softTokenValidateDto.setTxData(challengeCode.getTxData());
        }
    }


    private Integer authLevel(DecodedJWT internalAccessToken) {
        if (internalAccessToken == null) throw new UnauthorizedException(TOKEN_NOT_FOUND);
        return internalAccessToken.getClaim(AUTH_LEVEL_CLAIM).asInt();
    }

    TransactionSigning restrictedAccessAnnotation(ProceedingJoinPoint joinPoint) {
        return methodObject(joinPoint).getAnnotation(TransactionSigning.class);
    }

    private Method methodObject(ProceedingJoinPoint joinPoint) {
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        return methodSignature.getMethod();
    }

    private boolean isSoftTokenRequired(TransactionSigning annotation) {
        TokenType tokenType = annotation.tokenType();
        if (USER_PREFERRED.equals(tokenType)) {
            CSLRequestContext requestContext = requestContext();
            String preferredOtpType = requestContext.getPreferredOtpType();
            if (PREFERRED_TYPE_SOFT_TOKEN.equals(preferredOtpType)) {
                return true;
            }
        }
        return false;
    }

    private boolean isPrimaryOrOffline(){
        return  (StringUtils.equals(PRIMARY_DEVICE, requestContext().getDeviceMode())
               || StringUtils.equals(OFFLINE, requestContext().getDeviceMode())|| requestContext().getDeviceMode() == null);
    }

    private void prepareChallengeCode(ChallengeCode challengeCode) {
        if (isPrimaryOrOffline()) {
            challengeCode.setPushRequired(false);
            challengeCode.setTxData(new ArrayList(challengeCode.getPushTxData().values()));
            challengeCode.setPushTxData(null);
        } else {
            challengeCode.setPushRequired(true);
        }
    }

    CSLRequestContext requestContext() {
        return threadLocalStore().getRequestContext();
    }

    DecodedJWT getInternalAccessToken() {
        return threadLocalStore().getInternalAccessToken();
    }

    ThreadLocalStore threadLocalStore() {
        return ThreadLocalStore.getInstance();
    }


    private ChallengeCode getChallengeCodeObject(ProceedingJoinPoint joinPoint) {
        Map<String,String> txnData = null;
        Object[] arguments = joinPoint.getArgs();
        for (Object object : arguments) {
            if (object instanceof Map) {
                txnData = (Map<String,String>) object;
            }
        }
        if (txnData == null || txnData.isEmpty() ) {
            throw new TechnicalException(SOFT_TOKEN_CHALLENGE_OBJECT_REQUIRED);
        }
        ChallengeCode challengeCode = new ChallengeCode();
        challengeCode.setPushTxData(txnData);
        prepareChallengeCode(challengeCode);
        return challengeCode;
    }

    private RiskAccessLevel fetchRiskAssessment(String assessmentId) {
        RiskAssessmentDto riskAssessmentDto = RiskAssessmentService.getInstance().getRiskAssessmentAuthLevel(assessmentId);
        String reqAuthLevel = riskAssessmentDto.getAuthLevelConfiguration().get(0).getRiskAuthLevel().getRequiredAuthLevel();
        String parentAuthLevel = riskAssessmentDto.getAuthLevelConfiguration().get(0).getRiskAuthLevel().getParentAuthLevel();
        RiskAccessLevel riskAccessLevel = new RiskAccessLevel();
        riskAccessLevel.setRequiredAccessLevel(RiskAccessLevelAdopter.valueOf(reqAuthLevel));
        riskAccessLevel.setParentAccessLevel(RiskAccessLevelAdopter.valueOf(parentAuthLevel));
        return riskAccessLevel;
    }

    ChallengeCode postForChallengeCode(ChallengeCode challengeCode) {
        return ChallengeCodeService.getInstance().postForChallengeCode(challengeCode);
    }

    SoftTokenValidateDto postForChallengeCodeValidation(SoftTokenValidateDto softTokenValidateDto) {
        return ChallengeCodeService.getInstance().postForChallengeCodeValidation(softTokenValidateDto);
    }

    HighRiskTokenValidateDto postForHiRiskTransactionValidation(HighRiskTokenValidateDto highRiskTokenValidateDto) {
        return ChallengeCodeService.getInstance().postForHighRiskTransaction(highRiskTokenValidateDto);
    }

    private ErrorCode getErrorCode(){
        switch(requestContext().getDeviceMode()){
            case CSLConstants.PRIMARY_DEVICE :
                return SOFT_TOKEN_OTP_REQUIRED_PRIMARY;
            case CSLConstants.ONLINE :
                return SOFT_TOKEN_OTP_REQUIRED_ONLINE;
            case CSLConstants.OFFLINE :
                return SOFT_TOKEN_OTP_REQUIRED_OFFLINE;
            default:
                return SOFT_TOKEN_GENERIC_EXCEPTION;
        }
    }
}