package com.sc.csl.retail.core.web.header;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSLClient {
	private String clientRequestId;
	private String trueClientIP;
	private String sessionId;
	private String userAgent;
	private String channel;
	private String deviceTy;
}
