package com.sc.csl.retail.core.web.header;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSLHeader {
	private CSLUser user = new CSLUser();
	private CSLClient client = new CSLClient();
}
