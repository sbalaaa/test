package com.sc.csl.retail.core.web.header;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSLSoftTokenHeader {

     //  Added Soft Token attributes for identifying whether customer is softToken Registered or not
	private boolean softTokenRegistered;
	private boolean deviceRegistered;

}
