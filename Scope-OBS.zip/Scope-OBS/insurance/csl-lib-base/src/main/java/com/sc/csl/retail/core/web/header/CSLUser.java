package com.sc.csl.retail.core.web.header;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSLUser {
	private String uaas2id;
	private String relId;
	private String country;
	private String language;
	private String segCd;

	private String clientId;

	public CSLUser(String uaas2id, String relId, String country, String language, String segCd) {
		this.uaas2id = uaas2id;
		this.relId = relId;
		this.country = country;
		this.language = language;
		this.segCd = segCd;
	}
}
