package com.sc.csl.retail.core.web.header;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSLUserInfo {
	@JsonProperty(value = "ROLE")
    List<String> roles;
}
