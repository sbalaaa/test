package com.sc.csl.retail.core.web.request;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;
import java.util.Map;

public class JaxrsRequestAdaptor implements RequestAdaptor {
	private ContainerRequestContext requestContext;

	public JaxrsRequestAdaptor(ContainerRequestContext requestContext) {
		this.requestContext = requestContext;
	}

	@Override
	public String getHeader(String key) {
		return requestContext.getHeaderString(key);
	}

	@Override
	public String getCookie(String key) {
		Map<String, Cookie> cookies = requestContext.getCookies();
		Cookie cookie = cookies.get(key);
		return cookie == null ? null : cookie.getValue();
	}

	@Override
	public String getQueryParam(String key) {
		UriInfo uriInfo = requestContext.getUriInfo();
		MultivaluedMap<String, String> queryParameters = uriInfo.getQueryParameters();
		return queryParameters.getFirst(key);
	}
}
