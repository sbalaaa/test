package com.sc.csl.retail.core.web.request;

public interface RequestAdaptor {
	String getHeader(String key);
	String getCookie(String key);
	String getQueryParam(String key);
}
