package com.sc.csl.retail.core.web.request;

import org.springframework.web.util.WebUtils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class SpringRequestAdaptor implements RequestAdaptor {
	private HttpServletRequest request;

	public SpringRequestAdaptor(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public String getHeader(String key) {
		return request.getHeader(key);
	}

	@Override
	public String getCookie(String key) {
		Cookie cookie = WebUtils.getCookie(request, key);
		return (cookie == null) ? null : cookie.getValue();
	}

	@Override
	public String getQueryParam(String key) {
		return request.getParameter(key);
	}
}
