package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.mask.Mask;
import com.sc.csl.retail.core.mask.MaskConstant;
import com.sc.csl.retail.core.mask.Maskable;
import lombok.Data;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;

import java.io.Serializable;
import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;

public class LogFormatAspectTest {
    private ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    private MethodSignature methodSignature = mock(MethodSignature.class);
    private Object[] args;
    private LogFormatAspect logFormatAspect;
    private String message;

    @Before
    public void setup() throws NoSuchMethodException {
    	logFormatAspect = new LogFormatAspect() ;
        when(joinPoint.getSignature()).thenReturn(methodSignature);
        when(joinPoint.getTarget()).thenReturn(new LogFormatAspectTest());
        message ="My 16 DIGIT credit card no : 1234123412341234";
    }

    @Test
    public void should_mask_logWithMessage() throws Throwable {
    	
    	LogTestDto logDataObj = new LogTestDto();
		args = new Object[] { null, logDataObj };
		when(joinPoint.getArgs()).thenReturn(args);
		logFormatAspect.logMessage(message, joinPoint);
		
		String expected = "{\"serialNo\":\"12345\",\"logDateTime\":\"1499249832555\",\"creditCardNo\":\"1234123412341234\",\"accountNo\":\"123412341234\","
				+ "\"tokenNum\":null,\"debitAccNum\":\"******\",\"creditAccNum\":\"*******************0123\""
						+ ",\"account\":{\"seedNum\":\"23432423423\",\"otpNumber\":null,\"opaque\":null,"
						+ "\"debitAccNumCr\":\"******\",\"creditAccNumCr\":\"***********************\","
						+ "\"trans\":{\"transNo\":\"*********\",\"date\":\"12/10/2025\","
						+ "\"tranArr\":[\"**\",\"**\",\"**\"],\"tranStrArr\":[\"**\",\"**\",\"**\"],\"transList\":[\"*****\",\"****\"]"
						+ ",\"remarksDto\":[{\"remarks\":\"********\",\"date\":\"date1\"},{\"remarks\":\"**********\",\"date\":\"date1\"}]}}}";

		verifyMessage ( expected, (String)args[1] );
		assertThat( (String)args[0] , containsString( message ));

    }
    
    @Test
    public void should_mask_logWithException() throws Throwable {
    	
    	LogTestDto logDataObj = new LogTestDto();
		args = new Object[] { null, logDataObj };
		when(joinPoint.getArgs()).thenReturn(args);
		logFormatAspect.logException(message, null, joinPoint);
		
		String expected = "{\"serialNo\":\"12345\",\"logDateTime\":\"1499249832555\",\"creditCardNo\":\"1234123412341234\",\"accountNo\":\"123412341234\","
				+ "\"tokenNum\":null,\"debitAccNum\":\"******\",\"creditAccNum\":\"*******************0123\""
						+ ",\"account\":{\"seedNum\":\"23432423423\",\"otpNumber\":null,\"opaque\":null,"
						+ "\"debitAccNumCr\":\"******\",\"creditAccNumCr\":\"***********************\","
						+ "\"trans\":{\"transNo\":\"*********\",\"date\":\"12/10/2025\","
						+ "\"tranArr\":[\"**\",\"**\",\"**\"],\"tranStrArr\":[\"**\",\"**\",\"**\"],\"transList\":[\"*****\",\"****\"]"
						+ ",\"remarksDto\":[{\"remarks\":\"********\",\"date\":\"date1\"},{\"remarks\":\"**********\",\"date\":\"date1\"}]}}}";

		verifyMessage ( expected, (String)args[1] );
		assertThat( (String)args[0] , containsString( message ));
    }
    
    private void verifyMessage(String expected, String actual) throws Throwable {
    	assertEquals( expected ,  actual );
        verify(joinPoint, atLeastOnce()).proceed(args);
    }
}

@Maskable
@Data
class LogTestDto extends BaseLogTestDto {

	private String creditCardNo = "1234123412341234";
	private String accountNo ="123412341234";
	
	@Mask 
	private String tokenNum;
	
	@Mask
	private int debitAccNum = 123456;
	
	@Mask( regex= MaskConstant.PATTERN_DIGITS_23, replacement=MaskConstant.MASK_PATTERN_DIGITS_23 )
	private String creditAccNum = "12345678901234567890123";
	
	@Mask
	private AccountTestDto account = new AccountTestDto();
	
	{
		this.logDateTime = 1499249832555l; //System.currentTimeMillis();
	}
	
}

@Data
@Maskable
class BaseLogTestDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1234233432L;

	@Mask
	protected static int serialNo = 12345;
	
	protected long logDateTime;
}

@Maskable
@Data
class AccountTestDto {
	
	private String seedNum = "23432423423";
	private String otpNumber;
	
	@Mask 
	private String opaque;
	
	@Mask
	private int debitAccNumCr = 123456;
	
	@Mask
	private String creditAccNumCr = "12345678901234567890123";
	
	@Mask
	private TransactionTestDto trans = new TransactionTestDto();
}

@Maskable
class TransactionTestDto {
	
	@Mask
	private int transNo = 927921389;
	private String date = "12/10/2025";
	
	@Mask
	private int[] tranArr = {55,66,77};
	
	@Mask
	private Object[] tranStrArr = {"55","hi","77"};
	
	@Mask
	private ArrayList<Integer> transList = new ArrayList<Integer>();
	{
		transList.add(12345);
		transList.add(new Integer(4567));
	}
	
	@Mask
	private ArrayList<RemarksDto> remarksDto = new ArrayList<RemarksDto>();
	{
		RemarksDto rdto1 = new RemarksDto();
		rdto1.setRemarks("Personal");
		remarksDto.add(rdto1);
		
		RemarksDto rdto2 = new RemarksDto();
		rdto2.setRemarks("to-starhub");
		remarksDto.add(rdto2);
		
	}
	

}

@Maskable
@Data
class RemarksDto {
	
	@Mask 
	private String remarks;
	
	private String date ="date1";
}

