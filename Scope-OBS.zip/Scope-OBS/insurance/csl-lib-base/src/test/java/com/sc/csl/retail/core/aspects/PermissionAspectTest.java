package com.sc.csl.retail.core.aspects;

import com.sc.csl.retail.core.exception.ForbiddenException;
import com.sc.csl.retail.core.fap.FapGateway;
import com.sc.csl.retail.core.fap.annotation.Permission;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Map;

import static junit.framework.TestCase.fail;
import static org.mockito.Mockito.*;

@Permission
public class PermissionAspectTest {

    PermissionAspect permissionAspect;
    HttpServletRequest mockServletRequest;
    ProceedingJoinPoint mockProceddingJoinPoint;
    String mockUserInput ="{\"ROLE\":[\"RM\"]}";

    @Before
    public void setUp() throws Exception {
        mockProceddingJoinPoint = mock(ProceedingJoinPoint.class);
        when(mockProceddingJoinPoint.getTarget()).thenReturn(new PermissionAspectTest());
        mockServletRequest = mock(HttpServletRequest.class);
    }

    @Test
    public void test_If_FapGatway_Is_Disabled() throws Throwable {
        permissionAspect = new PermissionAspect();
        FapGateway fapGateway = permissionAspect.getFapGateway();
        fapGateway.setEnabled(false);
        permissionAspect.around(mockProceddingJoinPoint);
        try {
            verify(mockProceddingJoinPoint, times(1)).proceed();
        } catch (Throwable throwable) {
            fail(throwable.getMessage());
        }
    }


    @Test(expected = ForbiddenException.class)
    public void should_Throw_Exception_if_token_is_Null() throws Throwable {
        permissionAspect = new PermissionAspect() {
            @Override
            HttpServletRequest getCurrentHttpServletRequest() {
                return mockServletRequest;
            }
        };

        permissionAspect.around(mockProceddingJoinPoint);
    }


    @Test
    public void should_be_successful_If_User_Sent_In_Plain_Json() throws Throwable {
        permissionAspect = new PermissionAspect() {
            String header = "{\"ROLE\":[\"RM\"]}";

            @Override
            HttpServletRequest getCurrentHttpServletRequest() {
                when(mockServletRequest.getHeader("CSL-USER-INFO")).thenReturn(header);
                return mockServletRequest;
            }

            @Override
            FapGateway getFapGateway() {
                FapGateway fapGateway = mock(FapGateway.class);
                when(fapGateway.isEnabled()).thenReturn(true);
                String mockJsonResponseStr = "{\"hasPermission\":true,\"appName\":\"RDC\",\"action\":\"VIEW\"}";
                Map<String, Object> mockJsonResponse = CSLJsonUtils.parseJson(mockJsonResponseStr, Map.class);
                when(fapGateway.hasPermission(mockUserInput, "RDC", "permName", "VIEW")).thenReturn(mockJsonResponse);
                return fapGateway;
            }
        };

        MethodSignature mockMethodSignature = mock(MethodSignature.class);
        when(mockProceddingJoinPoint.getSignature()).thenReturn(mockMethodSignature);
        when(mockMethodSignature.getMethod()).thenReturn(myMethod("sampleMethod"));
        permissionAspect.around(mockProceddingJoinPoint);
        try {
            verify(mockProceddingJoinPoint, times(1)).proceed();
        } catch (Throwable throwable) {
            fail(throwable.getMessage());
        }
    }

    // mock methods
    Method myMethod(String methodName) throws Exception {
        return getClass().getDeclaredMethod(methodName);
    }

    @Permission(permissionName = "permName", requiredAction = "VIEW")
    public void sampleMethod() {
    }

}