package com.sc.csl.retail.core.config;

import org.junit.Test;

import static org.junit.Assert.*;

public class FapConfigTest {
    @Test
    public void should_return_singleton_fapgateway() {
        FapConfig fapConfig = new FapConfig();
        assertNotNull(fapConfig.fapGateway());
    }
}