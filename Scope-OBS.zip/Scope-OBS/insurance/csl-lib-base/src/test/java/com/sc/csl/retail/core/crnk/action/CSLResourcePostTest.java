package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.crnk.core.engine.dispatcher.Response;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.internal.dispatcher.path.JsonPath;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.internal.repository.ResourceRepositoryAdapter;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.NullPropertiesProvider;
import io.crnk.core.engine.query.QueryAdapter;
import io.crnk.core.engine.registry.RegistryEntry;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.repository.response.JsonApiResponse;
import io.crnk.core.utils.Nullable;
import io.crnk.legacy.internal.RepositoryMethodParameterProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Collections;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ CSLResourcePost.class })
public class CSLResourcePostTest {
    CSLResourcePost cslResourcePost;
    SidePostDocumentMapper sidePostDocumentMapper;
    ResourceRegistry resourceRegistry;
    TypeParser typeParser;
    ObjectMapper objectMapper;
    DocumentMapper documentMapper;

    @Before
    public void setup() throws Exception {
        sidePostDocumentMapper = mock(SidePostDocumentMapper.class);
        whenNew(SidePostDocumentMapper.class).withAnyArguments().thenReturn(sidePostDocumentMapper);

        resourceRegistry = mock(ResourceRegistry.class);
        typeParser = mock(TypeParser.class);
        objectMapper = mock(ObjectMapper.class);
        documentMapper = mock(DocumentMapper.class);
        cslResourcePost = spy(new CSLResourcePost(resourceRegistry, new NullPropertiesProvider(), typeParser, objectMapper, documentMapper, Collections.emptyList()));
    }


    @Test(expected = IllegalStateException.class)
    public void should_throw_IllegalStateException_for_handle() {
        JsonPath jsonPath = mock(JsonPath.class);
        when(jsonPath.getResourceType()).thenReturn("");
        QueryAdapter queryAdapter = mock(QueryAdapter.class);
        RepositoryMethodParameterProvider parameterProvider = mock(RepositoryMethodParameterProvider.class);
        Document document = mock(Document.class);

        Object result = new Object();
        RegistryEntry endpointRegistryEntry = mock(RegistryEntry.class);
        ResourceRepositoryAdapter resourceRepositoryAdapter = mock(ResourceRepositoryAdapter.class);
        JsonApiResponse jsonApiResponse = mock(JsonApiResponse.class);

        when(jsonApiResponse.getEntity()).thenReturn(null);
        when(resourceRepositoryAdapter.create(any(Object.class), any(QueryAdapter.class))).thenReturn(jsonApiResponse);
        when(endpointRegistryEntry.getResourceRepository(any(RepositoryMethodParameterProvider.class))).thenReturn(resourceRepositoryAdapter);
        when(sidePostDocumentMapper.fromDocument(eq(document), eq(false))).thenReturn(result);
        when(resourceRegistry.getEntry(any(Class.class))).thenReturn(endpointRegistryEntry);
        when(resourceRegistry.getEntry(anyString())).thenReturn(endpointRegistryEntry);
        cslResourcePost.handle(jsonPath, queryAdapter, parameterProvider, document);
    }

    @Test
    public void should_return_resource_for_handle() {
        JsonPath jsonPath = mock(JsonPath.class);
        when(jsonPath.getResourceType()).thenReturn("");
        QueryAdapter queryAdapter = mock(QueryAdapter.class);
        RepositoryMethodParameterProvider parameterProvider = mock(RepositoryMethodParameterProvider.class);
        Document document = mock(Document.class);

        Object result = new Object();
        RegistryEntry endpointRegistryEntry = mock(RegistryEntry.class);
        ResourceRepositoryAdapter resourceRepositoryAdapter = mock(ResourceRepositoryAdapter.class);
        JsonApiResponse jsonApiResponse = mock(JsonApiResponse.class);


        Resource resource = mock(Resource.class);
        when(jsonApiResponse.getEntity()).thenReturn(new Object());
        when(resourceRepositoryAdapter.create(any(Object.class), any(QueryAdapter.class))).thenReturn(jsonApiResponse);
        when(endpointRegistryEntry.getResourceRepository(any(RepositoryMethodParameterProvider.class))).thenReturn(resourceRepositoryAdapter);
        when(sidePostDocumentMapper.fromDocument(eq(document), eq(false))).thenReturn(result);
        when(resourceRegistry.getEntry(any(Class.class))).thenReturn(endpointRegistryEntry);
        when(resourceRegistry.getEntry(anyString())).thenReturn(endpointRegistryEntry);
        when(document.getData()).thenReturn(Nullable.of(new Resource()));
        Response resp = cslResourcePost.handle(jsonPath, queryAdapter, parameterProvider, document);
        assertNotNull(resp);
        assertEquals(Integer.valueOf(201), resp.getHttpStatus());
    }
}
