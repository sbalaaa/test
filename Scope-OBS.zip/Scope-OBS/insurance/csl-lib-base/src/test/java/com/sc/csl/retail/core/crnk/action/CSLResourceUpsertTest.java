package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.document.ResourceIdentifier;
import io.crnk.core.engine.information.resource.ResourceInformation;
import io.crnk.core.engine.information.resource.ResourceInstanceBuilder;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.internal.repository.ResourceRepositoryAdapter;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.NullPropertiesProvider;
import io.crnk.core.engine.query.QueryAdapter;
import io.crnk.core.engine.registry.RegistryEntry;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.exception.RepositoryNotFoundException;
import io.crnk.core.repository.response.JsonApiResponse;
import io.crnk.core.utils.Nullable;
import io.crnk.legacy.internal.RepositoryMethodParameterProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;
import static org.powermock.api.mockito.PowerMockito.verifyPrivate;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CSLResourceUpsert.class})
public class CSLResourceUpsertTest {
    @InjectMocks
    CSLResourceUpsert cslResourceUpsert;

    ResourceRegistry resourceRegistry;
    TypeParser typeParser;
    ObjectMapper objectMapper;
    DocumentMapper documentMapper;

    @Mock(name = "resourceMap")
    Map<String, Object> resourceMap = mock(HashMap.class);

    @Before
    public void setup() {
        resourceRegistry = mock(ResourceRegistry.class);
        typeParser = mock(TypeParser.class);
        objectMapper = mock(ObjectMapper.class);
        documentMapper = mock(DocumentMapper.class);
        cslResourceUpsert = spy(new CSLResourceUpsert(resourceRegistry, new NullPropertiesProvider(), typeParser, objectMapper, documentMapper, Collections.emptyList()));
    }


    @Test(expected = UnsupportedOperationException.class)
    public void shold_throw_unsuppoerted_exception_for_isAcceptable() {
        cslResourceUpsert.isAcceptable(null, null);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void shold_throw_unsuppoerted_exception_for_handle() {
        cslResourceUpsert.handle(null, null, null, null);
    }

    @Test
    public void should_return_entity_for_fetchRelated() {
        ResourceInformation resourceInformation = mock(ResourceInformation.class);
        RegistryEntry entry = mock(RegistryEntry.class);
        String relationId = "123456";

        RepositoryMethodParameterProvider parameterProvider = mock(RepositoryMethodParameterProvider.class);
        QueryAdapter queryAdapter = mock(QueryAdapter.class);
        ResourceRepositoryAdapter resourceRepositoryAdapter = mock(ResourceRepositoryAdapter.class);
        JsonApiResponse jsonApiResponse = mock(JsonApiResponse.class);

        when(jsonApiResponse.getEntity()).thenReturn(null);
        when(resourceRepositoryAdapter.findOne(relationId, queryAdapter)).thenReturn(jsonApiResponse);
        when(entry.getResourceInformation()).thenReturn(resourceInformation);
        when(entry.getResourceRepository(parameterProvider)).thenReturn(resourceRepositoryAdapter);

        cslResourceUpsert.fetchRelatedObject(entry, relationId, parameterProvider, queryAdapter);

        verify(resourceRepositoryAdapter, times(1)).findOne(relationId, queryAdapter);
        verify(entry, times(1)).getResourceInformation();
        verify(entry, times(1)).getResourceRepository(parameterProvider);
        verify(jsonApiResponse, times(1)).getEntity();
    }

    @Test
    public void should_return_entity_for_fetchRelatedNonEmptyMap() {
        initMocks(this);
        ResourceInformation resourceInformation = mock(ResourceInformation.class);
        RegistryEntry entry = mock(RegistryEntry.class);
        String relationId = "123456";

        RepositoryMethodParameterProvider parameterProvider = mock(RepositoryMethodParameterProvider.class);
        QueryAdapter queryAdapter = mock(QueryAdapter.class);
        ResourceRepositoryAdapter resourceRepositoryAdapter = mock(ResourceRepositoryAdapter.class);
        JsonApiResponse jsonApiResponse = mock(JsonApiResponse.class);

        Object expected = new Object();

        when(jsonApiResponse.getEntity()).thenReturn(null);
        when(resourceRepositoryAdapter.findOne(relationId, queryAdapter)).thenReturn(jsonApiResponse);
        when(entry.getResourceInformation()).thenReturn(resourceInformation);
        when(entry.getResourceRepository(parameterProvider)).thenReturn(resourceRepositoryAdapter);

        when(resourceMap.get(any(String.class))).thenReturn(expected);
        Object result = cslResourceUpsert.fetchRelatedObject(entry, relationId, parameterProvider, queryAdapter);

        verify(entry, times(1)).getResourceInformation();
        assertTrue(result == expected);
    }


    @Test
    public void should_return_string_id_forGetUid() {
        ResourceIdentifier resourceIdentifier = mock(ResourceIdentifier.class);
        when(resourceIdentifier.getType()).thenReturn("SampleType");
        when(resourceIdentifier.getId()).thenReturn("123");
        assertEquals("SampleType#123", cslResourceUpsert.getUID(resourceIdentifier));
    }

    @Test
    public void should_return_null_for_fromDocument() {
        ResourceIdentifier resourceIdentifier = mock(ResourceIdentifier.class);
        Document document = mock(Document.class);
        Nullable<Object> nullable = Nullable.empty();
        when(document.getData()).thenReturn(nullable);
        assertNull(cslResourceUpsert.fromDocument(document));
    }


    @Test(expected = RepositoryNotFoundException.class)
    public void should_throw_exception_fromDocument() {
        ResourceIdentifier resourceIdentifier = mock(ResourceIdentifier.class);
        Document document = mock(Document.class);
        Nullable<Object> nullable = Nullable.of(new Object());
        Resource resource = mock(Resource.class);
        when(document.getData()).thenReturn(nullable);
        when(document.getIncluded()).thenReturn(null);
        when(document.getCollectionData()).thenReturn(Nullable.of(Arrays.asList(resource)));

        assertNull(cslResourceUpsert.fromDocument(document));
    }

    @Test
    public void should_return_resource_fromDocument() {
        ResourceIdentifier resourceIdentifier = mock(ResourceIdentifier.class);
        Document document = mock(Document.class);
        Nullable<Object> nullable = Nullable.of(new Object());
        Resource resource = mock(Resource.class);
        when(document.getData()).thenReturn(nullable);
        when(document.getIncluded()).thenReturn(null);
        when(document.getCollectionData()).thenReturn(Nullable.of(Arrays.asList(resource)));


        cslResourceUpsert = new CSLResourceUpsert(resourceRegistry, new NullPropertiesProvider(), typeParser, objectMapper, documentMapper, Collections.emptyList()) {
            public List<Object> allocateResources(List<Resource> resources) {
                ArrayList objects = new ArrayList();
                objects.add(resource);
                return objects;
            }
            public void setRelations(List<Resource> resources) {
            }

        };
        assertTrue(resource == cslResourceUpsert.fromDocument(document));
    }

    @Test
    public void should_return_null_fromDocument() {
        ResourceIdentifier resourceIdentifier = mock(ResourceIdentifier.class);
        Document document = mock(Document.class);
        Nullable<Object> nullable = Nullable.of(new Object());
        Resource resource = mock(Resource.class);
        when(document.getData()).thenReturn(nullable);
        when(document.getIncluded()).thenReturn(Collections.emptyList());
        when(document.getCollectionData()).thenReturn(Nullable.of(Arrays.asList(resource)));


        cslResourceUpsert = new CSLResourceUpsert(resourceRegistry, new NullPropertiesProvider(), typeParser, objectMapper, documentMapper, Collections.emptyList()) {
            public List<Object> allocateResources(List<Resource> resources) {
                return new ArrayList();
            }

            public void setRelations(List<Resource> resources) {
            }

        };
        assertNull(cslResourceUpsert.fromDocument(document));
    }

    @Test
    public void should_call_protected_setRelations() throws Exception {
        initMocks(this);
        Object expected = new Object();
        Resource resource = mock(Resource.class);
        ArrayList objects = new ArrayList();
        objects.add(resource);
        when(resource.getType()).thenReturn("SampleType");
        when(resource.getId()).thenReturn("123");
        when(resourceMap.get(any(String.class))).thenReturn(expected);

        cslResourceUpsert.setRelations(objects) ;

        verify(resourceMap).get("SampleType#123");
        verify(resourceRegistry, times(1)).getEntry("SampleType");
        verifyPrivate(cslResourceUpsert, times(1)).invoke("setRelations",
                any(Object.class), eq(null), any(Resource.class), eq(null), eq(null), eq(true)
        );
    }


    @Test(expected = RepositoryNotFoundException.class)
    public void should_throw_RepositoryNotFoundException() throws Exception {
        initMocks(this);
        Object expected = new Object();
        Resource resource = mock(Resource.class);
        ArrayList objects = new ArrayList();
        objects.add(resource);

        cslResourceUpsert.allocateResources(objects) ;
    }


    @Test
    public void should_allocateResources() throws Exception {
        initMocks(this);
        Object expected = new Object();
        Resource resource = mock(Resource.class);
        ArrayList objects = new ArrayList();
        objects.add(resource);

        Object resourceObject = new Object();

        when(resource.getType()).thenReturn("SampleType");
        when(resource.getAttributes()).thenReturn(null);
        when(resource.getId()).thenReturn(null);
        ResourceInstanceBuilder resourceInstanceBuilder = mock(ResourceInstanceBuilder.class);
        RegistryEntry registryEntry = mock(RegistryEntry.class);
        ResourceInformation resourceInformation = mock(ResourceInformation.class);

        when(resourceInstanceBuilder.buildResource(any(Resource.class))).thenReturn(resourceObject);

        when(resourceInformation.getInstanceBuilder()).thenReturn(resourceInstanceBuilder);
        when(resourceRegistry.getEntry(any(String.class))).thenReturn(registryEntry);
        when(registryEntry.getResourceInformation()).thenReturn(resourceInformation);

        List<?> answer = cslResourceUpsert.allocateResources(objects);

        verify(resourceRegistry, times(1)).getEntry(eq("SampleType"));
        verify(registryEntry, times(1)).getResourceInformation();
        verify(resourceMap).put(eq("SampleType#null"), any(Object.class));
        assertTrue(answer.size() == 1);
        assertTrue(answer.get(0) == resourceObject);

    }
}
