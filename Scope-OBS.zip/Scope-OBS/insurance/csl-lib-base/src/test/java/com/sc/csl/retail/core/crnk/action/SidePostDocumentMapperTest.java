package com.sc.csl.retail.core.crnk.action;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.ErrorDataBuilder;
import io.crnk.core.engine.document.Resource;
import io.crnk.core.engine.filter.ResourceFilterDirectory;
import io.crnk.core.engine.internal.document.mapper.DocumentMapper;
import io.crnk.core.engine.parser.TypeParser;
import io.crnk.core.engine.properties.PropertiesProvider;
import io.crnk.core.engine.registry.ResourceRegistry;
import io.crnk.core.resource.list.DefaultResourceList;
import io.crnk.core.utils.Nullable;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SidePostDocumentMapper.class })
public class SidePostDocumentMapperTest {

    ResourceRegistry resourceRegistry;
    PropertiesProvider propertiesProvider;
    TypeParser typeParser;
    SidePostDocumentMapper cslDocumentMapper;
    ResourceFilterDirectory resourceFilterDirectory;
    DocumentMapper documentMapper;

    @Before
    public void setup() {
        resourceRegistry = mock(ResourceRegistry.class);
        propertiesProvider = mock(PropertiesProvider.class);
        typeParser = mock(TypeParser.class);
        resourceFilterDirectory = mock(ResourceFilterDirectory.class);
        documentMapper = mock(DocumentMapper.class);
        ResourceFilterDirectory filterBehaviorManager = mock(ResourceFilterDirectory.class);
        when(documentMapper.getFilterBehaviorManager()).thenReturn(filterBehaviorManager);

        cslDocumentMapper = new SidePostDocumentMapper(resourceRegistry, CSLJsonUtils.newObjectMapper(), propertiesProvider, typeParser, documentMapper);
    }

    @Test
    public void testFromDocumentError() {
        try {
            Document document = new Document();
            document.setErrors(Arrays.asList(new ErrorDataBuilder().setId("sampleError").build()));
            cslDocumentMapper.fromDocument(document, true);
            fail("Failed as IllegalStateException should be thrown.");
        } catch (Exception e) {
            assertEquals(IllegalStateException.class, e.getClass());
        }
    }

    @Test
    public void testFromDocumentNonEmptyData() {
        Document document = new Document();
        assertNull(cslDocumentMapper.fromDocument(document, true));
    }

    @Test
    public void should_return_DefaultResourceList_fromDocument() {
        List<Resource> dataList = new ArrayList<>();
        Nullable<List<Resource>> data = Nullable.of(dataList);

        Document document = mock(Document.class);
        ObjectNode objectNode = mock(ObjectNode.class);

        when(document.getData()).thenReturn(Nullable.of(new Object()));
        when(document.getIncluded()).thenReturn(null);
        when(document.getCollectionData()).thenReturn(data);
        when(document.getLinks()).thenReturn(objectNode);
        when(document.getMeta()).thenReturn(objectNode);

        Object result  = cslDocumentMapper.fromDocument(document, true);
        assertNotNull(result);
        assertEquals(result.getClass(), DefaultResourceList.class);
        DefaultResourceList defaultResourceList = (DefaultResourceList) result;
        assertNotNull(defaultResourceList.getMeta());
        assertNotNull(defaultResourceList.getLinks());
    }

    @Test(expected = IllegalStateException.class)
    public void should_throw_IllegalStateException_fromDocument() throws Exception {
        List<Object> dataList = new ArrayList<>();
        dataList.add(new Object());
        dataList.add(new Object());

        Document document = mock(Document.class);
        when(document.getData()).thenReturn(Nullable.of(new Object()));
        when(document.getIncluded()).thenReturn(Collections.emptyList());
        when(document.getCollectionData()).thenReturn( Nullable.of(Collections.emptyList()));

        CSLResourceUpsert cslResourceUpsert = mock(CSLResourceUpsert.class);
        doReturn(dataList).when(cslResourceUpsert).allocateResources(any(List.class));
        whenNew(CSLResourceUpsert.class).withAnyArguments().thenReturn(cslResourceUpsert);
        cslDocumentMapper.fromDocument(document, false);
    }

    @Test
    public void should_return_fromDocument() throws Exception {
        Object result = new Object();
        List<Object> dataList = new ArrayList<>();
        dataList.add(result);

        Document document = mock(Document.class);
        when(document.getData()).thenReturn(Nullable.of(new Object()));
        when(document.getIncluded()).thenReturn(Collections.emptyList());
        when(document.getCollectionData()).thenReturn( Nullable.of(Collections.emptyList()));

        CSLResourceUpsert cslResourceUpsert = mock(CSLResourceUpsert.class);
        doReturn(dataList).when(cslResourceUpsert).allocateResources(any(List.class));
        whenNew(CSLResourceUpsert.class).withAnyArguments().thenReturn(cslResourceUpsert);
        assertTrue(result == cslDocumentMapper.fromDocument(document, false));
    }

    @Test
    public void should_return_null_fromDocument() throws Exception {
        List<Object> dataList = new ArrayList<>();

        Document document = mock(Document.class);
        when(document.getData()).thenReturn(Nullable.of(new Object()));
        when(document.getIncluded()).thenReturn(Collections.emptyList());
        when(document.getCollectionData()).thenReturn( Nullable.of(Collections.emptyList()));

        CSLResourceUpsert cslResourceUpsert = mock(CSLResourceUpsert.class);
        doReturn(dataList).when(cslResourceUpsert).allocateResources(any(List.class));
        whenNew(CSLResourceUpsert.class).withAnyArguments().thenReturn(cslResourceUpsert);

        assertNull(cslDocumentMapper.fromDocument(document, false));
    }

}
