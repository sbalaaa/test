package com.sc.csl.retail.core.edmi;

import com.webmethods.jms.impl.WmConnectionFactoryImpl;
import com.webmethods.jms.impl.WmConnectionImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Properties;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.verifyNew;
import static org.powermock.api.mockito.PowerMockito.whenNew;

@RunWith(PowerMockRunner.class)
@PrepareForTest(EDMiConnectionFactory.class)
public class EDMiConnectionFactoryTest {

    private EDMiConnectionFactory edMiConnectionFactory;
    private WmConnectionFactoryImpl factory;
    private WmConnectionImpl connection;
    private InitialContext context;

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);

        connection = mock(WmConnectionImpl.class);

        factory = mock(WmConnectionFactoryImpl.class);
        when(factory.createConnection()).thenReturn(connection);
        when(factory.createConnection(anyString(), anyString())).thenReturn(connection);

        context = mock(InitialContext.class);
        when(context.lookup(anyString())).thenReturn(factory);
    }

    //@Test
    public void testSslTrustStorePathClasspath_OK() throws Exception {
        edMiConnectionFactory = new EDMiConnectionFactory();
        edMiConnectionFactory.setSslTrustStore("classpath:truststore/edmi.jks");
        edMiConnectionFactory.setupSslTrustStore(factory);

        String currentDir = System.getProperty("user.dir");
        String subpath = "target/test-classes";
        verify(factory).setSSLTruststore(currentDir + "/" + subpath + "/" + "truststore/edmi.jks");
    }

    @Test
    public void testSslTrustStorePathGlobal_OK() throws Exception {
        edMiConnectionFactory = new EDMiConnectionFactory();

        edMiConnectionFactory.setSslTrustStore("/jboss/truststore/edmi.jks");
        edMiConnectionFactory.setupSslTrustStore(factory);
        verify(factory).setSSLTruststore("/jboss/truststore/edmi.jks");
    }

    @Test
    public void testSslTrustStorePath_Fail() {
        try {
            edMiConnectionFactory = new EDMiConnectionFactory();

            edMiConnectionFactory.setSslTrustStore("classpath:truststore/edmi1.jks");
            edMiConnectionFactory.setupSslTrustStore(factory);
            fail("Should fail because file does not exist.");
        } catch (Exception e) {
            assertEquals(JMSException.class, e.getClass());
        }
    }

    @Test
    public void createConnectionTestNoCredentials() throws Exception {
        edMiConnectionFactory = new EDMiConnectionFactory() {
            InitialContext createInitialContext() throws NamingException {
                return context;
            }

            ConnectionFactory lookupConnectionFactory(InitialContext context) throws NamingException, JMSException {
                return factory;
            }
        };
        edMiConnectionFactory.setClientId("sample-client-id");

        edMiConnectionFactory.createConnection();

        verify(connection).setClientID("sample-client-id");
        verify(context).close();
        verify(factory).createConnection();
    }

    @Test
    public void lookupConnectionTest() throws Exception {
        edMiConnectionFactory = new EDMiConnectionFactory() {
            InitialContext createInitialContext() throws NamingException {
                return context;
            }
        };
        edMiConnectionFactory.setJndiName("sample-jndi-name");
        edMiConnectionFactory.setSslTrustStore("classpath:truststore/edmi.jks");
        assertEquals(factory, edMiConnectionFactory.lookupConnectionFactory(context));
        verify(context).lookup("sample-jndi-name");
    }

    @Test
    public void createConnectionTestWithCredentials() throws Exception {
        edMiConnectionFactory = new EDMiConnectionFactory() {
            InitialContext createInitialContext() throws NamingException {
                return context;
            }

            ConnectionFactory lookupConnectionFactory(InitialContext context) throws NamingException, JMSException {
                return factory;
            }
        };
        edMiConnectionFactory.setClientId("sample-client-id");

        edMiConnectionFactory.setUserName("user");
        edMiConnectionFactory.setPassword("password");

        edMiConnectionFactory.createConnection();

        verify(connection).setClientID("sample-client-id");
        verify(context).close();
        verify(factory).createConnection("user", "password");
    }

    @Test
    public void should_createInitial_context() throws Exception {
        whenNew(InitialContext.class).withArguments(any(Properties.class)).thenReturn(null);
        ArgumentCaptor<Properties> argument = ArgumentCaptor.forClass(Properties.class);

        edMiConnectionFactory = new EDMiConnectionFactory();
        edMiConnectionFactory.setClientId("sample-client-id");
        edMiConnectionFactory.setBrokerUrl("wmjmsnaming://EDMI951UAT_JNDI01@10.20.175.75:6712/EDMIFramework");
        edMiConnectionFactory.setUserName("user");
        edMiConnectionFactory.setPassword("password");
        edMiConnectionFactory.setClientGroup("admin");
        edMiConnectionFactory.createInitialContext();

        verifyNew(InitialContext.class).withArguments(argument.capture());
        Properties props = argument.getValue();
        assertEquals("wmjmsnaming://EDMI951UAT_JNDI01@10.20.175.75:6712/EDMIFramework", props.get(Context.PROVIDER_URL));
        assertEquals("true", System.getProperty("com.webmethods.jms.clientIDSharing"));
        assertEquals("admin", props.get("com.webmethods.jms.naming.clientgroup"));
    }

    @Test
    public void should_catch_exception_on_releaseContext() throws Exception {
        try {
            InitialContext context = mock(InitialContext.class);
            doThrow(new NamingException()).when(context).close();
            edMiConnectionFactory = new EDMiConnectionFactory();
            edMiConnectionFactory.releaseContext(context);
        } catch (NamingException e) {
            fail("Exception should be caught.");
        }
    }

    @Test
    public void should_catchNameing_exception_during_creation() throws Exception {
        whenNew(InitialContext.class).withArguments(any(Properties.class)).thenThrow(new NamingException("Naming exception"));
        try {
            edMiConnectionFactory = new EDMiConnectionFactory();
            edMiConnectionFactory.setClientId("sample-client-id");
            edMiConnectionFactory.setBrokerUrl("wmjmsnaming://EDMI951UAT_JNDI01@10.20.175.75:6712/EDMIFramework");
            edMiConnectionFactory.setUserName("user");
            edMiConnectionFactory.setPassword("password");
            edMiConnectionFactory.setClientGroup("admin");
            edMiConnectionFactory.createConnection();
            fail("Exception should be thrown");
        } catch (JMSException e) {
            assertEquals("Naming exception", e.getMessage());
        } catch (Exception e) {
            fail("Exception should be wrapped to JMSException");
        }
    }

}
