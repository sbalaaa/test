package com.sc.csl.retail.core.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import javax.ws.rs.core.Response;

import org.junit.Test;

import io.crnk.core.engine.http.HttpStatus;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CSLCrnkExceptionMapperTest {
	private CSLExceptionMapper exceptionMapper = new CSLExceptionMapper();

	@Test
	public void shouldReturnCrnkErrorResponseForJaxrs() {
		Response response = exceptionMapper.toResponse(new TechnicalException("Test Exception"));
		log.info("Response : {}", response.getEntity());
		assertNotNull(response.getEntity());
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR_500, response.getStatus());
	}
}