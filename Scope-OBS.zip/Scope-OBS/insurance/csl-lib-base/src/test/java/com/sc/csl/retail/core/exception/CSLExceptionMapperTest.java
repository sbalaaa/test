package com.sc.csl.retail.core.exception;

public class CSLExceptionMapperTest {

}