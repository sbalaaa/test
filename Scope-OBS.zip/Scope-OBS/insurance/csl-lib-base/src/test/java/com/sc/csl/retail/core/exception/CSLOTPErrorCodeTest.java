package com.sc.csl.retail.core.exception;

import static org.junit.Assert.*;

import org.junit.Test;

public class CSLOTPErrorCodeTest {

    @Test
    public void successfullyCreatedCSLOTPError() {
        CSLOTPErrorCode errorCode = new CSLOTPErrorCode("1307", "OTP expired", "dummy");
        assertEquals(errorCode.getCode(), "CSL-OTP-1307");
        assertEquals(errorCode.getTitle(), "OTP expired");
    }

}
