package com.sc.csl.retail.core.exception;

import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.model.SmsOtp;
import com.sc.csl.retail.core.util.CSLConstants;
import org.junit.Test;
import org.mockito.Mock;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.*;
import static org.junit.Assert.assertEquals;

public class OTPRequiredExceptionTest {

	private OTPRequiredException otpRequiredException; 
	
	@Mock
	SmsOtp smsResponse = new SmsOtp();
	
	@Test
	public void otpRequiredException_for_sms_response() {
		otpRequiredException = new OTPRequiredException(smsResponse);
		assertEquals(otpRequiredException.getErrorCode(),OTP_REQUIRED);
		assertEquals(otpRequiredException.getTokenType(),TokenType.SMS);
	}
	
	
	@Test
	public void otpRequiredException_for_token_type_sms() {
		otpRequiredException = new OTPRequiredException(TokenType.SMS);
		assertEquals(otpRequiredException.getErrorCode(),OTP_REQUIRED);
		assertEquals(otpRequiredException.getTokenType(),TokenType.SMS);
	}
	
	@Test
	public void otpRequiredException_for_token_type_other() {
		otpRequiredException = new OTPRequiredException(TokenType.SOFT_TOKEN);
		assertEquals(otpRequiredException.getErrorCode(),SOFT_TOKEN_OTP_REQUIRED);
		assertEquals(otpRequiredException.getTokenType(),TokenType.SOFT_TOKEN);
	}
	
	@Test
	public void otpRequiredException_for_sms_otp_and_mpin_register() {
		smsResponse.setType(CSLConstants.MPIN_PASSWORD_TYPE);
		otpRequiredException = new OTPRequiredException(smsResponse,CSLConstants.MPIN_REGISTER_PURPOSE);
		assertEquals(otpRequiredException.getErrorCode(),OTP_MPIN_REQUIRED);
		assertEquals(otpRequiredException.getTokenType(),TokenType.SMS);
		assertEquals(otpRequiredException.getSmsResponse().getPurpose(),CSLConstants.MPIN_REGISTER_PURPOSE);
	}
	
	@Test
	public void otpRequiredException_for_sms_otp_and_mpin_reset() {
		smsResponse.setType(CSLConstants.MPIN_PASSWORD_TYPE);
		otpRequiredException = new OTPRequiredException(smsResponse,CSLConstants.MPIN_RESET_PURPOSE);
		assertEquals(otpRequiredException.getErrorCode(),OTP_MPIN_REQUIRED);
		assertEquals(otpRequiredException.getTokenType(),TokenType.SMS);
		assertEquals(otpRequiredException.getSmsResponse().getPurpose(),CSLConstants.MPIN_RESET_PURPOSE);
	}
}
