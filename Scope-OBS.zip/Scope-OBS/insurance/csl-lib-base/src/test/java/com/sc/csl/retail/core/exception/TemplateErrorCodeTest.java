package com.sc.csl.retail.core.exception;

import lombok.Getter;
import org.junit.Test;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;
import static org.junit.Assert.assertEquals;

public class TemplateErrorCodeTest {
    @Test
    public void shouldGenerate_ProperDescription_ByReplacing_Substitutions() {
        TemplateErrorCode errorCode = TemplateErrorCode.create(TestErrorCodes.TEMPLATE_TEST, "Karthik", "1021928");
        BusinessException exception = new BusinessException(errorCode);

        TemplateErrorCode errorCode2 = TemplateErrorCode.create(TestErrorCodes.TEMPLATE_TEST, "Karthik2", "12345678");
        BusinessException exception2 = new BusinessException(errorCode2);

        ErrorCode actualErrorCode = exception.getErrorCode();
        ErrorCode actualErrorCode2 = exception2.getErrorCode();

        assertEquals("TEST-101", actualErrorCode.getCode());
        assertEquals("Template Test", actualErrorCode.getTitle());
        assertEquals("User Karthik is not authorized to access the case 1021928", actualErrorCode.getDescription());

        assertEquals("TEST-101", actualErrorCode2.getCode());
        assertEquals("Template Test", actualErrorCode2.getTitle());
        assertEquals("User Karthik2 is not authorized to access the case 12345678", actualErrorCode2.getDescription());
    }

    @Getter
    private enum TestErrorCodes implements ErrorCode {
        DEFAULT_ERROR_CODE("TEST-100", "Error Occurred", "An error occurred. Please contact the administrator"),
        TEMPLATE_TEST("TEST-101", "Template Test", "User %s is not authorized to access the case %s");

        private String code;
        private String title;
        private String description;

        public String toString() {
            return convertToString(this);
        }

        TestErrorCodes(String code, String title, String description) {
            this.code = code;
            this.title = title;
            this.description = description;
        }
    }

}