package com.sc.csl.retail.core.fap;

import org.junit.Before;
import org.junit.Test;
import org.powermock.core.classloader.annotations.PrepareForTest;

import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@PrepareForTest
public class FapGatewayTest {

    FapGateway fapGateway;
    @Before
    public void setUp() {
        Response mockResponse = mock(Response.class);
        fapGateway = new FapGateway() {
            @Override
            public Response post(String message, String endPont) {
                return mockResponse;
            }
        };

        Map<String, Object> mockMapResponse = new HashMap<>();
        mockMapResponse.put("hasPermission", true);
        mockMapResponse.put("appName", "TESTAPP");
        mockMapResponse.put("action", "UPDATE");

        when(mockResponse.readEntity(Map.class)).thenReturn(mockMapResponse);
    }

    @Test
    public void check_if_post_method_is_called() {
        Map<String, Object> responseMap = fapGateway.hasPermission("", "", "", "");
        assertNotNull(responseMap);
    }
}
