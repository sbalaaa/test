package com.sc.csl.retail.core.gateway;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jms.InvalidSelectorException;
import org.springframework.jms.core.JmsTemplate;

import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class CSLJmsGatewayTest {
    private JmsTemplate jmsTemplate;
    private String destination = "topic:sampleDestination";
    private String response = "topic:sampleResponse";
    private String selector = "paymentInitiationSystem IN ('IBK','MBK')";
    private CSLJmsGateway jmsGateway;
    private CSLJmsGateway jmsSyncGateway;

    @Before
    public void setup() {
        jmsTemplate = mock(JmsTemplate.class);
        jmsGateway = new CSLJmsGateway(jmsTemplate, destination);
        jmsSyncGateway = new CSLJmsGateway(jmsTemplate, destination, response, selector);
    }

    @Test
    public void testDefaultDestination() {
        jmsGateway.post("sample");
        verify(jmsTemplate).send(eq(destination), any());
    }

    @Test
    public void testCustomDestination() {
        jmsGateway.post("topic:destination1", "sample");
        verify(jmsTemplate).send(eq("topic:destination1"), any());
    }

    @Test
    public void testSend_WithErrorsIgnored() {
        Mockito.doThrow(new InvalidSelectorException(new javax.jms.InvalidSelectorException("Mock exception"))).
                when(jmsTemplate).
                send(anyString(), any());
        jmsGateway.post("sample", true);
        verify(jmsTemplate).send(eq(destination), any());
    }

    @Test
    public void testSend_WithErrorsNotIgnored() {
        try {
            Mockito.doThrow(new InvalidSelectorException(new javax.jms.InvalidSelectorException("Mock exception"))).
                    when(jmsTemplate).
                    send(anyString(), any());

            jmsGateway.post("topic:destination1", "sample", false);
        }
        catch (Exception e) {
            assertEquals(e.getClass(), InvalidSelectorException.class);
        }
    }

    @Test
    public void testPostAndReceiveWithCustomSelector() {
    	jmsSyncGateway.postAndReceive("topic:destination1", "sample", "responseSelector");
    	verify(jmsTemplate).receiveSelected(response, "responseSelector");
    }
    
    @Test
    public void testPostAndReceiveNoSelector() {
    	jmsSyncGateway.postAndReceive("sample");
        verify(jmsTemplate).receiveSelected(response, selector);
    }
}
