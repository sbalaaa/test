package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.crnk.helper.CSLHttpAdapter;
import io.crnk.client.CrnkClient;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

public class CSLJsonApiGatewayTest {
    public CSLJsonApiGateway cslJsonApiGateway() {
        CSLJsonApiGateway cslJsonApiGateway = new CSLJsonApiGateway() {};
        cslJsonApiGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslJsonApiGateway.setServiceUrl("/posts/1");
        return cslJsonApiGateway;
    }

    @Test
    public void should_return_CrnkClientNoParameters() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        assertNotNull(cslJsonApiGateway.getCrnkClient());

        CrnkClient crnkClient = cslJsonApiGateway.getCrnkClient();
        CSLHttpAdapter httpAdapter = (CSLHttpAdapter) crnkClient.getHttpAdapter();
        WebClient webClient = httpAdapter.webClient("https://jsonplaceholder.typicode.com");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

        assertNull(conduit.getTlsClientParameters());
    }

    @Test
    public void should_return_sameCrnkClient2times() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        CrnkClient client1 = (cslJsonApiGateway.getCrnkClient());
        CrnkClient client2 = (cslJsonApiGateway.getCrnkClient());
        assertTrue(client1 == client2);
    }

    @Test
    public void should_return_CrnkClientWithTimeout() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        cslJsonApiGateway.setTimeout(20L);

        CrnkClient crnkClient = cslJsonApiGateway.getCrnkClient();
        CSLHttpAdapter httpAdapter = (CSLHttpAdapter) crnkClient.getHttpAdapter();
        WebClient webClient = httpAdapter.webClient("https://jsonplaceholder.typicode.com");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

        assertEquals(20L, conduit.getClient().getReceiveTimeout());
    }

    @Test
    public void should_return_CrnkClientWithSsl() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        cslJsonApiGateway.setSslTrustStore("classpath:truststore/edmi.jks");
        cslJsonApiGateway.setSslTrustStorePassword("changeit");

        CrnkClient crnkClient = cslJsonApiGateway.getCrnkClient();
        CSLHttpAdapter httpAdapter = (CSLHttpAdapter) crnkClient.getHttpAdapter();
        WebClient webClient = httpAdapter.webClient("https://jsonplaceholder.typicode.com");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
        assertNotNull(conduit.getTlsClientParameters());
    }

    @Test
    public void should_return_WithoutSsl() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        cslJsonApiGateway.setSslTrustStore("classpath:truststore/edmi.jks");

        CrnkClient crnkClient = cslJsonApiGateway.getCrnkClient();
        CSLHttpAdapter httpAdapter = (CSLHttpAdapter) crnkClient.getHttpAdapter();
        WebClient webClient = httpAdapter.webClient("https://jsonplaceholder.typicode.com");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();
        assertNull(conduit.getTlsClientParameters());
    }

    @Test(expected = TechnicalException.class)
    public void should_fail_keystrorePathIsWrong() {
        CSLJsonApiGateway cslJsonApiGateway = cslJsonApiGateway();
        cslJsonApiGateway.setSslTrustStore("classpath:truststore/edmi1.jks");
        cslJsonApiGateway.setSslTrustStorePassword("changeit");


        CrnkClient crnkClient = cslJsonApiGateway.getCrnkClient();
        CSLHttpAdapter httpAdapter = (CSLHttpAdapter) crnkClient.getHttpAdapter();
        httpAdapter.webClient("https://jsonplaceholder.typicode.com");
    }
}
