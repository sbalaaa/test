package com.sc.csl.retail.core.gateway;

import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

import static java.util.Arrays.asList;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static javax.ws.rs.core.MediaType.APPLICATION_XML;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class CSLRestGatewayTest {

    private WebClient webClient = mock(WebClient.class);
    private Response response = mock(Response.class);

    @Before
    public void setup() {
        doReturn(response).when(webClient).get();
        doReturn(response).when(webClient).post(anyString());
        doReturn(response).when(webClient).put(anyString());

        doReturn("").when(response).readEntity(any(Class.class));
    }

    private CSLRestGateway cslRestGateway() {
        return new CSLRestGateway() {
            protected WebClient webClient(String path) {
                return webClient;
            }
            protected WebClient webClient(String path, String mediaType) {
                return webClient;
            }
        };
    }

    @Test
    public void testUrl() {
        CSLRestGateway cslRestGateway = new CSLRestGateway(){};
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        String result = cslRestGateway.url("/posts/1");
        assertEquals("https://jsonplaceholder.typicode.com/posts/1", result);
    }

    @Test
    public void testWebClient() {
        CSLRestGateway cslRestGateway = new CSLRestGateway(){};
        cslRestGateway.setTimeout(20000L);
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        WebClient webClient = cslRestGateway.webClient("/posts/1");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

        assertEquals(asList(APPLICATION_JSON), webClient.getHeaders().get("Content-Type"));
        assertEquals(20000L, conduit.getClient().getReceiveTimeout());
        assertEquals("/posts/1", webClient.getCurrentURI().getPath());
    }

    @Test
    public void testWebClientWithQueryParams() {
        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("customer-name", "Sample");
            queryParams.put("customer-id", "xyz");

            CSLRestGateway cslRestGateway = new CSLRestGateway() {
            };
            cslRestGateway.setTimeout(20000L);
            cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
            WebClient webClient = cslRestGateway.webClient("/posts/1", queryParams);
            HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

            String url = webClient.getCurrentURI().toURL().toString();
            assertTrue(url.contains("customer-name=Sample"));
            assertTrue(url.contains("customer-id=xyz"));
            assertEquals(asList(APPLICATION_JSON), webClient.getHeaders().get("Content-Type"));
            assertEquals(20000L, conduit.getClient().getReceiveTimeout());
            assertEquals("/posts/1", webClient.getCurrentURI().getPath());
        } catch (Exception e) {
            fail("Should not fail.");
        }
    }


    @Test
    public void testWebClientWithEmptyQueryParams() {
        try {
            Map<String, String> queryParams = new HashMap<>();

            CSLRestGateway cslRestGateway = new CSLRestGateway() {
            };
            cslRestGateway.setTimeout(20000L);
            cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
            WebClient webClient = cslRestGateway.webClient("/posts/1", queryParams);
            HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();


            String url = webClient.getCurrentURI().toURL().toString();
            assertFalse(url.contains("?"));

            assertEquals(asList(APPLICATION_JSON), webClient.getHeaders().get("Content-Type"));
            assertEquals(20000L, conduit.getClient().getReceiveTimeout());
            assertEquals("/posts/1", webClient.getCurrentURI().getPath());
        } catch (Exception e) {
            fail("Should not fail.");
        }
    }

    @Test
    public void testWebClientWithQueryParamsAndMediaType() {
        try {
            Map<String, String> queryParams = new HashMap<>();
            queryParams.put("customer-name", "Sample");
            queryParams.put("customer-id", "xyz");

            CSLRestGateway cslRestGateway = new CSLRestGateway() {
            };
            cslRestGateway.setTimeout(20000L);
            cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
            WebClient webClient = cslRestGateway.webClient("/posts/1", queryParams, APPLICATION_XML);
            HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();


            String url = webClient.getCurrentURI().toURL().toString();
            assertTrue(url.contains("customer-name=Sample"));
            assertTrue(url.contains("customer-id=xyz"));
            assertEquals(20000L, conduit.getClient().getReceiveTimeout());
            assertEquals("/posts/1", webClient.getCurrentURI().getPath());
        } catch (Exception e) {
            fail("Should not fail.");
        }
    }

    @Test
    public void testWebClientDefaultTimeout() {
        CSLRestGateway cslRestGateway = new CSLRestGateway(){};
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        WebClient webClient = cslRestGateway.webClient("/posts/1");
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

        assertEquals(asList(APPLICATION_JSON), webClient.getHeaders().get("Content-Type"));
        assertEquals(60000L, conduit.getClient().getReceiveTimeout());
        assertEquals("/posts/1", webClient.getCurrentURI().getPath());
    }

    @Test
    public void testWebClientMediaType() {
        CSLRestGateway cslRestGateway = new CSLRestGateway(){};
        cslRestGateway.setTimeout(20000L);
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        WebClient webClient = cslRestGateway.webClient("/posts/1", APPLICATION_XML);
        HTTPConduit conduit = WebClient.getConfig(webClient).getHttpConduit();

        assertEquals(asList(APPLICATION_XML), webClient.getHeaders().get("Content-Type"));
        assertEquals(20000L, conduit.getClient().getReceiveTimeout());
        assertEquals("/posts/1", webClient.getCurrentURI().getPath());
    }

    @Test
    public void testWebClientPostJsonWithEndpointAndMediaType() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.postRequest("{}", "/posts/1", "application/json");
        verify(webClient).post(any());
    }

    @Test
    public void testWebClientPostJsonWithEndpoint() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        String result = cslRestGateway.postRequest("{}", "/posts/1");
        verify(webClient).post(any());
    }

    @Test
    public void testWebClientPostJson() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.post("{}", "/posts/1");
        verify(webClient).post(any());
    }

    @Test
    public void testWebClientPostJsonAndMediaType() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.post("{}", "/posts/1", "application/json");
        verify(webClient).post(any());
    }

    @Test
    public void testWebClientGetRequest() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.getRequest("https://jsonplaceholder.typicode.com/posts/1", "application/json");
        verify(webClient).get();
    }

    @Test
    public void testGetWithServiceEndpointAndMediaType () {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.get("https://jsonplaceholder.typicode.com/posts/1", "application/json");
        verify(webClient).get();
    }


    @Test
    public void testGetWithServiceEndpoint() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.get("https://jsonplaceholder.typicode.com/posts/1");
        verify(webClient).get();
    }

    @Test
    public void testWebClientGetRequestWithMediaType() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.getRequest("/posts/1");
        verify(webClient).get();
    }

    @Test
    public void testWebClientPutRequestWithMediaType() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.putRequest("{}", "/posts/1");
        verify(webClient).put(any());
    }

    @Test
    public void testWebClientWithTrustStoreGetRequest() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        cslRestGateway.setSslTrustStore("classpath:truststore/edmi.jks");
        cslRestGateway.setSslTrustStorePassword("changeit");
        cslRestGateway.getRequest("https://jsonplaceholder.typicode.com/posts/1", "application/json");
        verify(webClient).get();
    }

    @Test
    public void testWebClientWithQueryParamsRequest() {
        CSLRestGateway cslRestGateway = cslRestGateway();
        cslRestGateway.setBaseUrl("https://jsonplaceholder.typicode.com");
        Map<String, String> queryParams = new HashMap<>();
        queryParams.put("customer-name", "Sample");
        queryParams.put("customer-id", "xyz");

        cslRestGateway.get("https://jsonplaceholder.typicode.com/posts/1", queryParams);
        verify(webClient).get();
    }
}