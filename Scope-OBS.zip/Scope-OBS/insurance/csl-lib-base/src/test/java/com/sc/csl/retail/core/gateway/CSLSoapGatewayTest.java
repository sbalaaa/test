package com.sc.csl.retail.core.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.security.ProxyAuthorizationPolicy;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.util.ResourceUtils;

import javax.xml.namespace.QName;
import javax.xml.ws.*;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.mockStatic;
import static org.powermock.api.mockito.PowerMockito.verifyStatic;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ClientProxy.class)
@PowerMockIgnore("javax.net.ssl.*")
public class CSLSoapGatewayTest {
    SampleTestPort sampleTestPort;
    SampleTestService sampleTestService;
    HTTPConduit conduit;
    org.apache.cxf.endpoint.Client client;

    @Before
    public void setup() {
        sampleTestPort = new SampleTestPort();
        sampleTestService = mock(SampleTestService.class);
        when(sampleTestService.getPort(SampleTestPort.class)).thenReturn(sampleTestPort);

        conduit = mock(HTTPConduit.class);
        client = mock(org.apache.cxf.endpoint.Client.class);
        when(client.getConduit()).thenReturn(conduit);

        mockStatic(ClientProxy.class);
        when(ClientProxy.getClient(any(SampleTestPort.class))).thenReturn(client);
    }

    @Test
    public void parentConstructorTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setTimeout(null);
        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);
        verify(sampleTestService).getPort(SampleTestPort.class);
    }


    @Test
    public void emptyPropertiesTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();

        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);
        assertNull(sampleTestPort.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY));
        assertNull(sampleTestPort.getRequestContext().get(BindingProvider.USERNAME_PROPERTY));
        assertNull(sampleTestPort.getRequestContext().get(BindingProvider.PASSWORD_PROPERTY));

    }

    @Test
    public void requestPropertiesTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setEndpointUrl("https://www.sample.endpoint.sg");
        props.setUserName("user");
        props.setPassword("password");
        props.setTimeout(null);

        new SampleTestGateway(sampleTestService, SampleTestPort.class, props) {
            protected void setupInterceptors() {
            }

        };
        assertEquals(sampleTestPort.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY), "https://www.sample.endpoint.sg");
        assertEquals(sampleTestPort.getRequestContext().get(BindingProvider.USERNAME_PROPERTY), "user");
        assertEquals(sampleTestPort.getRequestContext().get(BindingProvider.PASSWORD_PROPERTY), "password");
        verifyStatic(times(0));
        ClientProxy.getClient(any(SampleTestPort.class));
    }

    @Test
    public void trustStorePropertiesClasspathTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setSslTrustStore("classpath:truststore/edmi.jks");
        props.setSslTrustStorePassword("changeit");
        props.setTimeout(null);

        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(conduit).setTlsClientParameters(any(TLSClientParameters.class));
    }


    @Test
    public void trustStorePropertiesGlobalpathTest() throws FileNotFoundException {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setSslTrustStore(ResourceUtils.getFile("classpath:truststore/edmi.jks").getPath());
        props.setSslTrustStorePassword("changeit");
        props.setTimeout(null);
        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(conduit).setTlsClientParameters(any(TLSClientParameters.class));
    }

    @Test
    public void trustStorePropertiesFailedTest() {
        try {
            CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
            props.setSslTrustStore("classpath:truststore/edmi1.jks");
            props.setSslTrustStorePassword("changeit");
            props.setTimeout(null);
            new SampleTestGateway(sampleTestService, SampleTestPort.class, props);
            fail("Wrong jks file location, should fail.");
        } catch (TechnicalException e) {
            assertEquals("SOAP Gateway creation failed.", e.getMessage());
        }
    }

    @Test
    public void proxyPropertiesTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setProxyAddress("10.20.234.100");
        props.setProxyPort(8080);
        props.setProxyPassword("password");
        props.setProxyUserName("user");

        ProxyAuthorizationPolicy proxyAuthorization = mock(ProxyAuthorizationPolicy.class);

        HTTPClientPolicy httpClientPolicy = mock(HTTPClientPolicy.class);
        when(conduit.getClient()).thenReturn(httpClientPolicy);
        when(conduit.getProxyAuthorization()).thenReturn(proxyAuthorization);

        //SampleTestGateway.httpConduit = conduit;
        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(httpClientPolicy).setProxyServer("10.20.234.100");
        verify(httpClientPolicy).setProxyServerPort(8080);
        verify(proxyAuthorization).setUserName("user");
        verify(proxyAuthorization).setPassword("password");
    }


    @Test
    public void proxyPropertiesTestNoAuth() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setProxyAddress("10.20.234.100");
        props.setProxyPort(8080);

        ProxyAuthorizationPolicy proxyAuthorization = mock(ProxyAuthorizationPolicy.class);

        HTTPClientPolicy httpClientPolicy = mock(HTTPClientPolicy.class);
        when(conduit.getClient()).thenReturn(httpClientPolicy);
        when(conduit.getProxyAuthorization()).thenReturn(proxyAuthorization);

        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(httpClientPolicy).setProxyServer("10.20.234.100");
        verify(httpClientPolicy).setProxyServerPort(8080);
        verify(proxyAuthorization, times(0)).setUserName("user");
        verify(proxyAuthorization, times(0)).setPassword("password");
    }


    @Test
    public void proxyPropertiesTestNoPort() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setProxyAddress("10.20.234.100");

        ProxyAuthorizationPolicy proxyAuthorization = mock(ProxyAuthorizationPolicy.class);

        HTTPClientPolicy httpClientPolicy = mock(HTTPClientPolicy.class);
        when(conduit.getClient()).thenReturn(httpClientPolicy);
        when(conduit.getProxyAuthorization()).thenReturn(proxyAuthorization);

        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(httpClientPolicy).setProxyServer("10.20.234.100");
        verify(httpClientPolicy, times(0)).setProxyServerPort(8080);
        verify(proxyAuthorization, times(0)).setUserName("user");
        verify(proxyAuthorization, times(0)).setPassword("password");
    }

    @Test
    public void propertiesTimeoutTest() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setTimeout(1000L);
        HTTPClientPolicy httpClientPolicy = mock(HTTPClientPolicy.class);
        when(conduit.getClient()).thenReturn(httpClientPolicy);

//        SampleTestGateway.httpConduit = conduit;
        new SampleTestGateway(sampleTestService, SampleTestPort.class, props);

        verify(httpClientPolicy).setReceiveTimeout(1000L);
    }


    @Test
    public void should_call_ClientProxy_0Times() {
        CSLSoapGatewayProperties props = new CSLSoapGatewayProperties();
        props.setTimeout(null);


        new SampleTestGateway(sampleTestService, SampleTestPort.class, props) {
            protected void setupInterceptors() {
            }
        };
        verifyStatic(times(0));
        ClientProxy.getClient(any(SampleTestPort.class));
    }



    static class SampleTestGateway extends CSLSoapGateway<SampleTestPort> {
		public SampleTestGateway(Service service, Class<SampleTestPort> wsClazz, CSLSoapGatewayProperties properties) {
			super(service, wsClazz, properties);
		}
    }

    class SampleTestPort implements BindingProvider {

		private Map<String, Object> requestContext = new HashMap<>();
		private  Map<String, Object> responseContext = new HashMap<>();

		@Override
		public Map<String, Object> getRequestContext() {
			return requestContext;
		}

		@Override
		public Map<String, Object> getResponseContext() {
			return responseContext;
		}

		@Override
		public Binding getBinding() {
			return null;
		}

		@Override
		public EndpointReference getEndpointReference() {
			return null;
		}

		@Override
		public <T extends EndpointReference> T getEndpointReference(Class<T> clazz) {
			return null;
		}
	}

	class SampleTestService extends Service {
		protected SampleTestService(URL wsdlDocumentLocation, QName serviceName) {
			super(wsdlDocumentLocation, serviceName);
		}

		protected SampleTestService(URL wsdlDocumentLocation, QName serviceName, WebServiceFeature... features) {
			super(wsdlDocumentLocation, serviceName, features);
		}
	}
}
