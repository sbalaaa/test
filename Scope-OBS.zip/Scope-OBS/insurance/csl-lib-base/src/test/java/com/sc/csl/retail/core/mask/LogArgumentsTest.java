package com.sc.csl.retail.core.mask;

import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.when;

public class LogArgumentsTest {
    private Employee e1 = new Employee();
    private Employee e2 = new Employee();
    private Employee e3 = new Employee();
    private Employee e4 = new Employee();

    private Person p1 = new Person();
    private Person p2 = new Person();
    private Person p3 = new Person();
    private Person p4 = new Person();

    @Test
    public void should_NotMask_Null() {
        LogArguments logArguments = logArguments();
        assertNull(logArguments.maskObject(null));
    }

    @Test
    public void should_Mask_ClassesWithMaskAnnotation() {
        LogArguments logArguments = logArguments();
        logArguments.maskObject(e1);

        verify(logArguments, times(1)).mask(e1);
    }

    @Test
    public void should_NotMask_EmptyCollection() {
        LogArguments logArguments = logArguments();
        logArguments.maskObject(new ArrayList<Employee>());

        verify(logArguments, never()).mask(any());
    }

    @Test
    public void should_Mask_CollectionOfClassWithMaskAnnotation() {
        LogArguments logArguments = logArguments();
        List<Employee> list = new ArrayList<>();
        list.add(e1);
        list.add(e2);

        Set<Employee> set = new HashSet<>();
        set.add(e3);
        set.add(e4);

        logArguments.maskObject(list);
        verify(logArguments, times(1)).mask(e1);
        verify(logArguments, times(1)).mask(e2);

        logArguments.maskObject(set);
        verify(logArguments, times(1)).mask(e3);
        verify(logArguments, times(1)).mask(e4);
    }

    @Test
    public void should_Mask_ArrayOfClassWithMaskAnnotation() {
        LogArguments logArguments = logArguments();
        Employee[] array = {e1, e2};
        logArguments.maskObject(array);

        verify(logArguments, times(1)).mask(e1);
        verify(logArguments, times(1)).mask(e2);
    }

    @Test
    public void should_NotMask_EmptyArray() {
        LogArguments logArguments = logArguments();
        Employee[] array = {};
        logArguments.maskObject(array);

        verify(logArguments, never()).mask(any());
    }

    @Test
    public void should_Mask_MapOfClassWithMaskAnnotation() {
        LogArguments logArguments = logArguments();
        Map<String, Employee> map = new HashMap<>();
        map.put("1", e1);
        map.put("2", e2);
        logArguments.maskObject(map);

        verify(logArguments, times(1)).mask(e1);
        verify(logArguments, times(1)).mask(e2);
    }

    @Test
    public void should_NotMask_EmptyMap() {
        LogArguments logArguments = logArguments();
        Map<String, Employee> map = new HashMap<>();
        logArguments.maskObject(map);

        verify(logArguments, never()).mask(any());
    }

    @Test
    public void should_NotMask_NormalClasses() {
        LogArguments logArguments = logArguments();
        logArguments.maskObject(p1);

        verify(logArguments, never()).mask(p1);
    }

    @Test
    public void should_NotMask_CollectionOfNonMaskableClass() {
        LogArguments logArguments = logArguments();
        List<Person> list = new ArrayList<>();
        list.add(p1);
        list.add(p2);

        Set<Person> set = new HashSet<>();
        set.add(p3);
        set.add(p4);

        logArguments.maskObject(list);
        verify(logArguments, never()).mask(p1);
        verify(logArguments, never()).mask(p2);

        logArguments.maskObject(set);
        verify(logArguments, never()).mask(p3);
        verify(logArguments, never()).mask(p4);
    }

    @Test
    public void should_NotMask_ArrayOfNonMaskableClass() {
        LogArguments logArguments = logArguments();
        Person[] array = {p1, p2};
        logArguments.maskObject(array);

        verify(logArguments, never()).mask(p1);
        verify(logArguments, never()).mask(p2);
    }

    @Test
    public void should_NotMask_MapOfNonMaskableClass() {
        LogArguments logArguments = logArguments();
        Map<String, Person> map = new HashMap<>();
        map.put("1", p1);
        map.put("2", p2);
        logArguments.maskObject(map);

        verify(logArguments, never()).mask(p1);
        verify(logArguments, never()).mask(p2);
    }

    @Maskable
    private static class Employee {
        private String id;
        private String name;
        @Mask
        private String email;
    }

    private static class Person {
        private String name;
        private int age;
    }

    private LogArguments logArguments() {
        final LogArguments logArguments = new LogArguments(new Object[]{});
        final LogArguments spy = spy(logArguments);
        when(spy.mask(any())).thenReturn("Masked");

        return spy;
    }
}