package com.sc.csl.retail.core.mask;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class MaskUtilTest {

	@Test
	public void should_return_masked_objects_with_map() {

		LogTestDto logTestDao = new LogTestDto();

		HashMap<String, ArrayList<String>> mapfields = new HashMap<String, ArrayList<String>>();
		ArrayList<String> keyToMaskList = new ArrayList<String>();
		keyToMaskList.add("A");
		mapfields.put("maptoTest", keyToMaskList);

		LogTestDto response = (LogTestDto) MaskUtil.maskObject(logTestDao, mapfields);

		assertEquals("123412341234", response.getAccountNo());
		assertEquals("1234123412341234", response.getCreditCardNo());
		assertNull(response.getTokenNum());
		assertEquals(123456, response.getDebitAccNum());
		assertEquals("*******************0123", response.getCreditAccNum());
		assertEquals("23432423423", response.getAccount().getSeedNum());
		assertNull(response.getAccount().getOtpNumber());
		assertNull(response.getAccount().getOpaque());
		assertEquals("***********************", response.getAccount().getCreditAccNumCr());

		assertEquals(927921389, response.getAccount().getTrans().getTransactionNo());
		assertEquals("12/10/2025", response.getAccount().getTrans().getDate());
		assertEquals(55, response.getAccount().getTrans().getTransactionArr()[0]);
		assertEquals(66, response.getAccount().getTrans().getTransactionArr()[1]);
		assertEquals(77, response.getAccount().getTrans().getTransactionArr()[2]);

		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[0]);
		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[1]);
		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[2]);

		assertEquals(new Integer(12345), response.getAccount().getTrans().getTransactionList().get(0));
		assertEquals(new Integer(4567), response.getAccount().getTrans().getTransactionList().get(1));

		assertEquals("Personal", response.getAccount().getTrans().getRemarksDto().get(0).getRemarks());
		assertEquals("to-starhub", response.getAccount().getTrans().getRemarksDto().get(1).getRemarks());
		assertEquals("date1", response.getAccount().getTrans().getRemarksDto().get(1).getDate());
		assertEquals("date1", response.getAccount().getTrans().getRemarksDto().get(1).getDate());
		
		assertEquals("55", response.getTranStrArr()[0]);
		assertEquals("hi", response.getTranStrArr()[1]);
		assertEquals("77", response.getTranStrArr()[2]);
		
		assertEquals("*****", response.getMaptoTest().get("A"));
		assertEquals("hi", response.getMaptoTest().get("B"));
		
	}

	
	@Test
	public void should_return_masked_objects_without_map() {

		LogTestDto logTestDao = new LogTestDto();

		HashMap<String, ArrayList<String>> mapfields = new HashMap<String, ArrayList<String>>();
		ArrayList<String> keyToMaskList = new ArrayList<String>();
		keyToMaskList.add("A");
		mapfields.put("maptoTest", keyToMaskList);

		LogTestDto response = (LogTestDto) MaskUtil.maskObject(logTestDao);

		assertEquals("123412341234", response.getAccountNo());
		assertEquals("1234123412341234", response.getCreditCardNo());
		assertNull(response.getTokenNum());
		assertEquals(123456, response.getDebitAccNum());
		assertEquals("*******************0123", response.getCreditAccNum());
		assertEquals("23432423423", response.getAccount().getSeedNum());
		assertNull(response.getAccount().getOtpNumber());
		assertNull(response.getAccount().getOpaque());
		assertEquals("***********************", response.getAccount().getCreditAccNumCr());

		assertEquals(927921389, response.getAccount().getTrans().getTransactionNo());
		assertEquals("12/10/2025", response.getAccount().getTrans().getDate());
		assertEquals(55, response.getAccount().getTrans().getTransactionArr()[0]);
		assertEquals(66, response.getAccount().getTrans().getTransactionArr()[1]);
		assertEquals(77, response.getAccount().getTrans().getTransactionArr()[2]);

		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[0]);
		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[1]);
		assertEquals("**", response.getAccount().getTrans().getTransactionStrArr()[2]);

		assertEquals(new Integer(12345), response.getAccount().getTrans().getTransactionList().get(0));
		assertEquals(new Integer(4567), response.getAccount().getTrans().getTransactionList().get(1));

		assertEquals("Personal", response.getAccount().getTrans().getRemarksDto().get(0).getRemarks());
		assertEquals("to-starhub", response.getAccount().getTrans().getRemarksDto().get(1).getRemarks());
		assertEquals("date1", response.getAccount().getTrans().getRemarksDto().get(1).getDate());
		assertEquals("date1", response.getAccount().getTrans().getRemarksDto().get(1).getDate());
		
		assertEquals("55", response.getTranStrArr()[0]);
		assertEquals("hi", response.getTranStrArr()[1]);
		assertEquals("77", response.getTranStrArr()[2]);
		
		assertEquals("hello", response.getMaptoTest().get("A"));
		assertEquals("hi", response.getMaptoTest().get("B"));
		
	}
	
	@Test
	public void should_return_masked_maps() throws IllegalArgumentException, IllegalAccessException, IOException {

		Map<String, String> maptoTest = new HashMap<String, String>();
		maptoTest.put("key1", "hello");
		maptoTest.put("key2", "hi");

		ArrayList<MaskPattern> maskFieldsWithPatterns = new ArrayList<MaskPattern>();
		MaskPattern maskmapfield = new MaskPattern("key1");
		maskFieldsWithPatterns.add(maskmapfield);

		MaskPattern maskmapfield1 = new MaskPattern("key3");
		maskFieldsWithPatterns.add(maskmapfield1);

		Map<String, String> response = MaskUtil.maskMap(maptoTest, maskFieldsWithPatterns);
		assertEquals(response.get("key1"), "*****");
		assertEquals(response.get("key2"), "hi");
		assertNull(response.get("key3"));
	}

}

@Maskable
@Data
class LogTestDto extends BaseLogTestDto {

	private String creditCardNo = "1234123412341234";
	private String accountNo = "123412341234";

	@Mask
	private String tokenNum;

	@Mask
	private int debitAccNum = 123456;

	@Mask(regex = MaskConstant.PATTERN_DIGITS_23, replacement = MaskConstant.MASK_PATTERN_DIGITS_23)
	private String creditAccNum = "12345678901234567890123";

	@Mask
	private AccountTestDto account = new AccountTestDto();

	{
		this.logDateTime = 1499249832555L;
	}

	@Mask
	private Object[] tranStrArr = { "55", "hi", "77" };

	@Mask
	Map<String, String> maptoTest = new HashMap<String, String>();
	{
		maptoTest.put("A", "hello");
		maptoTest.put("B", "hi");
	}

}

@Data
@Maskable
class BaseLogTestDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1234233432L;

	@Mask
	protected static int serialNo = 12345;

	protected long logDateTime;
}

@Maskable
@Data
class AccountTestDto {

	private String seedNum = "23432423423";
	private String otpNumber;

	@Mask
	private String opaque;

	@Mask
	private int debitAccNumCr = 123456;

	@Mask
	private String creditAccNumCr = "12345678901234567890123";

	@Mask
	private TransactionTestDto trans = new TransactionTestDto();
}

@Maskable
@Data
class TransactionTestDto {

	@Mask
	private int transactionNo = 927921389;
	private String date = "12/10/2025";

	@Mask
	private int[] transactionArr = { 55, 66, 77 };

	@Mask
	private String[] transactionStrArr = { "55", "hi", "77" };

	@Mask
	private ArrayList<Integer> transactionList = new ArrayList<Integer>();
	{
		transactionList.add(12345);
		transactionList.add(new Integer(4567));
	}

	@Mask
	private ArrayList<RemarksDto> remarksDto = new ArrayList<RemarksDto>();
	{
		RemarksDto rdto1 = new RemarksDto();
		rdto1.setRemarks("Personal");
		remarksDto.add(rdto1);

		RemarksDto rdto2 = new RemarksDto();
		rdto2.setRemarks("to-starhub");
		remarksDto.add(rdto2);

	}

}

@Maskable
@Data
class RemarksDto {

	@Mask
	private String remarks;

	private String date = "date1";
}
