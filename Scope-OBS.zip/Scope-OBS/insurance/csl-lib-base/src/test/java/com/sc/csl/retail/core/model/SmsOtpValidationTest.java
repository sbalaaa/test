package com.sc.csl.retail.core.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.sc.csl.retail.core.util.CSLJsonUtils;

public class SmsOtpValidationTest {

    SmsOtpValidation model = new SmsOtpValidation();
    
    @Test
    public void parseJsonToValidationSuccessFully() {
        String jsonString = "{\"smsOtp\":{\"otpSn\":\"19098\",\"encOtp\":\"D8EREFWXJJy2E+Z6e/9e4T+p70GTkNMdNVFNzjqtjLEjjEcBxMvuEmmYmBq19Pejfv277bsthcta8F6w74NAR4d6PGxfl7DeqZ2/uCYdQQFaqWj8qffAhl0/Wb36KNqbhRnqL7xJdqsZ132xUAsz6/AVD+dacvxqqdeJ+Fxg0VT05gze97he9ufHv6WB5TZ+y6CV0bTBMEywv2XF+/M7f8+lWhsm7UAxK0bXmWCGJhKycPGSon28MayfYxxLAD1bmvmWx1lLkEPx1S19xV+j5kqf93tWxBe2KK1PqA9aqbXa33SFN0Jabu2tkxvNHd/osG2LWZP9R4FaY27EbnHmTw==\",\"purpose\":\"1\",\"keyIndex\":\"3\"}}";
        SmsOtpValidation validateRequest = CSLJsonUtils.parseJson(jsonString, SmsOtpValidation.class);
        assertNotNull(validateRequest);
        assertEquals("19098", validateRequest.getOtpSn());
        assertEquals("D8EREFWXJJy2E+Z6e/9e4T+p70GTkNMdNVFNzjqtjLEjjEcBxMvuEmmYmBq19Pejfv277bsthcta8F6w74NAR4d6PGxfl7DeqZ2/uCYdQQFaqWj8qffAhl0/Wb36KNqbhRnqL7xJdqsZ132xUAsz6/AVD+dacvxqqdeJ+Fxg0VT05gze97he9ufHv6WB5TZ+y6CV0bTBMEywv2XF+/M7f8+lWhsm7UAxK0bXmWCGJhKycPGSon28MayfYxxLAD1bmvmWx1lLkEPx1S19xV+j5kqf93tWxBe2KK1PqA9aqbXa33SFN0Jabu2tkxvNHd/osG2LWZP9R4FaY27EbnHmTw==", validateRequest.getEncOtp());
        assertEquals("1", validateRequest.getPurpose());
        assertEquals("3", validateRequest.getKeyIndex());
    }
    
    @Test(expected=java.lang.NullPointerException.class)
    public void parseJsonToValidationUnSuccessFully() {
        String jsonString = "{\"1smsOtp\":{\"otpSn\":\"19098\",\"encOtp\":\"D8EREFWXJJy2E+Z6e/9e4T+p70GTkNMdNVFNzjqtjLEjjEcBxMvuEmmYmBq19Pejfv277bsthcta8F6w74NAR4d6PGxfl7DeqZ2/uCYdQQFaqWj8qffAhl0/Wb36KNqbhRnqL7xJdqsZ132xUAsz6/AVD+dacvxqqdeJ+Fxg0VT05gze97he9ufHv6WB5TZ+y6CV0bTBMEywv2XF+/M7f8+lWhsm7UAxK0bXmWCGJhKycPGSon28MayfYxxLAD1bmvmWx1lLkEPx1S19xV+j5kqf93tWxBe2KK1PqA9aqbXa33SFN0Jabu2tkxvNHd/osG2LWZP9R4FaY27EbnHmTw==\",\"purpose\":\"1\",\"keyIndex\":\"3\"}}";
        SmsOtpValidation validateRequest = CSLJsonUtils.parseJson(jsonString, SmsOtpValidation.class);
        assertNotNull(validateRequest);
        assertEquals("19098", validateRequest.getOtpSn());
    }

}
