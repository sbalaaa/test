package com.sc.csl.retail.core.renderer;

import com.sc.csl.retail.core.config.FreemarkerConfig;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import freemarker.core.InvalidReferenceException;
import freemarker.template.TemplateNotFoundException;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class FreemarkerRendererTest {

    static FreemarkerRenderer freemarkerRenderer;

    @BeforeClass
    public static void setup() {
        FreemarkerConfig freemarkerConfig = new FreemarkerConfig();
        freemarkerRenderer = new FreemarkerRenderer(freemarkerConfig.freemarkerConfiguration());
    }

    @Test
    public void replaceTest() {
        final String expected = "<countryCode>SG</countryCode>";
        Map<String, Object> values = new HashMap<>();
        values.put("country", "SG");

        String result = freemarkerRenderer.render("test.xml", values);
        assertEquals(expected, result);
    }

    @Test
    public void wrongTemplateName() {
        try {
            Map<String, Object> values = new HashMap<>();
            values.put("country", "SG");
            String result = freemarkerRenderer.render("test-non-existent.xml", values);
            fail("Should fail as template name is wrong.");
        } catch (Exception e) {
            assertException(TemplateNotFoundException.class, e);
        }
    }

    @Test
    public void wrongTemplateFormat() {
        try {
            Map<String, Object> values = new HashMap<>();
            values.put("country", "SG");
            String result = freemarkerRenderer.render("bad-template.xml", values);
            fail("Should fail as template format is wrong.");
        } catch (Exception e) {
            assertException(InvalidReferenceException.class, e);
        }
    }

    static void assertException(Class<? extends Exception> expected, Exception actual) {
        if (actual.getClass() != TechnicalException.class)
            fail("Only TechnicalException should be thrown.");
        if (actual.getCause().getClass() !=  expected )
            fail("Parent exception should be " + actual.getCause().getClass());

        assertEquals("Template Render Exception", actual.getMessage());
    }    
}
