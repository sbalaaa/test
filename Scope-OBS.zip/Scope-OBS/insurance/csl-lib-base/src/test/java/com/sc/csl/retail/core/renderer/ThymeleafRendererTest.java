package com.sc.csl.retail.core.renderer;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.render.ThymeleafRenderer;
import org.junit.BeforeClass;
import org.junit.Test;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.exceptions.TemplateInputException;
import org.thymeleaf.exceptions.TemplateProcessingException;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class ThymeleafRendererTest {

    private static ThymeleafRenderer thymeleafRenderer;

    @BeforeClass
    public static void setup() {
        ClassLoaderTemplateResolver classLoaderTemplateResolver = new ClassLoaderTemplateResolver();
        classLoaderTemplateResolver.setPrefix("templates/thymeleaf/");

        TemplateEngine templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(classLoaderTemplateResolver);

        thymeleafRenderer = new ThymeleafRenderer(templateEngine);
    }

    @Test
    public void replaceTest() {
        final String expected = "<countryCode>SG</countryCode>";
        Map<String, Object> values = new HashMap<>();
        values.put("country", "SG");

        String result = thymeleafRenderer.render("test.xml", values);
        assertEquals(expected, result);
    }

    @Test
    public void wrongTemplateName() {
        try {
            Map<String, Object> values = new HashMap<>();
            values.put("country", "SG");
            String result = thymeleafRenderer.render("test-non-existent.xml", values);
            fail("Should fail as template name is wrong.");
        } catch (Exception e) {
            assertException(TemplateInputException.class, e);
        }
    }

    @Test
    public void wrongTemplateFormat() {
        try {
            Map<String, Object> values = new HashMap<>();
            values.put("country", "SG");
            String result = thymeleafRenderer.render("bad-template.xml", values);
            fail("Should fail as template format is wrong.");
        } catch (Exception e) {
            assertException(TemplateProcessingException.class, e);
        }
    }

    static void assertException(Class<? extends Exception> expected, Exception actual) {
        if (actual.getClass() != TechnicalException.class)
            fail("Only TechnicalException should be thrown.");
        if (actual.getCause().getClass() !=  expected )
            fail("Parent exception should be " + actual.getCause().getClass());

        assertEquals("Template Render Exception", actual.getMessage());
    }
}
