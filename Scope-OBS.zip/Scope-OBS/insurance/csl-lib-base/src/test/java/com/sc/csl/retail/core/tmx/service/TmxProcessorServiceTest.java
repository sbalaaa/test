package com.sc.csl.retail.core.tmx.service;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.config.TmxConfig;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TmxRedStatusException;
import com.sc.csl.retail.core.tmx.TmxObligatoryFields;
import com.sc.csl.retail.core.tmx.TmxRiskStatus;
import com.sc.csl.retail.core.tmx.gateway.TmxGateway;
import com.sc.csl.retail.core.tmx.model.TmxUserVerificationResponse;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.web.CSLRequestContext;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class TmxProcessorServiceTest {

    @Mock
    TmxConfig.CommonConfig tmxCommonConfig;

    @Mock
    TmxConfig.TmxCountryConfig tmxConfigurationHk;

    @Mock
    TmxConfig.TmxCountryConfig tmxConfigurationSg;

    TmxProcessorService tmxProcessor = TmxProcessorService.getInstance();

    @Mock
    CSLRequestContext cslRequestContext;

    Map<String, Object> tmxParamaters;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        when(cslRequestContext.getRelId()).thenReturn("01S94890");
        when(cslRequestContext.getUaas2id()).thenReturn("01S94890");
        when(cslRequestContext.getRequestId()).thenReturn("111111111111111");
        when(cslRequestContext.getChannel()).thenReturn("IBKBMW");
        when(cslRequestContext.getJSessionId()).thenReturn("1234567890");
        when(cslRequestContext.getOperatorId()).thenReturn("DUMMY-OPERATOR");
        when(cslRequestContext.getClientIp()).thenReturn("10.23.210.57");
        when(cslRequestContext.getCountry()).thenReturn("SG");
        when(cslRequestContext.getTmxSessionId()).thenReturn("1222-222-4444-222222222");
        when(cslRequestContext.getCurrentAuthLevel()).thenReturn(AccessLevel.ONE_FACTOR);

        when(tmxCommonConfig.getMessageVersion()).thenReturn("2.0");
        when(tmxCommonConfig.getMessageTypeName()).thenReturn("Risk:ThreatMetrixRiskMonitoring");
        //when(tmxCommonConfig.getMessageSubTypeName()).thenReturn("verifyUserSession");
        when(tmxCommonConfig.getMessageSenderBody()).thenReturn("IBNK");
        when(tmxCommonConfig.getMessageSenderDomainName()).thenReturn("Risk");
        when(tmxCommonConfig.getMessageSenderSubDomainNameType()).thenReturn("ComplianceScreening");
        when(tmxCommonConfig.getOriginationCountryCode()).thenReturn("ALL");
        when(tmxCommonConfig.getCaptureSystem()).thenReturn("IBNK");
        when(tmxCommonConfig.getRequestPayloadFormat()).thenReturn("JSON");
        when(tmxCommonConfig.getRequestPayloadVersion()).thenReturn("1.0");
        when(tmxCommonConfig.getRequestServiceTypeTMX()).thenReturn("ALL");
        when(tmxCommonConfig.getRequestOutputFormat()).thenReturn("JSON");
        when(tmxCommonConfig.getPossibleDuplicate()).thenReturn("FALSE");
        when(tmxCommonConfig.getApplicationName()).thenReturn("IBK");

        when(tmxConfigurationHk.getApiKey()).thenReturn("HK_API_KEY");
        when(tmxConfigurationHk.getOrgId()).thenReturn("HK_ORG_ID");
        when(tmxConfigurationHk.getUsername()).thenReturn("HK_USER");
        when(tmxConfigurationHk.getPassword()).thenReturn("HK_PASS");

        when(tmxConfigurationSg.getApiKey()).thenReturn("SG_API_KEY");
        when(tmxConfigurationSg.getOrgId()).thenReturn("SG_ORG_ID");
        when(tmxConfigurationSg.getUsername()).thenReturn("SG_USER");
        when(tmxConfigurationSg.getPassword()).thenReturn("SG_PASS");

        tmxProcessor.setCslRequestContext(cslRequestContext);
        tmxProcessor.setTmxCommonConfig(tmxCommonConfig);
        tmxProcessor.setCountryConfigMap(new HashMap<String, TmxConfig.TmxCountryConfig>() {{
            put(CSLConstants.COUNTRY_CODE_HK, tmxConfigurationHk);
            put(CSLConstants.COUNTRY_CODE_SG, tmxConfigurationSg);
        }});

        tmxParamaters = new HashMap<>();
        tmxParamaters.put("event_type", "ACCOUNT_CREATION");
        tmxParamaters.put("customer_event_type", "QuickBalancesRegistration");
    }

    @Test
    public void should_pass_no_feedback() {
        TmxGateway tmxGateway = prepareMockTmxGateway("LOW");
        tmxProcessor.setTmxGateway(tmxGateway);
        tmxProcessor.verifySession(tmxParamaters);
        verify(tmxGateway, never()).sendUserSessionFeedback(any());
    }

    @Test
    public void should_send_feedback_medium_risk() {
        TmxGateway tmxGateway = prepareMockTmxGateway("MEDIUM");
        tmxProcessor.setTmxGateway(tmxGateway);
        TmxUserVerificationResponse response = tmxProcessor.verifySession(tmxParamaters);
        assertEquals(TmxRiskStatus.MEDIUM, response.getTmxRiskStatus());
    }

    @Test
    public void should_send_feedback_medium_risk_response_contains_error() {
        TmxGateway tmxGateway = prepareMockTmxGateway("MEDIUM", "fail_internal_error");
        tmxProcessor.setTmxGateway(tmxGateway);
        TmxUserVerificationResponse response = tmxProcessor.verifySession(tmxParamaters);
        verify(tmxGateway, times(1)).verifyUserSession(any(), any());
        assertEquals(TmxRiskStatus.MEDIUM, response.getTmxRiskStatus());
    }

    @Test(expected = TechnicalException.class)
    public void should_throw_exception_country_not_configured() {
        when(cslRequestContext.getCountry()).thenReturn("NG");
        TmxGateway tmxGateway = prepareMockTmxGateway("MEDIUM");
        tmxProcessor.setTmxGateway(tmxGateway);
        tmxProcessor.verifySession(tmxParamaters);
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_throw_exception_empty_input() {
        TmxGateway tmxGateway = prepareMockTmxGateway("MEDIUM");
        tmxProcessor.setTmxGateway(tmxGateway);
        tmxProcessor.verifySession(null);
    }

    @Test(expected = TmxRedStatusException.class)
    public void should_throw_red_status_exception() {
        TmxGateway tmxGateway = prepareMockTmxGateway("HIGH");
        tmxProcessor.setTmxGateway(tmxGateway);
        tmxProcessor.verifySession(tmxParamaters);
    }

    @Test(expected = TechnicalException.class)
    public void should_throw_technical_exception_gateway_error() {
        TmxGateway tmxGateway = mock(TmxGateway.class);
        when(tmxGateway.verifyUserSession(any(), any())).thenThrow(new TechnicalException("Connection timeout."));

        tmxProcessor.setTmxGateway(tmxGateway);
        tmxProcessor.verifySession(tmxParamaters);
    }

    private TmxGateway prepareMockTmxGateway(String status) {
        return prepareMockTmxGateway(status, null);
    }

    private TmxGateway prepareMockTmxGateway(String status, String requestResult) {
        TmxGateway tmxGateway = mock(TmxGateway.class);

        doAnswer(invocationOnMock -> {
            Map<String, Object> obligatoryParameters = (Map<String, Object>) invocationOnMock.getArguments()[0];
            assertNotNull(obligatoryParameters.get(TmxObligatoryFields.messageTimestamp.name()));
            assertNotNull(obligatoryParameters.get(TmxObligatoryFields.initiatedTimestamp.name()));
            assertEquals("FALSE", obligatoryParameters.get(TmxObligatoryFields.possibleDuplicate.name()));
            assertEquals("111111111111111", obligatoryParameters.get(TmxObligatoryFields.requestUID.name()));
            assertEquals("Agent_Mobile", obligatoryParameters.get(TmxObligatoryFields.agentType.name()));
            assertEquals("1234567890", obligatoryParameters.get(TmxObligatoryFields.webSessionId.name()));
            assertEquals("01S94890", obligatoryParameters.get(TmxObligatoryFields.accountLogin.name()));
            assertEquals("10.23.210.57", obligatoryParameters.get(TmxObligatoryFields.inputIpAddress.name()));
            assertEquals("SG", obligatoryParameters.get(TmxObligatoryFields.countryCode.name()));
            assertEquals("1222-222-4444-222222222", obligatoryParameters.get(TmxObligatoryFields.sessionIdTMX.name()));
            assertEquals("SG_ORG_ID", obligatoryParameters.get(TmxObligatoryFields.orgId.name()));
            assertEquals("SG_ORG_ID", obligatoryParameters.get(TmxObligatoryFields.profileOrgId.name()));
            assertEquals("SG_API_KEY", obligatoryParameters.get(TmxObligatoryFields.apiKey.name()));
            assertEquals("SG_RETAIL_IBANKING", obligatoryParameters.get(TmxObligatoryFields.lineOfBusiness.name()));
            assertEquals("IBK", obligatoryParameters.get(TmxObligatoryFields.applicationName.name()));

            Map<String, Object> specificParameters = (Map<String, Object>) invocationOnMock.getArguments()[1];
            assertEquals( "ACCOUNT_CREATION", specificParameters.get("event_type"));
            assertEquals("QuickBalancesRegistration", specificParameters.get("customer_event_type"));

            TmxUserVerificationResponse tmxUserSessionVerificationResponse = new TmxUserVerificationResponse();
            tmxUserSessionVerificationResponse.setRiskRating(status);
            if (requestResult != null) {
                tmxUserSessionVerificationResponse.setRequestResult(requestResult);
            }
            return tmxUserSessionVerificationResponse;
        }).when(tmxGateway).verifyUserSession(anyMap(), anyMap());

        return tmxGateway;
    }
}
