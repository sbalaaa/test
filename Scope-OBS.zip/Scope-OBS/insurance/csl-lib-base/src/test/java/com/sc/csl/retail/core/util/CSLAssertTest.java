package com.sc.csl.retail.core.util;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.ErrorCode;
import lombok.Getter;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

public class CSLAssertTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
    public void isTrue() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.isTrue(false, TestErrorCodes.VALIDATION_ERROR_CODE);

    }

    @Test
    public void isNull() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.isNull("Something", TestErrorCodes.VALIDATION_ERROR_CODE);
    }

    @Test
    public void notNull() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.notNull(null, TestErrorCodes.VALIDATION_ERROR_CODE);
    }

    @Test
    public void hasLength() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.hasLength("", TestErrorCodes.VALIDATION_ERROR_CODE);
    }

    @Test
    public void doesNotContain() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.doesNotContain("check", "che", TestErrorCodes.VALIDATION_ERROR_CODE);
    }

    @Test
    public void doesContain() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.doesContain("100", "10", TestErrorCodes.VALIDATION_ERROR_CODE);
    }

    @Test
    public void regexMatcher() throws Exception {
        this.thrown.expect(BusinessException.class);
        this.thrown.expectMessage("Validation failed");
        CSLAssert.regexMatcher("number", "^[0-9]", TestErrorCodes.VALIDATION_ERROR_CODE);
    }
}

@Getter
enum TestErrorCodes implements ErrorCode {
    VALIDATION_ERROR_CODE("CSL-TEST-401", "Validation failed", "Validation failed");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    TestErrorCodes(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }
}