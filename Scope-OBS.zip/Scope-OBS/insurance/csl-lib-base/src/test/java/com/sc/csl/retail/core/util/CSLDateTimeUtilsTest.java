package com.sc.csl.retail.core.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;

import static com.sc.csl.retail.core.util.CSLDateTimeUtils.countrySpecificDateTime;
import static com.sc.csl.retail.core.util.CSLMockTestUtil.timeInstant;
import static org.junit.Assert.assertEquals;

@Slf4j
public class CSLDateTimeUtilsTest {
    @Before
    public void setUp() {
        CSLDateTimeUtils.freezeTime(timeInstant(12, 30));
    }

    @After
    public void tearDown() {
        CSLDateTimeUtils.unFreezeTime();
    }

    @Test
    public void should_ReturnTheLocalDateTime_ForTheGivenCountry() {
        assertEquals(localDateTime(10, 0), CSLDateTimeUtils.localDateTime("IN"));
        assertEquals(localDateTime(12, 30), CSLDateTimeUtils.localDateTime("SG"));
        assertEquals(localDateTime(12, 30), CSLDateTimeUtils.localDateTime("CN"));
        assertEquals(localDateTime(4, 30), CSLDateTimeUtils.localDateTime("CI"));
        assertEquals(localDateTime(7, 30), CSLDateTimeUtils.localDateTime("KE"));
    }

    @Test
    public void should_ReturnTheLocalDateTime_ForTheGivenCountry_InTheDefaultFormat() {
        assertEquals(localDate() + " 10:00:00", CSLDateTimeUtils.dateTimeAsString("IN"));
        assertEquals(localDate() + " 12:30:00", CSLDateTimeUtils.dateTimeAsString("SG"));
        assertEquals(localDate() + " 12:30:00", CSLDateTimeUtils.dateTimeAsString("CN"));
        assertEquals(localDate() + " 04:30:00", CSLDateTimeUtils.dateTimeAsString("CI"));
        assertEquals(localDate() + " 07:30:00", CSLDateTimeUtils.dateTimeAsString("KE"));
    }

    @Test
    public void should_ReturnTheLocalDateTime_ForTheGivenCountry_InTheGivenFormat() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MMM-dd hh:mm:ss");
        assertEquals(localDate("yyyy-MMM-dd") + " 10:00:00", CSLDateTimeUtils.dateTimeAsString("IN", dateTimeFormatter));
        assertEquals(localDate("yyyy-MMM-dd") + " 07:30:00", CSLDateTimeUtils.dateTimeAsString("KE", dateTimeFormatter));
    }

    @Test
    public void should_ReturnZonedDateTime_ForTheGivenDateString_TimeString_Country() {
        assertEquals(getDate("2018/05/06 00:30:00"), countrySpecificDateTime("2018/05/05","22:00:00","IN"));
        assertEquals(getDate("2018/05/05 16:00:00"), countrySpecificDateTime("2018/05/05","12:00:00","AE"));
        assertEquals(getDate("2018/05/05 11:30:00"), countrySpecificDateTime("2018/05/05","11:30:00","SG"));
        assertEquals(getDate("2018/05/05 11:30:00"), countrySpecificDateTime("2018/05/05","11:30:00","MY"));
        assertEquals(getDate("2018/05/05 11:30:00"), countrySpecificDateTime("2018/05/05","11:30:00","CN"));
        assertEquals(getDate("2018/05/05 11:30:00"), countrySpecificDateTime("2018/05/05","11:30:00","HK"));
        assertEquals(getDate("2018/05/05 16:30:00"), countrySpecificDateTime("2018/05/05","08:30:00","CI"));
    }

    @Test
    public void should_ReturnZonedDateTime_ForTheGivenDateString_Country() {
        assertEquals(getDate("2018/05/05 02:30:00"), countrySpecificDateTime("2018/05/05","IN"));
        assertEquals(getDate("2018/05/05 04:00:00"), countrySpecificDateTime("2018/05/05","AE"));
        assertEquals(getDate("2018/05/05 00:00:00"), countrySpecificDateTime("2018/05/05","SG"));
        assertEquals(getDate("2018/05/05 00:00:00"), countrySpecificDateTime("2018/05/05","MY"));
        assertEquals(getDate("2018/05/05 00:00:00"), countrySpecificDateTime("2018/05/05","CN"));
        assertEquals(getDate("2018/05/05 00:00:00"), countrySpecificDateTime("2018/05/05","HK"));
        assertEquals(getDate("2018/05/05 08:00:00"), countrySpecificDateTime("2018/05/05","CI"));
    }

    private Date getDate(String dateInString) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        try {
            formatter.setTimeZone(TimeZone.getTimeZone(ZoneId.of("Singapore")));
            return formatter.parse(dateInString);
        }
        catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private LocalDateTime localDateTime(int hour, int minute) {
        return LocalDateTime.of(LocalDate.now(), LocalTime.of(hour, minute, 0));
    }

    private String localDate() {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    private String localDate(String pattern) {
        return LocalDate.now().format(DateTimeFormatter.ofPattern(pattern));
    }

}
