package com.sc.csl.retail.core.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import javax.xml.bind.annotation.XmlRootElement;

import org.junit.Test;

import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import io.crnk.core.resource.list.DefaultResourceList;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CSLJsonApiUtilsTest {

	@Test
	public void should_return_Object_from_jsonApiString() {

		DefaultResourceList<CSLJsonApiUtilsTest.User> userList = CSLJsonApiUtils.toObject(jsonApiResponse(), CSLJsonApiUtilsTest.User.class);

		assertEquals(1,userList.size());
		assertEquals("Vincent Ming Wai",userList.get(0).getFirstName());
		assertNull(userList.get(0).getCity());
		assertEquals("Vincent.Wong@sc.com",userList.get(0).getEmail());
		assertEquals("Wong",userList.get(0).getLastName());
		assertEquals("1234040",userList.get(0).getPsId());
	}

	@Test
	public void should_return_jsonApiString_from_Object() {
		User user = new User();
		user.setAdmin(true);
		user.setFirstName("Vincent Ming Wai");
		user.setLastName("Wong");
		user.setEmail("Vincent.Wong@sc.com");
		user.setPsId("1234040");

		String requestStr = CSLJsonApiUtils.toJsonApiFormat(user);
		DefaultResourceList<User> users = CSLJsonApiUtils.toObject(requestStr, User.class);

		assertEquals(1,users.size());
		assertEquals("Vincent Ming Wai",users.get(0).getFirstName());
		assertNull(users.get(0).getCity());
		assertEquals("Vincent.Wong@sc.com",users.get(0).getEmail());
		assertEquals("Wong",users.get(0).getLastName());
		assertEquals("1234040",users.get(0).getPsId());
		assertEquals(true,users.get(0).isAdmin());

	}

	String jsonApiResponse() {
		String str = "{\"data\":[{\"id\":\"1234040\",\"type\":\"users\",\"attributes\":{\"firstName\""
				+ ":\"Vincent Ming Wai\",\"lastName\":\"Wong\",\"email\":\"Vincent.Wong@sc.com\"},"
				+ "\"relationships\":{},\"links\":{\"self\""
				+ ":\"http://localhost:8081/retail/api/v3/sample/users/1234040\"}}],\"links\""
				+ ": {\"health\":\"\"},\"meta\": {\"developer\""
				+ ": \"Karthik Chandraraj\",\"email\": \"karthik.chandraraj@sc.com\"}}";
		return str;
	}

	@Data
	@XmlRootElement
	@JsonApiResource(type = "users")
	static public class User {
		@JsonApiId
		private String psId;
		private String firstName;
		private String lastName;
		private String email;
		private boolean admin;
		private String city;
	}
}

