package com.sc.csl.retail.core.util;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.json.JSONException;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONAssert;

import io.crnk.core.engine.document.Document;
import io.crnk.core.engine.document.ErrorData;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CSLJsonUtilsTest {
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	private class TestDao {
		String id;
	}

	@Test
	public void should_Include_NullAttributes() throws JSONException {
		String json = CSLJsonUtils.toJson(new TestDao(), true);
		JSONAssert.assertEquals("{ \"id\" : null}", json, false);
	}

	@Test
	public void should_Include_EmptyAttributes() throws JSONException {
		String json = CSLJsonUtils.toJson(new TestDao(""), true);
		JSONAssert.assertEquals("{ \"id\" : \"\"}", json, false);
	}

	@Test
	public void should_NotInclude_NullAttributes() throws JSONException {
		String json = CSLJsonUtils.toJson(new TestDao());
		JSONAssert.assertEquals("{}", json, false);
	}

	@Test
	public void should_NotInclude_EmptyAttributes() throws JSONException {
		String json = CSLJsonUtils.toJson(new TestDao(""), true);
		JSONAssert.assertEquals("{}", json, false);
	}

	@Test
	public void should_Parse_CrnkResponse_DocumentsWithError() throws JSONException {
		String errorResponse = "{\n" +
				"    \"errors\": [\n" +
				"        {\n" +
				"            \"id\": \"2b951eee-13dd-494f-bff6-199b4b75bbe9\",\n" +
				"            \"status\": \"401\",\n" +
				"            \"code\": \"CSL-300\",\n" +
				"            \"title\": \"Unauthorized\",\n" +
				"            \"detail\": \"Not authorized to access the resource\",\n" +
				"            \"meta\": {\n" +
				"                \"accessLevel\": \"TWO_FACTOR\",\n" +
				"                \"tokenType\": \"SMS\"\n," +
				"                \"authFunction\": \"DEFAULTAUTH\"\n" +
				"            }\n" +
				"        }\n" +
				"    ]\n" +
				"}";
		Document document = CSLJsonUtils.parseJson(errorResponse, Document.class);
		List<ErrorData> errors = document.getErrors();
		assertNotNull(errors);
		ErrorData errorData = errors.get(0);
		assertNotNull(errorData);
		assertEquals("2b951eee-13dd-494f-bff6-199b4b75bbe9", errorData.getId());
		assertEquals("CSL-300", errorData.getCode());
		assertEquals("401", errorData.getStatus());
	}
}
