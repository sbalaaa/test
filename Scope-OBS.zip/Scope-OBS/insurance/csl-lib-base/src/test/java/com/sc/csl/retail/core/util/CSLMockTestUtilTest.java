package com.sc.csl.retail.core.util;

import org.junit.Test;

import com.sc.csl.retail.core.web.RestrictedAccessAspect;

public class CSLMockTestUtilTest {
	
	@Test
	public void should_get_mock_restricted_Access() {
		
		RestrictedAccessAspect mockRestrictedAccessAspect = CSLMockTestUtil.mockRestrictedAccessAspect(2);
		
		
	}

}
