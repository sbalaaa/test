package com.sc.csl.retail.core.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.builder.Input;
import org.xmlunit.diff.Diff;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlRootElement;

import static org.junit.Assert.*;

@Slf4j
@RunWith(PowerMockRunner.class)
public class CSLXmlUtilsTest {

	@Test
	@PrepareForTest(CSLXmlUtils.class)
	public void shouldCreate_NewJaxbContext_IfCacheNotAvailable() throws JAXBException, ClassNotFoundException {
		PowerMockito.spy(CSLXmlUtils.class);
		CSLXmlUtils.jaxbContext(Customer.class);
		CSLXmlUtils.jaxbContext(Customer.class);

		PowerMockito.verifyStatic(Mockito.times(1));
		CSLXmlUtils.createJaxbContext(Customer.class);

		PowerMockito.verifyStatic(Mockito.times(1));
		CSLXmlUtils.jaxbContextForClass(Customer.class);

		PowerMockito.verifyStatic(Mockito.never());
		CSLXmlUtils.jaxbContextForPackage(Customer.class.getPackage().getName());
	}

	@Test
	public void shouldConvert_ObjectToXml() throws JAXBException, ClassNotFoundException {
		Customer customer = new Customer("Drake", 35);

		String xml = CSLXmlUtils.toXml(customer);

		Diff diff = DiffBuilder.compare(Input.fromString(customerXml()))
					.withTest(Input.fromString(xml))
					.checkForSimilar()
					.build();

		assertFalse(diff.toString(), diff.hasDifferences());
	}

	@Test
	public void shouldConvert_XmlToObject() throws JAXBException, ClassNotFoundException {
		Customer customer = CSLXmlUtils.toObject(customerXml(), Customer.class);

		assertNotNull(customer);
		assertEquals("Drake", customer.name);
		assertEquals(35, customer.age);
	}

	private String customerXml() {
		return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
				"<customer><age>35</age><name>Drake</name></customer>";
	}

	@Data
	@AllArgsConstructor
	@XmlRootElement
	@NoArgsConstructor
	public static class Customer {
		private String name;
		private int age;
	}
}