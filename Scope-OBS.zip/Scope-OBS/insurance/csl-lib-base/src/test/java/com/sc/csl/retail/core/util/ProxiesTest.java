package com.sc.csl.retail.core.util;

import lombok.extern.slf4j.Slf4j;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.littleshoot.proxy.HttpProxyServer;
import org.littleshoot.proxy.impl.DefaultHttpProxyServer;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.Proxy;
import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

//Ignore this test for jenkins build, but still remains for further issue detection
@Ignore
@Slf4j
public class ProxiesTest {
    private static HttpProxyServer proxyServer;
    private static String testProxy;

    @BeforeClass
    public static void initProxyServer() {
        proxyServer = DefaultHttpProxyServer.bootstrap().withPort(0).start();
        String testProxyHost = proxyServer.getListenAddress().getHostString();
        int testProxyPort = proxyServer.getListenAddress().getPort();
        testProxy = testProxyHost + ":" + testProxyPort;
    }

    @AfterClass
    public static void tearDown() {
        proxyServer.stop();
    }

    @Test
    public void shouldReturnTheNextAvailableProxy() {
        Proxies proxies = new Proxies(asList(
                "127.0.0.2:8080",
                testProxy)
        );
        proxies.setTimeoutInMillis(2000);

        Proxy proxy = proxies.nextAvailableProxy();
        log.info("Available proxy : {}", proxy);
        assertEquals("HTTP @ /"+ testProxy, proxy.toString());
    }

    @Test
    public void shouldReturn_LastKnow_AvailableProxy() {
        Proxies object = new Proxies(asList(
                "127.0.0.2:8080",
                testProxy)
        );
        Proxies proxies = spy(object);
        List<Proxy> proxyList = (List<Proxy>) ReflectionTestUtils.getField(proxies, "proxyList");
        Proxy dummyProxy = proxyList.get(0);
        Proxy workingProxy = proxyList.get(1);
        ReflectionTestUtils.setField(proxies, "lastKnow", workingProxy);

        Proxy proxy = proxies.nextAvailableProxy();
        log.info("Available proxy : {}", proxy);

        assertEquals("HTTP @ /"+ testProxy, proxy.toString());
        assertEquals(workingProxy, workingProxy);
        verify(proxies, never()).isAvailable(dummyProxy);
    }


    @Test(expected = RuntimeException.class)
    public void should_Fail_TheNextAvailableProxy() {
        Proxies proxies = new Proxies(asList("127.0.0.2:8080"));
        proxies.setTimeoutInMillis(1000);
        proxies.nextAvailableProxy();
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_Fail_OnInit_WithInvalidValues() {
        Proxies proxies = new Proxies(asList("invalid"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_Fail_OnInit_WithEmptyList() {
        Proxies proxies = new Proxies(Collections.emptyList());
    }

}