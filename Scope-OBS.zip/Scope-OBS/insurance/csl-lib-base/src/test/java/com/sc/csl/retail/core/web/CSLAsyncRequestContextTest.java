package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CSLAsyncRequestContextTest {

	@Test
	public void should_SetCslHeaders_OnUpdatingRequestContext() {
		CSLAsyncRequestContext cslAsyncRequestContext = new CSLAsyncRequestContext();

		cslAsyncRequestContext.setRelId("0123187323");
		cslAsyncRequestContext.setChannel("MOBILE");
		cslAsyncRequestContext.setCountry("IN");
		cslAsyncRequestContext.setLanguage("EN");
		cslAsyncRequestContext.setRequestId("AJS1137u2o183");
		cslAsyncRequestContext.setUaas2id("1527380");
		cslAsyncRequestContext.setSegmentCode("S01");

		ThreadLocalStore localStore = ThreadLocalStore.getInstance();

		CSLUser cslUser = localStore.getCslUser();
		CSLHeader cslHeader = localStore.getCslHeader();
		CSLClient client = cslHeader.getClient();

		assertEquals("0123187323", cslUser.getRelId());

		assertEquals("IN", cslUser.getCountry());
		assertEquals("EN", cslUser.getLanguage());
		assertEquals("S01", cslUser.getSegCd());
		assertEquals("1527380", cslUser.getUaas2id());

		assertEquals("MOBILE", client.getChannel());
	}
}