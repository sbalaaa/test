package com.sc.csl.retail.core.web;

import com.auth0.jwt.JWT;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

import static com.google.common.net.HttpHeaders.X_FORWARDED_FOR;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class CSLContextFilterTest {
	private CSLContextFilter cslFilter = new CSLContextFilter();
	private ThreadLocalStore threadLocalStore = ThreadLocalStore.getInstance();

	@Mock
	private HttpServletRequest mockHttpRequest;

	@Before
	public void init() {
		cslFilter = new CSLContextFilter();
		initMocks(this);
		threadLocalStore.clearThreadLocalStore();
		threadLocalStore.setRequestId("REQ-101");
	}

	@Test
	public void should_populateTheRequestContext_FromInternalAccessToken() {
		String internalAccessToken = "eyJhbGciOiJSUzI1NiJ9.ewogICJqdGkiOiAiYjY2ZTYyOTljN2JlYjJmYTE5OThiY2ZlYmI5YTc2IiwKICAiY2xpZW50X2lkIjogIkNFTVMiLAogICJpYXQiOiAxNTA2MzMyMTI1LAogICJleHAiOiAxNTA2MzMyMjQ1LAogICJzdWIiOiAiMTUyNzM4MCIsCiAgInVzZXJuYW1lIjogIjE1MjczODAiLAogICJpc3MiOiAiQ1NMLUFVVEgiLAogICJhdWQiOiAiQ1NMLUFVVEgiLAogICJncmFudF90eXBlIjogImNsaWVudF9jcmVkZW50aWFscyIsCiAgInR5cGUiOiAiQ1NMLUlBVCIsCiAgImF1dGhfbGV2ZWwiOiAxLAogICJhdXRoX2xldmVsX25hbWUiOiAiT05FX0ZBQ1RPUiIsCiAgInJlbF9pZCI6ICIxMjIxMzQxMzh1IiwKICAiY2hhbm5lbCI6ICJDRU1TIiwKICAiY291bnRyeSI6ICJTRyIsCiAgImxhbmd1YWdlIjogImVuIiwKICAidWFhczJfaWQiOiAidXNlcjE4MCIsCiAgInNlZ21lbnRfY29kZSI6ICJJVCIsCiAgInJlcXVlc3RfaWQiOiAiN2IxY2E1NGUtMjg1YS00YWRhLWI4NjItZjVmNzU2MDdmNTc4Igp9.pPH4IzLCHKleSwD7P_y5_n1ryAr6MNS1-xHdm2mlGtzuyyDFQ4EFtZJ0lQWDIgyuNS7aX5uF6z-Q6nTXLxIlf_m0FfQ9yhasc--2GjVPLTknK-pJDK0-bcFUbz2D-YU53lv8SGFDF3UH7kDb1GKqschD1oQf1Ocws9OyH71e678G7fPmrfCRgKFo1Ir4pX1JYUtYnsMepUl2J9yQOaq_4advcDXfqGpqX3TVUymTzXQNRO5TgpTV6qpc9zOJ86gPXZ_YzRBXJ7EvkhEVxX8DKwRpbwFsJfuRRFPz01hZJbCkVHDUh21rRtXJrpTFfPTzNRW0KH1iYcQ538C7j5v07w";
		JWT jwt = JWT.decode(internalAccessToken);
		threadLocalStore.setInternalAccessTokenString(internalAccessToken);
		threadLocalStore.setInternalAccessToken(jwt);

		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertNotNull(requestContext);
		assertEquals("user180",requestContext.getUaas2id());
		assertEquals("122134138u",requestContext.getRelId());
		assertEquals("SG",requestContext.getCountry());
		assertEquals("en",requestContext.getLanguage());
		assertEquals("CEMS",requestContext.getChannel());
		assertEquals("CEMS",requestContext.getClientId());
		assertEquals("IT",requestContext.getSegmentCode());
		assertFalse("isCCLogin flag should be false", requestContext.isCCLogin());
		assertEquals(AccessLevel.ONE_FACTOR, requestContext.getCurrentAuthLevel());
	}

	@Test
	public void should_populateTheRequestContext_FromInternalAccessToken_ForCCLogin() {
		String iatCCLogin = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJiNjZlNjI5OWM3YmViMmZhMTk5OGJjZmViYjlhNzYiLCJjbGllbnRfaWQiOiJDRU1TIiwiaWF0IjoxNTA2MzMyMTI1LCJleHAiOjE1MjY0NzEwNDgsInN1YiI6IjE1MjczODAiLCJ1c2VybmFtZSI6IjE1MjczODAiLCJpc3MiOiJDU0wtQVVUSCIsImF1ZCI6IkNTTC1BVVRIIiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInR5cGUiOiJDU0wtSUFUIiwiYXV0aF9sZXZlbCI6MSwiYXV0aF9sZXZlbF9uYW1lIjoiT05FX0ZBQ1RPUiIsInJlbF9pZCI6IjEyMjEzNDEzOHUiLCJjaGFubmVsIjoiQ0VNUyIsImlzQ0NMb2dpbiI6InRydWUiLCJjb3VudHJ5IjoiU0ciLCJsYW5ndWFnZSI6ImVuIiwidWFhczJfaWQiOiJ1c2VyMTgwIiwic2VnbWVudF9jb2RlIjoiSVQiLCJyZXF1ZXN0X2lkIjoiN2IxY2E1NGUtMjg1YS00YWRhLWI4NjItZjVmNzU2MDdmNTc4In0.V_DGBBi9WxUdUgGFB0iznVG6dWLN8E1sv2PhpcamV-I";
		JWT jwt = JWT.decode(iatCCLogin);
		threadLocalStore.setInternalAccessTokenString(iatCCLogin);
		threadLocalStore.setInternalAccessToken(jwt);

		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertNotNull(requestContext);
		assertEquals("user180",requestContext.getUaas2id());
		assertEquals("122134138u",requestContext.getRelId());
		assertEquals("SG",requestContext.getCountry());
		assertEquals("en",requestContext.getLanguage());
		assertEquals("CEMS",requestContext.getChannel());
		assertEquals("CEMS",requestContext.getClientId());
		assertEquals("IT",requestContext.getSegmentCode());
		assertTrue("isCCLogin flag should be true", requestContext.isCCLogin());
		assertEquals(AccessLevel.ONE_FACTOR, requestContext.getCurrentAuthLevel());
	}

	@Test
	public void should_populateTheRequestContext_FromCslUserHeader() {
		CSLUser cslUser = new CSLUser("uaaId123", "01relId123", "IN", "en", "SEG01");
		when(mockHttpRequest.getHeader(CSL_REQUEST_ID)).thenReturn("REQ-101");
		when(mockHttpRequest.getHeader(CSL_USER)).thenReturn(CSLJsonUtils.toJson(cslUser));
		when(mockHttpRequest.getHeader(TRUE_CLIENT_IP)).thenReturn("203.20.20.25");
		when(mockHttpRequest.getHeader(X_FORWARDED_FOR)).thenReturn("203.20.20.25,15.23.45.43");
		
		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertNotNull(requestContext);
		assertEquals("REQ-101", requestContext.getRequestId());
		assertEquals("uaaId123", requestContext.getUaas2id());
		assertEquals("01relId123", requestContext.getCompositeRelId());
		assertEquals("01", requestContext.getCustomerType());
		assertEquals("relId123", requestContext.getCustomerId());
		assertEquals("IN", requestContext.getCountry());
		assertEquals("en", requestContext.getLanguage());
		assertEquals(null, requestContext.getChannel());
		assertEquals("SEG01", requestContext.getSegmentCode());
		assertEquals("203.20.20.25", requestContext.getClientIp());
		assertEquals("15.23.45.43", requestContext.getRemoteAddress());
		assertEquals(null, requestContext.getCurrentAuthLevel());
	}

	@Test
	public void should_populateTheRequestContext_FromCslUserCslHeaderCslUserInfo() {
		CSLUser cslUser = new CSLUser("uaaId123", "01relId123", "IN", "en", "SEG01", "CEMS");
		CSLClient cslClient = new CSLClient(
				"clientReqId123", "127.0.0.1", "82875bc8-335c-494f-8a7a-4a3a622a339a",
				"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1",
				"MBNK", "");
		CSLHeader cslHeader = new CSLHeader(cslUser, cslClient);

		when(mockHttpRequest.getHeader(CSL_REQUEST_ID)).thenReturn("REQ-101");
		when(mockHttpRequest.getHeader(CSL_USER)).thenReturn(CSLJsonUtils.toJson(cslUser));
		when(mockHttpRequest.getHeader(CSL_HEADER)).thenReturn(CSLJsonUtils.toJson(cslHeader));
		when(mockHttpRequest.getHeader(X_FORWARDED_FOR)).thenReturn("203.20.20.25,15.23.45.43");
		when(mockHttpRequest.getHeader(CSL_USER_INFO)).thenReturn("{\n" +
				"\t\"ROLE\": [\"SUPER_ADMIN\"],\n" +
				"\t\"COUNTRY\": [\"SG\"],\n" +
				"\t\"CHANNEL\": [\"IBNK\"]\n" +
				"}");

		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertEquals("REQ-101", threadLocalStore.getRequestId());
		assertNotNull(requestContext);
		assertEquals("CEMS", requestContext.getClientId());
		assertEquals("REQ-101", requestContext.getRequestId());
		assertEquals("uaaId123", requestContext.getUaas2id());
		assertEquals("relId123", requestContext.getCustomerId());
		assertEquals("01", requestContext.getCustomerType());
		assertEquals("IN", requestContext.getCountry());
		assertEquals("en", requestContext.getLanguage());
		assertEquals("MBNK", requestContext.getChannel());
		assertEquals("SEG01", requestContext.getSegmentCode());
		assertEquals("203.20.20.25", requestContext.getClientIp());
		assertEquals("15.23.45.43", requestContext.getRemoteAddress());
		assertEquals(1, requestContext.getRoles().size());
		assertEquals("SUPER_ADMIN", requestContext.getRoles().get(0));
	}

	@Test
	public void should_get_correct_customerId_for_ci() {
		CSLUser cslUser = new CSLUser("uaaId123", "relId123", "CI", "en", "SEG01");
		CSLClient cslClient = new CSLClient(
				"clientReqId123", "127.0.0.1", "82875bc8-335c-494f-8a7a-4a3a622a339a",
				"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1",
				"MBNK", "");
		CSLHeader cslHeader = new CSLHeader(cslUser, cslClient);

		when(mockHttpRequest.getHeader(CSL_REQUEST_ID)).thenReturn("REQ-101");
		when(mockHttpRequest.getHeader(CSL_USER)).thenReturn(CSLJsonUtils.toJson(cslUser));
		when(mockHttpRequest.getHeader(CSL_HEADER)).thenReturn(CSLJsonUtils.toJson(cslHeader));
		when(mockHttpRequest.getHeader(X_FORWARDED_FOR)).thenReturn("203.20.20.25");
		
		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertNotNull(requestContext);

		assertEquals("REQ-101", requestContext.getRequestId());
		assertEquals("uaaId123", requestContext.getUaas2id());
		assertEquals("relId123", requestContext.getCustomerId());
		assertNull(requestContext.getCustomerType());
		assertEquals("CI", requestContext.getCountry());
		assertEquals("en", requestContext.getLanguage());
		assertEquals("MBNK", requestContext.getChannel());
		assertEquals("SEG01", requestContext.getSegmentCode());
		assertEquals("203.20.20.25", requestContext.getClientIp());
		assertEquals("203.20.20.25", requestContext.getRemoteAddress());
		assertEquals(requestContext.getClientIp(), requestContext.getRemoteAddress());
	}

	@Test
	public void shouldReturn_TrueClientIp_IfTrueClientHeaderAvailable() {
		when(mockHttpRequest.getHeader(TRUE_CLIENT_IP)).thenReturn("203.20.20.25");
		String clientIp = cslFilter.clientIp(mockHttpRequest, emptyList());
		assertEquals("203.20.20.25", clientIp);
	}

	@Test
	public void shouldReturn_FirstAddressInForwardedList_IfTrueClientHeader_IsNotAvailable() {
		String clientIp = cslFilter.clientIp(mockHttpRequest, asList("201.20.20.21", "15.23.45.43"));
		assertEquals("201.20.20.21", clientIp);
	}

	@Test
	public void shouldReturn_RemoteAddress_IfOtherHeaders_AreNotAvailable() {
		when(mockHttpRequest.getRemoteAddr()).thenReturn("200.20.20.25");
		String clientIp = cslFilter.clientIp(mockHttpRequest, emptyList());
		assertEquals("200.20.20.25", clientIp);
	}

	@Test
	public void shouldReturn_LastAddressAsRemoteAddress_IfForwardedHeader_IsAvailable() {
		when(mockHttpRequest.getRemoteAddr()).thenReturn("200.20.20.25");
		String remoteAddress = cslFilter.remoteAddress(mockHttpRequest, asList("201.20.20.21", "15.23.45.43"));
		assertEquals("15.23.45.43", remoteAddress);
	}

	@Test
	public void shouldReturn_RemoteAddress_IfForwardedHeader_IsNotAvailable() {
		when(mockHttpRequest.getRemoteAddr()).thenReturn("200.20.20.25");
		String remoteAddress = cslFilter.remoteAddress(mockHttpRequest, emptyList());
		assertEquals("200.20.20.25", remoteAddress);
	}
	
	@Test
	public void shouldReturn_Null_IfScClientContextHeaderNotSent() {
		when(mockHttpRequest.getHeader(SC_CLIENT_CONTEXT)).thenReturn(null);
		cslFilter.populateUserContext(mockHttpRequest);
		assertNull(threadLocalStore.getSCClientContext());
	}

	@Test
	public void shouldReturn_SCClientContextHeader_IfHeaderSent() {
		when(mockHttpRequest.getHeader(SC_CLIENT_CONTEXT)).thenReturn(getSCClientContextString());
		cslFilter.populateUserContext(mockHttpRequest);

		String scClientContextStr = threadLocalStore.getSCClientContext();
		Map map = CSLJsonUtils.parseJson(scClientContextStr, Map.class);
		assertEquals("IN", map.get("Country"));
		assertEquals("RMID", map.get("userId"));
	}

	@Test
	public void shouldUse_LanguageHeader_IfUserContextNotAvailable() {
		when(mockHttpRequest.getHeader(LANGUAGE_HEADER)).thenReturn("en");
		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertEquals("en", requestContext.getLanguage());
	}

	@Test
	public void shouldUse_Null_IfBoth_UserContextAndHeader_NotAvailable() {
		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertNull(requestContext.getLanguage());
	}

	@Test
	public void shouldIgnore_LanguageHeader_IfUserContextAvailable() {
		CSLUser cslUser = new CSLUser("uaaId123", "01relId123", "IN", "en", "SEG01");
		when(mockHttpRequest.getHeader(CSL_REQUEST_ID)).thenReturn("REQ-101");
		when(mockHttpRequest.getHeader(CSL_USER)).thenReturn(CSLJsonUtils.toJson(cslUser));
		when(mockHttpRequest.getHeader(LANGUAGE_HEADER)).thenReturn("tamil");

		cslFilter.populateUserContext(mockHttpRequest);

		CSLRequestContext requestContext = threadLocalStore.getRequestContext();
		assertEquals("en", requestContext.getLanguage());
	}

	private String getSCClientContextString() {
		Map<String,String> scClientContextMap = new HashMap<>();
		scClientContextMap.put("userId", "RMID");
		scClientContextMap.put("Country","IN");
		return CSLJsonUtils.toJson(scClientContextMap);
	}
}