package com.sc.csl.retail.core.web;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Spy;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.apache.http.HttpHeaders.CONTENT_TYPE;
import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import static org.apache.http.entity.ContentType.MULTIPART_FORM_DATA;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class CSLCrnkFilterTest {

	@Spy
	private CSLCrnkFilter cslCrnkFilter = new CSLCrnkFilter(null, null);

	@Mock
	private HttpServletRequest mockRequest;
	@Mock
	private HttpServletResponse mockResponse;
	@Mock
	private FilterChain mockChain;

	@Before
	public void setUp() throws IOException, ServletException {
		initMocks(this);
		doNothing().when(cslCrnkFilter).superDoFilter(mockRequest, mockResponse, mockChain);
	}

	@Test
	public void should_Exclude_MultiPartFormData_FromCrnkFilter() throws IOException, ServletException {
		when(mockRequest.getHeader(CONTENT_TYPE)).thenReturn(MULTIPART_FORM_DATA.getMimeType());
		cslCrnkFilter.doFilter(mockRequest, mockResponse, mockChain);
		verify(mockChain).doFilter(mockRequest, mockResponse);
	}

	@Test
	public void should_NotExclude_JsonContent_FromCrnkFilter() throws IOException, ServletException {
		when(mockRequest.getHeader(CONTENT_TYPE)).thenReturn(APPLICATION_JSON.getMimeType());
		cslCrnkFilter.doFilter(mockRequest, mockResponse, mockChain);

		verify(cslCrnkFilter).superDoFilter(mockRequest, mockResponse, mockChain);
		verify(mockChain, never()).doFilter(mockRequest, mockResponse);
	}

	@Test
	public void should_NotExclude_NullContent_FromCrnkFilter() throws IOException, ServletException {
		when(mockRequest.getHeader(CONTENT_TYPE)).thenReturn(null);
		cslCrnkFilter.doFilter(mockRequest, mockResponse, mockChain);

		verify(cslCrnkFilter).superDoFilter(mockRequest, mockResponse, mockChain);
		verify(mockChain, never()).doFilter(mockRequest, mockResponse);
	}

	@Test
	public void should_NotExclude_EmptyContent_FromCrnkFilter() throws IOException, ServletException {
		when(mockRequest.getHeader(CONTENT_TYPE)).thenReturn("");
		cslCrnkFilter.doFilter(mockRequest, mockResponse, mockChain);

		verify(cslCrnkFilter).superDoFilter(mockRequest, mockResponse, mockChain);
		verify(mockChain, never()).doFilter(mockRequest, mockResponse);
	}
}
