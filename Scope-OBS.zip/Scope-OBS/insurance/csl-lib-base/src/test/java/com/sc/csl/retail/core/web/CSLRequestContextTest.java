package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLSoftTokenHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.CLIENT_ID;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CSLRequestContextTest {
	private static final List<String> CLAIMS_LIST = Arrays.asList(OPERATOR_ID_CLAIM,
			OPERATOR_TYPE_CLAIM,
			REL_ID_CLAIM,
			UAAS2_ID_CLAIM,
			CHANNEL_CLAIM,
			COUNTRY_CLAIM,
			LANGUAGE_CLAIM,
			SEGMENT_CODE_CLAIM,
			CLIENT_ID,
			PREFERRED_OTP_TYPE_CLAIM,
			JSESSION_ID_CLAIM,
			CSL_TRACKING_ID_CLAIM
	);

	@Test
	public void should_Return_CustomerType_For_2CharCountry() {
		String relId = "01S1200401Z";
		String country = "SG";
		CSLRequestContext cslRequestContext = getCslRequestContext(relId, country);

		assertNotNull(cslRequestContext.getCustomerId());
		assertNotNull(cslRequestContext.getCustomerType());
		assertEquals("01",cslRequestContext.getCustomerType());
		assertEquals("S1200401Z",cslRequestContext.getCustomerId());
	}

	@Test
	public void should_Not_SplitRelId_ForCI() {
		String relId = "1200401Z";
		String country = "CI";
		CSLRequestContext cslRequestContext = getCslRequestContext(relId, country);

		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());

		assertEquals("1200401Z",cslRequestContext.getCustomerId());
		assertEquals("1200401Z",cslRequestContext.getRelId());
	}

	@Test
	public void should_Return_CustomerType_For_NoCharCountry() {
		String relId = "S1200401Z";
		String country = "BN";

		CSLRequestContext cslRequestContext = getCslRequestContext(relId, country);

		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());
		assertEquals("S1200401Z",cslRequestContext.getCustomerId());
	}

	@Test
	public void should_Return_CustomerType_Default_2Char() {
		String relId = "01S1200401Z";
		String country = "YY";
		CSLRequestContext cslRequestContext = getCslRequestContext(relId, country);

		assertNotNull(cslRequestContext.getCustomerId());
		assertNotNull(cslRequestContext.getCustomerType());
		assertEquals("01",cslRequestContext.getCustomerType());
		assertEquals("S1200401Z",cslRequestContext.getCustomerId());
	}

	private CSLRequestContext getCslRequestContext(String relId, String country) {
		String requestId = "REQ-01";
		String sessionId = "abcd:2343:df89:2344";
		String locale = "en-ci";
		CSLHeader cslheader = new CSLHeader();
		CSLUser csluser = new CSLUser();
		csluser.setRelId(relId);
		csluser.setCountry(country);

		return new CSLRequestContext(sessionId, requestId, csluser, cslheader, locale);
	}

	@Test
	public void should_contain_jsession_id() {
		DecodedJWT internalAccessToken = mock(DecodedJWT.class);
		String requestId = "11111-2222-33333";
		Map<String, Claim> claimsMock = prepareClaimsMock();
		when(internalAccessToken.getClaims()).thenReturn(claimsMock);

		CSLRequestContext requestContext = new CSLRequestContext(internalAccessToken, requestId);
		assertEquals("jsession_id_value", requestContext.getJSessionId());
		assertEquals("operator_type_value", requestContext.getOperatorType());
		assertEquals("rel_id_value", requestContext.getRelId());
		assertEquals("uaas2_id_value", requestContext.getUaas2id());
		assertEquals("channel_value", requestContext.getChannel());
		assertEquals("country_value", requestContext.getCountry());
		assertEquals("language_value", requestContext.getLanguage());
		assertEquals("segment_code_value", requestContext.getSegmentCode());
		assertEquals("client_id_value", requestContext.getClientId());
		assertEquals("preferred_otp_type_value", requestContext.getPreferredOtpType());
		assertEquals("csl_tracking_id_value", requestContext.getTrackingId());
	}

	private Map<String, Claim> prepareClaimsMock() {
		Map<String, Claim> claimsMock = new HashMap<>();
		CLAIMS_LIST.stream().forEach( c -> claimsMock.put(c, prepareClaim(c + "_value")));
		return claimsMock;
	}

	private Claim prepareClaim(String claimString) {
		Claim claim = mock(Claim.class);
		when(claim.asString()).thenReturn(claimString);
		return claim;
	}


	@Test
	public void should_Return_CSLSoftTokenHeader() {
		String relId = "01S1200401Z";
		String country = "YY";
		String locale = "en-YY";
		CSLRequestContext cslRequestContext = getCslRequestContextForSoftTokenHeader(relId, country, locale);
		assertNotNull(cslRequestContext.getCustomerId());
		assertNotNull(cslRequestContext.getCustomerType());
		assertEquals("01",cslRequestContext.getCustomerType());
		assertEquals("S1200401Z",cslRequestContext.getCustomerId());
		assertEquals(true,cslRequestContext.isSoftTokenRegistered());
		assertEquals(true,cslRequestContext.isDeviceRegistered());
	}

	@Test
	public void should_Return_CSLRequestContext_When_Locale_Is_Empty() {
		String relId = "01012004011";
		String country = "CI";
		String locale = "";
		CSLRequestContext cslRequestContext = getCslRequestContextForSoftTokenHeader(relId, country, locale);
		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());
		assertEquals("", cslRequestContext.getLocale());
		assertEquals("01012004011", cslRequestContext.getCustomerId());
		assertEquals(true, cslRequestContext.isSoftTokenRegistered());
		assertEquals(true, cslRequestContext.isDeviceRegistered());
	}

	@Test
	public void should_Return_CSLRequestContext_When_Locale_Is_Null() {
		String relId = "01012004011";
		String country = "CI";
		String locale = null;
		CSLRequestContext cslRequestContext = getCslRequestContextForSoftTokenHeader(relId, country, locale);
		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());
		assertEquals(null, cslRequestContext.getLocale());
		assertEquals("01012004011", cslRequestContext.getCustomerId());
		assertEquals(true, cslRequestContext.isSoftTokenRegistered());
		assertEquals(true, cslRequestContext.isDeviceRegistered());
	}

	@Test
	public void should_Return_CSLRequestContext_With_En_Locale__When_Locale_Having_Value() {
		String relId = "01012004011";
		String country = "CI";
		String locale = "en-ci";
		CSLRequestContext cslRequestContext = getCslRequestContextForSoftTokenHeader(relId, country, locale);
		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());
		assertEquals("en-ci", cslRequestContext.getLocale());
		assertEquals("01012004011", cslRequestContext.getCustomerId());
		assertEquals(true, cslRequestContext.isSoftTokenRegistered());
		assertEquals(true, cslRequestContext.isDeviceRegistered());
	}

	@Test
	public void should_Return_CSLRequestContext_With_Fr_Locale__When_Locale_Having_Value() {
		String relId = "01012004011";
		String country = "CI";
		String locale = "fr-ci";
		CSLRequestContext cslRequestContext = getCslRequestContextForSoftTokenHeader(relId, country, locale);
		assertNotNull(cslRequestContext.getCustomerId());
		assertNull(cslRequestContext.getCustomerType());
		assertEquals("fr-ci", cslRequestContext.getLocale());
		assertEquals("01012004011", cslRequestContext.getCustomerId());
		assertEquals(true, cslRequestContext.isSoftTokenRegistered());
		assertEquals(true, cslRequestContext.isDeviceRegistered());
	}

	private CSLRequestContext getCslRequestContextForSoftTokenHeader(String relId, String country, String locale) {
		String requestId = "REQ-01";
		String sessionId = "abcd:2343:df89:2344";
		String language ="en";
		CSLHeader cslheader = new CSLHeader();
		CSLUser csluser = new CSLUser();
		csluser.setRelId(relId);
		csluser.setCountry(country);
		CSLSoftTokenHeader cslSoftTokenHeader = new CSLSoftTokenHeader();
		cslSoftTokenHeader.setSoftTokenRegistered(true);
		cslSoftTokenHeader.setDeviceRegistered(true);
		return new CSLRequestContext(sessionId, requestId, csluser, cslheader,language,cslSoftTokenHeader, locale);
	}
}
