package com.sc.csl.retail.core.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.HttpHeaders;
import java.io.IOException;

import static com.sc.csl.retail.core.util.CSLConstants.CALLER_SERVICE_NAME;
import static com.sc.csl.retail.core.util.CSLConstants.CSL_REQUEST_ID;
import static com.sc.csl.retail.core.util.CSLConstants.CSL_TRACKING_ID_HEADER;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class CSLRequestFilterTest {
	@Mock
	private HttpServletRequest mockRequest;
	@Mock
	private HttpServletResponse mockResponse;
	@Mock
	private FilterChain mockChain;
	@Mock
	private ThreadLocalStore mockThreadLocalStore;

	private static ObjectMapper objectMapper = CSLJsonUtils.newObjectMapper();
	private CSLRequestFilter cslRequestFilter;

	@Before
	public void setUp() {
		initMocks(this);
		when(mockRequest.getRequestURL()).thenReturn(new StringBuffer("/retail/api/v3/test"));
		when(mockRequest.getMethod()).thenReturn("GET");
		when(mockResponse.getStatus()).thenReturn(200);
		when(mockResponse.getContentType()).thenReturn(APPLICATION_JSON);
		
		cslRequestFilter = spy(new CSLRequestFilter());
		ReflectionTestUtils.setField(cslRequestFilter, "threadLocalStore", mockThreadLocalStore);
		cslRequestFilter.setObjectMapper(objectMapper);
	}

	@Test
	public void should_LogRequestAndResponse() throws ServletException, IOException {
		when(cslRequestFilter.isDebugEnabled()).thenReturn(false);
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		InOrder inOrder = Mockito.inOrder(cslRequestFilter, mockChain);
		inOrder.verify(cslRequestFilter).logRequest(mockRequest);
		inOrder.verify(mockChain).doFilter(mockRequest, mockResponse);
		inOrder.verify(cslRequestFilter).logResponse(mockRequest, mockResponse);
	}
	
	@Test
	public void should_PopulateTheRequestId_FromHeader() throws ServletException, IOException {
		when(mockRequest.getHeader(CSL_REQUEST_ID)).thenReturn("123");
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore).setRequestId("123");
	}

	@Test
	public void should_PopulateCallerServiceName_FromHeader() throws ServletException, IOException {
		when(mockRequest.getHeader(CALLER_SERVICE_NAME)).thenReturn("csl-svc-sample");
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore).setCallerServiceName("csl-svc-sample");
	}

	@Test
	public void should_NotPopulateCallerServiceName_IfHeaderNotAvailable() throws ServletException, IOException {
		when(mockRequest.getHeader(CALLER_SERVICE_NAME)).thenReturn(null);
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore, never()).setCallerServiceName(anyString());
	}

	@Test
	public void should_PopulateTracking_FromHeader() throws ServletException, IOException {
		when(mockRequest.getHeader(CSL_TRACKING_ID_HEADER)).thenReturn("f7a32ca6-6604-4ed0-a429-3c066644ab94");
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore).setTrackingId("f7a32ca6-6604-4ed0-a429-3c066644ab94");
	}

	@Test
	public void should_PopulateTracking_FromJWT() throws ServletException, IOException {
		when(mockRequest.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn("Bearer eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJlOTY1YTNmMWJhZDdhODg2MTBlMzUxNzk0ZjYxNWYxIiwiY2xpZW50X2lkIjoiTE9BRF9URVNUIiwiaWF0IjoxNTIyMzEzNDA5LCJleHAiOjE1MjIzMTM0MjksImlzcyI6IkNTTC1BVVRIIiwic2NvcGUiOlsicmVmcmVzaFRva2VuIl0sImF1ZCI6IkNTTC1BVVRIIiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsImNzbF90cmFja2luZ19pZCI6ImY3YTMyY2E2LTY2MDQtNGVkMC1hNDI5LTNjMDY2NjQ0YWI5NCJ9.bwzSM4XY8Kc3UIPEJYXqm__j5_1cn8lfl32gyd8CPQAR1v_RQoqNcH8xgT8E_X-Kb1e7Y_AXzRfrGCj_8jwTZueINbZ0XDyWE0MTlYiRPKEMnhpUYAKb_Jz2yuAn4IXurt185i3tJI__l3j5MNwSg3wBpCHWl_7MJAAsSNMDxyoSxTrT1N7vfWO5Xty78VQ3ZlcLNpBGgNBE-ZWYnYPyarp1pZ7lm0CxsJbSw1gMFwwUDVXCFHcvkOCK7YQIjmTX4Qh5pXtlEaPBpmU4haJfTg6kuqdpHzgdosZGPwlK_4jhiygky0H7shQxq4HvYiy-k9g9-AEd77YB1xAs_PbajA");
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore).setTrackingId("f7a32ca6-6604-4ed0-a429-3c066644ab94");
	}

	@Test
	public void should_GenerateNewRequestId_IfHeaderNotAvailable() throws ServletException, IOException {
		cslRequestFilter.doFilterInternal(mockRequest, mockResponse, mockChain);
		verify(mockThreadLocalStore).setRequestId(anyString());
	}
}