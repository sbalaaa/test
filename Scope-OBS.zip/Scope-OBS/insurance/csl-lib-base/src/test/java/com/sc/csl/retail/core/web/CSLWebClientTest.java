package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.model.CSLApplicationConfig;
import com.sc.csl.retail.core.util.CSLConstants;
import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.core.web.header.CSLUserInfo;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.ws.rs.core.MultivaluedMap;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static com.sc.csl.retail.core.web.CSLWebClient.DISABLE_CNC_CHECK_ENV_KEY;
import static com.sc.csl.retail.core.web.CSLWebClient.DISABLE_CNC_CHECK_KEY;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.spy;

@RunWith(PowerMockRunner.class)
@PrepareForTest({CSLWebClient.class, CSLApplicationConfig.class})
@PowerMockIgnore("javax.net.ssl.*")
public class CSLWebClientTest {
	private ThreadLocalStore mockThreadLocalStore = mock(ThreadLocalStore.class);
	private CSLRequestContext mockCSLRequestContext = mock(CSLRequestContext.class);

    private static String JKS_FILE_PATH = "classpath:/truststore/edmi.jks";
    private static String JKS_FILE_PASS = "changeit";

	@Before
	public void setup() {
		spy(System.class);
		System.setProperty(DISABLE_CNC_CHECK_KEY, "false");
	}

	@Test
	public void should_Set_Headers_For_SCB_Internal_Endpoints() {
		setUpThreadLocalStore();

		WebClient client = CSLWebClient.create(
				"https://api.sc.com",
				"username", "password", null,
				true);

		final MultivaluedMap<String, String> headers = client.getHeaders();

		assertEquals("123AB", headers.getFirst(CSLConstants.CSL_SESSION_ID));
		assertEquals("123ABC456", headers.getFirst(CSLConstants.CSL_REQUEST_ID));
		assertEquals("127.0.0.1", headers.getFirst(CSLConstants.TRUE_CLIENT_IP));
		assertEquals("1312313", headers.getFirst(CSLConstants.OTP_HEADER));
		assertEquals("csl-svc-sample", headers.getFirst(CSLConstants.CALLER_SERVICE_NAME));
		assertEquals("f7a32ca6-6604-4ed0-a429-3c066644ab94", headers.getFirst(CSLConstants.CSL_TRACKING_ID_HEADER));

		assertNotNull(headers.getFirst(CSLConstants.CSL_HEADER));
		assertNotNull(headers.getFirst(CSLConstants.CSL_USER));
		assertNotNull(headers.getFirst(CSLConstants.CSL_USER_INFO));
	}

	@Test
	public void should_Not_Set_Headers_For_External_Endpoints() {
		WebClient client = CSLWebClient.create(
				"https://jsonplaceholder.typicode.com",
				"username", "password",
				null);

		assertNull(client.getHeaders().getFirst(CSLConstants.CSL_HEADER));
		assertNull(client.getHeaders().getFirst(CSLConstants.CSL_USER));
		assertNull(client.getHeaders().getFirst(CSLConstants.CSL_SESSION_ID));
		assertNull(client.getHeaders().getFirst(CSLConstants.CSL_REQUEST_ID));
		assertNull(client.getHeaders().getFirst(CSLConstants.CSL_INTERNAL_ACCESS_TOKEN));
	}

    @Test
    public void should_return_WebClientWithDisabledCNCCheck() {
        System.setProperty(DISABLE_CNC_CHECK_KEY, "true");
        WebClient client = CSLWebClient.create("https://jsonplaceholder.typicode.com");
        CSLWebClient.setupSslTrustStore(client, JKS_FILE_PATH, JKS_FILE_PASS);

        final HTTPConduit httpConduit = WebClient.getConfig(client).getHttpConduit();
        assertTrue(httpConduit.getTlsClientParameters().isDisableCNCheck());
    }

    @Test
    public void should_return_WebClientWithTLSParamsNoTrustStore() {
        System.setProperty(DISABLE_CNC_CHECK_KEY, "true");
        WebClient client = CSLWebClient.create("https://jsonplaceholder.typicode.com");
        final HTTPConduit httpConduit = WebClient.getConfig(client).getHttpConduit();
        assertTrue(httpConduit.getTlsClientParameters().isDisableCNCheck());
    }

    @Test
    public void should_return_WebClientWithoutTLSParams() {
        WebClient client = CSLWebClient.create("https://jsonplaceholder.typicode.com");
        final HTTPConduit httpConduit = WebClient.getConfig(client).getHttpConduit();
        assertNull(httpConduit.getTlsClientParameters());
    }

    @Test
    public void should_return_TLSClientParameters() throws Exception {
        assertNotNull(CSLWebClient.getTLSClientParameters(JKS_FILE_PATH, JKS_FILE_PASS));
    }

    @Test(expected = IOException.class)
    public void should_fail_TLSClientParameters_wrongPassword() throws Exception {
        assertNotNull(CSLWebClient.getTLSClientParameters(JKS_FILE_PATH, "1"));
    }

    @Test(expected = FileNotFoundException.class)
    public void should_fail_TLSClientParameters_wrongClasspathPath() throws Exception {
        CSLWebClient.getTLSClientParameters("classpath:/truststore/edmi1.jks", JKS_FILE_PASS);
    }

    @Test(expected = FileNotFoundException.class)
    public void should_fail_TLSClientParameters_wrongGlobalPath() throws Exception {
        CSLWebClient.getTLSClientParameters("/jboss/random-name/some-subpath/truststore/edmi1.jks", JKS_FILE_PASS);
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_fail_TLSClientParameters_wrongParameters() throws Exception {
        CSLWebClient.getTLSClientParameters(null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_fail_TLSClientParameters_wrong1Parameter() throws Exception {
        CSLWebClient.getTLSClientParameters(JKS_FILE_PATH, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_fail_TLSClientParameters_wrong2Parameter() throws Exception {
        CSLWebClient.getTLSClientParameters(JKS_FILE_PATH, null);
    }

    @Test
    public void shouldReturnTrueFromSystemProperty_disableCncConfigured() {
		System.setProperty(DISABLE_CNC_CHECK_KEY, "true");
		assertTrue(CSLWebClient.isDisableCncConfigured());
	}

	@Test
	public void shouldReturnTrueFromSystemEnvironment_disableCncConfigured() throws ReflectiveOperationException {
		System.clearProperty(DISABLE_CNC_CHECK_KEY);
		when(System.getenv(DISABLE_CNC_CHECK_ENV_KEY)).thenReturn("true");
		assertTrue(CSLWebClient.isDisableCncConfigured());
	}

	@Test
	public void shouldReturnFalse_disableCncConfigured() {
		System.clearProperty(DISABLE_CNC_CHECK_KEY);
		when(System.getenv(DISABLE_CNC_CHECK_ENV_KEY)).thenReturn(null);
		assertFalse(CSLWebClient.isDisableCncConfigured());
	}

	private void setUpThreadLocalStore() {
		CSLHeader cslHeader = new CSLHeader();
		CSLUser cslUser = new CSLUser();
		cslUser.setRelId("0199385224456449");
		cslUser.setUaas2id("9113237694");
		cslUser.setCountry("IN");
		cslUser.setLanguage("en");
		cslUser.setSegCd("EXBN");

		CSLClient cslClient = new CSLClient();
		cslClient.setChannel("IBANK");
		cslHeader.setUser(cslUser);
		cslHeader.setClient(cslClient);

		CSLUserInfo cslUserInfo = new CSLUserInfo();
		List<String> roles = new ArrayList<>();
		roles.add("SUPER_ADMIN");
		cslUserInfo.setRoles(roles);

		String cslRequestId = "123ABC456";
		String cslSessionId = "123AB";
		String cslInternalAccessToken = "12323";

		spy(CSLWebClient.class);

		when(mockCSLRequestContext.getClientIp()).thenReturn("127.0.0.1");
		when(mockCSLRequestContext.getOtpHeader()).thenReturn("1312313");

		when(mockThreadLocalStore.getSessionId()).thenReturn(cslSessionId);
		when(mockThreadLocalStore.getCslHeader()).thenReturn(cslHeader);
		when(mockThreadLocalStore.getCslUser()).thenReturn(cslUser);
		when(mockThreadLocalStore.getCslUserInfo()).thenReturn(cslUserInfo);
		when(mockThreadLocalStore.getRequestId()).thenReturn(cslRequestId);
		when(mockThreadLocalStore.getRequestContext()).thenReturn(mockCSLRequestContext);
		when(mockThreadLocalStore.getInternalAccessTokenString()).thenReturn(cslInternalAccessToken);
		when(mockThreadLocalStore.getTrackingId()).thenReturn("f7a32ca6-6604-4ed0-a429-3c066644ab94");

		when(CSLWebClient.threadLocalStore()).thenReturn(mockThreadLocalStore);
		PowerMockito.mockStatic(CSLApplicationConfig.class);
		PowerMockito.when(CSLApplicationConfig.getApplicationName()).thenReturn("csl-svc-sample");
	}
}
