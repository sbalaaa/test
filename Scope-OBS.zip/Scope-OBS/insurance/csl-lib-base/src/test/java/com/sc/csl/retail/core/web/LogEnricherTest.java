package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest(LogEnricher.class)
public class LogEnricherTest {
	private ThreadLocalStore mockThreadLocalStore = mock(ThreadLocalStore.class);

	@Test
	public void should_ReturnTheCorrelationId_FromThreadLocalStore() {
		PowerMockito.spy(LogEnricher.class);
		when(mockThreadLocalStore.getCslCorrelationId()).thenReturn("[123:afd:test]");
		when(LogEnricher.threadLocalStore()).thenReturn(mockThreadLocalStore);

		String correlationId = LogEnricher.getCorrelationId();

		assertEquals("[123:afd:test]", correlationId);
	}

	@Test
	public void should_CreateEmptyCorrelation_IfRequestContextIsNull() {
		PowerMockito.spy(LogEnricher.class);
		when(mockThreadLocalStore.getCslCorrelationId()).thenReturn(null);
		when(LogEnricher.threadLocalStore()).thenReturn(mockThreadLocalStore);
		when(mockThreadLocalStore.getRequestContext()).thenReturn(null);

		String correlationId = LogEnricher.getCorrelationId();

		assertEquals("[]", correlationId);
	}

	@Test
	public void should_BuildTheCorrelationId_FromRequestContext() {
		CSLRequestContext requestContext = requestContext();

		PowerMockito.spy(LogEnricher.class);
		when(mockThreadLocalStore.getCslCorrelationId()).thenReturn(null);
		when(mockThreadLocalStore.getRequestId()).thenReturn("reqId1");
		when(mockThreadLocalStore.getRequestContext()).thenReturn(requestContext);
		when(LogEnricher.threadLocalStore()).thenReturn(mockThreadLocalStore);

		String correlationId = LogEnricher.getCorrelationId();

		assertEquals("[reqId1:session1:01relId1:IBANK:SG]", correlationId);
	}

	private CSLRequestContext requestContext() {
		CSLUser cslUser = new CSLUser("uaas1", "01relId1", "SG", "en", "seg1");
		CSLClient client = new CSLClient();
		client.setChannel("IBANK");
		CSLHeader cslHeader = new CSLHeader(cslUser, client);
		return new CSLRequestContext("session1", "reqId1", cslUser, cslHeader);
	}
}