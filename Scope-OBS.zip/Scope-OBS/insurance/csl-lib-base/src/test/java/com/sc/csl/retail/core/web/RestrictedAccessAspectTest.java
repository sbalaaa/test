package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.cache.annotations.CacheKey;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.auth.OTPParam;
import com.sc.csl.retail.core.auth.RestrictedAccess;
import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.exception.*;
import com.sc.csl.retail.core.model.OTPRequest;
import com.sc.csl.retail.core.model.SmsOtp;
import com.sc.csl.retail.core.model.SmsOtpFields;
import com.sc.csl.retail.core.model.SmsOtpValidation;
import com.sc.csl.retail.core.util.CSLConstants;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Map;

import static com.sc.csl.retail.core.auth.AccessLevel.ONE_FACTOR;
import static com.sc.csl.retail.core.auth.AccessLevel.TWO_FACTOR;
import static com.sc.csl.retail.core.exception.CSLErrorCodes.*;
import static com.sc.csl.retail.core.util.CSLConstants.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class RestrictedAccessAspectTest {
	@Mock
	private AuthGateway mockAuthGateway;
	@Mock
	private CSLRequestContext mockRequestContext;
	@Mock
	private DecodedJWT mockInternalAccessToken;
	@Mock
	private ThreadLocalStore mockLocalStore;
	@Mock
	private ProceedingJoinPoint mockJoinPoint;
	@Mock
	private Claim mockClaim;
	@Mock
	private HttpServletResponse mockResponse;

	@Before
	public void setUp() throws IOException {
		initMocks(this);
	}

	@Test
	public void shouldValidate_OtpHeader_AndGenerateTokens_For2FA() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		CSLTokenResponse cslTokenResponse = mock(CSLTokenResponse.class);
		when(cslTokenResponse.getAccessToken()).thenReturn("2134123");
		when(cslTokenResponse.getRefreshToken()).thenReturn("4523452");
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
		when(mockRequestContext.getOtpHeader()).thenReturn(otpHeader());
		when(mockAuthGateway.validateOtp(any(SmsOtpValidation.class))).thenReturn(cslTokenResponse);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockAuthGateway).validateOtp(any(SmsOtpValidation.class));
		verify(mockResponse).setHeader(CSL_ACCESS_TOKEN, "2134123");
		verify(mockResponse).setHeader(CSL_REFRESH_TOKEN, "4523452");
		verify(mockLocalStore).setInternalAccessToken(any());
		verify(mockLocalStore).setInternalAccessTokenString(any());
		verify(mockJoinPoint).proceed();

		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
		verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
	}

	@Test
	public void shouldValidate_OtpHeader_AndGenerateTokens_For2FAPlus() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		CSLTokenResponse cslTokenResponse = mock(CSLTokenResponse.class);
		when(cslTokenResponse.getAccessToken()).thenReturn("2134123");
		when(cslTokenResponse.getRefreshToken()).thenReturn("4523452");
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR_PLUS);

		when(mockRequestContext.getOtpHeader()).thenReturn(otpHeader());
		when(mockAuthGateway.validateOtp(any(SmsOtpValidation.class))).thenReturn(cslTokenResponse);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockAuthGateway).validateOtp(any(SmsOtpValidation.class));
		verify(mockResponse).setHeader(CSL_ACCESS_TOKEN, "2134123");
		verify(mockResponse).setHeader(CSL_REFRESH_TOKEN, "4523452");
		verify(mockLocalStore).setInternalAccessToken(any());
		verify(mockLocalStore).setInternalAccessTokenString(any());
		verify(mockJoinPoint).proceed();

		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
		verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
	}

	@Test
	public void shouldValidate_OtpHeader_AndNotGenerateTokens_For2FAPlus_AndAlreadyIn2FA() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		SmsOtpFields mockSmsOtpFields = mock(SmsOtpFields.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR_PLUS);

		when(mockRequestContext.getOtpHeader()).thenReturn(otpHeader());
		when(mockAuthGateway.validateOtpWithoutToken(any(SmsOtpFields.class))).thenReturn(mockSmsOtpFields);
		when(mockClaim.asInt()).thenReturn(TWO_FACTOR.authLevel()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
		verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
		verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
		verify(mockLocalStore, never()).setInternalAccessToken(any());
		verify(mockLocalStore, never()).setInternalAccessTokenString(any());

		verify(mockAuthGateway).validateOtpWithoutToken(any(SmsOtpFields.class));
		verify(mockJoinPoint).proceed();
		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
	}

	@Test
	public void shouldValidate_Otp_Mpin_Header_AndGenerateTokens_For2FAPlus() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		CSLTokenResponse cslTokenResponse = mock(CSLTokenResponse.class);
		
		when(cslTokenResponse.getAccessToken()).thenReturn("2134123");
		when(cslTokenResponse.getRefreshToken()).thenReturn("4523452");
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR_PLUS);
		when(mockAnnotation.mpinPurpose()).thenReturn(CSLConstants.MPIN_REGISTER_PURPOSE);
		
		when(mockRequestContext.getOtpHeader()).thenReturn(otpMpinHeader());
		when(mockAuthGateway.validateOtpAndMpin(any())).thenReturn(cslTokenResponse);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockAuthGateway).validateOtpAndMpin(any(SmsOtpValidation.class));
		verify(mockResponse).setHeader(CSL_ACCESS_TOKEN, "2134123");
		verify(mockResponse).setHeader(CSL_REFRESH_TOKEN, "4523452");
		verify(mockLocalStore).setInternalAccessToken(any());
		verify(mockLocalStore).setInternalAccessTokenString(any());
		verify(mockJoinPoint).proceed();

		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
		verify(mockAuthGateway, never()).validateOtpAndMpinWithoutToken(any(SmsOtpFields.class));
	}
	
	@Test
	public void shouldValidate_Otp_Mpin_Header_AndNotGenerateTokens_For2FAPlus_AndAlreadyIn2FA() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		SmsOtpFields mockSmsOtpFields = mock(SmsOtpFields.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR_PLUS);
		when(mockAnnotation.mpinPurpose()).thenReturn(CSLConstants.MPIN_RESET_PURPOSE);
		
		when(mockRequestContext.getOtpHeader()).thenReturn(otpMpinHeader());
		when(mockAuthGateway.validateOtpAndMpinWithoutToken(any(SmsOtpFields.class))).thenReturn(mockSmsOtpFields);
		when(mockClaim.asInt()).thenReturn(TWO_FACTOR.authLevel()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);
		

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockAuthGateway, never()).validateOtpAndMpin(any(SmsOtpValidation.class));
		verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
		verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
		verify(mockLocalStore, never()).setInternalAccessToken(any());
		verify(mockLocalStore, never()).setInternalAccessTokenString(any());

		verify(mockAuthGateway).validateOtpAndMpinWithoutToken(any(SmsOtpFields.class));
		verify(mockJoinPoint).proceed();
		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
	}

	
	@Test
	public void should_ThrowValidationFailedError_OnValidationError() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);

		when(mockRequestContext.getOtpHeader()).thenReturn(otpHeader());
		UnauthorizedException exception = new UnauthorizedException(new CSLOTPErrorCode("1023",
				"Max limit reached", "Validation failed"));
		doThrow(exception).when(mockAuthGateway).validateOtp(any(SmsOtpValidation.class));
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		}
		catch (RestrictedAccessException ex) {
			ErrorCode errorCode = ex.getErrorCode();
			assertEquals("CSL-OTP-1023", errorCode.getCode());
			assertEquals("Max limit reached", errorCode.getTitle());
			assertEquals("Validation failed", errorCode.getDescription());

			verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
			verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
			verify(mockLocalStore, never()).setInternalAccessToken(any());
			verify(mockLocalStore, never()).setInternalAccessTokenString(any());

			verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
			verify(mockJoinPoint, never()).proceed();
			verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
		}
	}

	@Test
	public void should_ThrowGenericValidationError_OnException() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);

		when(mockRequestContext.getOtpHeader()).thenReturn(otpHeader());
		doThrow(new RuntimeException("Test")).when(mockAuthGateway).validateOtp(any(SmsOtpValidation.class));
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		}
		catch (RestrictedAccessException ex) {
			ErrorCode errorCode = ex.getErrorCode();
			assertEquals(OTP_VALIDATION_FAILED.getCode(), errorCode.getCode());
			assertEquals(OTP_VALIDATION_FAILED.getTitle(), errorCode.getTitle());
			assertEquals(OTP_VALIDATION_FAILED.getDescription(), errorCode.getDescription());
		}
	}

	@Test
	public void should_ExecuteActualMethod_IfAlreadyOnRequiredAccessLevel() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);

		when(mockClaim.asInt()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);
		aspect.checkRestrictedAccess(mockJoinPoint);

		verify(mockJoinPoint).proceed();

		verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
		verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
		verify(mockLocalStore, never()).setInternalAccessToken(any());
		verify(mockLocalStore, never()).setInternalAccessTokenString(any());

		verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
		verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
		verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));

	}

	@Test
	public void should_NotExecuteActualMethod_AndTriggerSMS_IFNotInTheRequiredAccessLevel() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		SmsOtp mockSmsOtp = mock(SmsOtp.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
		when(mockAnnotation.tokenType()).thenReturn(TokenType.SMS);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);
		when(mockAuthGateway.sendOtp(any(OTPRequest.class))).thenReturn(mockSmsOtp);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		} catch (OTPRequiredException ex) {
			verify(mockAuthGateway).sendOtp(any(OTPRequest.class));
			assertEquals(OTP_REQUIRED, ex.getErrorCode());
			assertEquals(mockSmsOtp, ex.getSmsResponse());
			assertEquals(TokenType.SMS, ex.getTokenType());

			verify(mockJoinPoint, never()).proceed();
			verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
			verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
			verify(mockLocalStore, never()).setInternalAccessToken(any());
			verify(mockLocalStore, never()).setInternalAccessTokenString(any());

			verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
			verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));

		}
	}

	@Test
	public void should_NotExecuteActualMethod_AndTriggerSMS_For2FAPlus_EvenIfAlreadyIn2FA() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		SmsOtp mockSmsOtp = mock(SmsOtp.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
		when(mockAnnotation.tokenType()).thenReturn(TokenType.SMS);
		when(mockClaim.asInt()).thenReturn(TWO_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);
		when(mockAuthGateway.sendOtp(any(OTPRequest.class))).thenReturn(mockSmsOtp);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		}
		catch (OTPRequiredException ex) {
			verify(mockAuthGateway).sendOtp(any(OTPRequest.class));
			assertEquals(OTP_REQUIRED, ex.getErrorCode());
			assertEquals(mockSmsOtp, ex.getSmsResponse());
			assertEquals(TokenType.SMS, ex.getTokenType());

			verify(mockJoinPoint, never()).proceed();
			verify(mockResponse, never()).setHeader(eq(CSL_ACCESS_TOKEN), anyString());
			verify(mockResponse, never()).setHeader(eq(CSL_REFRESH_TOKEN), anyString());
			verify(mockLocalStore, never()).setInternalAccessToken(any());
			verify(mockLocalStore, never()).setInternalAccessTokenString(any());

			verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
			verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
		}
	}

	@Test
	public void should_NotExecuteActualMethod_AndFallbackToSMS_OTP() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		SmsOtp mockSmsOtp = mock(SmsOtp.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
		when(mockAnnotation.tokenType()).thenReturn(TokenType.USER_PREFERRED);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);
		when(mockAuthGateway.sendOtp(any(OTPRequest.class))).thenReturn(mockSmsOtp);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		}
		catch (OTPRequiredException ex) {
			verify(mockAuthGateway).sendOtp(any(OTPRequest.class));
			assertEquals(OTP_REQUIRED, ex.getErrorCode());
			assertEquals(mockSmsOtp, ex.getSmsResponse());
			assertEquals(TokenType.SMS, ex.getTokenType());

			verify(mockJoinPoint, never()).proceed();
			verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
			verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
		}
	}

	@Test
	public void should_NotExecuteActualMethod_AndThrow_RequireSoftTokenError() throws Throwable {
		RestrictedAccess mockAnnotation = mock(RestrictedAccess.class);
		when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
		when(mockAnnotation.tokenType()).thenReturn(TokenType.USER_PREFERRED);
		when(mockRequestContext.getPreferredOtpType()).thenReturn(PREFERRED_TYPE_SOFT_TOKEN);
		when(mockClaim.asInt()).thenReturn(ONE_FACTOR.authLevel());
		when(mockInternalAccessToken.getClaim(AUTH_LEVEL_CLAIM)).thenReturn(mockClaim);

		RestrictedAccessAspect aspect = restrictedAccessAspect(mockAnnotation);

		try {
			aspect.checkRestrictedAccess(mockJoinPoint);
		}
		catch (OTPRequiredException ex) {
			assertEquals(SOFT_TOKEN_OTP_REQUIRED, ex.getErrorCode());
			assertNull(ex.getSmsResponse());
			assertEquals(TokenType.SOFT_TOKEN, ex.getTokenType());

			verify(mockAuthGateway, never()).sendOtp(any(OTPRequest.class));
			verify(mockJoinPoint, never()).proceed();
			verify(mockAuthGateway, never()).validateOtp(any(SmsOtpValidation.class));
			verify(mockAuthGateway, never()).validateOtpWithoutToken(any(SmsOtpFields.class));
		}
	}
	
	@Test
	public void should_Set_OTPParams_FromParameterAnnotation() throws Throwable {
		RestrictedAccessAspect restrictedAccessAspect = new RestrictedAccessAspect();
		MethodSignature methodSignature = mock(MethodSignature.class);
		when(mockJoinPoint.getSignature()).thenReturn(methodSignature);
		when(mockJoinPoint.getArgs()).thenReturn(new Object[] { "1", "20 Seconds", "Chandrababu" });
		
		Method method = this.getClass().getDeclaredMethod("annotatedMethodToTestOTPParams", String.class, String.class, String.class);
		when(methodSignature.getMethod()).thenReturn(method);
		Map<String, String> otpParams = restrictedAccessAspect.otpParams(mockJoinPoint);
		assertEquals(otpParams.size(), 2);
		assertEquals(otpParams.get("validFor"), "20 Seconds");
		assertEquals(otpParams.get("beneficiary"), "Chandrababu");
	}

	@RestrictedAccess(accessLevel = AccessLevel.TWO_FACTOR, tokenType = TokenType.SMS, actionName = "add-payee")
	public void annotatedMethodToTestOTPParams(@CacheKey String str1,@CacheKey @OTPParam("validFor") String str2, @OTPParam("beneficiary") String varvalue) {
	}

	@Test
	public void should_Not_Set_OTPParams_FromParameterAnnotation() throws Throwable {
		RestrictedAccessAspect restrictedAccessAspect = new RestrictedAccessAspect();
		MethodSignature methodSignature = mock(MethodSignature.class);
		when(mockJoinPoint.getSignature()).thenReturn(methodSignature);
		when(mockJoinPoint.getArgs()).thenReturn(new Object[] { "1", "2", "Chandrababu" });
		
		Method method = this.getClass().getDeclaredMethod("annotatedMethodToTestWithoutOTPParams", String.class, String.class, String.class);
		when(methodSignature.getMethod()).thenReturn(method);
		Map<String, String> otpParams = restrictedAccessAspect.otpParams(mockJoinPoint);
		assertEquals(otpParams.size(), 0);
	}

	@RestrictedAccess(accessLevel = AccessLevel.TWO_FACTOR, tokenType = TokenType.SMS, actionName = "add-payee")
	public void annotatedMethodToTestWithoutOTPParams(String str1, String str2, String varvalue) {
	}

	private String otpHeader() {
		return "{\n" +
				"    \"smsOtp\": {\n" +
				"        \"encOtp\": \"UQvX1xkTZjEHM5RcAm9DNIG2TJLIZ\",\n" +
				"        \"purpose\": \"1\",\n" +
				"        \"otpSn\": \"19216\",\n" +
				"        \"keyIndex\": \"3\"\n" +
				"    },\n" +
				"    \"encOtp\": \"UQvX1xkTZjEHM5RcAm9DNIG2TJLIZ\",\n" +
				"    \"purpose\": \"1\",\n" +
				"    \"otpSn\": \"19216\",\n" +
				"    \"keyIndex\": \"3\"\n" +
				"}";
	}

	private String otpMpinHeader() {
		return "	{ \r\n" + 
				"	    \"smsOtp\": {\r\n" + 
				"	        \"encOtp\": \"UQvX1xkTZjEHM5RcAm9DNIG2TJLIZ\", \r\n" + 
				"	        \"purpose\": \"8\",\r\n" + 
				"	        \"otpSn\": \"19216\",\r\n" + 
				"	        \"keyIndex\": \"3\",\r\n" + 
				"	        \"type\": \"2\", \r\n" + 
				"	        \"encValue\": \"R7vvL3N4M8CoEac5rKrowE1g54KvbjOAZF4y3PmGJyRN4dMgUpg\"\r\n" + 
				"	    }, \r\n" + 
				"	    \"encOtp\": \"UQvX1xkTZjEHM5RcAm9DNIG2TJLIZ\",\r\n" + 
				"	    \"purpose\": \"8\",\r\n" + 
				"	    \"otpSn\": \"19216\", \r\n" + 
				"	    \"type\": \"2\",\r\n" + 
				"	    \"keyIndex\": \"3\",\r\n" + 
				"	    \"encValue\": \"R7vvL3N4M8CoEac5rKrowE1g54KvbjOAZF4y3PmGJyRN4dMgUpg\"\r\n" + 
				"	}";
	}
	
	private RestrictedAccessAspect restrictedAccessAspect(RestrictedAccess mockAnnotation) {
		return new RestrictedAccessAspect() {
			@Override
			RestrictedAccess restrictedAccessAnnotation(ProceedingJoinPoint joinPoint) {
				return mockAnnotation;
			}

			@Override
			Annotation[][] parameterAnnotations(ProceedingJoinPoint joinPoint) {
				Annotation[][] annotationArr = new Annotation[0][0];
				return annotationArr;
			}
			
			@Override
			CSLRequestContext requestContext() {
				return mockRequestContext;
			}

			@Override
			AuthGateway authGateway() {
				return mockAuthGateway;
			}

			@Override
			ThreadLocalStore threadLocalStore() {
				return mockLocalStore;
			}

			@Override
			public DecodedJWT getInternalAccessToken() {
				return mockInternalAccessToken;
			}

			@Override
			HttpServletResponse httpServletResponse() {
				return mockResponse;
			}
		};
	}
}