package com.sc.csl.retail.core.web;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TmxRedStatusException;
import com.sc.csl.retail.core.tmx.TmxParametersExtractor;
import com.sc.csl.retail.core.tmx.annotations.TmxEnabled;
import com.sc.csl.retail.core.tmx.annotations.TmxParam;
import com.sc.csl.retail.core.tmx.annotations.TmxProperty;
import com.sc.csl.retail.core.tmx.service.TmxProcessorService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.exception.CSLErrorCodes.TMX_STATUS_HIGH;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

public class TmxEnabledAspectTest {

    @Mock
    ProceedingJoinPoint mockJoinPoint;

    @Mock
    TmxProcessorService tmxProcessorService;

    TmxEnabledAspect tmxEnabledAspect;

    TmxParametersExtractor tmxParam1 = () -> new HashMap<String, String>() {{
        put("accountAddressZip", "310146");
        put("accountAddressCountry", "SG");
    }};
    TmxParametersExtractor tmxParam2 = () -> new HashMap<String, String>() {{
        put("transactionId", "abc-123");
        put("paymentReference", "9999");
    }};

    @Before
    public void setUp() throws Exception {
        initMocks(this);
        tmxEnabledAspect = new TmxEnabledAspect() {
            protected TmxProcessorService getTmxProcessorService() {
                return tmxProcessorService;
            }
        };
    }

    static final String METHOD_WITH_TMX_PARAMS = "methodWithTmxParams";
    static final String METHOD_WITH_TMX_PARAMS_ANNOTATED = "methodWithTmxParamsAnnotated";
    static final String METHOD_WITH_TMX_PARAMS_NO_PROPERTIES = "methodWithTmxParamsNoProperties";
    static final String METHOD_WITH_PLAIN_TMX_PARAMS = "methodWithPlainTmxParams";
    @Test
    public void should_create_tmx_parameters_from_annotations() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS, new Object[]{tmxParam1, tmxParam2});

        doAnswer(invocationOnMock -> {
            Map<String, Object> tmxParameters = (Map<String, Object>) invocationOnMock.getArguments()[0];
            assertEquals("ACCOUNT_CREATION", tmxParameters.get("eventType"));
            assertEquals("QuickBalancesRegistration", tmxParameters.get("customerEventType"));
            return null;
        }).when(tmxProcessorService).verifySession(anyMap());

        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, times(1)).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    @Test
    public void should_create_tmx_parameters_from_args() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS, new Object[]{tmxParam1, tmxParam2});

        doAnswer(invocationOnMock -> {
            Map<String, Object> tmxParameters = (Map<String, Object>) invocationOnMock.getArguments()[0];
            assertEquals("abc-123", tmxParameters.get("transactionId"));
            assertEquals("9999", tmxParameters.get("paymentReference"));
            assertEquals("310146", tmxParameters.get("accountAddressZip"));
            assertEquals("SG", tmxParameters.get("accountAddressCountry"));
            return null;
        }).when(tmxProcessorService).verifySession(anyMap());

        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, times(1)).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    @Test
    public void should_create_tmx_parameters_from_annotated_args() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS_ANNOTATED, new Object[]{tmxParam1, tmxParam2});
        doAnswer(invocationOnMock -> {
            Map<String, Object> tmxParameters = (Map<String, Object>) invocationOnMock.getArguments()[0];
            assertEquals("310146", tmxParameters.get("accountAddressZip"));
            assertEquals("SG", tmxParameters.get("accountAddressCountry"));
            return null;
        }).when(tmxProcessorService).verifySession(anyMap());

        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, times(1)).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    @Test
    public void should_create_tmx_parameters_from_plain_annotated_args() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_PLAIN_TMX_PARAMS, new Object[]{"abcd-1234-xxxx"}, new Class[] { String.class });
        doAnswer(invocationOnMock -> {
            Map<String, Object> tmxParameters = (Map<String, Object>) invocationOnMock.getArguments()[0];
            assertEquals("abcd-1234-xxxx", tmxParameters.get("deviceId"));
            return null;
        }).when(tmxProcessorService).verifySession(anyMap());

        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, times(1)).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    @Test (expected = IllegalArgumentException.class)
    public void should_throw_exception_no_annotation_parameters() throws Throwable {
        TmxParametersExtractor tmxEmptyParam1 = () -> Collections.EMPTY_MAP;
        TmxParametersExtractor tmxEmptyParam2 = () -> Collections.EMPTY_MAP;

        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS_NO_PROPERTIES, new Object[]{tmxEmptyParam1, tmxEmptyParam2});
        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
    }


    @Test (expected = IllegalArgumentException.class)
    public void should_throw_exception_null_args() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS_NO_PROPERTIES, new Object[]{null, null});
        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
    }

    @Test(expected = TmxRedStatusException.class)
    public void should_throw_red_status_exception() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS, new Object[]{tmxParam1, tmxParam2});
        doAnswer(invocationOnMock -> {
           throw new TmxRedStatusException(TMX_STATUS_HIGH);
        }).when(tmxProcessorService).verifySession(anyMap());
        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, never()).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    @Test(expected = TechnicalException.class)
    public void should_throw_technical_exception_gateway_error() throws Throwable {
        prepareMethodSignatureForTmx(METHOD_WITH_TMX_PARAMS, new Object[]{tmxParam1, tmxParam2});
        doAnswer(invocationOnMock -> {
            throw new RuntimeException("Some random error");
        }).when(tmxProcessorService).verifySession(anyMap());
        tmxEnabledAspect.checkTmxStatus(mockJoinPoint);
        verify(mockJoinPoint, never()).proceed();
        verify(tmxProcessorService, times(1)).verifySession(anyMap());
    }

    private void prepareMethodSignatureForTmx(String methodName, Object[] args, Class[] argsTypes) throws Exception {
        Method tmxAnnotatedMethod = this.getClass().getDeclaredMethod(methodName, argsTypes);
        MethodSignature methodSignature = mock(MethodSignature.class);
        when(mockJoinPoint.getSignature()).thenReturn(methodSignature);
        when(mockJoinPoint.getArgs()).thenReturn(args);
        when(methodSignature.getMethod()).thenReturn(tmxAnnotatedMethod);
    }

    private void prepareMethodSignatureForTmx(String methodName, Object[] args) throws Exception {
        prepareMethodSignatureForTmx(methodName, args, new Class[] {TmxParametersExtractor.class, TmxParametersExtractor.class});
    }

    @TmxEnabled(eventType = "ACCOUNT_CREATION", customerEventType = "QuickBalancesRegistration",
            tmxProperties = {
                    @TmxProperty(field = "conditionAttrib5", value = "dummy_data5"),
                    @TmxProperty(field = "conditionAttrib4", value = "dummy_data6")
            }
    )
    public void methodWithTmxParams(TmxParametersExtractor param1, TmxParametersExtractor param2) {}

    @TmxEnabled(eventType = "ACCOUNT_CREATION", customerEventType = "QuickBalancesRegistration")
    public void methodWithTmxParamsAnnotated(@TmxParam TmxParametersExtractor param1, TmxParametersExtractor param2) {}

    @TmxEnabled
    public void methodWithTmxParamsNoProperties(TmxParametersExtractor param1, TmxParametersExtractor param2) {}

    @TmxEnabled(eventType = "ACCOUNT_CREATION", customerEventType = "QuickBalancesRegistration")
    public void methodWithPlainTmxParams(@TmxParam(key = "deviceId") String deviceId) {}

}