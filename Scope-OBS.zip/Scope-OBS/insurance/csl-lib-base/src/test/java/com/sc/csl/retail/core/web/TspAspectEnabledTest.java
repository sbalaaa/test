package com.sc.csl.retail.core.web;

import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.auth.TransactionSigning;
import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.core.exception.TspRequiredException;
import com.sc.csl.retail.core.tsp.model.ChallengeCode;
import com.sc.csl.retail.core.tsp.model.HighRiskTokenValidateDto;
import com.sc.csl.retail.core.tsp.model.SoftTokenValidateDto;
import com.sc.csl.retail.core.tsp.service.ChallengeCodeService;
import com.sc.csl.retail.core.tsp.service.RiskAssessmentService;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.auth.TokenType.USER_PREFERRED;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

/**
 * Created by 1534833 on 7/27/2018.
 */
@Slf4j
public class TspAspectEnabledTest {


    @Mock
    private CSLRequestContext mockRequestContext;

    @Mock
    ProceedingJoinPoint mockJoinPoint;

    @Mock
    RiskAssessmentService riskAssessmentService;

    @Mock
    ChallengeCodeService challengeCodeService;

    @Mock
    DecodedJWT decodedJWT ;

    @Mock
    Claim claim;

    @Mock
    ThreadLocalStore threadLocalStore;

    @InjectMocks
    TransactionSigningAspect transactionSigningAspect;

    @Before
    public void setUp() throws Exception {
        initMocks(this);
     }


    @Test
    public void generateChallengeCodeForPrimaryDevice() throws Throwable {
        ErrorCode errorCode = null;
        TransactionSigning mockAnnotation = mock(TransactionSigning.class);
        Object[] object = new Object[1];
        object[0] = prepareChallengeCodeObject();
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockRequestContext.getDeviceMode()).thenReturn("PRIMARY_DEVICE");
        when(mockRequestContext.getPreferredOtpType()).thenReturn("ST");
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockAnnotation.tokenType()).thenReturn(USER_PREFERRED);
        when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
        when(claim.asInt()).thenReturn(AccessLevel.ONE_FACTOR.authLevel()).thenReturn(AccessLevel.TWO_FACTOR.authLevel());
        when(decodedJWT.getClaim(any())).thenReturn(claim);
        TransactionSigningAspect aspect = transactionSigning(mockAnnotation);
        try {
            aspect.transactionSigning(mockJoinPoint);
        }catch(TspRequiredException ex){
            errorCode = ex.getErrorCode();
        }
        Assert.assertEquals("CSL-ST-1529", errorCode.getCode());
    }

    @Test
    public void generateChallengeCodeForOnline() throws Throwable {
        ErrorCode errorCode = null;
        TransactionSigning mockAnnotation = mock(TransactionSigning.class);
        Object[] object = new Object[1];
        object[0] = prepareChallengeCodeObject();
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockRequestContext.getDeviceMode()).thenReturn("ONLINE");
        when(mockRequestContext.getPreferredOtpType()).thenReturn("ST");
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockAnnotation.tokenType()).thenReturn(USER_PREFERRED);
        when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
        when(claim.asInt()).thenReturn(AccessLevel.ONE_FACTOR.authLevel()).thenReturn(AccessLevel.TWO_FACTOR.authLevel());
        when(decodedJWT.getClaim(any())).thenReturn(claim);
        TransactionSigningAspect aspect = transactionSigning(mockAnnotation);
        try {
            aspect.transactionSigning(mockJoinPoint);
        }catch(TspRequiredException ex){
            errorCode = ex.getErrorCode();
        }
        Assert.assertEquals("CSL-ST-1527", errorCode.getCode());
    }

    @Test
    public void generateChallengeCodeForOffline() throws Throwable {
        ErrorCode errorCode = null;
        TransactionSigning mockAnnotation = mock(TransactionSigning.class);
        Object[] object = new Object[1];
        object[0] = prepareChallengeCodeObject();
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockRequestContext.getDeviceMode()).thenReturn("OFFLINE");
        when(mockRequestContext.getPreferredOtpType()).thenReturn("ST");
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockAnnotation.tokenType()).thenReturn(USER_PREFERRED);
        when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
        when(claim.asInt()).thenReturn(AccessLevel.ONE_FACTOR.authLevel()).thenReturn(AccessLevel.TWO_FACTOR.authLevel());
        when(decodedJWT.getClaim(any())).thenReturn(claim);
        TransactionSigningAspect aspect = transactionSigning(mockAnnotation);
        try {
            aspect.transactionSigning(mockJoinPoint);
        }catch(TspRequiredException ex){
            errorCode = ex.getErrorCode();
        }
        Assert.assertEquals("CSL-ST-1528", errorCode.getCode());
    }

    @Test
    public void validateChallengeCodePrimary() throws Throwable {
        TransactionSigning mockAnnotation = mock(TransactionSigning.class);
        Object[] object = new Object[1];
        object[0] = prepareChallengeCodeObject();
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockRequestContext.getDeviceMode()).thenReturn("PRIMARY_DEVICE");
        when(mockRequestContext.getPreferredOtpType()).thenReturn("ST");
        when(mockRequestContext.getChallengeCodeHeader()).thenReturn(getChallengeCodeHeaderPrimary());
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockAnnotation.tokenType()).thenReturn(USER_PREFERRED);
        when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
        when(claim.asInt()).thenReturn(AccessLevel.ONE_FACTOR.authLevel()).thenReturn(AccessLevel.TWO_FACTOR.authLevel());
        when(decodedJWT.getClaim(any())).thenReturn(claim);
        TransactionSigningAspect aspect = transactionSigning(mockAnnotation);
        aspect.transactionSigning(mockJoinPoint);
    }

    @Test
    public void validateChallengeCodeSecondary() throws Throwable {
        TransactionSigning mockAnnotation = mock(TransactionSigning.class);
        Object[] object = new Object[1];
        object[0] = prepareChallengeCodeObject();
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockRequestContext.getDeviceMode()).thenReturn("ONLINE");
        when(mockRequestContext.getPreferredOtpType()).thenReturn("ST");
        when(mockRequestContext.getChallengeCodeHeader()).thenReturn(getChallengeCodeHeaderSecondaryHighRisk());
        when(mockJoinPoint.getArgs()).thenReturn(object);
        when(mockAnnotation.tokenType()).thenReturn(USER_PREFERRED);
        when(mockAnnotation.accessLevel()).thenReturn(AccessLevel.TWO_FACTOR);
        when(claim.asInt()).thenReturn(AccessLevel.ONE_FACTOR.authLevel()).thenReturn(AccessLevel.TWO_FACTOR.authLevel());
        when(decodedJWT.getClaim(any())).thenReturn(claim);
        TransactionSigningAspect aspect = transactionSigning(mockAnnotation);
        aspect.transactionSigning(mockJoinPoint);

    }



    @TransactionSigning(riskAssessmentId = "LocalTransfer",actionName = "LocalTransfer", riskAssessmentRequired = false)
    private void validateSoftToken( Map<String, String> txnData ) {
        log.info("Perform softtoken TSP");
    }

    private Map<String, String> prepareChallengeCodeObject(){
        Map<String,String> txData = new HashMap<>();
        txData.put("payeeAccount","3242342344");
        txData.put("payeeAccountCur","HKD");
        txData.put("payee","Spartans");
        txData.put("transaction-typ","SVFT");
        return txData;
    }

    private ChallengeCode prepareChallengeCode(){
        ChallengeCode challengeCode = new ChallengeCode();
        challengeCode.setChallengeCode("94815693");
        challengeCode.setRandomNum("AAAAAAAAAAA=");
        challengeCode.setTxRefNo("caa4a691-ba43-4960-a034-be01d7da4546");
        challengeCode.setTransactionHash("2ad4e049ccc8d2dd4282ae3f863881124201482a525812b602a9edce6e2db15e");
        return challengeCode;
    }

    private TransactionSigningAspect transactionSigning(TransactionSigning mockAnnotation) {
        return new TransactionSigningAspect() {
            @Override
            TransactionSigning restrictedAccessAnnotation(ProceedingJoinPoint joinPoint) {
                return mockAnnotation;
            }

            @Override
            CSLRequestContext requestContext() {
                return mockRequestContext;
            }

            @Override
            ChallengeCode postForChallengeCode(ChallengeCode joinPoint) {
                return prepareChallengeCode();
            }

            @Override
            SoftTokenValidateDto postForChallengeCodeValidation(SoftTokenValidateDto softTokenValidateDto){
              softTokenValidateDto = new SoftTokenValidateDto();
              softTokenValidateDto.setValidationStatus("VALIDATED");
              return  softTokenValidateDto;
            }

            @Override
            HighRiskTokenValidateDto postForHiRiskTransactionValidation(HighRiskTokenValidateDto highRiskTokenValidateDto) {
                HighRiskTokenValidateDto highRiskTokenValidateDt = new HighRiskTokenValidateDto();
                return highRiskTokenValidateDt;
            }

            @Override
            ThreadLocalStore threadLocalStore() {
                return threadLocalStore;
            }

            @Override
            DecodedJWT getInternalAccessToken() {
                return decodedJWT;
            }

        };
    }

    private String getChallengeCodeHeaderPrimary(){
        return "ew0KICAgICAgInR4LXJlZi1udW0iOiAiMjEzZTE1MWMtZjY1OC00OTFjLWI2ZjgtZTQ3MGJhZDFlZGViIiwNCiAgICAgICJjaGFsbGVuZ2Utb3RwIjogIjc3OTY0NTAwIiwNCiAgICAgICJyYW5kb20tbnVtIjogIkFBQUFBQUFBQUFBPSIsDQogICAgICAidG9rZW4tc2VyaWFsLW51bWJlciI6IkZEMDMwOTA1OTQiLA0KICAgICAgInNlcXVlbmNlLW51bWJlciI6ICIzMiINCn0=";
    }

    private String getChallengeCodeHeaderSecondaryHighRisk(){
        return "ew0KICAgICAidHgtcmVmLW51bSI6ICIzYzJhYjgyYy1lNjlmLTQxN2QtYmFlZC0zN2Q4OWEzNDdiNTAi" +
                "LA0KICAgICAgICAiaGlnaC1yaXNrLXRva2VuIiA6ICJleUpoYkdjaU9pSlNVekkxTmlKOS5leUpxZEdraU9pSXhOakpqWXpGbE16a" +
                "3pZV00xWW1Sa00ySTVPREkxTXpFMk5EWXhZbVF5SWl3aVkyeHBaVzUwWDJsa0lqb2lUVTlDU1V4RlgwSkJUa3RKVGtjaUxDSnBZWFFpT2p" +
                "FMU1UWTVOakkyTkRRc0ltVjRjQ0k2TVRVeE5qazJNamMyTkN3aWMzVmlJam9pTldwTGVIZHlTMGxsTWpoWlMzaEpTMmRLTkcwNFVTSXNJblZ" +
                "6WlhKdVlXMWxJanB1ZFd4c0xDSnBjM01pT2lKRFUwd3RRVlZVU0NJc0ltVjRkSEpoWDNCeWIzQmxjblJwWlhNaU9uc2lkSEpoYm5OaFkz" +
                "UnBiMjVJWVhOb0lqb2lNR1JpTkRNelptRTBOakkyTWpVMk5ERmtPVFV5WlRSaE1tVmxZMkZpT0RJeU1HRXlaRE0wWW1JNVlqRTNOVEprTXpre" +
                "U4yRmlOakk1T0RZME56TTRNeUo5TENKbmNtRnVkRjkwZVhCbElqb2liM1J3SW4wLlFmMjU2RmpPd2Z0SGtJWUpJdGlHQnB1b1VMZ3ZOdE9kczBn" +
                "RDBWUmJEanF1N1hTR1l1SEs3MXAwTm1OOEd6aU5Sc1pfMWMwbm9jMUY3MWhnazVFQmY2VTctMUpYNVdGWU1KUjYyZ0k3c2M5N0lFRUk3dTBFRGRjdTh5bnNsWUVudnRrMm13RTlIZGlIZUdtSVpxMjhEOTNRdEhEQkk1S1NVZGppQTdUZ083aDVtZGlrS0Nka3U2dmQzTTFTZVg5VHZ2MUZwcEo0TTlCTzhpaDlwM3M3S0NZTmd4MHZyeFZ2YTVIaW9wUmlCOTF4QmVvXzh2YmVkOTE5aks0cnhyM2ROdC12WmVNW" +
                "jloMlViaUZ1akplMWMtOHZqTF90OHhKeEszTGxTaVlTQjl5LXlhWkNqejd6Qi1VZWhkdHBNZHBILTgxelJxeTBjTVJnd2RHR0xKbklrdyINCiAgICAgICAgICAgICANCn0=";
    }

}
