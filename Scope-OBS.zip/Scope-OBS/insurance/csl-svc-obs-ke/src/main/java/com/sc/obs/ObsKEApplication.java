package com.sc.obs;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.sc.csl.retail.cache.config.CacheConfig;
import com.sc.csl.retail.core.CSLSpringBootApplication;
import com.sc.csl.retail.core.config.AuthConfig;
import com.sc.csl.retail.core.config.HikariDataSourceConfig;
import com.sc.obs.crnk.ObsCrnkConfigV3;

@SpringBootApplication
@Import({
        ObsCrnkConfigV3.class,
        AuthConfig.class,
        HikariDataSourceConfig.class,
        CacheConfig.class
})
@EnableAspectJAutoProxy(proxyTargetClass=true)
@EnableScheduling
public class ObsKEApplication extends CSLSpringBootApplication {
    public static void main(String[] args) {
        configureApplication(new SpringApplicationBuilder()).run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return configureApplication(builder);
    }

    private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
        builder.sources(ObsKEApplication.class);
        initBase(builder, "csl-svc-obs-ke");
        return builder;
    }
}