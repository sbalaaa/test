package com.sc.obs.aspect.config;

import org.aspectj.lang.Aspects;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sc.obs.auth.TransactionOTPAspect;

@Configuration
public class TrasanctionOTPConfig {
	@Bean
    public TransactionOTPAspect theAspect() {
        return Aspects.aspectOf(TransactionOTPAspect.class);
    }
}
