/**
 * 
 */
package com.sc.obs.config;

import lombok.Getter;

import com.sc.csl.retail.core.exception.ErrorCode;

/**
 * @author 1567880
 *
 */
@Getter
public class ApplicationError implements ErrorCode {

    private final String code;
    private final String title;
    private final String description;

    public ApplicationError(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

}
