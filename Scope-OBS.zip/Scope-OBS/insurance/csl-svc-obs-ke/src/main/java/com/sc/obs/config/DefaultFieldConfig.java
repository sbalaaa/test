package com.sc.obs.config;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefaultFieldConfig {
    private Map<String,Map<String,Map<String,String>>> fieldsAndValues = new HashMap<>();
    private Map<String,Map<String,Map<String,String>>> applicationWizardState = new HashMap<>();   
}
