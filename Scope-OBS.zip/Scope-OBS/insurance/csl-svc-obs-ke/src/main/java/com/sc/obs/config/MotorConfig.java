package com.sc.obs.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Configuration
@Getter
@Setter
public class MotorConfig {
    
    @Bean
    @ConfigurationProperties(prefix = "config")
    public DefaultFieldConfig allDefaultConfigs() {
        return new DefaultFieldConfig();
    }

    public Map<String,String> getDefaultValues(String country, String isp) {
        return allDefaultConfigs().getFieldsAndValues().get(country).get(isp);
    }

    public Map<String,String> getApplicationState(String country, String isp) {
        return allDefaultConfigs().getApplicationWizardState().get(country).get(isp);
    }

}
