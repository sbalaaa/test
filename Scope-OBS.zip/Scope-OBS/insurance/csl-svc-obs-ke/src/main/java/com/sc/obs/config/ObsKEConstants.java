/**
 * 
 */
package com.sc.obs.config;

/**
 * @author 1567880
 *
 */
public class ObsKEConstants {

    private ObsKEConstants() {
        super();
    }
    public static final String AUTHENTICATION_ID = "AuthenticationID";
    public static final String REQUEST_ID = "RequestID";
    public static final String SANLAM_RESPONSE_TYPE_SUCCESS = "S";
    public static final String PRODUCT_TYPE_MOTOR = "MOTOR";
    public static final String CHANNEL_CODE_MOBILE = "mobile";
    public static final String SCREEN_CODE_GET_QUOTE = "get-quote";
    public static final String FIELD_DESC = PRODUCT_TYPE_MOTOR +"Ref Data";
    public static final String QUOTATION_NUMBER = "quotationNumber";
    public static final String UPLOAD_STATE = "uploadState";
    public static final String UPLOAD = "upload";
    public static final String DELETE = "delete";
    public static final String VEHICLE_MAKE = "VehicleMake";
    public static final String VEHICLE_MODEL = "VehicleModel";
    public static final String TRUE = "true";

}
