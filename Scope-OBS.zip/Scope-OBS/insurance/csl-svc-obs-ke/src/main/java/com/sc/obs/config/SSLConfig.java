/**
 * 
 */
package com.sc.obs.config;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * @author 1567880
 *
 */
@Configuration
public class SSLConfig {

	 	@Value("${proxy.host}")
	    private String proxyHost;

	    @Value("${proxy.port}")
	    private String proxyPort;

	    @Value("${proxy.useProxy}")
	    private Boolean hasProxy;
	    
	    @Value("${sanlam.userName}")
	    public String userName;
	    
	    @Value("${sanlam.password}")
	    private String password;
	    
	    @Value("${sanlam.readTimeout}")
	    private String readTimeout;
	    
	    @Value("${sanlam.connectionTimeout}")
	    private String connectionTimeout;
	    
	    @Autowired
	    private RestTemplateResponseErrorHandler responseHandler;


	    @Bean(name = "createProxyHost")
	    public HttpHost createProxyHost(){

	        if (hasProxy) {
	            int proxyPortNumber = Integer.parseInt(proxyPort);
	            return new HttpHost(proxyHost, proxyPortNumber,"http");
	        }

	       return null;
	    }

	    @Bean(name = "restClient")
	    public RestTemplate getRestClient() throws NoSuchAlgorithmException, KeyManagementException {
	        RestTemplate restClient = new RestTemplate();

	        SSLContext context = SSLContext.getInstance("TLSv1.2");
	        context.init(null, null, null);

	        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(5, TimeUnit.SECONDS);
	        connectionManager.setMaxTotal(500);
	        connectionManager.setDefaultMaxPerRoute(25);
	        
	        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
	        UsernamePasswordCredentials credentials
	         = new UsernamePasswordCredentials(userName, password);
	        credentialsProvider.setCredentials(AuthScope.ANY, credentials);

	        CloseableHttpClient httpClient = HttpClientBuilder
	                .create()
	                .setSSLContext(context)
	                .setProxy(createProxyHost())
	                .setConnectionManager(connectionManager)
	                .setDefaultCredentialsProvider(credentialsProvider)
	                .build();
	        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
	        factory.setConnectTimeout(Integer.valueOf(connectionTimeout));
	        factory.setReadTimeout(Integer.valueOf(readTimeout));
	        restClient.setRequestFactory(factory);
	        restClient.setErrorHandler(responseHandler);
	        return restClient;
	    }


}
