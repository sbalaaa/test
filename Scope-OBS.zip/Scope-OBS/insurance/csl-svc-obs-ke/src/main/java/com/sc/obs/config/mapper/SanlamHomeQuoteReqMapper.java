package com.sc.obs.config.mapper;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

import org.springframework.stereotype.Component;

import com.sc.obs.quotation.Quotation;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.HomeRisk;
import com.sc.obs.sanlam.quote.home.model.HomeSection;
import com.sc.obs.sanlam.quote.home.model.HomeSmiInfo;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReq;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReqWrapper;
import com.sc.obs.sanlam.quote.home.model.isp.HomeRiskReq;
import com.sc.obs.sanlam.quote.home.model.isp.HomeSectionReq;

@Component
public class SanlamHomeQuoteReqMapper extends ConfigurableMapper {
    
	protected void configure(MapperFactory factory) {
    	
    	factory.classMap(Quotation.class, HomeQuoteReqWrapper.class).fieldAToB("", "quote").register();
    	factory.classMap(Quotation.class, HomeQuoteReq.class).field("quotationId", "quotationNumber").fieldAToB("detail", "").register();

        factory.classMap(HomeQuote.class, HomeQuoteReq.class)
                .field("risks", "homeRisk").byDefault()
                .register();
        factory.classMap(HomeRisk.class, HomeRiskReq.class)
		        .field("building", "building")
		        .field("content", "content")
		        .field("personalLegalLiability", "personalLegalLiability")
		        .field("allRisk","allRisk")
        		.field("golfersCover", "golfersCover")
        		.field("sections", "sections").byDefault()
	        	.register();
        factory.classMap(HomeSection.class, HomeSectionReq.class)
		        .field("smiInfo", "smiInfo").byDefault()
		        .field("covers", "covers").byDefault()
		        .register();
        factory.classMap(HomeSmiInfo.class, HomeSmiInfo.class)
        		.byDefault()
		        .register();
        
    }


}
