package com.sc.obs.config.mapper;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

import org.springframework.stereotype.Component;

import com.sc.obs.sanlam.quote.home.model.HomeBenefit;
import com.sc.obs.sanlam.quote.home.model.HomeCover;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.HomeRisk;
import com.sc.obs.sanlam.quote.home.model.HomeSection;
import com.sc.obs.sanlam.quote.home.model.isp.HomeBenefitResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeCoverResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeRiskReq;
import com.sc.obs.sanlam.quote.home.model.isp.HomeSectionReq;

@Component
public class SanlamHomeQuoteResMapper extends ConfigurableMapper{
    
	protected void configure(MapperFactory factory) {
    	
    	
        factory.classMap( HomeQuoteResp.class,HomeQuote.class).byDefault()
                .field("homeRisk","risks")
                .field("benefits","benefits")
                .byDefault()
                .register();
        factory.classMap(HomeRiskReq.class, HomeRisk.class)
        		.field("sections","sections")
	        	.register();
        factory.classMap(HomeSectionReq.class, HomeSection.class)
				.field("covers","covers")
				.byDefault()
		    	.register();
        factory.classMap(HomeCoverResp.class, HomeCover.class)
		        .byDefault()
		    	.register();
        factory.classMap(HomeBenefitResp.class, HomeBenefit.class)
		        .byDefault()
		    	.register();
        
    }

}
