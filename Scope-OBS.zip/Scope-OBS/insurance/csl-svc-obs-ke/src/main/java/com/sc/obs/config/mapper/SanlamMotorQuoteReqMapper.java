/**
 * 
 */
package com.sc.obs.config.mapper;

import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.impl.ConfigurableMapper;

import org.springframework.stereotype.Component;

import com.sc.obs.quotation.Quotation;
import com.sc.obs.sanlam.quote.SanlamMotorCover;
import com.sc.obs.sanlam.quote.SanlamMotorCoverReq;
import com.sc.obs.sanlam.quote.SanlamMotorQuote;
import com.sc.obs.sanlam.quote.SanlamMotorQuoteReq;
import com.sc.obs.sanlam.quote.SanlamMotorQuoteReqWrapper;
import com.sc.obs.sanlam.quote.SanlamMotorRisk;
import com.sc.obs.sanlam.quote.SanlamMotorRiskReq;

/**
 * @author 1567880
 *
 */
@Component
public class SanlamMotorQuoteReqMapper extends ConfigurableMapper {
    protected void configure(MapperFactory factory) {
    	
    	factory.classMap(Quotation.class, SanlamMotorQuoteReqWrapper.class).fieldAToB("", "quote").register();
    	factory.classMap(Quotation.class, SanlamMotorQuoteReq.class).field("quotationId", "quotationNumber")
    	.customize(new CustomMapper<Quotation, SanlamMotorQuoteReq>() {
                    @Override
                    public void mapAtoB(Quotation a, SanlamMotorQuoteReq b, MappingContext context) {
                    	if(((SanlamMotorQuote)a.getDetail()).getMode() !=null && ((SanlamMotorQuote)a.getDetail()).getMode().equalsIgnoreCase("add")){
                    		b.setQuotationNumber("");
                    	}
                    }
                })
    	.fieldAToB("detail", "").register();

        factory.classMap(SanlamMotorQuote.class, SanlamMotorQuoteReq.class)
                .field("policyType", "policyType")
                .field("mode", "mode")
                .field("lobCode", "lobCode")
                .field("productCode","productCode")
                .field("fromDate", "fromDate")  
                .field("paymentMethod", "paymentMethod")
                .field("risks", "risk")
                .register();
        factory.classMap(SanlamMotorRisk.class, SanlamMotorRiskReq.class)
        	.field("cover", "cover").byDefault()
        	.register();
        factory.classMap(SanlamMotorCover.class, SanlamMotorCoverReq.class).byDefault()
    	.register();
    }


}
