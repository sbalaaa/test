/**
 * 
 */
package com.sc.obs.config.mapper;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

import org.springframework.stereotype.Component;

import com.sc.obs.sanlam.quote.Benefit;
import com.sc.obs.sanlam.quote.SanlamMotorCover;
import com.sc.obs.sanlam.quote.SanlamMotorCoverResp;
import com.sc.obs.sanlam.quote.SanlamMotorQuote;
import com.sc.obs.sanlam.quote.SanlamMotorQuoteResp;
import com.sc.obs.sanlam.quote.SanlamMotorRisk;
import com.sc.obs.sanlam.quote.SanlamMotorRiskResp;

/**
 * @author 1567880
 *
 */
@Component
public class SanlamMotorQuoteResMapper extends ConfigurableMapper{
    protected void configure(MapperFactory factory) {
    	
    	
        factory.classMap( SanlamMotorQuoteResp.class,SanlamMotorQuote.class).byDefault()
                .field("risk","risks")
                .field("installment","installments")
                .field("premiumSplitup","premiumSplitups")
                .byDefault()
                .register();
        factory.classMap(SanlamMotorRiskResp.class, SanlamMotorRisk.class)
        	.field("cover","cover").byDefault()
        	.field("benefits","benefits")
        	.register();
        
        factory.classMap(SanlamMotorCoverResp.class, SanlamMotorCover.class)
        .field("noofDays", "noOfDays")
        .field("sumInsured", "coverSumInsured")
        .byDefault()
    	.register();
        
        factory.classMap(Benefit.class, Benefit.class)
        .byDefault()
    	.register();
    }




}
