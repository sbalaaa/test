package com.sc.obs.crnk.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.collect.Lists;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.model.HomeApplicationDetail;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.quote.SanlamMotorQuote;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;

@Configuration
public class CrnkSubtypesConfig {

    @Bean
    @Qualifier("crnkSubTypes")
    public List<Class<?>> crnkSubTypes(){
        return Lists.newArrayList(CasaPaymentDetail.class, SanlamMotorQuote.class, HomeQuote.class, MotorApplicationDetail.class, HomeApplicationDetail.class);
    }
}
