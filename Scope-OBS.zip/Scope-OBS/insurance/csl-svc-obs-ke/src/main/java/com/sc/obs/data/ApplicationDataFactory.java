package com.sc.obs.data;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.BancaApplicationDetail;
import com.sc.obs.data.entity.*;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.model.HomeApplicationDetail;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.PolicyCover;
import com.sc.obs.sanlam.application.model.PremiumDetails;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.sc.obs.data.OrderTransaction.*;

@Component
public class ApplicationDataFactory {

    @Value("${config.default.currency:KES}")
    private String defaultKECurrency ;

    @Value("${config.default.isp.name:Sanlam}")
    private String defaultIspName ;

    private static final String DEFAULT_UPDATED_BY = "SYSTEM";

    private String encryptPassword;
    private String ispAccountNumber;
    private CSLRequestContext cslRequestContext;

    private OrderMasterMapper orderMasterMapper = new OrderMasterMapper();
    private OrderPaymentMapper paymentMapper = new OrderPaymentMapper();
    private MotorOrderProductMotorMapper productMotorMapper = new MotorOrderProductMotorMapper();
    //The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
    //private HomeOrderProductHomeMapper productHomeMapper = new HomeOrderProductHomeMapper();
    private InsuredDetailsMapper insuredDetailsMapper = new InsuredDetailsMapper();
    private MailingDetailMapper mailingDetailMapper = new MailingDetailMapper();
    private MotorOrderRequesterMapper motorRequesterMapper = new MotorOrderRequesterMapper();
    private HomeOrderRequesterMapper homeRequesterMapper = new HomeOrderRequesterMapper();
    private ProductPolicyMapper policyMapper = new ProductPolicyMapper();
    private CoverDetailsMapper coverDetailsMapper = new CoverDetailsMapper();
    private PremiumDetailsMapper premiumDetailsMapper = new PremiumDetailsMapper();
    private ObsMotorAuditMapper obsMotorAuditMapper = new ObsMotorAuditMapper();
    private ApplicationDetailsMapper applicationMapper = new ApplicationDetailsMapper();

    private ObsMotorAuditCslContextMapper obsMotorAuditCslContextMapper = new ObsMotorAuditCslContextMapper();

    @Autowired
    public void setCslRequestContext(CSLRequestContext cslRequestContext){
        this.cslRequestContext = cslRequestContext;
    }

    @Value("${casa.motor.ispAccountNumber}")
    public void setIspAccountNumber(String ispAccountNumber){
        this.ispAccountNumber = ispAccountNumber;
    }

    @Value("${jasypt.encryptor.password}")
    public void setEncryptPassword(String encryptPassword){
        this.encryptPassword = encryptPassword;
    }

    public OrderMaster createOrderMaster(BancaApplication bancaApplication, OrderMaster orderMaster){
        orderMasterMapper.map(bancaApplication, orderMaster);

        orderMasterMapper.map(bancaApplication.getBancaApplicationDetail(), orderMaster);
        return orderMaster;
    }

    public AppRequesterDetails createOrderRequesterDetails(BancaApplication bancaApplication, AppRequesterDetails existing){
        if(bancaApplication.getBancaApplicationDetail() instanceof MotorApplicationDetail) {
        	motorRequesterMapper.map(bancaApplication, existing);
        	motorRequesterMapper.map(bancaApplication.getBancaApplicationDetail(), existing);
        } else if(bancaApplication.getBancaApplicationDetail() instanceof HomeApplicationDetail) {
        	homeRequesterMapper.map(bancaApplication.getBancaApplicationDetail(), existing);
        }
        return existing;
    }

    public List<AppProductPremiumDetails> createPremiumDetails(ApplicationDataStore applicationDataStore, List<PremiumDetails> premiumDetails){
        return premiumDetails.stream()
                .map(premium -> {
                    AppProductPremiumDetails orderProductPremiumDetails =
                            premiumDetailsMapper.map(premium, AppProductPremiumDetails.class);
                    orderProductPremiumDetails.setPremiumCurr(defaultKECurrency);
                    orderProductPremiumDetails.setOrderProductMaster(applicationDataStore.getAppProductMaster());
                    return orderProductPremiumDetails;
                })
                .collect(Collectors.toList());
    }

    public OrderProductPaymentMap createOrderProductPaymentMap(OrderMaster order, AppProductMaster productMaster, OrderProductPayment payment){
    	OrderProductPaymentMap orderProductMap = new OrderProductPaymentMap();
        orderProductMap.setOrderMaster(order);
        orderProductMap.setAppProductMaster(productMaster);
        orderProductMap.setOrderPayment(payment);

        return orderProductMap;
    }

    public AppProductPolicy createOrderProductPolicy(BancaApplication bancaApplication){
    	AppProductPolicy productPolicy = policyMapper.map(bancaApplication.getBancaApplicationDetail(), AppProductPolicy.class);
        return productPolicy;
    }

    public AppProductMotor createOrderProductMotor(BancaApplication bancaApplication, AppProductMotor existing){
        productMotorMapper.map(bancaApplication, existing);

        productMotorMapper.map(bancaApplication.getBancaApplicationDetail(), existing);
        return existing;
    }
    
    //The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
    /*public AppProductHome createOrderProductHome(BancaApplication bancaApplication, AppProductHome existing){
        productHomeMapper.map(bancaApplication, existing);

        productHomeMapper.map(bancaApplication.getBancaApplicationDetail(), existing);
        return existing;
    }*/
    
    public AppProductMaster createAppProductMaster(BancaApplication bancaApplication){
    	AppProductMaster appProductMaster = new AppProductMaster();
        appProductMaster.setProductCode(bancaApplication.getBancaApplicationDetail().getProductCode());
        appProductMaster.setIspQuotationCd(bancaApplication.getQuotationNumber());
        appProductMaster.setIspName(defaultIspName);

        return appProductMaster;
    }

    public OrderProductPayment createOrderProductPayment(BancaApplication bancaApplication, OrderProductPayment existingPayment){
        paymentMapper.map(bancaApplication.getPaymentDetail(), existingPayment);
        CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) bancaApplication.getPaymentDetail();
        String debitAccountNo = casaPaymentDetail.getFromAccountNumber();

        existingPayment.setDebitAccountNo(EncryptUtils.encrypt(debitAccountNo, encryptPassword));
        existingPayment.setCreditAccountNo(EncryptUtils.encrypt(ispAccountNumber, encryptPassword));
        existingPayment.setDebitAccountMaskedNo(MaskUtils.maskAccountNumber(debitAccountNo));
        existingPayment.setCreditAccountMaskedNo(MaskUtils.maskAccountNumber(ispAccountNumber));
        existingPayment.setTxnRefNo(casaPaymentDetail.getCreditNarration());
        existingPayment.setTxnCurrencyCd(casaPaymentDetail.getTransactionCurrencyCode());
        return existingPayment;
    }

    public AppProductInsuredDetails createInsuredDetails(BancaApplication application, AppProductInsuredDetails insuredDetails) {
        insuredDetailsMapper.map(
                application.getBancaApplicationDetail(),
                insuredDetails);

        insuredDetails.setInsuredType(INSURED_TYPE_DRIVER);
        return insuredDetails;
    }

    public List<AppProductCoverDetails> createOrderProductCoverDetails(BancaApplication application) {
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) application.getPaymentDetail();
        List<AppProductCoverDetails> coverDetailsList = Lists.newArrayList();
        motorDetails.getPolicyDetails().getPolicyCovers()
                .forEach(policyCover -> {
                    AppProductCoverDetails coverDetails = coverDetailsMapper.map(policyCover, AppProductCoverDetails.class);
                    coverDetails.setCoverPremiumCurrency(casaPaymentDetail.getTransactionCurrency());
                    coverDetailsList.add(coverDetails);
                    });

        return coverDetailsList;
    }
    
    public List<AppProductCoverDetails> createOrderProductCoverDetailsForHome(BancaApplication application) {
        HomeApplicationDetail homeDetails = (HomeApplicationDetail) application.getBancaApplicationDetail();
        CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) application.getPaymentDetail();
        List<AppProductCoverDetails> coverDetailsList = Lists.newArrayList();
        homeDetails.getPolicyDetails().getPolicyCovers()
                .forEach(policyCover -> {
                    AppProductCoverDetails coverDetails = coverDetailsMapper.map(policyCover, AppProductCoverDetails.class);
                    coverDetails.setCoverPremiumCurrency(casaPaymentDetail.getTransactionCurrency());
                    coverDetailsList.add(coverDetails);
                    });

        return coverDetailsList;
    }
    
    public AuditLogDetails createAuditLogDetails(BancaApplication bancaApplication){
    	MotorApplicationDetail motorDetails = (MotorApplicationDetail) bancaApplication.getBancaApplicationDetail();
        AuditLogDetails auditLogDetails = obsMotorAuditMapper.map(motorDetails, AuditLogDetails.class);
        obsMotorAuditCslContextMapper.map(cslRequestContext, auditLogDetails);
        auditLogDetails.setAppName(APP_NAME_OBS);
        auditLogDetails.setUpdatedDate(new Date());
        auditLogDetails.setUpdatedBy(DEFAULT_UPDATED_BY);
        return auditLogDetails;
    }
    
    public List<AppProductPremiumDetails> updateExistingPremiumDetails(List<PremiumDetails> premiumDetails, List<AppProductPremiumDetails> existingPremiumList) {
        Map<String, AppProductPremiumDetails> premiumMap = Maps.newHashMap();
        existingPremiumList.forEach(premium -> premiumMap.put(premium.getPremiumDesc(), premium));

        premiumDetails.forEach(p -> {
            if (premiumMap.containsKey(p.getDescription())){
                premiumMap.get(p.getDescription()).setPremiumValue(new BigDecimal(p.getValue()));
            } else {
                AppProductPremiumDetails newPremium = new AppProductPremiumDetails();
                newPremium.setPremiumDesc(p.getDescription());
                newPremium.setPremiumValue(new BigDecimal(p.getValue()));
                newPremium.setPremiumCurr(defaultKECurrency);
                existingPremiumList.add(newPremium);
            }
        });

        return existingPremiumList;
    }

    public ApplicationDetails createApplicationDetails(BancaApplication application) {
        ApplicationDetails applicationDetails = applicationMapper.map(application, ApplicationDetails.class);
        applicationDetails.setRelId(cslRequestContext.getRelId());
        applicationDetails.setChannelCd(cslRequestContext.getChannel());
        applicationDetails.setChannelName(OrderTransaction.CHANNEL_MOBILE_NAME);

        return applicationDetails;
    }

    public AppProductMailingAddressDetails createMaillingDetails(BancaApplication application, AppProductMailingAddressDetails existing){
   
        mailingDetailMapper.map(application.getBancaApplicationDetail(), existing);

        return existing;
    }

    /**
     * Mapper classes
     */
    public static class ApplicationDetailsMapper extends ConfigurableMapper {
        protected void configure(MapperFactory factory) {

            factory.classMap(BancaApplication.class, ApplicationDetails.class)
                    .field("country","countryCd")
                    .register();
        }
    }

    public static class MailingDetailMapper extends ConfigurableMapper {
        protected void configure(MapperFactory factory){
            factory.classMap(BancaApplicationDetail.class, AppProductMailingAddressDetails.class)
                    .field("mailingAddress[0].addressLine1", "address1")
                    .field("mailingAddress[0].addressLine2", "address2")
                    .field("mailingAddress[0].addressLine3", "address3")
                    .field("mailingAddress[0].state", "state")
                    .field("mailingAddress[0].postalCode", "postalCode")
                    .register();
        }
    }
    
    public static class OrderMasterMapper extends ConfigurableMapper {
        protected void configure(MapperFactory factory) {

            factory.classMap(CasaPaymentDetail.class, OrderMaster.class)
                    .field("transactionAmount", "orderAmt")
                    .field("transactionCurrency", "orderCurrencyCd")
                    .register();
        }
    }

    public static class MotorOrderProductMotorMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(MotorApplicationDetail.class, AppProductMotor.class)
                    .field("engineNumber", "engineNumber")
//                    .field("typeOfCover", "typeOfCover")
                    .field("chassisNumber","chassisNumber")
                    .field("registrationNumber", "registrationNumber")
                    .field("vehicleModel", "vehicleModel")
                    .field("vehicleUsageType", "vehicleUsageType")
                    .field("vehicleType", "vehicleType")
                    .field("vehicleCylinderCode", "vehicleCylinderCode")
                    .field("colourCode", "colorCode")
                    .field("dealReferrerName", "dealReferrer")
                    .field("referrerId", "referrerPwId")
                    .register();

            factory.classMap(BancaApplication.class, AppProductMotor.class)
                    .field("country", "countryCode")
                    .register();
        }
    }
    
    // The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
    /*public static class HomeOrderProductHomeMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(HomeApplicationDetail.class, AppProductHome.class)
                    .field("fromDate", "startDate")
                    .field("endDate","endDate")
                    .field("dealReferrerName", "dealReferrer")
                    .field("referrerId", "referrerPwId")
                    .register();
        }
    }
    
    */


    public static class CoverDetailsMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory){
            factory.classMap(PolicyCover.class, AppProductCoverDetails.class)
                    .field("coverCode", "coverCode")
                    .field("coverPremium", "coverPremium")
                    .field("coverName", "coverName")
                    .register();
        }
    }

    public static class OrderPaymentMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory){
            factory.classMap(CasaPaymentDetail.class, OrderProductPayment.class)
                    .field("paymentType", "paymentMode")
                    .field("transactionAmount","txnAmt")
                    .field("transactionCurrency", "txnCurrencyCd")
                    .register();
        }
    }

    public static class PremiumDetailsMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory){
            factory.classMap(PremiumDetails.class, AppProductPremiumDetails.class)
                    .field("description", "premiumDesc")
                    .field("value","premiumValue")
                    .register();
        }
    }

    public static class MotorOrderRequesterMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(MotorApplicationDetail.class, AppRequesterDetails.class)
                    .field("businessSector", "businessSector")
                    .field("jobTitle", "jobTitle")
                    .field("identificationNumber","identificationId")
                    .field("identityType", "identificationType")
                    .field("firstName","firstName")
                    .field("lastName", "lastName")
                    .field("middleName", "middleName")
                    .field("emailId", "email")
                    .field("gender", "gender")
                    .field("title", "title")
                    .field("phoneNumber", "phoneNo")
                    .register();
        }
    }
    
    
    public static class HomeOrderRequesterMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(HomeApplicationDetail.class, AppRequesterDetails.class)
                    .field("businessSector", "businessSector")
                    .field("jobTitle", "jobTitle")
                    .field("identificationNumber","identificationId")
                    .field("identityType", "identificationType")
                    .field("firstName","firstName")
                    .field("lastName", "lastName")
                    .field("middleName", "middleName")
                    .field("emailId", "email")
                    .field("gender", "gender")
                    .field("title", "title")
                    .field("phoneNumber", "phoneNo")
                    .register();
        }
    }

    public static class InsuredDetailsMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(MotorApplicationDetail.class, AppProductInsuredDetails.class)
                    .field("identificationNumber","identificationId")
                    .field("identityType", "identificationType")
                    .field("firstName","firstName")
                    .field("lastName", "lastName")
                    .field("middleName", "middleName")
                    .field("gender", "gender")
                    .field("phoneNumber", "phoneNo")
                    .register();
        }
    }

    public static class ProductPolicyMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(MotorApplicationDetail.class, AppProductPolicy.class)
                    .field("policyDetails.policyNumber", "policyNo")
                    .field("policyDetails.policyNumber", "policyMasterNo")
                    .field("paymentReferenceNo", "paymentTransCd")
                    .register();
        }
    }
    
    public static class ObsMotorAuditMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(MotorApplicationDetail.class, AuditLogDetails.class)
                    .field("consentAuditDetails.location", "location")
                    .field("consentAuditDetails.deviceId", "deviceId")
                    .field("consentAuditDetails.customerName","customerName")
                    .field("consentAuditDetails.channelName","channelName")
                    .field("consentAuditDetails.segment", "customerSegment")
                    .field("policyDetails.policyNumber", "policyNo")
                    .register();
        }
    }
    
    public static class ObsMotorAuditCslContextMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

            factory.classMap(CSLRequestContext.class, AuditLogDetails.class)
                    .field("language", "languageCode")
                    .field("country", "countryCode")
                    .field("channel","channelCode")
                    .field("relId","customerId")
                    .register();
        }
    }
}
