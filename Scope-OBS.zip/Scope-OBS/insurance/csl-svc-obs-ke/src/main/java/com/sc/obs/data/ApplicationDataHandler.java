package com.sc.obs.data;

import static com.sc.obs.data.OrderTransactionStatus.*;
import static com.sc.obs.sanlam.application.common.Constants.NA;
import static com.sc.obs.sanlam.application.common.Constants.PAYMENT_DONE_ISSUANCE_PENDIND;
import static com.sc.obs.sanlam.application.common.Constants.PERSONAL_DETAILS;
import static com.sc.obs.sanlam.application.common.Constants.SUBMISSION_AND_PAYMENT;
import static com.sc.obs.sanlam.application.common.Constants.VALIDATION;
import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.OBS_CASA_PAYMENT_FAILURE;
import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.OBS_FAILURE;
import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.OBS_PAYMENT_TIMEOUT;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.config.MotorConfig;
import com.sc.obs.data.entity.*;
import com.sc.obs.data.repository.*;
import com.sc.obs.data.service.ApplicationDataService;
import com.sc.obs.payment.casa.CasaErrorCode;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.common.Constants;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;

@Slf4j
public abstract class ApplicationDataHandler implements ApplicationDataService{

    @Autowired
    protected MotorConfig config;

    protected static final String COUNTRY = "ke";
    protected static final String ISP = "sanlam";
    protected static final String STATUS_SUCCESS = "S";

    @Autowired
	protected ApplicationDataFactory applicationDataFactory;

    @Autowired
    @Getter
	protected ApplicationDataStore applicationDataStore;

    @Autowired
	protected OrderMasterRepository orderMasterRepository;

    @Autowired
	protected ApplicationDetailsRepository applicationRepository;

    @Autowired
	protected AppProductMasterRepository appProductMasterRepository;

    @Autowired
	protected AppProductMotorRepository productMotorRepository;
    
    //The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
   /* @Autowired
	protected AppProductHomeRepository productHomeRepository;
    
    @Autowired
	protected AppProductRiskMasterRepository productRiskMasterRepository;
    
    @Autowired
	protected AppProductRiskDetailsRepository productRiskDetailsRepository;*/

    @Autowired
	protected AppRequesterDetailsRepository requesterDetailsRepository;

    @Autowired
    private OrderProductPaymentMapRepository orderProductMapRepository;

    @Autowired
	protected AppProductMailingAddressDetailsRepository mailingDetailsRepository;

    @Autowired
	protected AppProductInsuredDetailsRepository insuredDetailsRepository;

    @Autowired
    private OrderProductPaymentRepository orderPaymentRepository;

    @Autowired
	protected AppProductPremiumDetailsRepository premiumDetailsRepository;

    @Autowired
	protected AppProductPolicyRepository orderProductPolicyRepository;

    @Autowired
	protected AppProductCoverDetailsRepository productCoverDetailsRepository;
    
    @Autowired
	protected ObsConsentMasterRepository obsConsentMasterRepository;
    
    @Autowired
	protected AuditLogDetailsRepository auditLogDetailsRepository;
    
    public ApplicationDataHandler() {
    }
    
    

    @Override
    public void initiateOrderData(BancaApplication application) {
        try {
            ApplicationDetails currentApplication = getApplicationDataStore().getApplicationByBancaApplication(application);
            if (currentApplication == null){
                throw new TechnicalException("Unable to find application details record with id:" + application.getApplicationId());
            }
            currentApplication.setApplicationStatus(APPLICATION_SUBMITTED);

            OrderMaster orderMaster = applicationDataFactory.createOrderMaster(application, new OrderMaster());
            CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) application.getPaymentDetail();
            orderMaster.setOrderStatus(PAYMENT_INITIATED);
            orderMaster.setOrderAmt(new BigDecimal(casaPaymentDetail.getTransactionAmount()));
            orderMaster.setOrderCurrencyCd(casaPaymentDetail.getTransactionCurrency());
            orderMaster.setApplicationDetails(currentApplication);

            OrderMaster createdOrder = orderMasterRepository.save(orderMaster);
            OrderProductPayment orderProductPayment = applicationDataFactory.createOrderProductPayment(application, new OrderProductPayment());
            orderProductPayment.setTxnStatus(PAYMENT_INITIATED);
            orderProductPayment.setOrderMaster(createdOrder);
            OrderProductPayment createdPayment = orderPaymentRepository.save(orderProductPayment);

            AppProductMaster productMaster = appProductMasterRepository.findByApplicationId(currentApplication.getApplicationId());

            OrderProductPaymentMap orderProductMap = applicationDataFactory.createOrderProductPaymentMap(createdOrder,
                    productMaster, createdPayment);

            applicationDataStore.setOrderProducPaymentMap(orderProductMapRepository.save(orderProductMap));
            applicationDataStore.setApplicationDetails(applicationRepository.save(currentApplication));
            applicationDataStore.setOrderMaster(createdOrder);
            applicationDataStore.setOrderProductPayment(createdPayment);
        } catch (Exception ex){
            log.error("Fail to create order and payment records in database upon submit bancaApplication for payment, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

   
    
    protected abstract String getApplicationStatus(BancaApplication application);
    protected abstract String getResponseStatus(BancaApplication application);	
    protected abstract void saveConsentAuditLogData(BancaApplication application);
    public abstract void handleApplicationReqData(BancaApplication application);
    public abstract void handleApplicationResData(BancaApplication application);


	/**
     * handle bancaApplication data in case of exception
     * @param application
     */
    public void handleApplicationExceptionData(BancaApplication application) {
    	String applicationStatus = getApplicationStatus(application);
        if (applicationStatus.contains(SUBMISSION_AND_PAYMENT)) {
            updateApplicationFailData(application);
        } else if (applicationStatus.contains(PERSONAL_DETAILS)) {
            updatePersonDetailFailData();
        } else if (applicationStatus.contains(VALIDATION)) {
            updateValidationFailData();
        }
    }

    protected void updateValidationFailData() {
        try {
            ApplicationDetails applicationDetails = applicationDataStore.getApplicationDetails();
            applicationDetails.setApplicationStatus(APPLICATION_INITIATED_FAIL);
            applicationDetails.setApplicationErrorDesc(toString(applicationDataStore.getRuntimeExceptionErrorMsg(),
                    OBS_FAILURE.getDescription()));
            applicationDataStore.setApplicationDetails(applicationRepository.save(applicationDetails));
        } catch (Exception ex) {
            log.error("Fail to update database records upon validation failure, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

    @Override
    public void updatePaymentFailData(BancaApplication application) {
        try {
            OrderProductPayment productPayment = applicationDataStore.getOrderProductPayment();
            productPayment.setTxnStatus(PAYMENT_FAIL);
            orderPaymentRepository.save(productPayment);

            OrderMaster orderMaster = applicationDataStore.getOrderMaster();
            orderMaster.setOrderStatus(PAYMENT_FAIL);
            if(toString(applicationDataStore.getRuntimeExceptionErrorCode(),
                    OBS_CASA_PAYMENT_FAILURE.getCode()).equals(CasaErrorCode.EDMI_FUNDTRANSFER_CONN_FAILURE.getCode())){
            	orderMaster.setOrderErrorDesc(OBS_PAYMENT_TIMEOUT.getDescription()+Constants.PIPE+toString(applicationDataStore.getRuntimeExceptionErrorMsg(),
                        OBS_CASA_PAYMENT_FAILURE.getDescription()));
            }else{
            	orderMaster.setOrderErrorDesc(NA+Constants.PIPE+toString(applicationDataStore.getRuntimeExceptionErrorMsg(),
                        OBS_CASA_PAYMENT_FAILURE.getDescription()));
            }
            orderMasterRepository.save(orderMaster);
        } catch (Exception ex) {
            log.error("Fail to update database records upon payment failure, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

    @Override
    public void updatePaymentSuccessData(BancaApplication application) {
        try {
        	OrderProductPayment productPayment = applicationDataStore.getOrderProductPayment();
            productPayment.setTxnStatus(PAYMENT_SUCCESS);

            applicationDataStore.setOrderProductPayment(orderPaymentRepository.save(productPayment));

            OrderMaster orderMaster = applicationDataStore.getOrderMaster();
            orderMaster.setOrderStatus(PAYMENT_SUCCESS);
            applicationDataStore.setOrderMaster(orderMasterRepository.save(orderMaster));
        } catch (Exception ex) {
            log.error("Fail to update database records upon payment success, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
    
    @Override
    public void updateApplicationFailData(BancaApplication application) {
        try {
            OrderMaster orderMaster = applicationDataStore.getOrderMaster();
            orderMaster.setOrderStatus(toString(POLICY_PURCHASE_FAIL, OBS_FAILURE.getCode()));
            orderMaster.setOrderErrorDesc(PAYMENT_DONE_ISSUANCE_PENDIND+Constants.PIPE+toString(applicationDataStore.getRuntimeExceptionErrorMsg(),
                    OBS_FAILURE.getDescription()));
            orderMasterRepository.save(orderMaster);
        } catch (Exception ex){
            log.error("Fail to update database records upon submit policy failure, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

    protected void updatePersonDetailFailData() {
        try {
        	ApplicationDetails applicationDetails = applicationDataStore.getApplicationDetails();
            applicationDetails.setApplicationStatus(toString(APPLICATION_UPDATE_FAIL, OBS_FAILURE.getCode()));
            applicationDetails.setApplicationErrorDesc(toString(applicationDataStore.getRuntimeExceptionErrorMsg(),
                    OBS_FAILURE.getDescription()));
            applicationRepository.save(applicationDetails);
        } catch (Exception ex){
            log.error("Fail to update database records upon update personal details failure, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

    protected void updatePersonDetailsSuccessData() {
        try {
            ApplicationDetails applicationDetails = applicationDataStore.getApplicationDetails();
            applicationDetails.setApplicationStatus(APPLICATION_UPDATE_SUCCESS);
            applicationRepository.save(applicationDetails);
        } catch (Exception ex){
            log.error("Fail to update database records upon update personal details success, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }



    protected void handlePersonDetailsUpdateRequestData(BancaApplication application) {
        try {
        	ApplicationDetails currentApplication = applicationDataStore.getApplicationByBancaApplication(application);
            if (currentApplication == null){
                throw new TechnicalException("Unable to find application details record with id:" + application.getApplicationId());
            }
            currentApplication.setApplicationStatus(APPLICATION_UPDATE_STARTED);
            applicationDataStore.setApplicationDetails(applicationRepository.save(currentApplication));

            AppProductMaster appProductMaster = appProductMasterRepository.findByApplicationId(currentApplication.getApplicationId());
            applicationDataStore.setAppProductMaster(appProductMaster);

            AppRequesterDetails existingRequester = requesterDetailsRepository.findByApplicationId(currentApplication.getApplicationId());
            // if requester details with quotation number already existed
            if (existingRequester != null){
            	applicationDataFactory.createOrderRequesterDetails(application, existingRequester);
                applicationDataStore.setAppRequesterDetails(requesterDetailsRepository.save(existingRequester));

                AppProductInsuredDetails insuredDetails = insuredDetailsRepository.findByProductId(appProductMaster.getProductId());

                applicationDataFactory.createInsuredDetails(application, insuredDetails);
                applicationDataStore.setInsuredDetails(insuredDetailsRepository.save(insuredDetails));

                AppProductMailingAddressDetails addressDetails = mailingDetailsRepository.findByRequesterId(existingRequester.getRequesterDetailsId());
                applicationDataFactory.createMaillingDetails(application, addressDetails);
                mailingDetailsRepository.save(addressDetails);
                return;
            }

            AppRequesterDetails requesterDetails = applicationDataFactory.createOrderRequesterDetails(application, new AppRequesterDetails());
            requesterDetails.setApplicationDetails(applicationDataStore.getApplicationDetails());
            AppRequesterDetails createdRequester = requesterDetailsRepository.save(requesterDetails);
            applicationDataStore.setAppRequesterDetails(requesterDetailsRepository.save(requesterDetails));

            AppProductMailingAddressDetails mailingAddressDetails = applicationDataFactory.createMaillingDetails(application, new AppProductMailingAddressDetails());
            mailingAddressDetails.setAddressHolderId(createdRequester.getRequesterDetailsId());
            mailingAddressDetails.setAddressHolderType(REQUESTER_TYPE);
            mailingDetailsRepository.save(mailingAddressDetails);

            AppProductInsuredDetails insuredDetails = applicationDataFactory.createInsuredDetails(application, new AppProductInsuredDetails());
            insuredDetails.setAppProductMaster(appProductMaster);
            applicationDataStore.setInsuredDetails(insuredDetailsRepository.save(insuredDetails));
        } catch (Exception ex){
            log.error("Fail to create database records upon personal update request, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }

    /**
     * Get first input if not empty else take second input
     * @param input
     * @param orElseStr
     * @return
     */
    private String toString(String input, String orElseStr){
        return StringUtils.isNotBlank(input) ? input : orElseStr;
    }
    
 }
