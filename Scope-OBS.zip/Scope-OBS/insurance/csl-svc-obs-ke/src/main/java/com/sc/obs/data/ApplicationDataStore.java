package com.sc.obs.data;

import java.util.List;
import java.util.Optional;

import com.sc.obs.application.BancaApplication;
import com.sc.obs.data.entity.*;
import com.sc.obs.data.repository.ApplicationDetailsRepository;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.google.common.collect.Iterables;
import com.sc.csl.retail.core.exception.CSLRuntimeException;
import com.sc.obs.data.repository.AppProductMasterRepository;
import com.sc.obs.data.repository.OrderMasterRepository;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyWrapper;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Scope(scopeName = WebApplicationContext.SCOPE_REQUEST,
        proxyMode = ScopedProxyMode.TARGET_CLASS)
@Component
public class ApplicationDataStore {
    private ApplicationDetails applicationDetails;
    private OrderMaster orderMaster;
    private OrderProductPaymentMap orderProducPaymentMap;
    private AppProductMotor appProductMotor;
    // The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
    /*private AppProductHome appProductHome;
    private AppProductRiskMaster appProductRiskMaster;
    private AppProductRiskDetails appProductRiskDetails;*/
    private AppProductMaster appProductMaster;
    private AppRequesterDetails appRequesterDetails;
    private AppProductInsuredDetails insuredDetails;
    private OrderProductPayment orderProductPayment;
    private AppProductPolicy orderProductPolicy;
    private List<AppProductPremiumDetails> premiumDetailsList;
    private SanlamPolicyResponseWrapper responseWrapper;
    private Exception applicationDataException;
    private String quotationNo;
    private String applicationId;

    private ApplicationDetailsRepository applicationDetailsRepository;
    private OrderMasterRepository orderMasterRepository;
    private AppProductMasterRepository appProductMasterRepository;

    @Autowired
    public void setApplicationDetailsRepository(ApplicationDetailsRepository applicationDetailsRepository){
        this.applicationDetailsRepository = applicationDetailsRepository;
    }

    @Autowired
    public void setOrderMasterRepository(OrderMasterRepository orderMasterRepository){
        this.orderMasterRepository = orderMasterRepository;
    }

    @Autowired
    public void setAppsProductMasterRepository(AppProductMasterRepository appProductMasterRepository){
        this.appProductMasterRepository = appProductMasterRepository;
    }

    public OrderMaster getOrderMaster(){
        if (orderMaster == null){
            return orderMasterRepository.findByApplicationId(Long.valueOf(applicationId));
        }

        return orderMaster;
    }

    public AppProductMaster getAppProductMaster(){
        if (appProductMaster == null){
            List<AppProductMaster> appProductMasters = appProductMasterRepository.findByMotorQuotationNumber(
                    quotationNo);
            if (CollectionUtils.isNotEmpty(appProductMasters)){
                this.appProductMaster =  Iterables.getLast(appProductMasters);
            }
        }
        return appProductMaster;
    }

    public String getSanlamApiErrorMsg(){
        return Optional.ofNullable(responseWrapper)
                        .map(SanlamPolicyResponseWrapper::getResponseValue)
                        .map(SanlamPolicyWrapper::getErrorMessage)
                        .orElse(StringUtils.EMPTY);
    }

    public String getSanlamApiErrorCode(){
        return Optional.ofNullable(responseWrapper)
                .map(SanlamPolicyResponseWrapper::getResponseValue)
                .map(SanlamPolicyWrapper::getErrorCode)
                .orElse(StringUtils.EMPTY);
    }

    public String getRuntimeExceptionErrorMsg(){
        if (applicationDataException == null){
            return StringUtils.EMPTY;
        } else {
            return applicationDataException.getMessage();
        }
    }

    public String getRuntimeExceptionErrorCode(){
        if (applicationDataException == null || !(applicationDataException instanceof CSLRuntimeException)){
            return StringUtils.EMPTY;
        }

        return ((CSLRuntimeException) applicationDataException).getErrorCode().getCode();
    }

    public ApplicationDetails getApplicationByBancaApplication(BancaApplication bancaApplication) {
        if (StringUtils.isNotEmpty(bancaApplication.getApplicationId())){
            return applicationDetailsRepository.findByApplicationId(Long.valueOf(bancaApplication.getApplicationId()));
        }

        return null;
    }
}
