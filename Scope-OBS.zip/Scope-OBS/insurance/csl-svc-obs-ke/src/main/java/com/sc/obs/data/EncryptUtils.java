package com.sc.obs.data;

import org.jasypt.util.text.BasicTextEncryptor;

public final class EncryptUtils {

    private EncryptUtils() {
    }

    public static String encrypt(String input, String password){
        BasicTextEncryptor bte = new BasicTextEncryptor();
        bte.setPassword(password);

        return bte.encrypt(input);
    }
}