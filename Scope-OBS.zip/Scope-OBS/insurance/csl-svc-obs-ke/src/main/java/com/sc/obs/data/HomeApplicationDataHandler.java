package com.sc.obs.data;

import static com.sc.obs.data.OrderTransactionStatus.APPLICATION_INITIATED;
import static com.sc.obs.data.OrderTransactionStatus.APPLICATION_INITIATED_SUCCESS;
import static com.sc.obs.data.OrderTransactionStatus.POLICY_PURCHASE_SUCCESS;
import static com.sc.obs.sanlam.application.common.Constants.PERSONAL_DETAILS;
import static com.sc.obs.sanlam.application.common.Constants.SUBMISSION_AND_PAYMENT;
import static com.sc.obs.sanlam.application.common.Constants.VALIDATION;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.data.entity.AppProductCoverDetails;
//The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
//import com.sc.obs.data.entity.AppProductHome;
import com.sc.obs.data.entity.AppProductMaster;
import com.sc.obs.data.entity.AppProductPolicy;
import com.sc.obs.data.entity.AppProductPremiumDetails;
//The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
/*import com.sc.obs.data.entity.AppProductRiskDetails;
import com.sc.obs.data.entity.AppProductRiskMaster;*/
import com.sc.obs.data.entity.ApplicationDetails;
import com.sc.obs.data.entity.AuditLogDetails;
import com.sc.obs.data.entity.OrderMaster;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.application.model.HomeApplicationDetail;
import com.sc.obs.sanlam.application.model.HomePolicyRisk;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class HomeApplicationDataHandler extends ApplicationDataHandler {

	public String getResponseStatus(BancaApplication application) {
		HomeApplicationDetail homeDetails = getHomeApplicationDetail(application);
		String responseStatus = homeDetails.getResponseStatus();
        return responseStatus;
    }
	
	
	public String getApplicationStatus(BancaApplication application) {
		HomeApplicationDetail homeDetails = getHomeApplicationDetail(application);
		String applicationStatus = homeDetails.getCurrentApplicationStage();
        Map<String, String> applicationState = config.getApplicationState(COUNTRY, ISP);
        if(applicationState.containsKey(applicationStatus)) {
            applicationStatus = applicationState.get(applicationStatus);
        }
        return applicationStatus;
    }
	
	 /**
     * handle bancaApplication data before send request to Sanlam
     * @param application
     */
    public void handleApplicationReqData(BancaApplication application){
        String applicationStatus = getApplicationStatus(application);
        if (applicationStatus.contains(PERSONAL_DETAILS)){
        	handleRequestData(application);
        	handlePersonDetailsUpdateRequestData(application);
        }
    }
    
    /**
     * This is the start of submit bancaApplication process
     * @param application
     */
    private void handleRequestData(BancaApplication application){
        try {
            ApplicationDetails currentApplicationRecord = getApplicationDataStore().getApplicationByBancaApplication(application);
            
            // if order with quotation number already existed
            if (currentApplicationRecord != null){
                applicationDataStore.setApplicationDetails(currentApplicationRecord);
                
                //The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
                /*AppProductHome existingProduct = Optional.ofNullable(productHomeRepository.findByHomeQuotationNumber(application.getQuotationNumber()))
                        .map(Iterables::getLast)
                        .orElse(new AppProductHome());

                existingProduct = applicationDataFactory.createOrderProductHome(application, existingProduct);
                applicationDataStore.setAppProductHome(productHomeRepository.save(existingProduct));*/

                return;
            }

            // else need to initiate new set of data
            ApplicationDetails newApplicationRecord = applicationDataFactory.createApplicationDetails(application);
            newApplicationRecord.setApplicationStatus(APPLICATION_INITIATED);
            ApplicationDetails createdApplication = applicationRepository.save(newApplicationRecord);
            applicationDataStore.setApplicationDetails(createdApplication);

            AppProductMaster appProductMaster = applicationDataFactory.createAppProductMaster(application);
            appProductMaster.setApplicationDetails(createdApplication);
            applicationDataStore.setAppProductMaster(appProductMasterRepository.save(appProductMaster));

            //The below comment will be removed after AppProductHome,AppProductRisk and related repository is merged.
            /*
            AppProductHome appProductHome = applicationDataFactory.createOrderProductHome(application, new AppProductHome());
            appProductHome.setAppProductMaster(applicationDataStore.getAppProductMaster());
            Map<String, String> defaultValues = config.getDefaultValues(COUNTRY, ISP);
            appProductHome.setDealReferrer(defaultValues.get("dealReferrer"));
            appProductHome.setReferrerPwId(defaultValues.get("referrerPWId"));
            applicationDataStore.setAppProductHome(productHomeRepository.save(appProductHome));

            AppProductRiskMaster appProductRiskMaster = new AppProductRiskMaster();
            appProductRiskMaster.setAppProductMaster(applicationDataStore.getAppProductMaster());
            applicationDataStore.setAppProductRiskMaster(productRiskMasterRepository.save(appProductRiskMaster));
            
            AppProductRiskDetails appProductRiskDetails = new AppProductRiskDetails();
            appProductRiskDetails.setAppProductRiskMaster(applicationDataStore.getAppProductRiskMaster());
            applicationDataStore.setAppProductRiskDetails(productRiskDetailsRepository.save(appProductRiskDetails));
            */
            // set application id as ID from record
            application.setApplicationId(createdApplication.getApplicationId().toString());
        } catch (Exception ex){
            log.error("Fail to create database records upon validation request, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
    /**
     * handle bancaApplication data after received response from Sanlam
     * @param application
     */
    public void handleApplicationResData(BancaApplication application){
      	String applicationStatus = getApplicationStatus(application);
    	String responseStatus = getResponseStatus(application);
    	if (applicationStatus.contains(PERSONAL_DETAILS)) {
            if (responseStatus.equalsIgnoreCase(STATUS_SUCCESS)){
            	updatePersonDetailsSuccessData();
            } else {
            	updatePersonDetailFailData();
            }
        } else if (applicationStatus.contains(SUBMISSION_AND_PAYMENT)){
            if (responseStatus.equalsIgnoreCase(STATUS_SUCCESS)) {
                // bancaApplication submit to Sanlam success
                updateApplicationSuccessData(application);
                saveConsentAuditLogData(application);
            } else {
                updateApplicationFailData(application);
            }
        }
    }
    
    
    public void saveConsentAuditLogData(BancaApplication application) {
       // Need to change
    }
	
	public void updateApplicationSuccessData(BancaApplication application) {
        try {
            OrderMaster orderMaster = applicationDataStore.getOrderMaster();
            orderMaster.setOrderStatus(POLICY_PURCHASE_SUCCESS);
            applicationDataStore.setOrderMaster(orderMasterRepository.save(orderMaster));
            AppProductMaster productMaster = appProductMasterRepository.findByApplicationId(Long.valueOf(application.getApplicationId()));
            if (productMaster != null){
                HomeApplicationDetail homeDetails = (HomeApplicationDetail) application.getBancaApplicationDetail();
                CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) application.getPaymentDetail();
                productMaster.setPremiumAmt(homeDetails.getPolicyDetails().getPremium());
                productMaster.setPremiumAmtCurr(casaPaymentDetail.getTransactionCurrency());
                productMaster.setTotalSumAssuredAmt(homeDetails.getPolicyDetails().getPremium());
                productMaster.setTotalSumAssuredAmtCurr(casaPaymentDetail.getTransactionCurrency());
                appProductMasterRepository.save(productMaster);
            } else {
                throw new TechnicalException("Unable to find application product master record with id:" + application.getApplicationId());
            }

            List<AppProductCoverDetails> coverDetails = applicationDataFactory.createOrderProductCoverDetailsForHome(application);
            Objects.requireNonNull(coverDetails).forEach(c -> c.setOrderProductMaster(productMaster));
            productCoverDetailsRepository.save(coverDetails);

            AppProductPolicy productPolicy = applicationDataFactory.createOrderProductPolicy(application);
            productPolicy.setStatus(POLICY_PURCHASE_SUCCESS);
            productPolicy.setAppProductMaster(productMaster);

            applicationDataStore.setOrderProductPolicy(orderProductPolicyRepository.save(productPolicy));
        } catch (Exception ex){
            log.error("Fail to update database records upon submit policy success, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
	
	private HomeApplicationDetail getHomeApplicationDetail(BancaApplication application) {
        return (HomeApplicationDetail) application.getBancaApplicationDetail();
    }

	
}
