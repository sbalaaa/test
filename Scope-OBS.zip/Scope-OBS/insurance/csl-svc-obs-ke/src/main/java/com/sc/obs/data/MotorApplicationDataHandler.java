package com.sc.obs.data;

import static com.sc.obs.data.OrderTransactionStatus.*;
import static com.sc.obs.sanlam.application.common.Constants.PERSONAL_DETAILS;
import static com.sc.obs.sanlam.application.common.Constants.SUBMISSION_AND_PAYMENT;
import static com.sc.obs.sanlam.application.common.Constants.VALIDATION;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Iterables;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.data.entity.AppProductCoverDetails;
import com.sc.obs.data.entity.AppProductInsuredDetails;
import com.sc.obs.data.entity.AppProductMailingAddressDetails;
import com.sc.obs.data.entity.AppProductMaster;
import com.sc.obs.data.entity.AppProductMotor;
import com.sc.obs.data.entity.AppProductPolicy;
import com.sc.obs.data.entity.AppProductPremiumDetails;
import com.sc.obs.data.entity.AppRequesterDetails;
import com.sc.obs.data.entity.ApplicationDetails;
import com.sc.obs.data.entity.AuditLogDetails;
import com.sc.obs.data.entity.OrderMaster;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MotorApplicationDataHandler extends ApplicationDataHandler {

	
	public String getResponseStatus(BancaApplication application) {
		MotorApplicationDetail motorDetails = getMotorApplicationDetail(application);
		String responseStatus = motorDetails.getResponseStatus();
        return responseStatus;
    }
	
	
	public String getApplicationStatus(BancaApplication application) {
		MotorApplicationDetail motorDetails = getMotorApplicationDetail(application);
		String applicationStatus = motorDetails.getCurrentApplicationStage();
        Map<String, String> applicationState = config.getApplicationState(COUNTRY, ISP);
        if(applicationState.containsKey(applicationStatus)) {
            applicationStatus = applicationState.get(applicationStatus);
        }
        return applicationStatus;
    }
	
	 /**
     * handle bancaApplication data before send request to Sanlam
     * @param application
     */
    public void handleApplicationReqData(BancaApplication application){
        String applicationStatus = getApplicationStatus(application);
        if(applicationStatus.contains(VALIDATION)) {
            handleValidationRequestData(application);
        } else if (applicationStatus.contains(PERSONAL_DETAILS)){
            handlePersonDetailsUpdateRequestData(application);
        }
    }
    
    
    /**
     * handle bancaApplication data after received response from Sanlam
     * @param application
     */
    public void handleApplicationResData(BancaApplication application){
    	String applicationStatus = getApplicationStatus(application);
    	String responseStatus = getResponseStatus(application);
        if (applicationStatus.contains(VALIDATION)) {
            if (responseStatus.equalsIgnoreCase(STATUS_SUCCESS)) {
                updateValidationSuccessData(application);
            } else {
                updateValidationFailData();
            }
        } else if (applicationStatus.contains(PERSONAL_DETAILS)) {
            if (responseStatus.equalsIgnoreCase(STATUS_SUCCESS)){
                updatePersonDetailsSuccessData();
            } else {
                updatePersonDetailFailData();
            }
        } else if (applicationStatus.contains(SUBMISSION_AND_PAYMENT)){
            if (responseStatus.equalsIgnoreCase(STATUS_SUCCESS)) {
                // bancaApplication submit to Sanlam success
                updateApplicationSuccessData(application);
                saveConsentAuditLogData(application);
            } else {
                updateApplicationFailData(application);
            }
        }
    }
    
    
    /**
     * This is the start of submit bancaApplication process
     * @param application
     */
    private void handleValidationRequestData(BancaApplication application){
        try {
            ApplicationDetails currentApplicationRecord = getApplicationDataStore().getApplicationByBancaApplication(application);

            // if order with quotation number already existed
            if (currentApplicationRecord != null){
                applicationDataStore.setApplicationDetails(currentApplicationRecord);

                AppProductMotor existingProduct = Optional.ofNullable(productMotorRepository.findByMotorQuotationNumber(application.getQuotationNumber()))
                        .map(Iterables::getLast)
                        .orElse(new AppProductMotor());

                existingProduct = applicationDataFactory.createOrderProductMotor(application, existingProduct);
                applicationDataStore.setAppProductMotor(productMotorRepository.save(existingProduct));

                return;
            }

            // else need to initiate new set of data
            ApplicationDetails newApplicationRecord = applicationDataFactory.createApplicationDetails(application);
            newApplicationRecord.setApplicationStatus(APPLICATION_INITIATED);
            ApplicationDetails createdApplication = applicationRepository.save(newApplicationRecord);
            applicationDataStore.setApplicationDetails(createdApplication);

            AppProductMaster appProductMaster = applicationDataFactory.createAppProductMaster(application);
            appProductMaster.setApplicationDetails(createdApplication);
            applicationDataStore.setAppProductMaster(appProductMasterRepository.save(appProductMaster));

            AppProductMotor appProductMotor = applicationDataFactory.createOrderProductMotor(application, new AppProductMotor());
            appProductMotor.setAppProductMaster(applicationDataStore.getAppProductMaster());
            Map<String, String> defaultValues = config.getDefaultValues(COUNTRY, ISP);
            appProductMotor.setDealReferrer(defaultValues.get("dealReferrer"));
            appProductMotor.setReferrerPwId(defaultValues.get("referrerPWId"));
            applicationDataStore.setAppProductMotor(productMotorRepository.save(appProductMotor));

            // set application id as ID from record
            application.setApplicationId(createdApplication.getApplicationId().toString());
        } catch (Exception ex){
            log.error("Fail to create database records upon validation request, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
	private void updateValidationSuccessData(BancaApplication application) {
		MotorApplicationDetail motorDetails = getMotorApplicationDetail(application);
		try {
            ApplicationDetails applicationDetails = applicationDataStore.getApplicationDetails();
            applicationDetails.setApplicationStatus(APPLICATION_INITIATED_SUCCESS);
            applicationDataStore.setApplicationDetails(applicationRepository.save(applicationDetails));
            List<AppProductPremiumDetails> existingPremiumList = premiumDetailsRepository.findByProductId(applicationDataStore.getAppProductMaster().getProductId());
            if (CollectionUtils.isNotEmpty(existingPremiumList)){
                applicationDataFactory.updateExistingPremiumDetails(motorDetails.getPremiumDetails(), existingPremiumList);
                applicationDataStore.setPremiumDetailsList(
                       premiumDetailsRepository.save(existingPremiumList));
                return;
            }
            List<AppProductPremiumDetails> premiumDetailsList =
                    applicationDataFactory.createPremiumDetails(applicationDataStore, motorDetails.getPremiumDetails());
            applicationDataStore.setPremiumDetailsList(
                    premiumDetailsRepository.save(premiumDetailsList));
        } catch (Exception ex){
            log.error("Fail to update database records upon validation success, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
	public void saveConsentAuditLogData(BancaApplication application) {
        try {
            MotorApplicationDetail motorDetails = getMotorApplicationDetail(application);
            if (motorDetails.getConsentAuditDetails()!=null && !CollectionUtils.isEmpty(motorDetails.getConsentAuditDetails().getConsentIds())) {
                for (Long consentId : motorDetails.getConsentAuditDetails().getConsentIds()) {
                    AuditLogDetails auditLogDetails = applicationDataFactory.createAuditLogDetails(application);
                    auditLogDetails.setObsConsentMaster(obsConsentMasterRepository.findOne(consentId));
                    auditLogDetailsRepository.save(auditLogDetails);
                }
            }
        } catch (Exception ex) {
            log.error("Fail to update database records upon save consent audit, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
	public void updateApplicationSuccessData(BancaApplication application) {
        try {
            OrderMaster orderMaster = applicationDataStore.getOrderMaster();
            orderMaster.setOrderStatus(POLICY_PURCHASE_SUCCESS);
            applicationDataStore.setOrderMaster(orderMasterRepository.save(orderMaster));
            AppProductMaster productMaster = appProductMasterRepository.findByApplicationId(Long.valueOf(application.getApplicationId()));
            if (productMaster != null){
                MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
                CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) application.getPaymentDetail();
                productMaster.setPremiumAmt(motorDetails.getPolicyDetails().getPremium());
                productMaster.setPremiumAmtCurr(casaPaymentDetail.getTransactionCurrency());
                productMaster.setTotalSumAssuredAmt(motorDetails.getPolicyDetails().getPremium());
                productMaster.setTotalSumAssuredAmtCurr(casaPaymentDetail.getTransactionCurrency());
                appProductMasterRepository.save(productMaster);
            } else {
                throw new TechnicalException("Unable to find application product master record with id:" + application.getApplicationId());
            }

            List<AppProductCoverDetails> coverDetails = applicationDataFactory.createOrderProductCoverDetails(application);
            Objects.requireNonNull(coverDetails).forEach(c -> c.setOrderProductMaster(productMaster));
            productCoverDetailsRepository.save(coverDetails);

            AppProductPolicy productPolicy = applicationDataFactory.createOrderProductPolicy(application);
            productPolicy.setStatus(POLICY_PURCHASE_SUCCESS);
            productPolicy.setAppProductMaster(productMaster);

            applicationDataStore.setOrderProductPolicy(orderProductPolicyRepository.save(productPolicy));
        } catch (Exception ex){
            log.error("Fail to update database records upon submit policy success, reason :: {}", ex.getMessage());
            throw new TechnicalException(ApplicationErrorCode.OBS_DATABASE_FAILURE, ex.getMessage());
        }
    }
	
	
	private MotorApplicationDetail getMotorApplicationDetail(BancaApplication application) {
        return (MotorApplicationDetail) application.getBancaApplicationDetail();
    }
	
	
}
