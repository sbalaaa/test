package com.sc.obs.data;

public final class OrderTransaction {

    private OrderTransaction() {
    }


    public static final String VALIDATION_SUCCESS = "VALIDATION_SUCCESS";
    public static final String VALIDATION_FAILED = "VALIDATION_FAILED";
    public static final String UPDATE_PERSONAL_DETAILS_FAILED = "UPDATE_PERSONAL_DETAILS_FAILED";
    public static final String UPDATE_PERSONAL_DETAILS_INITIATED = "UPDATE_PERSONAL_DETAILS_INITIATED";
    public static final String UPDATE_PERSONAL_DETAILS_SUCCESS= "UPDATE_PERSONAL_DETAILS_SUCCESS";

    public static final String PAYMENT = "payment";
    public static final String SUBMIT_POLICY = "submit policy";
    public static final String INSURED_TYPE_DRIVER = "driver";
    public static final String CHANNEL_MOBILE_NAME = "MobileBanking";
    public static final String CHANNEL_MOBILE_CODE = "IBNK";
    public static final String PRODUCT_MOTOR = "MOTOR";
    public static final String APP_NAME_OBS = "OBS";
}
