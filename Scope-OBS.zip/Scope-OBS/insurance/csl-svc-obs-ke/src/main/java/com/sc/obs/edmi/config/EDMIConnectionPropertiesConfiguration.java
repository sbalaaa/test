package com.sc.obs.edmi.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.obs.common.properties.EdmiProductCasaConfigProperties;
import com.sc.obs.edmi.account.adapter.AccountValidationRequestProperties;
import com.sc.obs.edmi.fundtransfer.adapter.FundTransferRequestProperties;

@Configuration
@EnableConfigurationProperties
public class EDMIConnectionPropertiesConfiguration {
	
    @Bean
    @ConfigurationProperties(prefix = "edmi.request.fundTransfer")
    public FundTransferRequestProperties edmiFundTransferCountryProperties() {
        return new FundTransferRequestProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "edmi.connection.casa.fundTransfer")
    public CSLSoapGatewayProperties edmiFundTransferConnectionProperties(@Qualifier("edmiCommonConnectionProperties") CSLSoapGatewayProperties properties){
    	return properties;
    }
    
    @Bean
    @ConfigurationProperties(prefix = "edmi.connection.common")
    @Scope(value="prototype")
    public CSLSoapGatewayProperties edmiCommonConnectionProperties() {
        return new CSLSoapGatewayProperties();
    }
    
    @Bean
    @ConfigurationProperties(prefix = "edmi.request.account")
    public AccountValidationRequestProperties edmiAccountCountryProperties() {
        return new AccountValidationRequestProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "edmi.connection.account.validation")
    public CSLSoapGatewayProperties edmiAccountConnectionProperties(@Qualifier("edmiCommonConnectionProperties") CSLSoapGatewayProperties properties) {
        return properties;
    }
    
    @Bean
    @ConfigurationProperties(prefix = "casa.motor")
    public EdmiProductCasaConfigProperties edmiMotorProductConfigProperties() {
        return new EdmiProductCasaConfigProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "casa.home")
    public EdmiProductCasaConfigProperties edmiHomeProductConfigProperties() {
        return new EdmiProductCasaConfigProperties();
    }

    
}
