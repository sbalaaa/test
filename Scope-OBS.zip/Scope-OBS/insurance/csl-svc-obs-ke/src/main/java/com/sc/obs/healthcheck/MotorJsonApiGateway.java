package com.sc.obs.healthcheck;

import com.sc.csl.retail.core.exception.CSLErrorCodes;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.CSLOTPErrorCode;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.auth.SmsOTP;
import com.sc.obs.auth.ValidateOTP;
import com.sc.obs.exception.ObsBusinessException;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;

import io.crnk.core.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Lazy
@ConfigurationProperties(prefix = "csl.gateway.motor")
public class MotorJsonApiGateway extends CSLJsonApiGateway {


    private static final String UAAS_SUCCESS_CODE = "100";


    public BancaApplication saveApplication() {
        ResourceRepositoryV2<BancaApplication, String> appl = getCrnkClient().getRepositoryForType(BancaApplication.class);
        BancaApplication details = new BancaApplication();
        BancaApplication response = appl.save(details);
        log.debug(response.toString());
        
        return response;
    }



    public ValidateOTP validateOtp(ValidateOTP validateOtp) {
        ResourceRepositoryV2<ValidateOTP, String> validateOtpRepo = getCrnkClient().getRepositoryForType(ValidateOTP.class);
        ValidateOTP validateOtpResponse = validateOtpRepo.create(validateOtp);
        log.debug(validateOtpResponse.toString());

        if (!UAAS_SUCCESS_CODE.equals(validateOtpResponse.getStatusCode())) {
            CSLOTPErrorCode errorCode = new CSLOTPErrorCode(validateOtpResponse.getStatusCode(), validateOtpResponse.getErrorMessage(), CSLErrorCodes.OTP_VALIDATION_FAILED.getDescription());
            log.info("Validate OTP failed : {}", errorCode);
            throw new ObsBusinessException(errorCode);
        }

        return validateOtpResponse;
    }




}
