package com.sc.obs.healthcheck;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicy;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyWrapper;

@Component
public class SanlamConnectivityHC implements HealthIndicator{

    @Autowired
    private SanlamAdapter adaptor;

    @Override
    public Health health() {
        try {
            SanlamPolicy request = new SanlamPolicy();
            request.setCountry("");
            SanlamPolicyWrapper validationReq = new SanlamPolicyWrapper(request);
            MultiValueMap<String ,String> headers = new HttpHeaders();
            headers.add("policyState","validation");
            adaptor.callSanlam("policy", HttpMethod.PATCH, validationReq, SanlamPolicyResponseWrapper.class,MediaType.APPLICATION_JSON, headers);
        } catch (Exception ex){
            return Health.down(ex).build();
        }

        return Health.up().build();
    }
}
