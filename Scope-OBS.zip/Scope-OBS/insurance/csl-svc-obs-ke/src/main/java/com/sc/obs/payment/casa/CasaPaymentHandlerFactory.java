package com.sc.obs.payment.casa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.obs.application.BancaApplication;
import com.sc.obs.code.Country;
import com.sc.obs.code.PaymentType;
import com.sc.obs.payment.PaymentHandlerFactoryRegistry;
import com.sc.obs.payment.PaymentProcessor;
import com.sc.obs.payment.PaymentProcessorFactory;

@Component
public class CasaPaymentHandlerFactory implements PaymentProcessorFactory {

    @Autowired
    @Qualifier("casaKE")
    private CasaPaymentService casaPaymentService;

    @Autowired
    public void setPaymentServiceHandlerFactoryRegistry(PaymentHandlerFactoryRegistry paymentHandlerFactoryRegistry) {
        paymentHandlerFactoryRegistry.register(Country.KE, PaymentType.CASA, this);
    }

    @Override
    public PaymentProcessor createPaymentProcessor(BancaApplication bancaApplicationRequest) {
        CasaPaymentDetail paymentDetail = (CasaPaymentDetail) bancaApplicationRequest.getPaymentDetail();
        return new CasaPaymentProcessor(paymentDetail, casaPaymentService);
    }

}
