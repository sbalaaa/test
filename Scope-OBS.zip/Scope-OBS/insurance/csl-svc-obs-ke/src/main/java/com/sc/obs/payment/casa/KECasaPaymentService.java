package com.sc.obs.payment.casa;


import java.util.Collections;

import com.sc.obs.product.ProductType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.obs.common.properties.EdmiProductCasaConfigProperties;
import com.sc.obs.edmi.EdmiErrorList;
import com.sc.obs.edmi.account.adapter.AccountDetailsAdapter;
import com.sc.obs.edmi.account.adapter.AccountValidationResponse;
import com.sc.obs.edmi.account.adapter.AccountValidationStatus;
import com.sc.obs.edmi.account.response.handlers.AccountValidationEBBSResponseHandler;
import com.sc.obs.edmi.fundstransfer.response.handlers.FundTransferEbbsV6ResponseHandler;
import com.sc.obs.edmi.fundtransfer.adapter.FundTransferV6Adapter;
import com.sc.obs.payment.PaymentResponse;
import com.sc.obs.payment.PaymentStatus;

@Service
@Qualifier("casaKE")
public class KECasaPaymentService implements CasaPaymentService {

    @Autowired
    private FundTransferV6Adapter fundTransferV6Adapter;
    
    @Autowired
    private AccountDetailsAdapter accountValidationAdapter;
    
    @Autowired
    private FundTransferEbbsV6ResponseHandler fundTransferEbbsV6ResponseHandler;
    
    @Autowired
    private AccountValidationEBBSResponseHandler accountValidationEBBSResponseHandler;

    private EdmiProductCasaConfigProperties edmiMotorProductCasaConfigProperties;

    private EdmiProductCasaConfigProperties edmiHomeProductCasaConfigProperties;
    
    @Autowired
    @Qualifier("edmiMotorProductConfigProperties")
	public void setEdmiMotorProductCasaConfigProperties(
			EdmiProductCasaConfigProperties edmiMotorProductCasaConfigProperties) {
		this.edmiMotorProductCasaConfigProperties = edmiMotorProductCasaConfigProperties;
	}

    @Autowired
    @Qualifier("edmiHomeProductConfigProperties")
    public void setEdmiHomeProductCasaConfigProperties(
            EdmiProductCasaConfigProperties edmiHomeProductCasaConfigProperties) {
        this.edmiHomeProductCasaConfigProperties = edmiHomeProductCasaConfigProperties;
    }

	@Override
    public PaymentResponse executePayment(CasaPaymentDetail paymentDetail) {
        return fundTransferV6Adapter.postTransaction(paymentDetail)
                .map(response -> fundTransferEbbsV6ResponseHandler.process(response))
                .orElse(new PaymentResponse(PaymentStatus.Failure, new EdmiErrorList(Collections.emptyList()), "Error while processing fund transfer from EDMI"));
    }

    @Override
    public CasaPaymentDetail prePopulateCasaPaymentDetail(CasaPaymentDetail paymentDetail) {
        switch (ProductType.valueOf(paymentDetail.getProductType())){
            case MOTOR:
            {
                paymentDetail.setToAccountNumber(edmiMotorProductCasaConfigProperties.getIspAccountNumber());
                paymentDetail.setDebitNarration(edmiMotorProductCasaConfigProperties.getDebitNarration());
                break;
            }
            case HOME:
            {
                paymentDetail.setToAccountNumber(edmiHomeProductCasaConfigProperties.getIspAccountNumber());
                paymentDetail.setDebitNarration(edmiHomeProductCasaConfigProperties.getDebitNarration());
                break;
            }

        }

        return paymentDetail;
    }

	@Override
	public AccountValidationResponse validateAccount(CasaPaymentDetail paymentDetail) {
		return accountValidationAdapter.getAccountDetails(paymentDetail)
				.map(response -> accountValidationEBBSResponseHandler.process(response))
                .orElse(new AccountValidationResponse(AccountValidationStatus.Failure, new EdmiErrorList(Collections.emptyList()), "Error while validating account from EDMI"));
	}
	

}
