package com.sc.obs.product;

public enum ProductType {
		MOTOR, HOME
}
