/**
 * 
 */
package com.sc.obs.sanlam;

/**
 * @author 1567880
 *
 */
public class SanlamRequest {

}
