/**
 * 
 */
package com.sc.obs.sanlam.adapter;


import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.sc.csl.retail.core.gateway.CSLRestGateway;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.code.Country;
import com.sc.obs.code.Key;
import com.sc.obs.config.ObsKEConstants;
import com.sc.obs.sanlam.SanlamRequest;
import com.sc.obs.sanlam.SanlamResponse;

/**
 * @author 1567880
 *
 */
@Component("sanlamAdapter")
public class SanlamAdapter extends CSLRestGateway {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SanlamAdapter.class);
	
	@Value("${sanlam.contextpath}")
    private String sanlamContextPath;
	
	@Value("${sanlam.authentication-id-part1}")
	private String authIdPartOne;
	
	@Value("${sanlam.authentication-id-part2}")
	private String authIdPartTwo;

	@Autowired
    @Qualifier("restClient")
    private RestTemplate restClient;
	
	/*
     * SanlamRequest payload - primary payload when content type is application/json
     * MultiValueMap<String, Object> paramsMap - seconday payload when Content-Type is multipart/form-data.
     * 
     */
    @LogTimeTaken
    public SanlamResponse callSanlam(String serviceName,HttpMethod httpMethod,SanlamRequest payload,Class<? extends SanlamResponse> respClass, MediaType contentType, MultiValueMap<String, String> httpHeadersMap){
        return callSanlam(serviceName, httpMethod, payload, respClass, contentType, httpHeadersMap, null);
    }
	/*
	 * SanlamRequest payload - primary payload when content type is application/json
	 * MultiValueMap<String, Object> paramsMap - seconday payload when Content-Type is multipart/form-data.
	 * 
	 */
	@LogTimeTaken
	public SanlamResponse callSanlam(String serviceName,HttpMethod httpMethod,SanlamRequest payload,Class<? extends SanlamResponse> respClass, MediaType contentType, MultiValueMap<String, String> httpHeadersMap, MultiValueMap<String, Object> multipartDataMap){
		LOGGER.info("sanlam request URL : {}",sanlamContextPath + serviceName);
		LOGGER.debug("sanlam request payload : {}",payload);
		SanlamResponse response = (SanlamResponse)restClient.exchange(sanlamContextPath + serviceName,httpMethod, prepareReqEntity(payload,contentType,httpHeadersMap,multipartDataMap),respClass).getBody();
		LOGGER.info("SANLAM response :  {}",response);
		return response;
	}
	
	private HttpEntity<Object> prepareReqEntity(SanlamRequest request, MediaType contentType, MultiValueMap<String, String> httpHeadersMap,MultiValueMap<String, Object> multipartDataMap){
	    HttpHeaders headers = new HttpHeaders();
	    if(contentType==null){
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
	    }else{
	    	headers.setContentType(contentType);
	    }
	    if(httpHeadersMap!=null){
	    	headers.putAll(httpHeadersMap);
	    }
        headers.add(Key.COUNTRY, Country.KE);
        headers.add(ObsKEConstants.AUTHENTICATION_ID, authIdPartOne+":"+authIdPartTwo);
        String requestId =  RandomStringUtils.randomAlphanumeric(40);
        LOGGER.info("requestId : {}",requestId);
        headers.add(ObsKEConstants.REQUEST_ID,requestId);
        HttpEntity<Object> entity = null;
        if(headers.getContentType().equals(MediaType.MULTIPART_FORM_DATA)){
        	entity = new HttpEntity<>(multipartDataMap,headers);
        }else{
        	entity = new HttpEntity<>(CSLJsonUtils.toJson(request), headers);
        }
        LOGGER.debug("sanlam request entity : {}",entity);
        return entity;
	}
}
