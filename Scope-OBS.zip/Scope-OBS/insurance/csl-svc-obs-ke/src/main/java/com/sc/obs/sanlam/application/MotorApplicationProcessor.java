package com.sc.obs.sanlam.application;

import static com.sc.csl.retail.core.util.CSLLogConstants.TIME_TAKEN_IN_MILLIS;
import static com.sc.obs.sanlam.application.common.Constants.PERSONAL_DETAILS;
import static com.sc.obs.sanlam.application.common.Constants.SUBMISSION_AND_PAYMENT;
import static com.sc.obs.sanlam.application.common.Constants.VALIDATION;
import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.OBS_CASA_PAYMENT_FAILURE;
import static net.logstash.logback.argument.StructuredArguments.kv;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.ResourceAccessException;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.BancaApplicationProcessor;
import com.sc.obs.application.BancaApplicationProcessorRegistry;
import com.sc.obs.auth.TransactionOTP;
import com.sc.obs.code.Country;
import com.sc.obs.config.ApplicationError;
import com.sc.obs.config.MotorConfig;
import com.sc.obs.data.ApplicationDataHandler;
import com.sc.obs.data.entity.OrderMaster;
import com.sc.obs.exception.ObsBusinessException;
import com.sc.obs.payment.EdmiError;
import com.sc.obs.payment.PaymentHandlerFactoryRegistry;
import com.sc.obs.payment.PaymentProcessor;
import com.sc.obs.payment.PaymentProcessorFactory;
import com.sc.obs.payment.PaymentResponse;
import com.sc.obs.payment.PaymentStatus;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.product.ProductType;
import com.sc.obs.sanlam.SanlamRequest;
import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.common.ApplicationExceptionHandler;
import com.sc.obs.sanlam.application.common.Constants;
import com.sc.obs.sanlam.application.common.Gender;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicy;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyWrapper;

/**
 * Author Akshay (1519510)
 * This resource will cater the Motor Insurance application submission
 * Supported Country :: Kenya , Botswana
 */
@Slf4j
@Component
public class MotorApplicationProcessor implements BancaApplicationProcessor {

    @Autowired
    @Qualifier("motorApplicationDataHandler")
    private ApplicationDataHandler applicationDataHandler;

    @Autowired
    private PaymentHandlerFactoryRegistry paymentHandlerFactoryRegistry;

    @Autowired
    private MotorApplicationMapper mapper;

    @Autowired
    @Qualifier("sanlamAdapter")
    private SanlamAdapter sanlamAdapter;

    @Autowired
    private MotorConfig config;

    @Autowired
    private ApplicationExceptionHandler exceptionHandler;

    @Value("${casa.motor.ispAccountNumber:}")
    private String ispAccountNumber ;

    private static final String DEFAULT_STATIC_IDENTIFIER = "10001";
    private static final String COUNTRY = "ke";
    private static final String ISP = "sanlam";
    private static final String SERVICE_URL = "policy";
    private static final String POLICY_STATE_HEADER = "policyState";

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    @Autowired
    public void setRegistry(BancaApplicationProcessorRegistry registry) {
        registry.register(Country.KE, ProductType.MOTOR.name(), this);
    }

    @Override
    public BancaApplication submitBancaApplication(BancaApplication bancaApplicationRequest) {
        MotorApplicationDetail motorDetails = preProcess(bancaApplicationRequest);
        final String applicationStatus = getApplicationStatus(motorDetails);
        List<String> sectionList = Collections.singletonList(applicationStatus);
        bancaApplicationRequest.setId(bancaApplicationRequest.getQuotationNumber());
        SanlamPolicy request = mapper.map(bancaApplicationRequest, sectionList);
        SanlamPolicyWrapper validationReq = new SanlamPolicyWrapper(request);
        if (applicationStatus.equalsIgnoreCase(SUBMISSION_AND_PAYMENT)) {
            initiatePaymentRequest(bancaApplicationRequest);
        }
        applicationDataHandler.handleApplicationReqData(bancaApplicationRequest);
        final SanlamPolicyResponseWrapper responseVal = saveApplications(validationReq, applicationStatus, bancaApplicationRequest);
        bancaApplicationRequest = mapper.map(bancaApplicationRequest, responseVal, sectionList);
        applicationDataHandler.handleApplicationResData(bancaApplicationRequest);
        return bancaApplicationRequest;

    }

    @TransactionOTP(actionName="TRANSACTION_OTP")
	private void initiatePaymentRequest(BancaApplication bancaApplicationRequest){
    	Long startTime = System.currentTimeMillis();
		try {
		    applicationDataHandler.initiateOrderData(bancaApplicationRequest);
		    submitPaymentRequest(bancaApplicationRequest);
		    

		    applicationDataHandler.updatePaymentSuccessData(bancaApplicationRequest);
		} catch (Exception e) {
		    applicationDataHandler.getApplicationDataStore().setApplicationDataException(e);
		    applicationDataHandler.updatePaymentFailData(bancaApplicationRequest);
		    throw e;
		}finally{
        	log.info("Request time taken : {} {} ms",kv(Constants.EDMI_PAYMENT_SERVICE, "/banca-applications"),
					kv(TIME_TAKEN_IN_MILLIS, (System.currentTimeMillis() - startTime))
					);
        }
	}

    private SanlamPolicyResponseWrapper saveApplications(SanlamRequest validationReq, String applicationStage,BancaApplication bancaApplicationRequest)
    {
    	Long startTime = System.currentTimeMillis();
        try {
            SanlamPolicyResponseWrapper responseVal = sendApplicationToISP(validationReq, applicationStage);
            applicationDataHandler.getApplicationDataStore().setResponseWrapper(responseVal);
            exceptionHandler.errorHandler(responseVal, applicationStage);
            return responseVal;
        } catch (ResourceAccessException e) {
        	log.error("Sanlam policy service timeout, current stage :: {} :: reason :: {}", applicationStage, e.getMessage());
        	TechnicalException te = new TechnicalException(ApplicationErrorCode.OBS_APPLICATION_SUBMISSION_TIMEOUT, e.getMessage());
        	applicationDataHandler.getApplicationDataStore().setApplicationDataException(te);
        	applicationDataHandler.handleApplicationExceptionData(bancaApplicationRequest);
            throw te;
        } catch (Exception ex){
            log.error("Fail to process application to Sanlam, current stage :: {} :: reason :: {}", applicationStage, ex.getMessage());
            applicationDataHandler.getApplicationDataStore().setApplicationDataException(ex);
            applicationDataHandler.handleApplicationExceptionData(bancaApplicationRequest);
            throw ex;
        }finally{
        	log.info("Request time taken : {} {} ms",kv(Constants.SANLAM_SERVICE, "/banca-applications"),
					kv(TIME_TAKEN_IN_MILLIS, (System.currentTimeMillis() - startTime))
					);
        }
    }

    private SanlamPolicyResponseWrapper sendApplicationToISP(SanlamRequest validationReq, String applicationStage)
    {

        MultiValueMap<String ,String> headers = new HttpHeaders();
        headers.add(POLICY_STATE_HEADER,applicationStage);
        SanlamPolicyResponseWrapper responseVal = (SanlamPolicyResponseWrapper) sanlamAdapter.callSanlam(SERVICE_URL, HttpMethod.PATCH,
                    validationReq, SanlamPolicyResponseWrapper.class,MediaType.APPLICATION_JSON ,headers);
        return responseVal;

    }

    private boolean submitPaymentRequest(BancaApplication bancaApplicationRequest) {
        String country = bancaApplicationRequest.getCountry();
        String paymentType = bancaApplicationRequest.getPaymentDetail().getPaymentType();
        CasaPaymentDetail casaPaymentDetail = (CasaPaymentDetail) bancaApplicationRequest.getPaymentDetail();
        OrderMaster orderMaster = applicationDataHandler.getApplicationDataStore().getOrderMaster();
        casaPaymentDetail.setUniqueReferenceIdentifier(orderMaster != null ? orderMaster.getOrderId().toString() : DEFAULT_STATIC_IDENTIFIER);
        casaPaymentDetail.setProductType(bancaApplicationRequest.getBancaApplicationDetail().getProductCode().toUpperCase());
        PaymentProcessor paymentProcessor = createPaymentProcessor(bancaApplicationRequest, country, paymentType);
        
        paymentProcessor.preProcess();
        PaymentResponse paymentResponse = paymentProcessor.executePayment();
        if (paymentResponse.getStatus() == PaymentStatus.Success) {
            paymentProcessor.processSuccess();
            return true;
        } else {        	
            //paymentProcessor.processFailure();
        	StringBuffer edmiErroMsg = new StringBuffer("");
        	for(EdmiError edmiError:paymentResponse.getErrors().getExceptions()){
        		log.error("edmi-error : code = {}, edmi-code = {}",edmiError.getCode(),edmiError.getEdmiCode());
        		edmiErroMsg.append(edmiErroMsg.toString().equals("")?"":Constants.PIPE);
        		edmiErroMsg.append("code="+edmiError.getCode()+", edmi-code="+edmiError.getEdmiCode());
        	}            
            throw new ObsBusinessException(new ApplicationError(OBS_CASA_PAYMENT_FAILURE.getCode(),edmiErroMsg.toString(),edmiErroMsg.toString()));
        }
        
    }

    private MotorApplicationDetail preProcess(BancaApplication bancaApplicationRequest) {
        MotorApplicationDetail motorDetails = (MotorApplicationDetail)bancaApplicationRequest.getBancaApplicationDetail();
        String applicationStatus = getApplicationStatus(motorDetails);
        Map<String, String> defaultValues = config.getDefaultValues(COUNTRY, ISP);
        applicationDataHandler.getApplicationDataStore().setQuotationNo(bancaApplicationRequest.getQuotationNumber());
        applicationDataHandler.getApplicationDataStore().setApplicationId(bancaApplicationRequest.getApplicationId());
        if(applicationStatus.contains(VALIDATION))
        {
            motorDetails.setFromDate(defaultValues.get("fromDate"));
            motorDetails.setVehicleType(defaultValues.get("vehicleType"));
            motorDetails.setVehicleCylinderCode(defaultValues.get("vehicleCylinderCode"));
            motorDetails.setColourCode(defaultValues.get("colourCode"));
        }
        if(applicationStatus.contains(PERSONAL_DETAILS))
        {
            motorDetails.setDealReferrerName(defaultValues.get("dealReferrer"));
            motorDetails.setReferrerId(defaultValues.get("referrerPWId"));
            motorDetails.setAutoRenewal(defaultValues.get("autoRenewal"));
            motorDetails.setGender(getGender(motorDetails.getGender()));
            motorDetails.setIdentityType(defaultValues.get("identityType"));
        }
        else if (applicationStatus.contains(SUBMISSION_AND_PAYMENT))
        {
            CasaPaymentDetail paymentDetails = (CasaPaymentDetail)bancaApplicationRequest.getPaymentDetail();
            motorDetails.setPaymentType(paymentDetails.getPaymentType());
            motorDetails.setCreditedToAccount(ispAccountNumber);
            motorDetails.setAmount(new BigDecimal(paymentDetails.getTransactionAmount()));
            String paymentDate = LocalDate.now().format(formatter);
            motorDetails.setPaymentDate(paymentDate);
            motorDetails.setPaymentReferenceNo(bancaApplicationRequest.getQuotationNumber());
            paymentDetails.setCreditNarration(bancaApplicationRequest.getQuotationNumber());
        }
        return motorDetails;
    }

    private String getApplicationStatus(MotorApplicationDetail motorDetails) {
        String applicationStatus = motorDetails.getCurrentApplicationStage();
        Map<String, String> applicationState = config.getApplicationState(COUNTRY, ISP);
        if(applicationState.containsKey(applicationStatus))
        {
            applicationStatus = applicationState.get(applicationStatus);
        }
        return applicationStatus;
    }

    private String getGender(String gender)
    {
        if(StringUtils.isNotBlank(gender))
        {
            return Gender.valueOf(gender.toUpperCase()).getGender();
        }
        return null;
    }

    private PaymentProcessor createPaymentProcessor(BancaApplication bancaApplicationRequest, String country, String paymentType) {
        PaymentProcessorFactory paymentProcessorFactory = paymentHandlerFactoryRegistry.get(country, paymentType);
        return paymentProcessorFactory.createPaymentProcessor(bancaApplicationRequest);
    }

}