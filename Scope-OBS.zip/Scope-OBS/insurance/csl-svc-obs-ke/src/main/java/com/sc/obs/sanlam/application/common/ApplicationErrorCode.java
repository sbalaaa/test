package com.sc.obs.sanlam.application.common;

import com.sc.obs.code.ObsErrorCode;

import lombok.Getter;

/**
 * Class to cater the exceptions for Applications Model until database exception handling is implemented
 * @author akshaymhatre
 *
 */
public enum ApplicationErrorCode implements ObsErrorCode {

    //100 for application specific errors
    OBS_FAILURE("OBS-100",
            "Unknown Error",
            "Unknow Error has occurred, please refer logs for more details"),
    
    OBS_VALIDATION_FAILURE("OBS-101",
            "Validation Failure",
            "There was an error when connecting to ISP's Application API."),

    OBS_QUOTATION_EXPIRED("OBS-102",
            "Quotation expired",
            "Quotation expired"),
   
    OBS_INVALID_COUNTRY_FAILURE("OBS-103",
            "Invalid country",
            "Invalid country"),
    
    OBS_CASA_PAYMENT_FAILURE("OBS-104",
            "CASA Payment failure",
            "CASA Payment failure"),
    
    OBS_APPLICATION_SUBMISSION_FAILURE("OBS-105",
            "Application Submission failure",
            "Application Submission failure"),
    
    OBS_INVALID_REQUEST("OBS-106",
            "Invalid Request",
            "Request couldn't be process at this time"),
     
    OBS_QUOTATION_FALURE("OBS-107",
            "Quotation service fail",
            "Quotation service fail"),

    OBS_DATABASE_FAILURE("OBS-108",
            "Database application failure",
            "Unable to persist data or connect to database"),
    
    OBS_TIMEOUT("OBS-109",
            "OBS timeout",
            "OBS timeout"),
    
    OBS_PAYMENT_TIMEOUT("OBS-110",
            "Payment TIMEOUT",
            "Payment TIMEOUT"),
    
    OBS_APPLICATION_SUBMISSION_TIMEOUT("OBS-111",
            "OBS Application Submission timeout",
            "OBS Application Submission timeout"),
            
    OBS_QUOTATION_TIMEOUT("OBS-112",
                    "Quotation service timeout",
                    "Quotation service timeout"),
                    
    OBS_SANLAM_DATALOADER_SERVICE_TIMEOUT("OBS-113",
                    "Sanlam lov data loader service timeout",
                    "Sanlam lov data loader service timeout"),
    
    //200 for Coomunication Protocol and Connectivity level Errors
    OBS_INVALID_REQ_ID_FAILURE("OBS-201",
            "Invalid Request Id",
            "Invalid Request Id"),
    
    OBS_AUTHENTICATION_FAIL_FAILURE("OBS-202",
            "Authentication Failure",
            "Authentication Failure"),
    
    OBS_INTERNAL_SERVER_ERROR_FAILURE("OBS-203",
            "Internal Server Error",
            "Internal Server Error"),
    
    //300 for docupload validations
    OBS_DOC_UPLOAD_UN_SUPPORTED_FILE_FORMAT("OBS-301",
            "Unsupported File Format",
            "Unsupported File Format"),
            
    OBS_DOC_UPLOAD_FILE_IS_INVALID_OR_NULL("OBS-302",
                    "File is invalid or null",
                    "File is invalid or null"),
                    
    OBS_DOC_UPLOAD_INVALID_FILE_ID("OBS-303",
            "Invalid file-id",
            "Invalid file-id"),
    
    //400 for dataloader Error codes
    OBS_LOV_DATLOADER_FAILED("OBS-401",
            "Failed to load/process LOV masters from sanlam",
            "Failed to load/process LOV masters from sanlam"),

    //Field level errors
    OBS_PIN_MATCHED_FAILED("OBS-501",
             "PIN NOT MATCHED from sanlam",
             "PIN NOT MATCHED from sanlam");

    @Getter
    private final String code;

    @Getter
    private final String title;

    @Getter
    private final String description;

    ApplicationErrorCode(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

}
