package com.sc.obs.sanlam.application.common;

import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.exception.ObsBusinessException;
import com.sc.obs.sanlam.application.model.isp.HomePolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;

@Component
public class ApplicationExceptionHandler {

    private static final String SANLAM_ERROR_RESPONSE_CODE = "F";

    public void errorHandler(SanlamPolicyResponseWrapper sanlamResponse,String applicationStage) {
    	handleExceptions(sanlamResponse.getResponseType(),sanlamResponse.getErrorCode(),sanlamResponse.getErrorMsg(),applicationStage);
    }

    public void errorHandler(HomePolicyResponseWrapper sanlamResponse,String applicationStage) {
    	handleExceptions(sanlamResponse.getResponseType(),sanlamResponse.getErrorCode(),sanlamResponse.getErrorMsg(),applicationStage);
    }
    
    public void handleExceptions(String responseType, String errorCode, String errorDesc, String applicationStage) {
    	if (responseType.equalsIgnoreCase(SANLAM_ERROR_RESPONSE_CODE)) {
            if(applicationStage.equalsIgnoreCase(Constants.SUBMISSION_AND_PAYMENT))
            {
                throw new TechnicalException(ApplicationErrorCode.OBS_APPLICATION_SUBMISSION_FAILURE, errorDesc);
            } else if (errorCode.equalsIgnoreCase("INVALID_REQUEST")) {
                throw new TechnicalException(ApplicationErrorCode.OBS_INVALID_REQUEST, errorDesc);
            } else if (errorCode.equalsIgnoreCase("QUOTATION_EXPIRED")) {
                throw new TechnicalException(ApplicationErrorCode.OBS_QUOTATION_EXPIRED, errorDesc);
            } else if (errorCode.equalsIgnoreCase("PIN_NOT_MATCHED")) {
                throw new TechnicalException(ApplicationErrorCode.OBS_PIN_MATCHED_FAILED, errorDesc);
            } else {
                throw new ObsBusinessException(ApplicationErrorCode.OBS_FAILURE);
            }
        }
    }
}
