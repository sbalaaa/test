package com.sc.obs.sanlam.application.common;

public class Constants {
	
    private Constants() {
		super();
	}
	public static final String VALIDATION = "validation";
    public static final String PERSONAL_DETAILS = "update";
    public static final String SUBMISSION_AND_PAYMENT = "submission";
    public static final String NA = "NA";
    public static final String PAYMENT_DONE_ISSUANCE_PENDIND = "Payment Done, Issuance pending";
    public static final String PIPE = "|";
    public static final String SANLAM_SERVICE = "SanlamService";
    public static final String EDMI_PAYMENT_SERVICE = "EdmiPaymentService";
}
