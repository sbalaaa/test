package com.sc.obs.sanlam.application.common;

public enum Gender {
    M("01"), F("02");
    private String gender;
    
    Gender(String gender)
    {
        this.gender = gender;
    }
    
    public String getGender()
    {
        return gender;
    }
    
}
