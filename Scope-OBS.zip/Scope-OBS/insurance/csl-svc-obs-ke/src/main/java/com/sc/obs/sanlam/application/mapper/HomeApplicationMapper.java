package com.sc.obs.sanlam.application.mapper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.obs.application.BancaApplication;

import static com.sc.obs.sanlam.application.common.Constants.*;

import com.sc.obs.sanlam.application.model.HomeApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.HomePolicy;
import com.sc.obs.sanlam.application.model.isp.HomePolicyResponseWrapper;

import lombok.Setter;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

@Component
@Setter
public class HomeApplicationMapper {

    @Autowired
    private HomeApplicationCustomerDetailsReqMapper custDetailsReqMapper;
    
    @Autowired
    private HomeApplicationCustomerDetailsResMapper custDetailsResMapper;
    
    @Autowired
    private HomeApplicationSubmissionReqMapper submissionReqMapper;
    
    @Autowired
    private HomeApplicationSubmissionResMapper submissionResMapper;
    

    public HomePolicy map(BancaApplication bancaApplication, List<String> subTypes)
    {
        HomePolicy policy = new HomePolicy();
        if(subTypes.contains(PERSONAL_DETAILS))
        {
        	custDetailsReqMapper.map(bancaApplication, policy);
            custDetailsReqMapper.map(bancaApplication.getBancaApplicationDetail(), policy);
        }
        if(subTypes.contains(SUBMISSION_AND_PAYMENT))
        {
            submissionReqMapper.map(bancaApplication, policy);
            submissionReqMapper.map(bancaApplication.getBancaApplicationDetail(), policy);
        }
        return policy;
    }
    
    public BancaApplication map(BancaApplication bancaApplication, HomePolicyResponseWrapper sanlamValidationRes, List<String> subTypes)
    {
        if(subTypes.contains(PERSONAL_DETAILS))
        {
            custDetailsResMapper.map(sanlamValidationRes, bancaApplication.getBancaApplicationDetail());
            custDetailsResMapper.map(sanlamValidationRes, bancaApplication);
        }
        if(subTypes.contains(SUBMISSION_AND_PAYMENT))
        {
            submissionResMapper.map(sanlamValidationRes, bancaApplication);
            submissionResMapper.map(sanlamValidationRes, bancaApplication.getBancaApplicationDetail());
        }
        return bancaApplication;
    } 
    
    @Component
    public static class HomeApplicationCustomerDetailsReqMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {

        	 factory.classMap(HomePolicy.class, BancaApplication.class)
             .field("country", "country")
             .field("quotationNumber", "quotationNumber")
             .register();
             
             factory.classMap(HomePolicy.class, HomeApplicationDetail.class)
             .mapNulls(false)
             .field("dealReferrer", "dealReferrerName")
             .field("referrerPWId", "referrerId")
             .field("nextInstallmentDate", "nextInstallmentDate")
             .field("autoRenewal", "autoRenewal")
             .field("paymentMethod", "paymentMethod")
             .field("personalDetails.identificationNumber", "identificationNumber")
             .field("personalDetails.identityType", "identityType")
             .field("personalDetails.phoneNumber", "phoneNumber")
             .field("personalDetails.emailId", "emailId")
             .field("personalDetails.firstName", "firstName")
             .field("personalDetails.middleName", "middleName")
             .field("personalDetails.lastName", "lastName")
             .field("personalDetails.gender", "gender")
             .field("personalDetails.businessSector", "businessSector")
             .field("personalDetails.jobtitle", "jobTitle")
             .field("personalDetails.title", "title")
             .field("personalDetails.address.address1", "mailingAddress[0].addressLine1")
             .field("personalDetails.address.address2", "mailingAddress[0].addressLine2")
             .field("personalDetails.address.state", "mailingAddress[0].state")
             .field("personalDetails.address.postalCode", "mailingAddress[0].postalCode")
             .field("risk[0]", "risks[0]")
             .register();

        }
    }
    
    @Component
    public static class HomeApplicationCustomerDetailsResMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(HomeApplicationDetail.class,HomePolicyResponseWrapper.class)
            .mapNulls(false)
            .field("responseStatus", "responseType")
            .field("responseStatusDescription", "responseValue.policy.message")
            .register();
            
            factory.classMap(BancaApplication.class,HomePolicyResponseWrapper.class)
            .mapNulls(false)
            .field("policyNumber", "responseValue.policy.policyNumber")
            .register();
    }
    }
    
    @Component
    public static class HomeApplicationSubmissionReqMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(HomePolicy.class, BancaApplication.class)
            .field("country", "country")
            .field("quotationNumber", "quotationNumber")
            .register();
            
            factory.classMap(HomePolicy.class, HomeApplicationDetail.class)
            .mapNulls(false)
            .field("nextInstallmentDate", "nextInstallmentDate")
            .field("payment[0].paymentType", "paymentType")
            .field("payment[0].paymentDate", "paymentDate")
            .field("payment[0].paymentReferenceNo", "paymentReferenceNo")
            .field("payment[0].accountNo", "creditedToAccount")
            .field("payment[0].paidAmount", "amount")
            .register();

        }
    }
    
    @Component
    public static class HomeApplicationSubmissionResMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(BancaApplication.class,HomePolicyResponseWrapper.class)
            .mapNulls(false)
            .field("policyNumber", "responseValue.policy.policyNumber")
            .register();
            
            factory.classMap(HomeApplicationDetail.class,HomePolicyResponseWrapper.class)
            .mapNulls(false)
            .field("responseStatus", "responseType")
            .field("policyDetails.policyNumber", "responseValue.policy.policyNumber")
            .field("policyDetails.status", "responseValue.policy.status")
            .field("policyDetails.premium", "responseValue.policy.premium")
            .field("policyDetails.parentPolicyNumber", "responseValue.policy.policyNumber")
            .field("policyDetails.policyCovers", "responseValue.policy.cover").byDefault()
            .register();
        }
    }
}
