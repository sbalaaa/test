package com.sc.obs.sanlam.application.mapper;

public enum MapperSubSection {
       VALIDATION,
       PERSONAL_DETAILS, 
       SUBMISSION 
}
