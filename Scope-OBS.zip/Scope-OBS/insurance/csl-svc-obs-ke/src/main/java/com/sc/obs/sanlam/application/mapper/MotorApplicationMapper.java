package com.sc.obs.sanlam.application.mapper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.obs.application.BancaApplication;
import static com.sc.obs.sanlam.application.common.Constants.*;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicy;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;

import lombok.Setter;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.ConfigurableMapper;

@Component
@Setter
public class MotorApplicationMapper {

    @Autowired
    private MotorApplicationValidationReqMapper validationReqMapper;
    
    @Autowired
    private MotorApplicationValidationResMapper validationResMapper;
    
    @Autowired
    private MotorApplicationCustomerDetailsReqMapper custDetailsReqMapper;
    
    @Autowired
    private MotorApplicationCustomerDetailsResMapper custDetailsResMapper;
    
    @Autowired
    private MotorApplicationSubmissionReqMapper submissionReqMapper;
    
    @Autowired
    private MotorApplicationSubmissionResMapper submissionResMapper;
    

    public BancaApplication map(BancaApplication bancaApplication, SanlamPolicyResponseWrapper sanlamValidationRes, List<String> subTypes)
    {
        if(subTypes.contains(VALIDATION))
        {
            validationResMapper.map(sanlamValidationRes, bancaApplication.getBancaApplicationDetail());
        }
        if(subTypes.contains(PERSONAL_DETAILS))
        {
            custDetailsResMapper.map(sanlamValidationRes, bancaApplication.getBancaApplicationDetail());
        }
        if(subTypes.contains(SUBMISSION_AND_PAYMENT))
        {
            submissionResMapper.map(sanlamValidationRes, bancaApplication);
            submissionResMapper.map(sanlamValidationRes, bancaApplication.getBancaApplicationDetail());
        }
        return bancaApplication;
    }
    public SanlamPolicy map(BancaApplication bancaApplication, List<String> subTypes)
    {
        SanlamPolicy policy = new SanlamPolicy();
        if(subTypes.contains(VALIDATION))
        {
            validationReqMapper.map(bancaApplication, policy);
            validationReqMapper.map(bancaApplication.getBancaApplicationDetail(), policy);
        }
        if(subTypes.contains(PERSONAL_DETAILS))
        {
            custDetailsReqMapper.map(bancaApplication, policy);
            custDetailsReqMapper.map(bancaApplication.getBancaApplicationDetail(), policy);
        }
        if(subTypes.contains(SUBMISSION_AND_PAYMENT))
        {
            submissionReqMapper.map(bancaApplication, policy);
            submissionReqMapper.map(bancaApplication.getBancaApplicationDetail(), policy);
        }
        return policy;
    }
    
    @Component
    public static class MotorApplicationValidationReqMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(SanlamPolicy.class, BancaApplication.class)
            .field("country", "country")
            .field("quotationNumber", "quotationNumber")
            .register();
            
            factory.classMap(SanlamPolicy.class, MotorApplicationDetail.class)
            .mapNulls(false)
            .field("engineNumber", "engineNumber")
            .field("chassisNumber","chassisNumber")
            .field("registrationNumber", "registrationNumber")                
            .field("model", "vehicleModel")
            .field("usageType", "vehicleUsageType")
            .field("bodyType", "vehicleType")
            .field("cylinder", "vehicleCylinderCode")
            .field("colour", "colourCode")
            .field("fromDate", "fromDate")
            .register();
        }
    }
    
    @Component
    public static class MotorApplicationValidationResMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {            
            factory.classMap(MotorApplicationDetail.class,SanlamPolicyResponseWrapper.class)
            .mapNulls(false)
            .field("responseStatus", "responseType")
            .field("validationFlag", "responseValue.policy.validationFlag")
            .field("validation","responseValue.policy.validation").byDefault()
            .field("premiumDetails", "responseValue.policy.premiumSplitup").byDefault()                
            .register();
        }
    }
    
    @Component
    public static class MotorApplicationCustomerDetailsReqMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(SanlamPolicy.class, BancaApplication.class)
            .field("country", "country")
            .field("quotationNumber", "quotationNumber")
            .register();
            
            factory.classMap(SanlamPolicy.class, MotorApplicationDetail.class)
            .mapNulls(false)
            .field("dealReferrer", "dealReferrerName")
            .field("referrerPWId", "referrerId")
            .field("autoRenewal", "autoRenewal")
            .field("paymentMethod", "paymentMethod")
            .field("personalDetails.identificationNumber", "identificationNumber")
            .field("personalDetails.identityType", "identityType")
            .field("personalDetails.phoneNumber", "phoneNumber")
            .field("personalDetails.emailId", "emailId")
            .field("personalDetails.firstName", "firstName")
            .field("personalDetails.middleName", "middleName")
            .field("personalDetails.lastName", "lastName")
            .field("personalDetails.gender", "gender")
            .field("personalDetails.businessSector", "businessSector")
            .field("personalDetails.jobtitle", "jobTitle")
            .field("personalDetails.title", "title")
            .field("personalDetails.address.address1", "mailingAddress[0].addressLine1")
            .field("personalDetails.address.address2", "mailingAddress[0].addressLine2")
            .field("personalDetails.address.state", "mailingAddress[0].state")
            .field("personalDetails.address.postalCode", "mailingAddress[0].postalCode")
            .register();
        }
    }
    
    @Component
    public static class MotorApplicationCustomerDetailsResMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(MotorApplicationDetail.class,SanlamPolicyResponseWrapper.class)
            .mapNulls(false)
            .field("responseStatus", "responseType")
            .field("responseStatusDescription", "responseValue.policy.message")
            .register();
    }
    }
    
    @Component
    public static class MotorApplicationSubmissionReqMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(SanlamPolicy.class, BancaApplication.class)
            .field("country", "country")
            .field("quotationNumber", "quotationNumber")
            .register();
            
            factory.classMap(SanlamPolicy.class, MotorApplicationDetail.class)
            .mapNulls(false)
            .field("nextInstallmentDate", "nextInstallmentDate")
            .field("payment[0].paymentType", "paymentType")
            .field("payment[0].paymentDate", "paymentDate")
            .field("payment[0].paymentReferenceNo", "paymentReferenceNo")
            .field("payment[0].accountNo", "creditedToAccount")
            .field("payment[0].paidAmount", "amount")
            .register();

        }
    }
    
    @Component
    public static class MotorApplicationSubmissionResMapper extends ConfigurableMapper{
        protected void configure(MapperFactory factory) {
            factory.classMap(BancaApplication.class,SanlamPolicyResponseWrapper.class)
            .mapNulls(false)
            .field("policyNumber", "responseValue.policy.policyNumber")
            .register();
            
            factory.classMap(MotorApplicationDetail.class,SanlamPolicyResponseWrapper.class)
            .mapNulls(false)
            .field("responseStatus", "responseType")
            .field("policyDetails.policyNumber", "responseValue.policy.policyNumber")
            .field("policyDetails.status", "responseValue.policy.status")
            .field("policyDetails.premium", "responseValue.policy.premium")
            .field("policyDetails.parentPolicyNumber", "responseValue.policy.policyNumber")
            .field("policyDetails.policyCovers", "responseValue.policy.cover").byDefault()
            .register();
        }
    }
}
