/**
 * 
 */
package com.sc.obs.sanlam.application.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author 1567880
 *
 */
@Getter
@Setter
public class ConsentAuditDetails {
	
	private String location;
    
    @JsonProperty("device-id")
    private String deviceId;

    @JsonProperty("channel-name")
    private String channelName;
    
    @JsonProperty("customer-name")
    private String customerName;
    
    @JsonProperty("consent-ids")
    private List<Long> consentIds;
    
    private String segment;

}
