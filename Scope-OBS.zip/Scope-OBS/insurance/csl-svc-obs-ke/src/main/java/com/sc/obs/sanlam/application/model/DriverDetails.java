package com.sc.obs.sanlam.application.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class DriverDetails {
    @JsonProperty("driver-name")
    private	String	driverName;
    @JsonProperty("license-number")
    private	String	licenseNumber;
    private	String	nationality;
    @JsonProperty("dob")
    private LocalDate dateOfBirth;
    private	String	gender;
}
