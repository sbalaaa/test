package com.sc.obs.sanlam.application.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;


@Getter
@Setter
@JsonTypeName("HOME")
public class HomeApplicationDetail extends com.sc.obs.application.BancaApplicationDetail {

    
    @JsonProperty("application-stage")
    private String currentApplicationStage;
    
    @JsonIgnore
    private String nextApplicationStage;
    
    @JsonIgnore
    public String dealReferrerName;
    
    @JsonIgnore
    public String referrerId;
    
    @JsonProperty("title") 
    public String title;
    
    
    @JsonProperty("next-installment-date") 
    public String nextInstallmentDate;
    
    @JsonIgnore
    public String autoRenewal;
       
    @JsonProperty("identification-number")
    public String identificationNumber;
    
    @JsonIgnore
    public String identityType;
    
    @JsonProperty("business-sector")
    private String businessSector;
    
    @JsonProperty("job-title")
    private String jobTitle;
    
    @JsonProperty("risks")
    public List<HomePolicyRisk> risks;

    @JsonProperty("payment-type")
    public String paymentType;
    
    /**
     * Extra field for update Response Starts here
     */ 
    @JsonProperty("response-status")
    public String responseStatus;
    
    @JsonProperty("response-status-description")
    public String responseStatusDescription;    
    /**
     * update Response Ends here
     */
    

    /**
     * Submission Request Starts here
     */
    @JsonProperty("payment-date")
    public String paymentDate;
    
    @JsonProperty("payment-reference-number")
    public String paymentReferenceNo;
    
    @JsonProperty("credited-account")
    public String creditedToAccount;
    
    @JsonProperty("credited-amount")
    public BigDecimal amount;
        
    @JsonIgnore
    public String paymentMethod;
    /**
     * Submission Request Ends here
     */ 
 
    /**
     * Submission Response Starts here
     */ 
    @JsonProperty("policy-details")
    private PolicyDetails policyDetails;   
    /**
     * Submission Response Ends here
     */ 
     
    @JsonIgnore
    public String fromDate;
   /* @JsonIgnore
    public String endDate;  */ 
    @JsonProperty("consent-audit-details")
    private ConsentAuditDetails consentAuditDetails;
    
    @JsonProperty("premium-Details")
    public List<PremiumDetails> premiumDetails;
    
}
