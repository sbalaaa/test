package com.sc.obs.sanlam.application.model;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
public class HomePolicyRisk {
	@JsonProperty("riskClass")
	private String riskClass;
	@JsonProperty("riskLocation")
	private String riskLocation;
	@JsonProperty("city")
	private String city;
	@JsonProperty("descriptionOfBuilding")
	private String descriptionOfBuilding;
	@JsonProperty("locOfBuilding")
	private String locOfBuilding;
}
