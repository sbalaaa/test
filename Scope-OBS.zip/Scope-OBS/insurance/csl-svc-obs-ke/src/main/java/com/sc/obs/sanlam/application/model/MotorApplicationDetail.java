package com.sc.obs.sanlam.application.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeName;

/**
 * Author Akshay (1519510) This resource will cater the Motor Insurance
 * Application submission Supported Country :: Kenya
 */

@Getter
@Setter
@JsonTypeName("MOTOR")
public class MotorApplicationDetail extends com.sc.obs.application.BancaApplicationDetail {

    /**
     * Validation Request Starts here
     */
    
    @JsonProperty("application-stage")
    private String currentApplicationStage;
    
    @JsonIgnore
    private String nextApplicationStage;
    
    @JsonProperty("vehicle-model")
    private String vehicleModel;
    
    @JsonProperty("vehicle-usage-type")
    private String vehicleUsageType;
    
    @JsonIgnore
    private String vehicleType;
    
    @JsonProperty("registration-number")
    private String registrationNumber;
    
    @JsonProperty("engine-number")
    private String engineNumber;
    
    @JsonProperty("chassis-number")
    private String chassisNumber;

//    @JsonProperty("type-of-cover")
//    private String typeOfCover;
    
    @JsonIgnore
    private String vehicleCylinderCode;
    
    @JsonIgnore
    private String colourCode;
    
    /**
     * Validation Request Ends here
     */
    
    /**
     * Validation Response Starts here
     */
    @JsonProperty("response-status")
    public String responseStatus;
    
    @JsonProperty("validation-flag")
    public String validationFlag;
    
    @JsonProperty("validations")
    public List<Validation> validation;
    
    @JsonProperty("premium-Details")
    public List<PremiumDetails> premiumDetails;
    
    /**
     * Validation Response Ends here
     */
    
    /**
     * Extra field for update Request Starts here
     */
    @JsonIgnore
    public String dealReferrerName;
    
    @JsonIgnore
    public String referrerId;
    
    @JsonProperty("title") 
    public String title;
    
    @JsonIgnore
    public String fromDate;
    
    @JsonProperty("next-installment-date") 
    public String nextInstallmentDate;
    
    @JsonIgnore
    public String autoRenewal;
    
    @JsonIgnore
    public String paymentMethod;
    
    @JsonProperty("identification-number")
    public String identificationNumber;
    
    @JsonIgnore
    public String identityType;
    
    @JsonProperty("business-sector")
    private String businessSector;
    
    @JsonProperty("job-title")
    private String jobTitle;
    
    /**
     * Extra field for update Request Ends here
     */   
    
    /**
     * Extra field for update Response Starts here
     */  
    @JsonProperty("response-status-description")
    public String responseStatusDescription;
    /**
     * Extra field for update Response Ends here
     */  
    
    /**
     * Extra field for Submission Request Starts here
     */  
    @JsonProperty("payment-type")
    public String paymentType;
    
    @JsonProperty("payment-date")
    public String paymentDate;
    
    @JsonProperty("payment-reference-number")
    public String paymentReferenceNo;
    
    @JsonProperty("credited-account")
    public String creditedToAccount;
    
    @JsonProperty("credited-amount")
    public BigDecimal amount;
    
    @JsonProperty("consent-audit-details")
    private ConsentAuditDetails consentAuditDetails;
    
    
    /**
     * Extra field for Submission Request Ends here
     */ 
    
    /**
     * Extra field for Submission Response Starts here
     */ 
    
    @JsonProperty("policy-details")
    private PolicyDetails policyDetails;
    
    /**
     * Extra field for Submission Response Ends here
     */ 
}
