package com.sc.obs.sanlam.application.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PolicyCover {
    @JsonProperty("cover-code")
    private     String  coverCode;
    @JsonProperty("cover-name")
    private     String  coverName;
    @JsonProperty("cover-premium")
    private     String  coverPremium;
    @JsonProperty("cover-premium-currency")
    private     String  coverPremiumCurr;
}
