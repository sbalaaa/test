package com.sc.obs.sanlam.application.model;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PolicyDetails {

    @JsonProperty("policy-number")
    private     String  policyNumber;
    @JsonProperty("status")
    private     String  status;
    @JsonProperty("premium")
    private     BigDecimal  premium;
    @JsonProperty("premium-currency")
    private     String  premiumCurr;
    @JsonProperty("parent-policy-number")
    private     String  parentPolicyNumber;
    @JsonProperty("policy-covers")
    private     List<PolicyCover>  policyCovers;
}
