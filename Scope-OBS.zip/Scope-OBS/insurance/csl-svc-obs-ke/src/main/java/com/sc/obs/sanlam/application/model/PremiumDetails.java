package com.sc.obs.sanlam.application.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PremiumDetails {
    @JsonProperty("premium-description")
    public String description;
    @JsonProperty("premium-value")
    public String value;
}
