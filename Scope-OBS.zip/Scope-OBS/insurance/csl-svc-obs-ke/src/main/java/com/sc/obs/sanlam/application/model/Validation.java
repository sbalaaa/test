package com.sc.obs.sanlam.application.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Validation {

@JsonProperty("validation-name")
public String validationName;
@JsonProperty("field-name")
public String fieldName;
@JsonProperty("status")
public String status;
@JsonProperty("failed-reason")
public String failedReason;

}
