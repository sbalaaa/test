package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Driver {

@JsonProperty("driverName")
private String driverName;
@JsonProperty("driverNationality")
private String driverNationality;
@JsonProperty("driverLicenseNo")
private String driverLicenseNo;
@JsonProperty("driverGender")
private String driverGender;
@JsonProperty("driverDOB")
private String driverDOB;

}
