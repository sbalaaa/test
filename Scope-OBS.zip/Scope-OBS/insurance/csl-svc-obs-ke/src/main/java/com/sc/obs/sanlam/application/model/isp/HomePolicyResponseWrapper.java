package com.sc.obs.sanlam.application.model.isp;

import com.sc.obs.sanlam.SanlamResponse;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

@Getter
@Setter
public class HomePolicyResponseWrapper extends SanlamResponse{

    private String responseType;
    private HomePolicyWrapper responseValue;

    public String getErrorMsg(){
        return Optional.ofNullable(this.responseValue)
                .map(HomePolicyWrapper::getErrorMessage)
                .orElse(StringUtils.EMPTY);
    }

    public String getErrorCode(){
        return Optional.ofNullable(this.responseValue)
                .map(HomePolicyWrapper::getErrorCode)
                .orElse(StringUtils.EMPTY);
    }
}
