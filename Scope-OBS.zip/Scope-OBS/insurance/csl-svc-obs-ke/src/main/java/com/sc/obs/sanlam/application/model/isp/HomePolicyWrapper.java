package com.sc.obs.sanlam.application.model.isp;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HomePolicyWrapper extends SanlamRequest{

    private HomePolicyWrapper()
    {
        
    }

    public HomePolicyWrapper(HomePolicy policy) {
        super();
        this.policy = policy;
    }

    private HomePolicy policy; 
    private String errorMessage;
    private String errorCode;
    private String exceptionType;
    
    @Override
    public String toString() {
        return CSLJsonUtils.toJson(this);
    }
}
