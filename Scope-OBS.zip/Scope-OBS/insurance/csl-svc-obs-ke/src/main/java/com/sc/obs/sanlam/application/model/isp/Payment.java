package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Payment {

@JsonProperty("paymentType")
public String paymentType;
@JsonProperty("paymentDate")
public String paymentDate;
@JsonProperty("paymentReferenceNo")
public String paymentReferenceNo;
@JsonProperty("accountNo")
public String accountNo;
@JsonProperty("paidAmount")
public String paidAmount;

}
