package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SanlamAddress {

@JsonProperty("address1")
public String address1;
@JsonProperty("address2")
public String address2;
@JsonProperty("state")
public String state;
@JsonProperty("postalCode")
public String postalCode;

}
