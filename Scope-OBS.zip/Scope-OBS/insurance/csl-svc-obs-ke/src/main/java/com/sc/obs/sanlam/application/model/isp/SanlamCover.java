package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SanlamCover {

    @JsonProperty("coverCode")
    private String coverCode;
    
    @JsonProperty("coverPremium")
    private String coverPremium;
    
    @JsonProperty("coverName")
    private String coverName;
}
