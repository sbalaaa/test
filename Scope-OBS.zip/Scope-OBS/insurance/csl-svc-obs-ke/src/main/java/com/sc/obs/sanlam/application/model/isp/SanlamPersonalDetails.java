package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SanlamPersonalDetails {

@JsonProperty("identificationNumber")
public String identificationNumber;
@JsonProperty("identityType")
public String identityType;
@JsonProperty("phoneNumber")
public String phoneNumber;
@JsonProperty("emailId")
public String emailId;
@JsonProperty("firstName")
public String firstName;
@JsonProperty("middleName")
public String middleName;
@JsonProperty("lastName")
public String lastName;
@JsonProperty("businessSector")
public String businessSector;
@JsonProperty("gender")
public String gender;
@JsonProperty("jobtitle")
public String jobtitle;
@JsonProperty("title")
public String title;
@JsonProperty("address")
public SanlamAddress address;

}
