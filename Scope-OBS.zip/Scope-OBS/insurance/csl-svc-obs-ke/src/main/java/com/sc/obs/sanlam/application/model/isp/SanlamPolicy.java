package com.sc.obs.sanlam.application.model.isp;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.obs.sanlam.SanlamRequest;

import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class SanlamPolicy extends SanlamRequest{
    
/**
 *  validation request params starts here
 */
@JsonProperty("country")
private String country;
@JsonProperty("quotationNumber")
private String quotationNumber;
@JsonProperty("engineNumber")
private String engineNumber;
@JsonProperty("chassisNumber")
private String chassisNumber;
@JsonProperty("registrationNumber")
private String registrationNumber;
@JsonProperty("model")
private String model;
@JsonProperty("usageType")
private String usageType;
@JsonProperty("bodyType")
private String bodyType;
@JsonProperty("cylinder")
private String cylinder;
@JsonProperty("colour")
private String colour;
@JsonProperty("fromDate")
private String fromDate;
/**
 *  validation request params ends here
 */

/**
 *  validation response  params starts here
 */

@JsonProperty("validationFlag")
private String validationFlag;
@JsonProperty("validation")
private List<SanlamValidationResponse> validation = null;
@JsonProperty("premiumSplitup")
private List<com.sc.obs.sanlam.quote.PremiumSplitup> premiumSplitup = null;

/**
 *  validation response params ends here
 */

/** 
 * update request params starts here
 */
@JsonProperty("dealReferrer")
private String dealReferrer;
@JsonProperty("referrerPWId")
private String referrerPWId;
@JsonProperty("nextInstallmentDate")
private String nextInstallmentDate;
@JsonProperty("autoRenewal")
private String autoRenewal;
@JsonProperty("paymentMethod")
private String paymentMethod;
@JsonProperty("personalDetails")
private SanlamPersonalDetails personalDetails;

/**
 *  update request params ends here
 */

/**
 *  update response params starts here
 */

@JsonProperty("message")
private String message;

/**
 *  update response params ends here
 */

/**
 *  submission request params starts here
 */

@JsonProperty("payment")
private List<Payment> payment;

/**
 *  submission request params ends here
 */

/**
 *  submission response params starts here
 */
@JsonProperty("policyNumber")
private String policyNumber;
@JsonProperty("status")
private String status;
@JsonProperty("premium")
private BigDecimal premium;
@JsonProperty("cover")
private List<SanlamCover> cover;
/**
 *  submission response params ends here
 */
}



