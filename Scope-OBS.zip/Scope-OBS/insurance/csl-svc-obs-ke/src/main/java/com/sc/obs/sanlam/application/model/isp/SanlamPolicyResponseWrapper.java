package com.sc.obs.sanlam.application.model.isp;

import com.sc.obs.sanlam.SanlamResponse;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import java.util.Optional;

@Getter
@Setter
public class SanlamPolicyResponseWrapper extends SanlamResponse{

    private String responseType;
    private SanlamPolicyWrapper responseValue;

    public String getErrorMsg(){
        return Optional.ofNullable(this.responseValue)
                .map(SanlamPolicyWrapper::getErrorMessage)
                .orElse(StringUtils.EMPTY);
    }

    public String getErrorCode(){
        return Optional.ofNullable(this.responseValue)
                .map(SanlamPolicyWrapper::getErrorCode)
                .orElse(StringUtils.EMPTY);
    }
}
