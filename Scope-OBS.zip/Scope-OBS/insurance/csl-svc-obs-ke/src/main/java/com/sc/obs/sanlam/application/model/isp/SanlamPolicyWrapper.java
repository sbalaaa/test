package com.sc.obs.sanlam.application.model.isp;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SanlamPolicyWrapper extends SanlamRequest{

    private SanlamPolicyWrapper()
    {
        
    }
    public SanlamPolicyWrapper(SanlamPolicy policy) {
        super();
        this.policy = policy;
    }

    private SanlamPolicy policy;
    
    private String errorMessage;
    private String errorCode;
    private String exceptionType;
    
    @Override
    public String toString() {
        return CSLJsonUtils.toJson(this);
    }
}
