package com.sc.obs.sanlam.application.model.isp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SanlamValidationResponse {


        @JsonProperty("validationName")
        private String validationName;
        @JsonProperty("fieldName")
        private String fieldName;
        @JsonProperty("Status")
        private String status;
        @JsonProperty("failedReason")
        private String failedReason;

}
