package com.sc.obs.sanlam.motorlov.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.sc.obs.data.entity.Staging;


public interface StagingRepository extends CrudRepository<Staging, Long> {

    @Procedure(name="dataSync_Between_Staging_To_OBS_tables")
    void callStoredProcedureForSynDataToOBSTable(@Param("screen_code") String screenCode, @Param("product_code") String productCode, @Param("channel_code") String channelCode, @Param("field_desc") String fieldDesc);


    @Modifying
    @Transactional
    void deleteByCountry(String country);
}
