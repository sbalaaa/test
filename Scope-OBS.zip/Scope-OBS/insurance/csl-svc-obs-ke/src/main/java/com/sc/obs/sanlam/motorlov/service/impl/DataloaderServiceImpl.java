/**
 * 
 */
package com.sc.obs.sanlam.motorlov.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.cache.api.CSLCacheService;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.code.Country;
import com.sc.obs.config.ObsKEConstants;
import com.sc.obs.data.entity.Staging;
import com.sc.obs.dataloader.DataLoaderErrorCode;
import com.sc.obs.dataloader.DataLoaderService;
import com.sc.obs.dataloader.DataLoaderServiceRegistry;
import com.sc.obs.product.ProductType;
import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.motorlov.repository.StagingRepository;
import com.sc.obs.sanlam.motorlov.vo.SanlamLovMasterDataSetVO;
import com.sc.obs.sanlam.motorlov.vo.SanlamLovMasterVO;
import com.sc.obs.sanlam.motorlov.vo.SanlamLovResponseVO;
import com.sc.obs.sanlam.motorlov.vo.SanlamLovResponseValueVO;

/**
 * @author 1567880
 *
 */
@Service
public class DataloaderServiceImpl implements DataLoaderService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DataloaderServiceImpl.class);
	
	@Value("${sanlam.motor-lov-url}")
	private String motorLovUrl;
	
	@Autowired
	private StagingRepository stagingRepository;

	@Autowired
	private CSLCacheService cacheService;
	
	@Value("${sanlam.lovDataFilePath}")
	private String lovDataFilePath;

	@Autowired
	public void setRegistry(DataLoaderServiceRegistry registry) {
		registry.register(Country.KE, ProductType.MOTOR.name(), this);
	}
	@Autowired
	@Qualifier("sanlamAdapter")
	private SanlamAdapter sanlamAdapter;
	
	/* (non-Javadoc)
	 * @see com.sc.obs.dataloader.service.DataloaderService#loadSanlamLovMasters()
	 */
	@Override
	public boolean loadLovMasters(String country,String loadFromSanlam) throws Exception {
		LOGGER.info("country {} , loadFromSanlam : {}",country,loadFromSanlam);
		if(country !=null && country.equalsIgnoreCase(Country.KE)) {
			processSanLamMotorLovResponse(country,loadFromSanlam);
			stagingRepository.callStoredProcedureForSynDataToOBSTable(ObsKEConstants.SCREEN_CODE_GET_QUOTE, ObsKEConstants.PRODUCT_TYPE_MOTOR, ObsKEConstants.CHANNEL_CODE_MOBILE, ObsKEConstants.FIELD_DESC);
			cacheService.clearAll("config-cache");
		}else{

			throw new BusinessException(DataLoaderErrorCode.INVALID_COUNTRY_CODE);
		}
		return true;
	}
	private void  processSanLamMotorLovResponse(String country,String loadFromSanlam){
		List<SanlamLovResponseValueVO> sanlamLovResponseValueVOList = getReponseFromSanLamAPIforLOV(country,loadFromSanlam);
		if(sanlamLovResponseValueVOList !=null && sanlamLovResponseValueVOList.size()>0) {
			for (SanlamLovResponseValueVO sanlamLovResponseValueVO : sanlamLovResponseValueVOList) {
				LOGGER.info("processing the country  : {}, loadFromSanlam: {}", sanlamLovResponseValueVO.getCountry(),loadFromSanlam);
				parseJsonAndInsertIntoStagingTable(sanlamLovResponseValueVO.getMaster(), sanlamLovResponseValueVO.getCountry());
			}
		}
	}
	private List<SanlamLovResponseValueVO> getReponseFromSanLamAPIforLOV(String country,String loadFromSanlam) {
		try {
			SanlamLovResponseVO sanlamLovResponseVO = null;
			LOGGER.info("loadLovDataFromSanlam = {} , load LOV's from : {}",loadFromSanlam,
					loadFromSanlam.equalsIgnoreCase(ObsKEConstants.TRUE)?"Sanlam Service":"JSON File");
			if(loadFromSanlam.equalsIgnoreCase(ObsKEConstants.TRUE)){
				LOGGER.info("LOV data source location : sanlam service");
				sanlamLovResponseVO = (SanlamLovResponseVO)sanlamAdapter.callSanlam(motorLovUrl, HttpMethod.GET, null, SanlamLovResponseVO.class,null,null, null);
			}else{
				LOGGER.info("LOV data source location : JSON file");
				ObjectMapper objectMapper = new ObjectMapper();
				FileInputStream fileInputStream = new FileInputStream(new File(lovDataFilePath));
				sanlamLovResponseVO = objectMapper.readValue(fileInputStream, SanlamLovResponseVO.class);
			}
			LOGGER.info("response {}",sanlamLovResponseVO);
			if (sanlamLovResponseVO !=null) {
				LOGGER.info("response Type {}",sanlamLovResponseVO.getResponseType());
				if (sanlamLovResponseVO.getResponseType().equalsIgnoreCase(ObsKEConstants.SANLAM_RESPONSE_TYPE_SUCCESS)) {
					stagingRepository.deleteByCountry(country);
					return sanlamLovResponseVO.getResponseValue();
				} else {
					LOGGER.info("failure response from sanLam  reason {}", sanlamLovResponseVO.getErrorMessage());
					LOGGER.info("sanlam motor lov response : {}", sanlamLovResponseVO.getResponseType());
					throw new BusinessException(ApplicationErrorCode.OBS_LOV_DATLOADER_FAILED);
				}
			}
		} catch (ResourceAccessException e) {
            throw new TechnicalException(ApplicationErrorCode.OBS_SANLAM_DATALOADER_SERVICE_TIMEOUT, e.getMessage());
		}catch(Exception exception ){
			LOGGER.info(" exception failure response from sanLam {}",exception.getMessage());
			throw new TechnicalException(ApplicationErrorCode.OBS_LOV_DATLOADER_FAILED,exception.getMessage());
		}

		return null;
	}

	private void parseJsonAndInsertIntoStagingTable(List<SanlamLovMasterVO> listOfSanlamLovMasterVO, String country){
		List<Staging> staginglist = new ArrayList<>();
		for(SanlamLovMasterVO sanlamLovMasterVO:listOfSanlamLovMasterVO) {
			if(sanlamLovMasterVO.getName() !=null && sanlamLovMasterVO.getValues() !=null) {
				for (SanlamLovMasterDataSetVO sanlamLovMasterDataSetVO : sanlamLovMasterVO.getValues()) {
					LOGGER.info("name {}", sanlamLovMasterVO.getName());
					staginglist.add(new Staging(sanlamLovMasterVO.getName().trim(),country,sanlamLovMasterDataSetVO.getKey(),sanlamLovMasterDataSetVO.getValue(),null,null,null));
					LOGGER.info("key  {} value {} models size {}", sanlamLovMasterDataSetVO.getKey(), sanlamLovMasterDataSetVO.getValue(), sanlamLovMasterDataSetVO.getModels() != null ? sanlamLovMasterDataSetVO.getModels().size() : 0);
					if(ObsKEConstants.VEHICLE_MAKE.equals(sanlamLovMasterVO.getName())){
						if (sanlamLovMasterDataSetVO.getModels() != null && sanlamLovMasterDataSetVO.getModels().size() > 0) {
							for (SanlamLovMasterDataSetVO sanlamLovMasterDataSetVOforModel : sanlamLovMasterDataSetVO.getModels()) {
								staginglist.add(new Staging(sanlamLovMasterVO.getName().trim(),country,sanlamLovMasterDataSetVO.getKey(),sanlamLovMasterDataSetVO.getValue(),ObsKEConstants.VEHICLE_MODEL,sanlamLovMasterDataSetVOforModel.getKey(),sanlamLovMasterDataSetVOforModel.getValue()));
							}

						}
					}
				}

			}
		}
		if(staginglist !=null && staginglist.size()>0){
			LOGGER.info("staginglist size {}",staginglist.size());
			stagingRepository.save(staginglist);
			LOGGER.info(" Lov Data successfully inserted into staging table");
		}


	}
}
