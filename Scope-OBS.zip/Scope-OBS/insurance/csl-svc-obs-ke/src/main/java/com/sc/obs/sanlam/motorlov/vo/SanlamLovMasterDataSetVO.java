/**
 * 
 */
package com.sc.obs.sanlam.motorlov.vo;

import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamLovMasterDataSetVO {
	private String key;
	private String value;
	private List<SanlamLovMasterDataSetVO> models;
}
