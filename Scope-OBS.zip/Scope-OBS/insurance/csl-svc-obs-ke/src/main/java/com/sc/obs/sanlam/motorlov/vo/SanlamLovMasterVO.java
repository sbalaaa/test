/**
 * 
 */
package com.sc.obs.sanlam.motorlov.vo;

import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamLovMasterVO {
	private String name;
	private List<SanlamLovMasterDataSetVO> values;
}
