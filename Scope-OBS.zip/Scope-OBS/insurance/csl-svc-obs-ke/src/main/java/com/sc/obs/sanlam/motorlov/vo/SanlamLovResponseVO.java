package com.sc.obs.sanlam.motorlov.vo;

import java.util.List;

import lombok.Data;

import com.sc.obs.sanlam.SanlamResponse;

@Data
public class SanlamLovResponseVO extends SanlamResponse {
	private String responseType;
	private String errorMessage;
	private String errorCode;
	private List<SanlamLovResponseValueVO> responseValue;
	
}
