/**
 * 
 */
package com.sc.obs.sanlam.quote;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class Benefit {
	private String id;
	private String description;
	private String value;
}
