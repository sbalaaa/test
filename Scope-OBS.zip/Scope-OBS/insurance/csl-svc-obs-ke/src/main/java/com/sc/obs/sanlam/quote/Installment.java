/**
 * 
 */
package com.sc.obs.sanlam.quote;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class Installment {
	private String installmentName;
	private String premium;
}
