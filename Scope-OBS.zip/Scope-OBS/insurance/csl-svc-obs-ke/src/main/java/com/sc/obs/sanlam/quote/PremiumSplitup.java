/**
 * 
 */
package com.sc.obs.sanlam.quote;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class PremiumSplitup {
	private String description;
	private String value;
}
