/**
 * 
 */
package com.sc.obs.sanlam.quote;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorCover {
	private String coverCode;
	private String coverName;
	private String coverSumInsured;
	private String noOfDays;
	private BigDecimal coverPremium;
	private String sumInsuredEditable;
	private String noOfDaysEditable;
	private String sumInsuredDisplayble;
	private String mandatoryCover;
	private String typeOfCover;
	private String coverSelected;
	private List<Benefit> benefit;
	private String noOfDaysDisplayable;
}
