/**
 * 
 */
package com.sc.obs.sanlam.quote;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorCoverReq {
	private String coverCode;
	private String coverSumInsured;
	private String noOfDays;
	private String coverSelected;
	
}
