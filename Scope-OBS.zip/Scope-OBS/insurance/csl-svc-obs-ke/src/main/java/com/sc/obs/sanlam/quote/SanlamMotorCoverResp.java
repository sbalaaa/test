/**
 * 
 */
package com.sc.obs.sanlam.quote;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorCoverResp {

	private String coverCode;
	private String coverName;
	private BigDecimal sumInsured;
	private String noofDays;
	private BigDecimal coverPremium;
	private String sumInsuredEditable;
	private String noOfDaysEditable;
	private String sumInsuredDisplayble;
	private String mandatoryCover;
	private String typeOfCover;
	private String coverSelected;
	private List<Benefit> benefit;
	private String noOfDaysDisplayable;

}
