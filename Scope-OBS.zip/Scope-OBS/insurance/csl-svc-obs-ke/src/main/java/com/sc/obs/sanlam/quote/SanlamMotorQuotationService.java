/**
 * 
 */
package com.sc.obs.sanlam.quote;

import static com.sc.csl.retail.core.util.CSLLogConstants.TIME_TAKEN_IN_MILLIS;
import static net.logstash.logback.argument.StructuredArguments.kv;

import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.code.Country;
import com.sc.obs.config.ApplicationError;
import com.sc.obs.config.mapper.SanlamMotorQuoteReqMapper;
import com.sc.obs.config.mapper.SanlamMotorQuoteResMapper;
import com.sc.obs.product.ProductType;
import com.sc.obs.quotation.Quotation;
import com.sc.obs.quotation.QuotationService;
import com.sc.obs.quotation.QuotationServiceRegistry;
import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.common.Constants;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;

/**
 * @author 1567880
 *
 */
@Component
public class SanlamMotorQuotationService implements QuotationService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SanlamMotorQuotationService.class);
	
	@Value("${sanlam.quote-url}")
    private String quoteUrl;
	
	@Autowired
	@Qualifier("sanlamAdapter")
	private SanlamAdapter sanlamAdapter;
	
	@Autowired
	private SanlamMotorQuoteReqMapper quoteReqMapper;

	@Autowired
	private SanlamMotorQuoteResMapper quoteRespMapper;

	@Autowired
    public void setRegistry(QuotationServiceRegistry registry) {
        registry.register(Country.KE, ProductType.MOTOR.name(), this);
    }
	

	/* (non-Javadoc)
	 * @see com.sc.obs.quotation.QuotationAdapter#getQuotation(com.sc.obs.quotation.Quotation)
	 */
	@Override
    public Quotation execute(Quotation quotationRequest) {
		Long startTime = System.currentTimeMillis();
		try{
        quotationRequest = prepareQuotationRequest(quotationRequest);
        return quotationRequest;
		}catch(Exception e){
			throw e;
		}finally{
			LOGGER.info("Request time taken : {} {} ms",kv(Constants.SANLAM_SERVICE, "/quotations"),
					kv(TIME_TAKEN_IN_MILLIS, (System.currentTimeMillis() - startTime))
					);
		}
    }
	
	private Quotation prepareQuotationRequest(Quotation quotationReqResp) {
		
        SanlamMotorQuote response = null;
        try {
            response = callGateway(quotationReqResp);
        } catch (ResourceAccessException e) {
            throw new TechnicalException(ApplicationErrorCode.OBS_QUOTATION_TIMEOUT, e.getMessage());
        } catch (Exception e) {
            throw new TechnicalException(ApplicationErrorCode.OBS_QUOTATION_FALURE, e.getMessage());
        }
        
        quotationReqResp.setDetail(response);
        quotationReqResp.setQuotationId(response.getQuotationNumber());
        return quotationReqResp;
    }
	
	private SanlamMotorQuote callGateway(Quotation  req)
            throws Exception {
        
		SanlamMotorQuoteReqWrapper motorQuoteReq = quoteReqMapper.map(req, SanlamMotorQuoteReqWrapper.class);
        motorQuoteReq.getQuote().setCountry(Country.KE);
        
        SanlamMotorQuoteRespWrapper response = (SanlamMotorQuoteRespWrapper)sanlamAdapter.callSanlam(quoteUrl, HttpMethod.POST, motorQuoteReq, SanlamMotorQuoteRespWrapper.class, null, null, null);
        SanlamMotorQuote quoteResponse = null;
        if(response.getResponseType().equals("S")){
	    	quoteResponse = quoteRespMapper.map(response.getResponseValue().getQuote(), SanlamMotorQuote.class);
	    	if(((SanlamMotorQuote)req.getDetail()).getRisks().get(0).getCover()!=null){
	    		Map<String, String> reqCoverCodeCoverSelectedMap = ((SanlamMotorQuote)req.getDetail()).getRisks().get(0).getCover().stream().collect(Collectors.toMap(SanlamMotorCover::getCoverCode, SanlamMotorCover::getCoverSelected));
		    	quoteResponse.getRisks().get(0).getCover()
		    	   .stream()
		    	   .filter(item -> reqCoverCodeCoverSelectedMap.containsKey(item.getCoverCode()))
		    	   .forEach(item -> item.setCoverSelected(reqCoverCodeCoverSelectedMap.get(item.getCoverCode())));
	    	}
	    	
        }else if(response.getResponseType().equals("F")){
        	LOGGER.error("SANLAM Quote Call failed, ErrorCode : {} & ErrorMessage : {}",response.getResponseValue().getErrorCode(),response.getResponseValue().getErrorMessage());
        	throw new BusinessException(new ApplicationError(response.getResponseValue().getErrorCode(),response.getResponseValue().getErrorMessage(),null));
        }
        return quoteResponse;
    }


	@Override
	public boolean validate(Quotation arg0) {
		// TODO Auto-generated method stub
		return true;
	}
}
