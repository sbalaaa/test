/**
 * 
 */
package com.sc.obs.sanlam.quote;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.sc.obs.quotation.QuotationDetail;

/**
 * @author 1567880
 *
 */
@Data
@JsonTypeName("sanlam-motor-quote")
public class SanlamMotorQuote extends QuotationDetail{
	@NotBlank(message = "policyType is mandatory")
	private String policyType;
	private String policyDuration;
	
	@NotBlank(message = "mode is mandatory")
	private String mode;
	private String lobCode;
	private String productCode;
	
	@JsonFormat(pattern="dd-MMM-yyyy mm:ss")
	private Date fromDate;
	private String quotationNumber;
	@NotBlank(message = "paymentMethod is mandatory")
	private String paymentMethod;
	private String totalPremium;
	private String currencyCode;
	private BigDecimal totalBasicCoverPremium;
	private BigDecimal totalRiderCoverPremium;
	private BigDecimal totalSumAssured;
	private Long noOfDays;
	@JsonFormat(pattern="dd-MMM-yy")
	private Date toDate;
	private List<SanlamMotorRisk> risks;
	private List<Installment> installments;
	private List<PremiumSplitup> premiumSplitups;

}
