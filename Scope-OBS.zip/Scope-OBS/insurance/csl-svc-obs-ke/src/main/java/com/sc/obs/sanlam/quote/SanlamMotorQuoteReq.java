package com.sc.obs.sanlam.quote;

import java.util.Date;
import java.util.List;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonFormat;

@Data
public class SanlamMotorQuoteReq {
	private String country;
	private String policyType;
	private String  mode;
	private String lobCode;
	private String productCode;
	
	@JsonFormat(pattern="dd-MMM-yyyy mm:ss")
	private Date fromDate;
	private String quotationNumber;
	private String paymentMethod;
	private String policyDuration;
	private List<SanlamMotorRiskReq> risk;
	
}
