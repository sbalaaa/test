/**
 * 
 */
package com.sc.obs.sanlam.quote;

import lombok.Data;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamRequest;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorQuoteReqWrapper extends SanlamRequest{
	private SanlamMotorQuoteReq quote;
	
	@Override
	public String toString() {
		return CSLJsonUtils.toJson(this);
	}
}
