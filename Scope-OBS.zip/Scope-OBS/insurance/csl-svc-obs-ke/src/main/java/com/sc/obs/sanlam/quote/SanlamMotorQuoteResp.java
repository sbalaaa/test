/**
 * 
 */
package com.sc.obs.sanlam.quote;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorQuoteResp {
	
	private String policyType;
	private String policyDuration;
	private String mode;
	private String lobCode;
	private String productCode;
	
	@JsonFormat(pattern="dd-MMM-yyyy mm:ss")
	private Date fromDate;
	private String quotationNumber;
	private String paymentMethod;
	private String totalPremium;
	private String currencyCode;
	private BigDecimal totalBasicCoverPremium;
	private BigDecimal totalRiderCoverPremium;
	private BigDecimal totalSumAssured;
	private Long noOfDays;
	@JsonFormat(pattern="dd-MMM-yy")
	private Date toDate;
	private List<SanlamMotorRiskResp> risk;
	private List<Installment> installment;
	private List<PremiumSplitup> premiumSplitup;
	



}
