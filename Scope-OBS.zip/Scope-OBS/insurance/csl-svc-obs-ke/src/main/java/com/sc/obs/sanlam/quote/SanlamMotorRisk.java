/**
 * 
 */
package com.sc.obs.sanlam.quote;

import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorRisk {
	private String riskIndex;
	private String make;
	private String typeOfCover;
	private String mfgYear;
	private String vehicleValue;
	private String vehicleCategory;
	private String typeOfVehicle;
	private List<SanlamMotorCover> cover;
	private List<Benefit> benefits;
}
