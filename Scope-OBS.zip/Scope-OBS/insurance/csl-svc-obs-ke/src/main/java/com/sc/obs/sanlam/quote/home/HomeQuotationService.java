package com.sc.obs.sanlam.quote.home;

import java.math.BigDecimal;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.code.Country;
import com.sc.obs.config.ApplicationError;
import com.sc.obs.config.mapper.SanlamHomeQuoteReqMapper;
import com.sc.obs.config.mapper.SanlamHomeQuoteResMapper;
import com.sc.obs.product.ProductType;
import com.sc.obs.quotation.Quotation;
import com.sc.obs.quotation.QuotationService;
import com.sc.obs.quotation.QuotationServiceRegistry;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReq;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReqWrapper;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteRespWrapper;

import ma.glasnost.orika.MappingContext;

import com.sc.obs.sanlam.adapter.SanlamAdapter;


@Component
public class HomeQuotationService implements QuotationService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HomeQuotationService.class);
	
	@Value("${sanlam.quote-url}")
    private String quoteUrl;
	
	@Autowired
	@Qualifier("sanlamAdapter")
	private SanlamAdapter sanlamAdapter;
	
	@Autowired
	private SanlamHomeQuoteReqMapper quoteReqMapper;

	@Autowired
	private SanlamHomeQuoteResMapper quoteRespMapper;

	@Autowired
    public void setRegistry(QuotationServiceRegistry registry) {
        registry.register(Country.KE, ProductType.HOME.name(), this);
    }
	

	/* (non-Javadoc)
	 * @see com.sc.obs.quotation.QuotationAdapter#getQuotation(com.sc.obs.quotation.Quotation)
	 */
	@Override
    public Quotation execute(Quotation quotationRequest) {
		quotationRequest = prepareQuotationRequest(quotationRequest);
        return quotationRequest;
    }
	
	private Quotation prepareQuotationRequest(Quotation quotationReqResp) {
		
        HomeQuote response = null;
        try {
            response = callGateway(quotationReqResp);
        } catch (Exception e) {
        	throw new TechnicalException(ApplicationErrorCode.OBS_QUOTATION_FALURE, e.getMessage());
        }
        
        quotationReqResp.setDetail(response);
        quotationReqResp.setQuotationId(response.getQuotationNumber());
        return quotationReqResp;
    }
	
	private HomeQuote callGateway(Quotation  req)
            throws Exception {
        
		HomeQuoteReqWrapper homeQuoteReq = quoteReqMapper.map(req, HomeQuoteReqWrapper.class);
		if(((HomeQuote)req.getDetail()).getMode() !=null && ((HomeQuote)req.getDetail()).getMode().equalsIgnoreCase("add")){
			homeQuoteReq.getQuote().setQuotationNumber("");
    	}
		homeQuoteReq.getQuote().setCountry(Country.KE);
        LOGGER.info("sanlam home request payload: {}",homeQuoteReq);
        HomeQuoteRespWrapper response = (HomeQuoteRespWrapper)sanlamAdapter.callSanlam(quoteUrl, HttpMethod.POST, homeQuoteReq, HomeQuoteRespWrapper.class, null, null, null);
        HomeQuote quoteResponse = null;
        if(response.getResponseType().equals("S")){
	    	quoteResponse = quoteRespMapper.map(response.getResponseValue().getQuote(), HomeQuote.class);
        }else if(response.getResponseType().equals("F")){
        	LOGGER.error("SANLAM Home Quote Call failed, ErrorCode : {} & ErrorMessage : {}",response.getResponseValue().getErrorCode(),response.getResponseValue().getErrorMessage());
        	throw new BusinessException(new ApplicationError(response.getResponseValue().getErrorCode(),response.getResponseValue().getErrorMessage(),null));
        }
        return quoteResponse;
    }


	@Override
	public boolean validate(Quotation arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	
}
