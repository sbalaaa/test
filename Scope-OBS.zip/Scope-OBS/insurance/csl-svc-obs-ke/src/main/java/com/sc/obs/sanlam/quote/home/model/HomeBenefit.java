package com.sc.obs.sanlam.quote.home.model;

import lombok.Data;

@Data
public class HomeBenefit {
	private String benefitId;
	private String description;
	private String value;
}
