package com.sc.obs.sanlam.quote.home.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class HomeCover {

	private String coverCode;
	private String coverName;
	private BigDecimal sumInsured;
	private BigDecimal coverPremium;
	private String sumInsuredDisplayble;
	private String mandatoryCover;
	private String sumInsuredEditable;
	private String coverSelected;
	private BigDecimal rate;
	private BigDecimal coverSumInsured;
}
