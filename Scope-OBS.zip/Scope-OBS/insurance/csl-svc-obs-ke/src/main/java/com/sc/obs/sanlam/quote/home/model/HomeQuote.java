package com.sc.obs.sanlam.quote.home.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.sc.obs.quotation.QuotationDetail;

@Data
@JsonTypeName("HOME")
public class HomeQuote extends QuotationDetail{
	@NotBlank(message = "policyType is mandatory")
	private String policyType;
	private String policyDuration;
	
	@NotBlank(message = "mode is mandatory")
	private String mode;
	private String lobCode;
	private String productCode;
	
	@JsonFormat(pattern="dd-MMM-yyyy hh:mm")
	private Date fromDate;
	private String quotationNumber;
	@NotBlank(message = "paymentMethod is mandatory")
	private String paymentMethod;
	private BigDecimal totalPremium;
	private String currencyCode;
	private BigDecimal totalSumAssured;
	private Long noOfDays;
	@JsonFormat(pattern="dd-MMM-yy")
	private Date toDate;
	
	private List<HomeRisk> risks;
	private List<HomeBenefit> benefits;
	
}
