package com.sc.obs.sanlam.quote.home.model;

import java.util.List;

import lombok.Data;

@Data
public class HomeRisk {
	private HomeSection building;
	private HomeSection content;
	private HomeSection personalLegalLiability;
	private HomeSection allRisk;
	private HomeSection golfersCover;
	private List<HomeSection> sections;
}
