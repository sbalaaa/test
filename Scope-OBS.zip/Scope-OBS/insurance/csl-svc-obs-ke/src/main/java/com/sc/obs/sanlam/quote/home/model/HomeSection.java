package com.sc.obs.sanlam.quote.home.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class HomeSection {
	private String sectionCode;
	private String sectionSelected;
	private BigDecimal sectionPremium;
	private Integer riskId;
	private Integer noOfEmployee;
	private List<HomeSmiInfo> smiInfo;
	private List<HomeCover> covers; 
}
