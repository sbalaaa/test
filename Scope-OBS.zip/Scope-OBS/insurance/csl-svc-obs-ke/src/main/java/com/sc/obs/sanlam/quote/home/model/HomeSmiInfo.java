/**
 * 
 */
package com.sc.obs.sanlam.quote.home.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class HomeSmiInfo {
	private BigDecimal smiValue;
}
