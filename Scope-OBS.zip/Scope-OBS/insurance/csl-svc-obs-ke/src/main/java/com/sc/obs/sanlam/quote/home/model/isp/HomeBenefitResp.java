package com.sc.obs.sanlam.quote.home.model.isp;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HomeBenefitResp {
	@JsonProperty(value="benefitID")
	private String benefitId;
	private String description;
	private String value;
}
