package com.sc.obs.sanlam.quote.home.model.isp;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HomeCoverResp {

	private String coverCode;
	private String coverName;
	private BigDecimal sumInsured;
	private BigDecimal coverPremium;
	@JsonProperty(value="sumInsuredDisplaybleYN")
	private String sumInsuredDisplayble;
	@JsonProperty(value="mandatoryCoverYN")
	private String mandatoryCover;
	@JsonProperty(value="sumInsuredEditableYN")
	private String sumInsuredEditable;
	@JsonProperty(value="coverSelectedYN")
	private String coverSelected;
	private BigDecimal rate;
	private BigDecimal coverSumInsured;
	
}
