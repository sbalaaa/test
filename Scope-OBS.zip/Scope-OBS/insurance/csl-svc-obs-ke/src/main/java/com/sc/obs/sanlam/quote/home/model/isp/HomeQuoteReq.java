package com.sc.obs.sanlam.quote.home.model.isp;

import java.util.Date;
import java.util.List;



import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class HomeQuoteReq {
	private String country;
	private String  mode;
	private String lobCode;
	private String productCode;
	
	@JsonFormat(pattern="dd-MMM-yyyy hh:mm")
	private Date fromDate;
	private String quotationNumber;
	private String paymentMethod;
	private String policyDuration;
	private List<HomeRiskReq> homeRisk;
}
