package com.sc.obs.sanlam.quote.home.model.isp;



import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamRequest;

import lombok.Data;

@Data
public class HomeQuoteReqWrapper extends SanlamRequest{
	private HomeQuoteReq quote;
	
	@Override
	public String toString() {
		return CSLJsonUtils.toJson(this);
	}
}
