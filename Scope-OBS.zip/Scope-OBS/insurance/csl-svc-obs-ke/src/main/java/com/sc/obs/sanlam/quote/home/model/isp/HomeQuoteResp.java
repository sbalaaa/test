package com.sc.obs.sanlam.quote.home.model.isp;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.sc.obs.sanlam.quote.home.model.isp.HomeBenefitResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeRiskReq;

import lombok.Data;

@Data
public class HomeQuoteResp {
	
	private String quotationNumber;
	private BigDecimal totalPremium;
	@JsonFormat(pattern="dd-MMM-yy")
	private Date toDate;
	private BigDecimal totalSumAssured;
	private Long noOfDays;
	private String currencyCode;
	
	private BigDecimal commission;
	private BigDecimal vat;
	private String message;
	
	private List<HomeRiskReq> homeRisk;
	private List<HomeBenefitResp> benefits;
	
}
