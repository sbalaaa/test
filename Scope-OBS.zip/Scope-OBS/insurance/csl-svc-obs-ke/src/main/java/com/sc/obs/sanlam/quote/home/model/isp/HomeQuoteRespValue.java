/**
 * 
 */
package com.sc.obs.sanlam.quote.home.model.isp;

import lombok.Data;

@Data
public class HomeQuoteRespValue  {
	private HomeQuoteResp quote;
	private String errorMessage;
	private String errorCode;
	private String exceptionType;
}
