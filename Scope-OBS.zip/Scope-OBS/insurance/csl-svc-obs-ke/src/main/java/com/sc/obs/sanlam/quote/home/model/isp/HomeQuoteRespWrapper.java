/**
 * 
 */
package com.sc.obs.sanlam.quote.home.model.isp;



import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamResponse;

import lombok.Data;

@Data
public class HomeQuoteRespWrapper extends SanlamResponse{
	private String responseType;
	private HomeQuoteRespValue responseValue;

	@Override
	public String toString() {
		return CSLJsonUtils.toJson(this);
	}
}
