package com.sc.obs.sanlam.quote.home.model.isp;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HomeRiskReq {
	@JsonProperty(value="buildings")
	private HomeSectionReq building;
	@JsonProperty(value="contents")
	private HomeSectionReq content;
	@JsonProperty(value="personallegalliability")
	private HomeSectionReq personalLegalLiability;
	@JsonProperty(value="allrisks")
	private HomeSectionReq allRisk;
	@JsonProperty(value="golferscover")
	private HomeSectionReq golfersCover;
	@JsonProperty(value="section")
	private List<HomeSectionReq> sections;
}
