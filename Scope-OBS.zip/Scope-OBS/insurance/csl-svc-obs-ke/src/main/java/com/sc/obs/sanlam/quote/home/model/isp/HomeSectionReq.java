package com.sc.obs.sanlam.quote.home.model.isp;

import java.math.BigDecimal;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HomeSectionReq {
	private String sectionCode;
	@JsonProperty(value="sectionSelectedYN")
	private String sectionSelected;
	private BigDecimal sectionPremium;
	@JsonProperty(value="riskID")
	private Integer riskId;
	private Integer noOfEmployee;
	private List<HomeSmiInfoReq> smiInfo;
	@JsonProperty(value="cover")
	private List<HomeCoverResp> covers; 
}
