/**
 * 
 */
package com.sc.obs.sanlam.quote.home.model.isp;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class HomeSmiInfoReq {
	private BigDecimal smiValue;
}
