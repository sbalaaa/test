/**
 * 
 */
package com.sc.obs.upload.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sc.obs.upload.model.SanlamMotorDocumentResponseWrapper;
import com.sc.obs.upload.model.UploadModel;
import com.sc.obs.upload.service.DocUploadService;

/**
 * @author 1567880
 *
 */
@RestController
public class DocUploadController {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(DocUploadController.class);
	
	@Autowired
	private DocUploadService docUploadService;

	@PostMapping("/docupload")
	public ResponseEntity<SanlamMotorDocumentResponseWrapper> documentUpload(
			@ModelAttribute UploadModel uploadModel)throws IOException {

		LOGGER.debug("Multiple file upload! With UploadModel");
		SanlamMotorDocumentResponseWrapper response = docUploadService.documentUpload(uploadModel);
		return new ResponseEntity(response, HttpStatus.OK);

	}

}
