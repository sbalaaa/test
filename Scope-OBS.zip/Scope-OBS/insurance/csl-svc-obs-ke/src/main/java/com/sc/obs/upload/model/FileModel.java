/**
 * 
 */
package com.sc.obs.upload.model;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author 1567880
 *
 */
@Data
public class FileModel {
	
	private String fileId;
 	
 	private String fileType;

    private MultipartFile fileContent;
    
    private String fileName;

}
