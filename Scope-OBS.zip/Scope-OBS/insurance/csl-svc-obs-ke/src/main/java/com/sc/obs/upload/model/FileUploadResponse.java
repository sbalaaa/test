/**
 * 
 */
package com.sc.obs.upload.model;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class FileUploadResponse {
	private String fileId;
	private String fileName;
	private String message;
}
