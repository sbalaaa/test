/**
 * 
 */
package com.sc.obs.upload.model;

import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorDocumentResponse {
	private String errorMessage;
	private String errorCode;
	private String exceptionType;
	private List<FileUploadResponse> file;

}
