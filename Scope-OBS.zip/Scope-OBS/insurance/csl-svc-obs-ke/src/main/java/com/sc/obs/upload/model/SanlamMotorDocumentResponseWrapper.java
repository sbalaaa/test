/**
 * 
 */
package com.sc.obs.upload.model;

import lombok.Data;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.sanlam.SanlamResponse;

/**
 * @author 1567880
 *
 */
@Data
public class SanlamMotorDocumentResponseWrapper extends SanlamResponse {
	private String responseType;
	private SanlamMotorDocumentResponse responseValue;
	
	@Override
	public String toString() {
		return CSLJsonUtils.toJson(this);
	}
}
