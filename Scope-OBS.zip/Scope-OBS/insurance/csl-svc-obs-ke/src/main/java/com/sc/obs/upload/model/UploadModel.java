/**
 * 
 */
package com.sc.obs.upload.model;

import java.util.List;

import lombok.Data;

/**
 * @author 1567880
 *
 */
@Data
public class UploadModel {
	private List<FileModel> file;
	private String quotationId;
	private String uploadState;
}
