/**
 * 
 */
package com.sc.obs.upload.service;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.obs.config.ObsKEConstants;
import com.sc.obs.config.ApplicationError;
import com.sc.obs.exception.ObsBusinessException;
import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.upload.model.FileModel;
import com.sc.obs.upload.model.SanlamMotorDocumentResponseWrapper;
import com.sc.obs.upload.model.UploadModel;

/**
 * @author 1567880
 *
 */
@Service
public class DocUploadService {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(DocUploadService.class);
	
	@Autowired
	private SanlamAdapter sanlamAdapter;
	
	@Value("${sanlam.doc-upload-url}")
    private String docUploadUrl;
	
	@Value("${docupload.allowedFileTypes}")
	private String allowedFileTypes;
	
	public SanlamMotorDocumentResponseWrapper documentUpload(
			UploadModel uploadModel) throws IOException {

		LOGGER.debug("Multiple file upload! With UploadModel");
		MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<String, String>();
		headersMap.add(ObsKEConstants.QUOTATION_NUMBER, uploadModel.getQuotationId());
		headersMap.add(ObsKEConstants.UPLOAD_STATE, uploadModel.getUploadState());
		MultiValueMap<String, Object> multipartDataMap = new LinkedMultiValueMap<String, Object>();
		convertUploadModelToMap(uploadModel, multipartDataMap);
		SanlamMotorDocumentResponseWrapper response = (SanlamMotorDocumentResponseWrapper)sanlamAdapter.callSanlam(docUploadUrl, HttpMethod.POST, null, SanlamMotorDocumentResponseWrapper.class, MediaType.MULTIPART_FORM_DATA, headersMap, multipartDataMap);
		return response;

	}

	private void convertUploadModelToMap(UploadModel uploadModel,
			MultiValueMap<String, Object> paramsMap)throws IOException {
		int counter = 0;
		validateFileFormat(uploadModel);
		for(FileModel fileModel:uploadModel.getFile()){
			ByteArrayResource contentsAsResource = null;
			if(fileModel.getFileContent()!=null){
				contentsAsResource = new ByteArrayResource(fileModel.getFileContent().getBytes()){
		            @Override
		            public String getFilename(){
		                return fileModel.getFileContent().getOriginalFilename();
		            }
		        };
			}
			paramsMap.add("file["+counter+"].fileId", fileModel.getFileId());
	        paramsMap.add("file["+counter+"].fileContent", contentsAsResource);
	        paramsMap.add("file["+counter+"].fileType", fileModel.getFileType());
	        paramsMap.add("file["+counter+"].fileName", fileModel.getFileName());
	        counter++;
		}
	}

	private void validateFileFormat(UploadModel uploadModel) {
		String fileName = "";
		for(FileModel fileModel:uploadModel.getFile()){
			if(ObsKEConstants.UPLOAD.equals(uploadModel.getUploadState())){
				if(fileModel.getFileContent()!=null){
					fileName = fileModel.getFileContent().getOriginalFilename();
					int lastIndex = fileName.lastIndexOf('.');
					String substring = fileName.substring(lastIndex+1, fileName.length());
					if (!allowedFileTypes.contains(substring.toLowerCase())){
						String errorMessage = "Invalid file format "+substring+", allowed formats are "+allowedFileTypes;
						LOGGER.error(errorMessage);
			        	throw new ObsBusinessException(ApplicationErrorCode.OBS_DOC_UPLOAD_UN_SUPPORTED_FILE_FORMAT);
					}
				}else{
					LOGGER.error("Failed to upload document, reason -> File is invalid or NULL");
					throw new ObsBusinessException(ApplicationErrorCode.OBS_DOC_UPLOAD_FILE_IS_INVALID_OR_NULL);
				}
			}
			
			if(ObsKEConstants.DELETE.equals(uploadModel.getUploadState()) && StringUtils.isEmpty(fileModel.getFileId())){
				LOGGER.error("Failed to delete document, reason -> File Id is not valid");
				throw new ObsBusinessException(ApplicationErrorCode.OBS_DOC_UPLOAD_INVALID_FILE_ID);
			}
		}
	}

}
