select o.order_id,app.rel_id as rel_id, op_pay.payment_mode as payment_method, op_pay.debit_acc_masked_no as debit_acc_no,
req.first_name as first_name, req.middle_name as middle_name, req.last_name as last_name,
o.order_status, op_mstr.isp_quotation_cd as quotation_id, app.channel_name as sales_channel, o.order_amt_curr as currency,
'Sanlam' as ISP_name, o.created_timestamp::date as request_date, op_pol.policy_no as policy_number,
(select case when cov.cover_name like '%Loss%of%Use%' then 'Comprehensive plan' else cov.cover_name end from obs_app_prdt_cover_dtls cov
where cov.prdt_id = op_mstr.prdt_id and cov.cover_name in ('Loss of Use','Fire And Theft', 'Third party Only')) as rider,
extract_premium_details(op_mstr.prdt_id, 'Total Premium') as Basic_Premium,
op_pay.tran_amt as premium_paid,
coalesce(op_motor.language_cd, 'en') as language_code,
case
when o.order_error_desc like '%Payment%Done%' then 'After Payment'
when o.order_error_desc is not null then 'Before Payment' end as error_location,
split_part(o.order_error_desc, '|', 1) as error_description,

op_motor.cntry_cd as origin_country_cd,

op_pay.tran_amt_curr as payment_currency, op_mstr.premium_amt as total_premium,
op_pay.obs_tran_ref_no as transaction_ref_no,
op_pay.created_timestamp::date as transaction_date,
op_motor.first_installment_amt as first_installment, op_motor.second_installment_amt as second_installment,
op_motor.next_installment_date as next_installment_date,

(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=req.title and ocm.field_code='Title') as title,
req.phone_no as mobile_number, req.email as email_id,
(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm
where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=req.identification_type and ocm.field_code='IdentityDocumentType') as document_type, req.identification_id as document_number,
(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=req.job_title and ocm.field_code='JobTitle') as job_title,
(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=req.business_sector and ocm.field_code='BusinessSector') as business_sector,
addr.address_1 as mailling_address_1,addr.address_2 as mailling_address_2, addr.state as state, addr.postal_cd as postal_code,


(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=op_motor.vehicle_model and ocm.field_code='VehicleModel') as model,
(select ord.field_val_label from obs_ref_data ord ,obs_config_master ocm where ord.config_mstr_id=ocm.config_mstr_id and ord.field_val=op_motor.vehicle_usage_type and ocm.field_code='UsageType') as usage_type,
op_motor.registration_no as registration_no,
op_motor.engine_no as engine_no, op_motor.chassis_no as chasis_no,

extract_premium_details(op_mstr.prdt_id, 'Excess Protection (+)') as Excess_Protection,
extract_premium_details(op_mstr.prdt_id, 'Loss Of Use (+)') as Loss_of_Use,
extract_premium_details(op_mstr.prdt_id, 'Own Damage (+)') as Own_Damage,
extract_premium_details(op_mstr.prdt_id, 'Political Violence, Terrorism And Sabotage (+)') as Political_Violence_Terrorism_Sabotage,
extract_premium_details(op_mstr.prdt_id, 'Aa Fee Deduction - D - P (-)') as Aa_Fee_Deduction,
extract_premium_details(op_mstr.prdt_id, 'Variable Access Fee') as Variable_Access_Fee,
extract_premium_details(op_mstr.prdt_id, 'Marketing Fee') as Marketing_Fee,

extract_premium_details(op_mstr.prdt_id, 'Sem Recovery Fee') as Sem_Recovery_Fee,
extract_premium_details(op_mstr.prdt_id, 'Stamp Duty (+)') as Stamp_Duty,
extract_premium_details(op_mstr.prdt_id, 'Policy Holders Compensation Fund (+)') as Policy_Holders_CompensationFund,
extract_premium_details(op_mstr.prdt_id, 'Training Levy (+)') as Training_Levy,
extract_premium_details(op_mstr.prdt_id, 'Insurance Premium Levy') as Insurance_Premium_Levy,
extract_premium_details(op_mstr.prdt_id, 'Aa Fee (+)') as Aa_Fee,
extract_premium_details(op_mstr.prdt_id, 'Sub Total') as Sub_Total,
extract_premium_details(op_mstr.prdt_id, 'Total Amount') as Total_Amount,
extract_premium_details(op_mstr.prdt_id, 'Broker Summary') as Broker_Summary,
extract_premium_details(op_mstr.prdt_id, 'Total Commission') as Total_Commission

from obs_order_master o
inner join obs_application_dtls app on app.application_id = o.application_id
inner join obs_order_prdt_payment_map opm on opm.order_id = o.order_id
inner join obs_app_requester_dtls req on req.application_id = o.application_id
inner join obs_app_prdt_master op_mstr on op_mstr.prdt_id = opm.prdt_id
inner join obs_app_prdt_motor op_motor on op_motor.prdt_id = op_mstr.prdt_id
inner join obs_app_prdt_insured_dtls ins on ins.prdt_id = op_mstr.prdt_id
inner join obs_app_prdt_mailling_addr_dtls addr on addr.address_holder_id = req.requester_dtls_id
left join obs_app_prdt_policy op_pol on op_pol.prdt_id = op_mstr.prdt_id
left join obs_order_prdt_payment op_pay on op_pay.order_prdt_payment_id = opm.payment_id

where op_mstr.product_cd = 'MOTOR' and app.cntry_cd = 'KE'
and o.order_status like '%Purchase%Success%'
and o.created_timestamp >= DATE_TRUNC('month', CURRENT_DATE) 
and o.created_timestamp < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month';
