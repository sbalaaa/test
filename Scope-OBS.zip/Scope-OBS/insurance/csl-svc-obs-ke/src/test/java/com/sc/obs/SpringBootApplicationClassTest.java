package com.sc.obs;

import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.doReturn;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.spy;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.builder.SpringApplicationBuilder;

@RunWith(PowerMockRunner.class)
@PrepareForTest(ObsKEApplication.class)
public class SpringBootApplicationClassTest {
    private SpringApplicationBuilder applicationBuilder;

    @Before
    public void setUp() throws Exception {
        spy(ObsKEApplication.class);
        applicationBuilder = mock(SpringApplicationBuilder.class);

        doReturn(applicationBuilder).when(ObsKEApplication.class, "configureApplication", any());
    }

    @Test
    public void testMainClass() {
        ObsKEApplication.main(new String[] {});
    }

    @Test
    public void testConfigureMethod(){
        new ObsKEApplication().configure(new SpringApplicationBuilder());
    }
}
