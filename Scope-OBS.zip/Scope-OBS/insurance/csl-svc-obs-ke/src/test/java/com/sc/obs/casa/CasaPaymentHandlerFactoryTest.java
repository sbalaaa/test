package com.sc.obs.casa;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.sc.obs.application.BancaApplication;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.payment.casa.CasaPaymentHandlerFactory;
import com.sc.obs.payment.casa.CasaPaymentProcessor;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CasaPaymentHandlerFactoryTest {
    @Autowired
    private CasaPaymentHandlerFactory casaPaymentHandlerFactory;

    @Test
    public void testCreatePaymentProcessor(){
    	BancaApplication bancaApplication = new BancaApplication();
        CasaPaymentDetail casaPaymentDetail = new CasaPaymentDetail();
        casaPaymentDetail.setCountryCode("KE");
        casaPaymentDetail.setFromAccountNumber("01234142412");
        casaPaymentDetail.setToAccountNumber("098978663113");

        bancaApplication.setPaymentDetail(casaPaymentDetail);

        CasaPaymentProcessor casaPaymentProcessor = (CasaPaymentProcessor) casaPaymentHandlerFactory.createPaymentProcessor(bancaApplication);

        assertNotNull(casaPaymentProcessor);
    }
}
