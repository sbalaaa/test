package com.sc.obs.casa;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.powermock.api.mockito.PowerMockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.sc.corebanking.v6.ws.provider.account.GetAccountDetailsRes;
import com.sc.obs.common.properties.EdmiProductCasaConfigProperties;
import com.sc.obs.edmi.account.adapter.AccountDetailsAdapter;
import com.sc.obs.edmi.account.adapter.AccountValidationResponse;
import com.sc.obs.edmi.account.adapter.AccountValidationStatus;
import com.sc.obs.edmi.account.response.handlers.AccountValidationEBBSResponseHandler;
import com.sc.obs.edmi.fundstransfer.response.handlers.FundTransferEbbsV6ResponseHandler;
import com.sc.obs.edmi.fundtransfer.adapter.FundTransferV6Adapter;
import com.sc.obs.payment.PaymentResponse;
import com.sc.obs.payment.PaymentStatus;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.payment.casa.KECasaPaymentService;
import com.sc.obs.product.ProductType;
import com.sc.obs.utils.TestHelper;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;

@RunWith(SpringRunner.class)
@SpringBootTest
public class KECasaPaymentServiceTest {
    @Mock
    private FundTransferV6Adapter fundTransferV6Adapter;

    @Mock
    private FundTransferEbbsV6ResponseHandler fundTransferEbbsV6ResponseHandler;
    
    @Mock
    private AccountDetailsAdapter accountValidationAdapter;
    
    @Mock
    private AccountValidationEBBSResponseHandler accountValidationEBBSResponseHandler;

    @InjectMocks
    private KECasaPaymentService keCasaPaymentService;
    
    @Before
    public void setUp(){
        when(fundTransferV6Adapter.postTransaction(any(CasaPaymentDetail.class)))
                .thenReturn(Optional.of(TestHelper.mockSuccessKEFundTransferResponse()));
        when(fundTransferEbbsV6ResponseHandler.process(any(PostTransactionResponse.class)))
                .thenReturn(TestHelper.mockSuccessPaymentResponse());
        when(accountValidationAdapter.getAccountDetails(any(CasaPaymentDetail.class)))
        .thenReturn(Optional.of(TestHelper.mockSuccessKEAccValidationResponse()));
        when(accountValidationEBBSResponseHandler.process(any(GetAccountDetailsRes.class)))
        .thenReturn(TestHelper.mockSuccessAccValResponse());
    }

    @Test
    public void testExecutePaymentSuccess(){
        PaymentResponse paymentResponse = keCasaPaymentService.executePayment(TestHelper.mockCasaPaymentDetail());
        assertNotNull(paymentResponse);
        assertThat(paymentResponse.getStatus(), is(PaymentStatus.Success));
    }

    @Test
    public void testFundTransferAdapterReturnNullHandle(){
        when(fundTransferV6Adapter.postTransaction(any(CasaPaymentDetail.class)))
                .thenReturn(Optional.empty());
        PaymentResponse paymentResponse = keCasaPaymentService.executePayment(TestHelper.mockCasaPaymentDetail());
        assertNotNull(paymentResponse);
        assertThat(paymentResponse.getStatus(), is(PaymentStatus.Failure));
    }

    @Test
    public void testPrePopulateMotorCasaPaymentDetail(){
    	EdmiProductCasaConfigProperties edmiMotorProductCasaConfigProperties = new EdmiProductCasaConfigProperties();
    	edmiMotorProductCasaConfigProperties.setDebitNarration("Sanlam Motor Insurance Premium");
    	edmiMotorProductCasaConfigProperties.setIspAccountNumber("0151800162600");
        CasaPaymentDetail paymentDetail = TestHelper.mockCasaPaymentDetail();
        paymentDetail.setToAccountNumber(null);
        paymentDetail.setUniqueReferenceIdentifier("11111");
        paymentDetail.setProductType(ProductType.MOTOR.name());
        
        keCasaPaymentService.setEdmiMotorProductCasaConfigProperties(edmiMotorProductCasaConfigProperties);

        CasaPaymentDetail paymentDetail1 = keCasaPaymentService.prePopulateCasaPaymentDetail(paymentDetail);

        assertNotNull(paymentDetail);
        assertThat(paymentDetail1.getToAccountNumber(), is("0151800162600"));
        assertThat(paymentDetail1.getDebitNarration(), is("Sanlam Motor Insurance Premium"));
    }
    
    @Test
    public void testPrePopulateHomeCasaPaymentDetail(){
    	EdmiProductCasaConfigProperties edmiHomeProductCasaConfigProperties = new EdmiProductCasaConfigProperties();
    	edmiHomeProductCasaConfigProperties.setDebitNarration("Sanlam Home Content Insurance Premium");
    	edmiHomeProductCasaConfigProperties.setIspAccountNumber("0151800162600");
        CasaPaymentDetail paymentDetail = TestHelper.mockCasaPaymentDetail();
        paymentDetail.setToAccountNumber(null);
        paymentDetail.setUniqueReferenceIdentifier("11111");
        paymentDetail.setProductType(ProductType.HOME.name());
        
        keCasaPaymentService.setEdmiHomeProductCasaConfigProperties(edmiHomeProductCasaConfigProperties);

        CasaPaymentDetail paymentDetail1 = keCasaPaymentService.prePopulateCasaPaymentDetail(paymentDetail);

        assertNotNull(paymentDetail);
        assertThat(paymentDetail1.getToAccountNumber(), is("0151800162600"));
        assertThat(paymentDetail1.getDebitNarration(), is("Sanlam Home Content Insurance Premium"));
    }
    

    @Test
    public void testAccountValidationSuccess(){
        AccountValidationResponse response = keCasaPaymentService.validateAccount(TestHelper.mockCasaPaymentDetail());
        assertNotNull(response);
        assertThat(response.getStatus(), is(AccountValidationStatus.Success));
    }
    
    @Test
    public void testAccountValidationAdapterReturnNullHandle(){
        when(accountValidationAdapter.getAccountDetails(any(CasaPaymentDetail.class)))
                .thenReturn(Optional.empty());
        AccountValidationResponse response = keCasaPaymentService.validateAccount(TestHelper.mockCasaPaymentDetail());
        assertNotNull(response);
        assertThat(response.getStatus(), is(AccountValidationStatus.Failure));
    }
}
