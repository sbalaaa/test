package com.sc.obs.config.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.obs.quotation.Quotation;
import com.sc.obs.quotation.QuotationDetail;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.HomeRisk;
import com.sc.obs.sanlam.quote.home.model.HomeSection;
import com.sc.obs.sanlam.quote.home.model.HomeSmiInfo;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReqWrapper;

import static org.mockito.Mockito.doThrow;

public class HomeQuoteReqMapperTest {

	@Mock
	private SanlamHomeQuoteReqMapper mapper;
	@Mock
	private HomeQuote homeQuote;

	@Before
	public void initSetupMock() {

		MockitoAnnotations.initMocks(this);
	}

	 @Test
	public void testHomeQuoteReqMapper() {
		mapper = new SanlamHomeQuoteReqMapper();
		HomeQuoteReqWrapper quoteDetails;
		quoteDetails = mapper.map(mockQuotation(), HomeQuoteReqWrapper.class);
		assertNotNull(quoteDetails);
		assertEquals("1002", quoteDetails.getQuote().getProductCode());
		assertEquals("add", quoteDetails.getQuote().getMode());
		assertEquals("07", quoteDetails.getQuote().getPaymentMethod());
		assertEquals("10", quoteDetails.getQuote().getLobCode());
		// Builds section
		assertEquals("1000", quoteDetails.getQuote().getHomeRisk().get(0).getBuilding().getSectionCode());			
		assertEquals(new BigDecimal("1000000"),
				quoteDetails.getQuote().getHomeRisk().get(0).getBuilding().getSmiInfo().get(0).getSmiValue());
		// start section for contents
		assertEquals(new Integer("1"), quoteDetails.getQuote().getHomeRisk().get(0).getContent().getRiskId());
		assertEquals("1000", quoteDetails.getQuote().getHomeRisk().get(0).getContent().getSectionCode());
		assertEquals(new Integer("1"), quoteDetails.getQuote().getHomeRisk().get(0).getContent().getRiskId());		
		
		assertEquals(new BigDecimal("1000000"),
				quoteDetails.getQuote().getHomeRisk().get(0).getContent().getSmiInfo().get(0).getSmiValue());

		// start section for Personallegalliability
		assertEquals(new Integer("1"), quoteDetails.getQuote().getHomeRisk().get(0).getPersonalLegalLiability().getRiskId());
		assertEquals("1000", quoteDetails.getQuote().getHomeRisk().get(0).getPersonalLegalLiability().getSectionCode());
				
		assertEquals(new BigDecimal("1000000"),
				quoteDetails.getQuote().getHomeRisk().get(0).getPersonalLegalLiability().getSmiInfo().get(0).getSmiValue());
		// start section for AllRisk
		assertEquals("1000", quoteDetails.getQuote().getHomeRisk().get(0).getAllRisk().getSectionCode());		
		assertEquals(new BigDecimal("1000000"),
				quoteDetails.getQuote().getHomeRisk().get(0).getAllRisk().getSmiInfo().get(0).getSmiValue());
		// start section for golferscover
		assertEquals("1000", quoteDetails.getQuote().getHomeRisk().get(0).getGolfersCover().getSectionCode());
		assertEquals(new Integer("1"), quoteDetails.getQuote().getHomeRisk().get(0).getGolfersCover().getRiskId());
		
		assertEquals(new BigDecimal("1000000"),
				quoteDetails.getQuote().getHomeRisk().get(0).getGolfersCover().getSmiInfo().get(0).getSmiValue());
	}

	@Test
	public void fieldValidationNotEmpty() throws Exception {
		HomeQuoteReqWrapper quoteDetails;
		mapper = new SanlamHomeQuoteReqMapper();
		quoteDetails = mapper.map(mockQuotationempty(), HomeQuoteReqWrapper.class);
		doThrow(IllegalArgumentException.class).when(homeQuote).setMode("");
		assertEquals("", quoteDetails.getQuote().getMode());
		doThrow(IllegalArgumentException.class).when(homeQuote).setPaymentMethod("");
		assertEquals("", quoteDetails.getQuote().getPaymentMethod());

	}

	private Quotation mockQuotation() {

		Quotation quotation = new Quotation();
		quotation.setQuotationId("12345");
		quotation.setCountry("KE");

		HomeQuote homeQuote = new HomeQuote();
		homeQuote.setMode("add");
		homeQuote.setProductCode("1002");
		homeQuote.setQuotationNumber("12345");
		homeQuote.setPaymentMethod("07");
		homeQuote.setLobCode("10");
		HomeRisk homeRisk = new HomeRisk();

		List<HomeSmiInfo> smiInfoList = new ArrayList<>();
		HomeSmiInfo smiInfo = new HomeSmiInfo();
		smiInfo.setSmiValue(new BigDecimal("1000000"));
		smiInfoList.add(smiInfo);

		HomeSection common = getSanlamHomeSection();
		common.setSmiInfo(smiInfoList);

		homeRisk.setBuilding(common);
		homeRisk.setContent(common);
		HomeSection personallegalliability = getSanlamHomeSection();
		personallegalliability.setNoOfEmployee(new Integer(20));
		personallegalliability.setSmiInfo(smiInfoList);
		homeRisk.setPersonalLegalLiability(personallegalliability);
		HomeSection allrisks = getSanlamHomeSection();
		allrisks.setSmiInfo(smiInfoList);
		homeRisk.setAllRisk(allrisks);
		HomeSection golferscover = getSanlamHomeSection();
		golferscover.setSmiInfo(smiInfoList);
		homeRisk.setGolfersCover(golferscover);

		List<HomeRisk> risks = new ArrayList<>();
		risks.add(homeRisk);

		homeQuote.setRisks(risks);

		quotation.setDetail(homeQuote);

		return quotation;
	}

	private static HomeSection getSanlamHomeSection() {
		HomeSection obj = new HomeSection();
		obj.setSectionCode("1000");
		obj.setRiskId(new Integer(1));
		return obj;
	}

	private Quotation mockQuotationempty() {
		Quotation quotation = new Quotation();
		quotation.setQuotationId("12345");
		quotation.setCountry("KE");

		HomeQuote homeQuote = new HomeQuote();
		homeQuote.setMode("");
		homeQuote.setProductCode("1002");
		homeQuote.setQuotationNumber("12345");
		homeQuote.setPaymentMethod("");
		homeQuote.setLobCode("10");
		quotation.setDetail(homeQuote);

		return quotation;
	} 
}
