package com.sc.obs.config.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.mockito.Mock;

import com.sc.obs.quotation.Quotation;
import com.sc.obs.quotation.QuotationDetail;
import com.sc.obs.sanlam.quote.home.model.HomeBenefit;
import com.sc.obs.sanlam.quote.home.model.HomeCover;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.HomeRisk;
import com.sc.obs.sanlam.quote.home.model.HomeSection;
import com.sc.obs.sanlam.quote.home.model.HomeSmiInfo;
import com.sc.obs.sanlam.quote.home.model.isp.HomeBenefitResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeCoverResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteReqWrapper;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteResp;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteRespValue;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteRespWrapper;
import com.sc.obs.sanlam.quote.home.model.isp.HomeRiskReq;
import com.sc.obs.sanlam.quote.home.model.isp.HomeSectionReq;

public class HomeQuoteResMapperTest {
	@Mock
	private SanlamHomeQuoteResMapper mapper;
	@Mock
	HomeQuoteResp salnomResponse;

	@Test
	public void testHomeQuoteResMapper() {
		mapper = new SanlamHomeQuoteResMapper();
		salnomResponse = mockSanlamHomeQuoteResp();
		HomeQuote quoteResponse = mapper.map(salnomResponse, HomeQuote.class);
		assertNotNull(quoteResponse);

		assertEquals("KES", quoteResponse.getCurrencyCode());
		assertEquals(new BigDecimal("13098.50"), quoteResponse.getTotalPremium());
		assertEquals("PT/HOME/KENYA/QUOTATION/0012345", quoteResponse.getQuotationNumber());
		assertEquals("BENF001", quoteResponse.getBenefits().get(0).getBenefitId());
		assertEquals("Emergency medical expenses", quoteResponse.getBenefits().get(0).getDescription());
		assertEquals("KHS50,000", quoteResponse.getBenefits().get(0).getValue());
		assertEquals("3101", quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getCoverCode());
		assertEquals("Own Damage",
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getCoverName());
		assertEquals(new BigDecimal("20000"),
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getSumInsured());
		assertEquals(new BigDecimal("30000"),
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getCoverPremium());
		assertEquals("yes",
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getSumInsuredDisplayble());
		assertEquals("yes",
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getMandatoryCover());
		assertEquals("yes",
				quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getSumInsuredEditable());
		assertEquals("yes", quoteResponse.getRisks().get(0).getSections().get(0).getCovers().get(0).getCoverSelected());

	}

	private HomeQuoteResp mockSanlamHomeQuoteResp() {

		HomeQuoteResp resp = new HomeQuoteResp();
		resp.setQuotationNumber("PT/HOME/KENYA/QUOTATION/0012345");
		resp.setCurrencyCode("KES");
		resp.setNoOfDays(200L);
		resp.setTotalPremium(new BigDecimal("13098.50"));
		resp.setMessage("Home quote sampple");
		HomeCoverResp coverResp = new HomeCoverResp();
		coverResp.setCoverCode("3101");
		coverResp.setCoverName("Own Damage");
		coverResp.setSumInsured(new BigDecimal(20000.00));
		coverResp.setCoverPremium(new BigDecimal(30000.00));
		coverResp.setSumInsuredDisplayble("yes");
		coverResp.setMandatoryCover("yes");
		coverResp.setMandatoryCover("yes");
		coverResp.setSumInsuredEditable("yes");
		coverResp.setCoverSelected("yes");
		coverResp.setRate(new BigDecimal(10));

		HomeSectionReq section = new HomeSectionReq();
		section.setRiskId(new Integer(1));
		section.setSectionCode("10012");
		section.setSectionSelected("sectionSelectedYN");
		List<HomeCoverResp> cover = new ArrayList<>();
		cover.add(coverResp);
		section.setCovers(cover);

		HomeRiskReq risk = new HomeRiskReq();
		
		List<HomeSectionReq> sections = new ArrayList<>();
		sections.add(section);
		risk.setSections(sections);
		List<HomeRiskReq> risks = new ArrayList<>();
		risks.add(risk);
		resp.setHomeRisk(risks);

		HomeBenefitResp benefit = new HomeBenefitResp();
		benefit.setBenefitId("BENF001");
		benefit.setDescription("Emergency medical expenses");
		benefit.setValue("KHS50,000");
		List<HomeBenefitResp> benefits = new ArrayList<>();
		benefits.add(benefit);
		resp.setBenefits(benefits);

		return resp;
	} 
}
