package com.sc.obs.crnk.config;

import static org.junit.Assert.assertNotNull;
import io.crnk.core.boot.CrnkBoot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CrnkConfigTest {
    @Autowired
    private CrnkBoot crnkBoot;

    @Test
    public void testCrnkBootLoader(){
        assertNotNull(crnkBoot);
        assertNotNull(crnkBoot.getObjectMapper());
    }
}
