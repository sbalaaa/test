package com.sc.obs.crnk.config;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.sc.obs.sanlam.application.model.MotorApplicationDetail;

public class CrnkSubtypesConfigTest {

    @InjectMocks
    private CrnkSubtypesConfig config;
    
    @Before
    public void init()
    {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void retrieveConfigForMotorSuccessfully() {
        assertTrue(config.crnkSubTypes().contains(MotorApplicationDetail.class));
    }

}
