package com.sc.obs.data;

import com.google.common.collect.Lists;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.data.entity.*;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.utils.TestHelper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationDataFactoryTest {
    @Mock
    private CSLRequestContext cslRequestContext;

    @Mock
    private ApplicationDataStore applicationDataStore;

    @InjectMocks
    private ApplicationDataFactory applicationDataFactory;

    private BancaApplication application;

    @Before
    public void setUp(){
//        when(cslRequestContext.getRelId()).thenReturn("04A785671");
        application = TestHelper.mockBancaApplication();
        applicationDataFactory.setIspAccountNumber("123456789");
        applicationDataFactory.setEncryptPassword("password");

        when(applicationDataStore.getAppProductMaster()).thenReturn(TestHelper.mockAppProductMaster());
    }

    @Test
    public void testCreateOrderMaster(){
        OrderMaster orderMaster =  applicationDataFactory.createOrderMaster(application, new OrderMaster());

        assertNotNull(orderMaster);
    }

    @Test
    public void testCreateOrderRequesterDetails(){
        AppRequesterDetails requesterDetails = applicationDataFactory.createOrderRequesterDetails(application, new AppRequesterDetails());

        assertNotNull(requesterDetails);

        assertThat(requesterDetails.getBusinessSector(), is("02"));
        assertThat(requesterDetails.getJobTitle(), is("008"));
        assertThat(requesterDetails.getFirstName(), is("Vince"));
        assertThat(requesterDetails.getLastName(), is("Hoang"));
        assertThat(requesterDetails.getTitle(), is("Mr"));
        assertThat(requesterDetails.getGender(), is("01"));
        assertThat(requesterDetails.getPhoneNo(), is("9003387371"));
        assertThat(requesterDetails.getIdentificationId(), is("5757999757"));
        assertThat(requesterDetails.getIdentificationType(), is("1"));
    }

    @Test
    public void testCreatePremiumDetails(){
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        List<AppProductPremiumDetails> premiumDetails = applicationDataFactory.createPremiumDetails(applicationDataStore, motorDetails.premiumDetails);

        assertNotNull(premiumDetails);
        assertThat(premiumDetails.get(0).getPremiumDesc(), is("Excess Protection (+)"));
        assertThat(premiumDetails.get(0).getPremiumValue(), is(new BigDecimal("250")));
        assertThat(premiumDetails.get(1).getPremiumDesc(), is("Loss Of Use (+)"));
        assertThat(premiumDetails.get(1).getPremiumValue(), is(new BigDecimal("250")));
    }

    @Test
    public void testCreateInsuredDetails(){
        AppProductInsuredDetails insuredDetails = applicationDataFactory.createInsuredDetails(application, new AppProductInsuredDetails());

        assertNotNull(insuredDetails);
        assertThat(insuredDetails.getIdentificationId(), is("5757999757"));
        assertThat(insuredDetails.getIdentificationType(), is("1"));
        assertThat(insuredDetails.getFirstName(), is("Vince"));
        assertThat(insuredDetails.getLastName(), is("Hoang"));
        assertThat(insuredDetails.getPhoneNo(), is("9003387371"));
        assertThat(insuredDetails.getGender(), is("01"));
    }

    @Test
    public void testCreateOrderProductMotor(){
        AppProductMotor orderProductMotor = applicationDataFactory.createOrderProductMotor(application, new AppProductMotor());

        assertNotNull(orderProductMotor);
        assertThat(orderProductMotor.getChassisNumber(),is("e3hh8ew"));
        assertThat(orderProductMotor.getColorCode(), is("001"));
        assertThat(orderProductMotor.getCountryCode(), is("KE"));
        assertThat(orderProductMotor.getEngineNumber(), is("243r9ur"));
        assertThat(orderProductMotor.getVehicleCylinderCode(), is("001"));
        assertThat(orderProductMotor.getVehicleModel(), is("9992"));
        assertThat(orderProductMotor.getVehicleUsageType(), is("001"));
        assertThat(orderProductMotor.getVehicleType(), is("001"));
    }

    @Test
    public void testCreateOrderProductPayment(){
        OrderProductPayment payment = applicationDataFactory.createOrderProductPayment(application, new OrderProductPayment());

        assertNotNull(payment);
        assertThat(payment.getPaymentMode(), is("CASA"));
        assertThat(payment.getTxnAmt(), is(BigDecimal.valueOf(1L)));
        assertThat(payment.getTxnCurrencyCd(), is("KES"));
        assertThat(payment.getCreditAccountMaskedNo(), is("XXXXX6789"));
        assertThat(payment.getDebitAccountMaskedNo(), is("XXXXXXXXX2600"));
    }

    @Test
    public void testCreatePolicy(){
        AppProductPolicy policy = applicationDataFactory.createOrderProductPolicy(application);

        assertNotNull(policy);
        assertThat(policy.getPolicyNo(), is("P/100/1002/2018/00669"));
        assertThat(policy.getPolicyMasterNo(), is("P/100/1002/2018/00669"));
        assertThat(policy.getPaymentTransCd(), is("Q/100/1002/2018/18496"));
    }

    @Test
    public void testCreateCoverDetails(){
        List<AppProductCoverDetails> coverDetailsList = applicationDataFactory.createOrderProductCoverDetails(application);

        assertNotNull(coverDetailsList);

        assertThat(coverDetailsList.get(0).getCoverCode(), is("3196"));
        assertThat(coverDetailsList.get(0).getCoverName(), is("Loss of Use"));
        assertThat(coverDetailsList.get(0).getCoverPremium(), is(BigDecimal.valueOf(25000)));
        assertThat(coverDetailsList.get(0).getCoverPremiumCurrency(), is("KES"));

        assertThat(coverDetailsList.get(1).getCoverCode(), is("3101"));
        assertThat(coverDetailsList.get(1).getCoverName(), is("Own Damage"));
        assertThat(coverDetailsList.get(1).getCoverPremium(), is(BigDecimal.valueOf(350000)));
        assertThat(coverDetailsList.get(1).getCoverPremiumCurrency(), is("KES"));

        assertThat(coverDetailsList.get(2).getCoverCode(), is("3178"));
        assertThat(coverDetailsList.get(2).getCoverName(), is("Third Party Property Damage"));
        assertThat(coverDetailsList.get(2).getCoverPremium(), is(BigDecimal.valueOf(0)));
        assertThat(coverDetailsList.get(2).getCoverPremiumCurrency(), is("KES"));

    }

    @Test
    public void testCreateOrderProductMaster(){
        AppProductMaster appProductMaster = applicationDataFactory.createAppProductMaster(application);

        assertNotNull(appProductMaster);
        assertThat(appProductMaster.getProductCode(), is("MOTOR"));
        assertThat(appProductMaster.getIspQuotationCd(), is("Q/100/1002/2018/01509"));
    }

    @Test
    public void testUpdateExistingPremiumDetails() {
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        AppProductPremiumDetails premiumDetails = new AppProductPremiumDetails();
        premiumDetails.setPremiumDetailsId(1L);
        premiumDetails.setPremiumDesc("Excess Protection (+)");
        premiumDetails.setPremiumValue(BigDecimal.ONE);
        List<AppProductPremiumDetails> premiumDetailsList = applicationDataFactory.updateExistingPremiumDetails(motorDetails.getPremiumDetails(), Lists.newArrayList(premiumDetails));

        assertNotNull(premiumDetailsList);
        assertThat(premiumDetailsList.get(0).getPremiumDesc(), is("Excess Protection (+)"));
        assertThat(premiumDetailsList.get(0).getPremiumValue(), is(BigDecimal.valueOf(250)));
        assertThat(premiumDetailsList.get(1).getPremiumDesc(), is("Loss Of Use (+)"));
        assertThat(premiumDetailsList.get(1).getPremiumValue(), is(BigDecimal.valueOf(250)));
    }
}
