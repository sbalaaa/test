package com.sc.obs.data;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.config.MotorConfig;
import com.sc.obs.data.entity.*;
import com.sc.obs.data.repository.*;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.PolicyDetails;
import com.sc.obs.utils.TestHelper;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.sc.obs.data.OrderTransactionStatus.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationDataHandlerTest {

    @Mock
    private AppProductMasterRepository appProductMasterRepository;

    @Mock
    private OrderMasterRepository orderMasterRepository;

    @Mock
    private CSLRequestContext cslRequestContext;

    @Mock
    private OrderProductPaymentRepository orderPaymentRepository;

    @Mock
    private ApplicationDetailsRepository applicationRepository;

    @Mock
    private AppProductMotorRepository productMotorRepository;

    @Mock
    private AppProductMasterRepository appProductMapRepository;

    @Mock
    private AppProductMailingAddressDetailsRepository mailingAddressDetailsRepository;

    @Mock
    private AppRequesterDetailsRepository requesterDetailsRepository;

    @Mock
    private AppProductInsuredDetailsRepository insuredDetailsRepository;

    @Mock
    private AppProductPolicyRepository appProductPolicyRepository;

    @Mock
    private AppProductCoverDetailsRepository productCoverDetailsRepository;

    @Mock
    private AppProductPremiumDetailsRepository premiumDetailsRepository;

    @Mock
    private OrderProductPaymentMapRepository orderProductPaymentMapRepository;

    @Mock
    private MotorConfig config;

    @Spy
    private ApplicationDataStore applicationDataStore = new ApplicationDataStore();

    @Spy
    private ApplicationDataFactory applicationDataFactory = new ApplicationDataFactory();

    @Captor
    private ArgumentCaptor<ArrayList<AppProductCoverDetails>> coverDetailsCaptor = ArgumentCaptor.forClass((Class) List.class);

    @Captor
    private ArgumentCaptor<ArrayList<AppProductPremiumDetails>> premiumDetailsCaptor = ArgumentCaptor.forClass((Class) List.class);

    @Captor
    private ArgumentCaptor<ApplicationDetails> applicationCaptor = ArgumentCaptor.forClass(ApplicationDetails.class);

    @Captor
    private ArgumentCaptor<AppProductPolicy> policyCaptor = ArgumentCaptor.forClass(AppProductPolicy.class);

    @Captor
    private ArgumentCaptor<AppProductMailingAddressDetails> addressCaptor = ArgumentCaptor.forClass(AppProductMailingAddressDetails.class);

    @Captor
    private ArgumentCaptor<AppRequesterDetails> requesterCaptor = ArgumentCaptor.forClass(AppRequesterDetails.class);

    @Captor
    private ArgumentCaptor<AppProductInsuredDetails> insuredCaptor = ArgumentCaptor.forClass(AppProductInsuredDetails.class);

    @Captor
    private ArgumentCaptor<OrderProductPayment> paymentCaptor = ArgumentCaptor.forClass(OrderProductPayment.class);

    @Captor
    private ArgumentCaptor<OrderMaster> orderCaptor = ArgumentCaptor.forClass(OrderMaster.class);

    @Captor
    private ArgumentCaptor<AppProductMaster> appProductMasterCaptor = ArgumentCaptor.forClass(AppProductMaster.class);

    @Captor
    private ArgumentCaptor<AppProductMotor> productMotorCaptor = ArgumentCaptor.forClass(AppProductMotor.class);

    @Captor
    private ArgumentCaptor<OrderProductPaymentMap> orderProductMapCaptor = ArgumentCaptor.forClass(OrderProductPaymentMap.class);

    @InjectMocks
    private MotorApplicationDataHandler applicationDataHandler;

    private BancaApplication application;

    @Before
    public void setUp(){
//        when(cslRequestContext.getCustomerId()).thenReturn("04A785671");
        when(orderMasterRepository.findByApplicationId(anyLong())).thenReturn(TestHelper.mockOrderMaster());
        when(appProductMasterRepository.findByApplicationId(anyLong())).thenReturn(TestHelper.mockAppProductMaster());
        when(applicationRepository.findByApplicationId(anyLong())).thenReturn(TestHelper.mockApplicationDetails());
        when(mailingAddressDetailsRepository.findByRequesterId(anyLong())).thenReturn(TestHelper.mockMaillingDetails());

        when(requesterDetailsRepository.save(requesterCaptor.capture())).thenReturn(TestHelper.mockRequesterDetails());
        when(mailingAddressDetailsRepository.save(addressCaptor.capture())).thenReturn(TestHelper.mockMaillingDetails());
        when(insuredDetailsRepository.save(insuredCaptor.capture())).thenReturn(TestHelper.mockInsuredDetails());
        when(orderPaymentRepository.save(paymentCaptor.capture())).thenReturn(TestHelper.mockOrderProductPayment());
        when(orderMasterRepository.save(orderCaptor.capture())).thenReturn(TestHelper.mockOrderMaster());
        when(orderProductPaymentMapRepository.save(orderProductMapCaptor.capture())).thenReturn(TestHelper.mockOrderProductMap());
        when(appProductMasterRepository.save(appProductMasterCaptor.capture())).thenReturn(TestHelper.mockAppProductMaster());
        when(productMotorRepository.save(productMotorCaptor.capture())).thenReturn(TestHelper.mockProductMotor());
        when(appProductPolicyRepository.save(policyCaptor.capture())).thenReturn(TestHelper.mockPolicy());
        when(productCoverDetailsRepository.save(coverDetailsCaptor.capture())).thenReturn(TestHelper.mockCoverDetails());
        when(premiumDetailsRepository.save(premiumDetailsCaptor.capture())).thenReturn(TestHelper.mockPremiumDetails());
        when(applicationRepository.save(applicationCaptor.capture())).thenReturn(TestHelper.mockApplicationDetails());

        when(insuredDetailsRepository.findByProductId(anyLong())).thenReturn(TestHelper.mockInsuredDetails());
        when(premiumDetailsRepository.findByProductId(anyLong())).thenReturn(Lists.newArrayList(TestHelper.mockPremiumDetails()));
        when(requesterDetailsRepository.findByApplicationId(anyLong())).thenReturn(TestHelper.mockRequesterDetails());

        applicationDataStore.setQuotationNo("Q/100/1002/2018/01509");
        applicationDataStore.setApplicationId("123");
        applicationDataStore.setResponseWrapper(TestHelper.mockPolicyResponseWrapper());
        applicationDataStore.setOrderMasterRepository(orderMasterRepository);
        applicationDataStore.setApplicationDetailsRepository(applicationRepository);
        applicationDataStore.setAppProductMasterRepository(appProductMasterRepository);
        applicationDataStore.setAppProductMaster(TestHelper.mockAppProductMaster());
        applicationDataFactory.setCslRequestContext(cslRequestContext);
        when(config.getApplicationState(anyString(), anyString())).thenReturn(TestHelper.mockApplicationWizardState());
        when(config.getDefaultValues(anyString(), anyString())).thenReturn(TestHelper.mockFieldsAndValues());
        application = TestHelper.mockBancaApplication();
        applicationDataFactory.setIspAccountNumber("123456789");
        applicationDataFactory.setEncryptPassword("password");
    }

    @Test
    public void testInitiateOrderData(){
        application.setApplicationId(String.valueOf(1));
        applicationDataHandler.initiateOrderData(application);

        OrderProductPayment payment = paymentCaptor.getValue();
        OrderMaster order = orderCaptor.getValue();
        OrderProductPaymentMap orderProductPaymentMap = orderProductMapCaptor.getValue();

        assertNotNull(applicationDataStore.getOrderProductPayment());
        assertThat(payment.getTxnAmt(), is(BigDecimal.ONE));
        assertThat(payment.getTxnStatus(), is(PAYMENT_INITIATED));

        assertNotNull(applicationDataStore.getOrderMaster());
        assertThat(order.getOrderStatus(), is(PAYMENT_INITIATED));
        assertThat(order.getOrderAmt(), is(BigDecimal.ONE));
        assertThat(order.getOrderCurrencyCd(), is("KES"));

        assertNotNull(applicationDataStore.getOrderProducPaymentMap());
        assertNotNull(orderProductPaymentMap.getOrderMaster());
        assertNotNull(orderProductPaymentMap.getOrderPayment());
        assertNotNull(orderProductPaymentMap.getAppProductMaster());
    }

    @Test
    public void testHandlerValidationRequestData(){
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        application.setApplicationId(null);
        motorDetails.setCurrentApplicationStage("01");
        applicationDataHandler.handleApplicationReqData(application);

        assertNotNull(applicationDataStore.getApplicationDetails());
        assertNotNull(applicationDataStore.getAppProductMaster());
        assertNotNull(applicationDataStore.getAppProductMotor());

        AppProductMaster appProductMaster = appProductMasterCaptor.getValue();
        AppProductMotor productMotor = productMotorCaptor.getValue();

        assertNotNull(appProductMaster);
        assertThat(appProductMaster.getProductCode(), is(OrderTransaction.PRODUCT_MOTOR));

        assertNotNull(productMotor);
        assertThat(productMotor.getEngineNumber(), is("243r9ur"));
        assertThat(productMotor.getChassisNumber(), is("e3hh8ew"));
    }

    @Test
    public void testHandlerUpdatePersonRequestData(){
        application.setApplicationId(String.valueOf(1));
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("02");
        applicationDataHandler.handleApplicationReqData(application);

        assertNotNull(applicationDataStore.getApplicationDetails());
        assertNotNull(applicationDataStore.getAppRequesterDetails());
        assertNotNull(applicationDataStore.getInsuredDetails());

        ApplicationDetails applicationDetails = applicationCaptor.getValue();
        AppRequesterDetails requesterDetails = requesterCaptor.getValue();
        AppProductInsuredDetails insuredDetails = insuredCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_UPDATE_STARTED));

        assertNotNull(requesterDetails);
        assertNotNull(insuredDetails);
    }

    @Test
    public void testHandlerUpdatePersonRequestDataNewRequester(){
        application.setApplicationId(String.valueOf(1));
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("02");
        when(requesterDetailsRepository.findByApplicationId(anyLong())).thenReturn(null);
        applicationDataHandler.handleApplicationReqData(application);


        assertNotNull(applicationDataStore.getApplicationDetails());
        assertNotNull(applicationDataStore.getAppRequesterDetails());
        assertNotNull(applicationDataStore.getInsuredDetails());

        ApplicationDetails applicationDetails = applicationCaptor.getValue();
        AppRequesterDetails requesterDetails = requesterCaptor.getValue();
        AppProductInsuredDetails insuredDetails = insuredCaptor.getValue();
        AppProductMailingAddressDetails mailingAddressDetails = addressCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_UPDATE_STARTED));

        assertNotNull(requesterDetails);
        assertNotNull(insuredDetails);
        assertNotNull(mailingAddressDetails);
    }

    @Test
    public void testValidationSuccessData(){

        applicationDataStore.setAppProductMotor(TestHelper.mockProductMotor());
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("01");
        motorDetails.setResponseStatus("S");

        applicationDataHandler.handleApplicationResData(application);

        ApplicationDetails applicationDetails = applicationCaptor.getValue();
        List<AppProductPremiumDetails> premiumDetailsList = premiumDetailsCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_INITIATED_SUCCESS));

        assertNotNull(premiumDetailsList);
        assertThat(premiumDetailsList.get(0).getPremiumDesc(), is("Excess Protection (+)"));
        assertThat(premiumDetailsList.get(0).getPremiumValue(), is(new BigDecimal("250")));
        assertThat(premiumDetailsList.get(1).getPremiumDesc(), is("Loss Of Use (+)"));
        assertThat(premiumDetailsList.get(1).getPremiumValue(), is(new BigDecimal("250")));
    }

    @Test
    public void testValidationFailUpdateData(){
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("01");
        motorDetails.setResponseStatus("F");

        applicationDataHandler.handleApplicationResData(application);
        ApplicationDetails applicationDetails = applicationCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_INITIATED_FAIL));
    }

    @Test
    public void testUpdatePersonalDetailsFailUpdateData(){
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("02");
        motorDetails.setResponseStatus("F");

        applicationDataHandler.handleApplicationResData(application);
        ApplicationDetails applicationDetails = applicationCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_UPDATE_FAIL));
    }

    @Test
    public void testUpdatePersonalDetailsSuccessUpdateData(){
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("02");
        motorDetails.setResponseStatus("S");

        applicationDataHandler.handleApplicationResData(application);
        ApplicationDetails applicationDetails = applicationCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_UPDATE_SUCCESS));
    }

    @Test
    public void testUpdatePaymentSuccessData(){
        applicationDataStore.setOrderMaster(TestHelper.mockOrderMaster());
        applicationDataStore.setOrderProductPayment(TestHelper.mockOrderProductPayment());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("03");

        applicationDataHandler.updatePaymentSuccessData(application);

        OrderMaster orderMaster = orderCaptor.getValue();
        OrderProductPayment payment = paymentCaptor.getValue();

        assertNotNull(orderMaster);
        assertThat(orderMaster.getOrderStatus(), is(PAYMENT_SUCCESS));

        assertNotNull(payment);
        assertThat(payment.getTxnStatus(), is(PAYMENT_SUCCESS));
    }

    @Test
    public void testUpdatePaymentFailData(){
        applicationDataStore.setOrderMaster(TestHelper.mockOrderMaster());
        applicationDataStore.setOrderProductPayment(TestHelper.mockOrderProductPayment());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("03");

        applicationDataHandler.updatePaymentFailData(application);

        OrderMaster orderMaster = orderCaptor.getValue();
        OrderProductPayment payment = paymentCaptor.getValue();

        assertNotNull(orderMaster);
        assertThat(orderMaster.getOrderStatus(), is(PAYMENT_FAIL));

        assertNotNull(payment);
        assertThat(payment.getTxnStatus(), is(PAYMENT_FAIL));
    }

    @Test
    public void testUpdateApplicationFailData(){
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("03");
        motorDetails.setResponseStatus("F");
        applicationDataHandler.handleApplicationResData(application);

        OrderMaster orderMaster = orderCaptor.getValue();

        assertNotNull(orderMaster);
        assertThat(orderMaster.getOrderStatus(), is(POLICY_PURCHASE_FAIL));
    }

    @Test
    public void testUpdateApplicationExceptionData(){
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("03");
        motorDetails.setResponseStatus("F");
        applicationDataHandler.handleApplicationExceptionData(application);

        OrderMaster orderMaster = orderCaptor.getValue();

        assertNotNull(orderMaster);
        assertThat(orderMaster.getOrderStatus(), is(POLICY_PURCHASE_FAIL));
    }

    @Test
    public void testUpdatePersonalDetailsExceptionData(){
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("02");
        motorDetails.setResponseStatus("F");
        applicationDataHandler.handleApplicationExceptionData(application);

        ApplicationDetails applicationDetails = applicationCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_UPDATE_FAIL));
    }

    @Test
    public void testValidationExceptionData(){
        applicationDataStore.setApplicationDetails(TestHelper.mockApplicationDetails());

        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("01");

        applicationDataHandler.handleApplicationExceptionData(application);
        ApplicationDetails applicationDetails = applicationCaptor.getValue();

        assertNotNull(applicationDetails);
        assertThat(applicationDetails.getApplicationStatus(), is(APPLICATION_INITIATED_FAIL));
    }

    @Test
    public void testUpdateApplicationSuccessData(){
        MotorApplicationDetail motorDetails = (MotorApplicationDetail) application.getBancaApplicationDetail();
        motorDetails.setCurrentApplicationStage("03");
        motorDetails.setResponseStatus("S");

        applicationDataHandler.handleApplicationResData(application);


        PolicyDetails policyDetails = new PolicyDetails();
        policyDetails.setPolicyNumber("P/100/1002/2018/00669");

        OrderMaster orderMaster = orderCaptor.getValue();
        AppProductPolicy policy = policyCaptor.getValue();
        List<AppProductCoverDetails> coverDetailsList = coverDetailsCaptor.getValue();

        assertNotNull(orderMaster);
        assertNotNull(policy);
        assertNotNull(coverDetailsList);

        assertThat(orderMaster.getOrderStatus(), is(POLICY_PURCHASE_SUCCESS));
        assertThat(policy.getStatus(), is(POLICY_PURCHASE_SUCCESS));
        assertThat(policy.getPolicyMasterNo(), is("P/100/1002/2018/00669"));
        assertThat(policy.getPolicyNo(), is("P/100/1002/2018/00669"));
    }
}
