package com.sc.obs.edmi.config;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.obs.edmi.account.adapter.AccountValidationRequestProperties;
import com.sc.obs.edmi.fundtransfer.adapter.FundTransferRequestProperties;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EDMIConnectionPropertiesConfigTest {

    @Autowired
    private CSLSoapGatewayProperties edmiCommonConnectionProperties;

    @Autowired
    private FundTransferRequestProperties edmiFundTransferCountryProperties;
    
    @Autowired
    private AccountValidationRequestProperties edmiAccountCountryProperties;
    
    @Autowired
    private CSLSoapGatewayProperties edmiAccountConnectionProperties;

    @Autowired
    private CSLSoapGatewayProperties edmiFundTransferConnectionProperties;

    @Test
    public void testEdmiCommonConnectionPropertiesShouldLoad(){
        assertNotNull(edmiCommonConnectionProperties);
        assertNotNull(edmiCommonConnectionProperties.getPassword());
        assertNotNull(edmiCommonConnectionProperties.getUserName());
        assertNotNull(edmiCommonConnectionProperties.getSslTrustStore());
        assertNotNull(edmiCommonConnectionProperties.getSslTrustStorePassword());
    }

    @Test
    public void testEdmiFundTransferCountryPropertiesShouldLoad(){
        assertNotNull(edmiFundTransferCountryProperties);
        assertNotNull(edmiFundTransferCountryProperties.getChannelId());
        assertNotNull(edmiFundTransferCountryProperties.getMessageSender());
        assertNotNull(edmiFundTransferCountryProperties.getTransactionType());
        assertNotNull(edmiFundTransferCountryProperties.getProcessName());
        assertNotNull(edmiFundTransferCountryProperties.getEventType());
        assertNotNull(edmiFundTransferCountryProperties.getBranchNumber());
        assertNotNull(edmiFundTransferCountryProperties.getCreditDebitIndicator());
        assertNotNull(edmiFundTransferCountryProperties.getHostSystemName());
        assertNotNull(edmiFundTransferCountryProperties.getPayloadVersion());
        assertNotNull(edmiFundTransferCountryProperties.getMessageVersion());
        assertNotNull(edmiFundTransferCountryProperties.getSourceSystemName());
    }

    @Test
    public void testEdmiFundTransferConnectionPropertiesShouldLoad(){
        assertNotNull(edmiFundTransferConnectionProperties);
    }
    
    @Test
    public void testEdmiAccountValidationCountryPropertiesShouldLoad(){
        assertNotNull(edmiAccountCountryProperties);
        assertNotNull(edmiAccountCountryProperties.getChannelId());
        assertNotNull(edmiAccountCountryProperties.getHostSystemName());
        assertNotNull(edmiAccountCountryProperties.getPayloadVersion());
        assertNotNull(edmiAccountCountryProperties.getMessageVersion());
        assertNotNull(edmiAccountCountryProperties.getSourceSystemName());
    }
    
    @Test
    public void testEdmiAccountValidationConnectionPropertiesShouldLoad(){
        assertNotNull(edmiAccountConnectionProperties);
    }
}
