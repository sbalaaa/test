package com.sc.obs.sanlam.application;

import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.exception.ObsBusinessException;
import com.sc.obs.sanlam.application.common.ApplicationExceptionHandler;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.utils.TestHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.*;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class ApplicationExceptionHandlerTest {
    @InjectMocks
    private ApplicationExceptionHandler applicationExceptionHandler;

    private MotorApplicationDetail motorDetails = (MotorApplicationDetail)TestHelper.mockBancaApplication().getBancaApplicationDetail();

    @Test(expected = TechnicalException.class)
    public void testSanlamFailResponseSubmitPaymentShouldThrowException(){
        motorDetails.setCurrentApplicationStage("03");

        SanlamPolicyResponseWrapper policyResponseWrapper = TestHelper.mockPolicyResponseWrapper();

        applicationExceptionHandler.errorHandler(policyResponseWrapper, "submission");
    }

    @Test
    public void testSanlamInvalidRequestResponseSubmitPaymentShouldThrowException(){
        motorDetails.setCurrentApplicationStage("01");

        SanlamPolicyResponseWrapper policyResponseWrapper = TestHelper.mockPolicyResponseWrapper();
        policyResponseWrapper.getResponseValue().setErrorCode("INVALID_REQUEST");
        policyResponseWrapper.getResponseValue().setErrorMessage("Invalid Request");

        try {
            applicationExceptionHandler.errorHandler(policyResponseWrapper, "validation");
        } catch (TechnicalException ex){
            ErrorCode errorCode = ex.getErrorCode();
            assertThat(errorCode.getCode(), is(OBS_INVALID_REQUEST.getCode()));
            assertThat(errorCode.getDescription(), is(OBS_INVALID_REQUEST.getDescription()));
        }
    }

    @Test
    public void testSanlamQuotationExpiredResponseSubmitPaymentShouldThrowException(){
        motorDetails.setCurrentApplicationStage("01");

        SanlamPolicyResponseWrapper policyResponseWrapper = TestHelper.mockPolicyResponseWrapper();
        policyResponseWrapper.getResponseValue().setErrorCode("QUOTATION_EXPIRED");
        policyResponseWrapper.getResponseValue().setErrorMessage("Quotation Expired");

        try {
            applicationExceptionHandler.errorHandler(policyResponseWrapper, "validation");
        } catch (TechnicalException ex){
            ErrorCode errorCode = ex.getErrorCode();
            assertThat(errorCode.getCode(), is(OBS_QUOTATION_EXPIRED.getCode()));
            assertThat(errorCode.getDescription(), is(OBS_QUOTATION_EXPIRED.getDescription()));
        }
    }

    @Test
    public void testSanlamDefaulErrorResponseSubmitPaymentShouldThrowException(){
        motorDetails.setCurrentApplicationStage("01");

        SanlamPolicyResponseWrapper policyResponseWrapper = TestHelper.mockPolicyResponseWrapper();
        policyResponseWrapper.getResponseValue().setErrorCode("DEFAULT");
        policyResponseWrapper.getResponseValue().setErrorMessage("Default error");

        try {
            applicationExceptionHandler.errorHandler(policyResponseWrapper, "validation");
        } catch (ObsBusinessException ex){
            ErrorCode errorCode = ex.getErrorCode();
            assertThat(errorCode.getCode(), is(OBS_FAILURE.getCode()));
            assertThat(errorCode.getDescription(), is(OBS_FAILURE.getDescription()));
        }
    }

    @Test
    public void testSanlamApplicationSubmissionPinNotMatchedShouldThrowException(){
        motorDetails.setCurrentApplicationStage("02");

        SanlamPolicyResponseWrapper policyResponseWrapper = TestHelper.mockPolicyResponseWrapper();
        policyResponseWrapper.getResponseValue().setErrorCode("PIN_NOT_MATCHED");
        policyResponseWrapper.getResponseValue().setErrorMessage("PIN NOT MATCHED from sanlam");

        try {
            applicationExceptionHandler.errorHandler(policyResponseWrapper, "validation");
        } catch (TechnicalException ex){
            ErrorCode errorCode = ex.getErrorCode();
            assertThat(errorCode.getCode(), is(OBS_PIN_MATCHED_FAILED.getCode()));
            assertThat(errorCode.getDescription(), is(OBS_PIN_MATCHED_FAILED.getDescription()));
        }
    }
}
