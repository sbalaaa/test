package com.sc.obs.sanlam.application;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.MailingAddress;
import com.sc.obs.config.DefaultFieldConfig;
import com.sc.obs.config.MotorConfig;
import com.sc.obs.data.ApplicationDataHandler;
import com.sc.obs.data.ApplicationDataStore;
import com.sc.obs.payment.*;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.adapter.SanlamAdapter;
import com.sc.obs.sanlam.application.common.ApplicationExceptionHandler;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.*;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import lombok.Getter;
import lombok.Setter;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;

public class MotorApplicationProcessorTest {

    @InjectMocks
    private MotorApplicationProcessor processor;
    
    @Spy
    @Autowired
    private PaymentHandlerFactoryRegistry paymentHandlerFactoryRegistry;
    
    @Spy
    private PaymentProcessorFactoryImpl factory;
    
    @Spy
    private MotorApplicationMapper mapper;
    
    @Mock
    private MotorConfig config;
    
    @Spy
    private MotorApplicationDetail motorDetails;
    
    @Spy
    private Map<String,String> applicationState ;
    
    @Spy
    private ProcessorImpl paymentProcessor;

    @Mock
    private ApplicationDataHandler applicationDataHandler;

    @Mock
    private ApplicationExceptionHandler applicationExceptionHandler;

    @Mock
    private ApplicationDataStore applicationDataStore;
    
    Map<String,Map<String,Map<String,String>>> defaultVal ;
    
    Map<String,Map<String,Map<String,String>>> wizardStage;
    
    MotorApplicationMapper mapperImpl;
    
    @Spy
    SanlamAdapter sanlamAdapter;
    
    @Mock
    DefaultFieldConfig defaultConfig ;
    
    private MotorApplicationValidationReqMapper validationReqMapper;
    
    private MotorApplicationValidationResMapper validationResMapper;

    private MotorApplicationCustomerDetailsReqMapper custDetailsReqMapper;
    
    private MotorApplicationCustomerDetailsResMapper custDetailsResMapper;

    private MotorApplicationSubmissionReqMapper submissionReqMapper;

    private MotorApplicationSubmissionResMapper submissionResMapper;
    
    @Before
    public void init()
    {
        defaultVal = new HashMap<>();
        wizardStage = new HashMap<>();
        Map<String,Map<String,String>> tmp = new HashMap<>();
        
        Map defaultVal_ = new HashMap<>();
        defaultVal_.put("dealReferrer", "Digital Mobile Sales");
        defaultVal_.put("referrerPWId",  "Digital Mobile Sales");
        defaultVal_.put("paymentMethod", "05");
        
        tmp.put("sanlam", defaultVal_);
        defaultVal.put("ke", tmp);
        
        Map wizardStage_ = new HashMap<>();
        wizardStage_.put("01" ,"validation");
        wizardStage_.put("02" , "update");
        wizardStage_.put("03" , "submission");  
        
        tmp.clear();
        tmp.put("sanlam", wizardStage_);
        wizardStage.put("ke", tmp);
        //defaultConfig.setApplicationWizardState(wizardStage);
        
        mapperImpl = new MotorApplicationMapper();
        
        MockitoAnnotations.initMocks(this);
        
        validationReqMapper = new MotorApplicationValidationReqMapper();
        validationResMapper = new MotorApplicationValidationResMapper();
        custDetailsReqMapper = new MotorApplicationCustomerDetailsReqMapper();
        custDetailsResMapper = new MotorApplicationCustomerDetailsResMapper();
        submissionReqMapper  = new MotorApplicationSubmissionReqMapper();
        submissionResMapper = new MotorApplicationSubmissionResMapper();
        mapperImpl.setCustDetailsReqMapper(custDetailsReqMapper);
        mapperImpl.setSubmissionReqMapper(submissionReqMapper);
        mapperImpl.setValidationReqMapper(validationReqMapper);
        mapperImpl.setValidationResMapper(validationResMapper);
        mapperImpl.setCustDetailsResMapper(custDetailsResMapper);
        mapperImpl.setSubmissionResMapper(submissionResMapper);
        
        doReturn(defaultConfig).when(config).allDefaultConfigs();
        doReturn(defaultVal).when(defaultConfig).getFieldsAndValues();
        doReturn(wizardStage).when(defaultConfig).getApplicationWizardState();
        doReturn(applicationDataStore).when(applicationDataHandler).getApplicationDataStore();
        
        factory = new PaymentProcessorFactoryImpl(); 
    }
    
    @Test
    public void testSubmitBancaApplicationValidation() {       
        BancaApplication bancaApplicationRequest = generateBancaRequest(RequestType.VALIDATION);
        MotorApplicationDetail details = (MotorApplicationDetail)bancaApplicationRequest.getBancaApplicationDetail();
        doReturn(true).when(applicationState).containsKey(details.getCurrentApplicationStage());               
        SanlamPolicyResponseWrapper sanlamResponse = getSanlamPolicyResponseWrapper(RequestType.VALIDATION);
        doReturn(sanlamResponse).when(sanlamAdapter).callSanlam(any(), any(), any(), any(), any(), any(),any());
        List<String> sectionList = new ArrayList<>();
        sectionList.add(RequestType.VALIDATION.name().toLowerCase());
        doReturn(mapperImpl.map(bancaApplicationRequest, sectionList)).when(mapper).map(bancaApplicationRequest,sectionList);
        doReturn(mapperImpl.map(bancaApplicationRequest, sanlamResponse, sectionList)).when(mapper).map(bancaApplicationRequest, sanlamResponse, sectionList);
        BancaApplication response =  processor.submitBancaApplication(bancaApplicationRequest);
        MotorApplicationDetail motorRes = (MotorApplicationDetail)response.getBancaApplicationDetail();
        
        assertNotNull(response);
        assertEquals(motorRes.getResponseStatus(), "S");
        assertEquals("EngineNumberCheck", motorRes.getValidation().get(0).getValidationName());
        assertEquals("engineNo", motorRes.getValidation().get(0).getFieldName());
        assertEquals("pass", motorRes.getValidation().get(0).getStatus());
        assertEquals("", motorRes.getValidation().get(0).getFailedReason());
    }

    @Test
    public void testSubmitBancaApplicationUpdate() {       
        BancaApplication bancaApplicationRequest = generateBancaRequest(RequestType.UPDATE);
        MotorApplicationDetail details = (MotorApplicationDetail)bancaApplicationRequest.getBancaApplicationDetail();
        doReturn(true).when(applicationState).containsKey(details.getCurrentApplicationStage());               
        SanlamPolicyResponseWrapper sanlamResponse = getSanlamPolicyResponseWrapper(RequestType.UPDATE);
        doReturn(sanlamResponse).when(sanlamAdapter).callSanlam(any(), any(), any(), any(), any(), any(),any());
        List<String> sectionList = new ArrayList<>();
        sectionList.add(RequestType.UPDATE.name().toLowerCase());
        doReturn(mapperImpl.map(bancaApplicationRequest, sectionList)).when(mapper).map(bancaApplicationRequest,sectionList);
        doReturn(mapperImpl.map(bancaApplicationRequest, sanlamResponse, sectionList)).when(mapper).map(bancaApplicationRequest, sanlamResponse, sectionList);
        BancaApplication response =  processor.submitBancaApplication(bancaApplicationRequest);
        MotorApplicationDetail motorRes = (MotorApplicationDetail)response.getBancaApplicationDetail();
        assertNotNull(response);
        assertEquals(motorRes.getResponseStatus(), "S");
        assertEquals("Quotation Update Successfully", motorRes.getResponseStatusDescription());
    }
    
    @Test
    public void testSubmitBancaApplicationSubmission() {       
        BancaApplication bancaApplicationRequest = generateBancaRequest(RequestType.SUBMISSION);
        MotorApplicationDetail details = (MotorApplicationDetail)bancaApplicationRequest.getBancaApplicationDetail();
        doReturn(true).when(applicationState).containsKey(details.getCurrentApplicationStage());               
        SanlamPolicyResponseWrapper sanlamResponse = getSanlamPolicyResponseWrapper(RequestType.SUBMISSION);
        doReturn(sanlamResponse).when(sanlamAdapter).callSanlam(any(), any(), any(), any(), any(), any(),any());
        List<String> sectionList = new ArrayList<>();
        sectionList.add(RequestType.SUBMISSION.name().toLowerCase());
        doReturn(mapperImpl.map(bancaApplicationRequest, sectionList)).when(mapper).map(bancaApplicationRequest,sectionList);
        doReturn(mapperImpl.map(bancaApplicationRequest, sanlamResponse, sectionList)).when(mapper).map(bancaApplicationRequest, sanlamResponse, sectionList);
        doReturn(factory).when(paymentHandlerFactoryRegistry).get("KE", "CASA");
        BancaApplication response =  processor.submitBancaApplication(bancaApplicationRequest);
        MotorApplicationDetail motorRes = (MotorApplicationDetail)response.getBancaApplicationDetail();
        assertNotNull(response);
        assertEquals(motorRes.getResponseStatus(), "S");
        assertNotNull(motorRes.getPolicyDetails());
        assertEquals("P/100/1002/2018/00669", motorRes.getPolicyDetails().getPolicyNumber());
        assertEquals("3196", motorRes.getPolicyDetails().getPolicyCovers().get(0).getCoverCode());
        assertEquals("25000", motorRes.getPolicyDetails().getPolicyCovers().get(0).getCoverPremium());
        assertEquals("Loss of Use", motorRes.getPolicyDetails().getPolicyCovers().get(0).getCoverName());
    }
    
    private enum RequestType {
        VALIDATION, UPDATE, SUBMISSION;
    }
    private BancaApplication generateBancaRequest(RequestType requestType) {
        BancaApplication req = new BancaApplication();
        MotorApplicationDetail appDetails = new MotorApplicationDetail();

        if (requestType.equals(RequestType.VALIDATION)) {
            req.setCountry("KE");
            appDetails.setCurrentApplicationStage("01");
            appDetails.setVehicleModel("9992");
            appDetails.setVehicleUsageType("001");
            appDetails.setVehicleType("001");
            appDetails.setVehicleCylinderCode("001");
            appDetails.setColourCode("001");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setRegistrationNumber("1l21n3l");
            appDetails.setEngineNumber("243r9ur");
            appDetails.setChassisNumber("e3hh8ew");
        }else if (requestType.equals(RequestType.UPDATE))
        {
            req.setCountry("KE");
            appDetails.setCurrentApplicationStage("02");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setReferrerId("d");
            appDetails.setDealReferrerName("raja");
            appDetails.setNextInstallmentDate("02-Aug-2018");
            appDetails.setAutoRenewal("d");
            appDetails.setPaymentMethod("05");
            appDetails.setIdentificationNumber("5757999757");
            appDetails.setIdentityType("1");
            appDetails.setPhoneNumber("9003387371");
            appDetails.setEmailId("rajaguru.p@3i-infotech.com");
            appDetails.setFirstName("raja");
            appDetails.setMiddleName("");
            appDetails.setLastName("guru");
            appDetails.setBusinessSector("02");
            appDetails.setJobTitle("008");
            appDetails.setGender("M");
            List<MailingAddress> addresses = new ArrayList<>();
            MailingAddress address = new MailingAddress();
            address.setAddressLine1("1");
            address.setAddressLine2("xyz");
            address.setState("Kenya");
            address.setPostalCode("11112223");
            addresses.add(address);
            appDetails.setMailingAddress(addresses);
        }
        else if (requestType.equals(RequestType.SUBMISSION))
        {
            req.setCountry("KE");
            appDetails.setCurrentApplicationStage("03");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setPaymentType("01");
            appDetails.setPaymentDate("02-08-2018");
            appDetails.setPaymentReferenceNo("afedasf");
            appDetails.setCreditedToAccount("123456");
            appDetails.setAmount(new BigDecimal(2300));   
            CasaPaymentDetail casa = new CasaPaymentDetail();
            casa.setPaymentType("CASA");
            casa.setFromAccountNumber("0101800162600");
            casa.setTransactionAmount("1");
            req.setPaymentDetail(casa);
        }
        req.setBancaApplicationDetail(appDetails);
        return req;
    }
    
    private SanlamPolicyResponseWrapper getSanlamPolicyResponseWrapper(RequestType requestType)
    {
        String json = null;
        if(requestType.equals(RequestType.VALIDATION))
        {
            json  =  "{\n" + 
                    "    \"responseType\": \"S\",\n" + 
                    "    \"responseValue\": {\n" + 
                    "        \"policy\": {\n" + 
                    "            \"quotationNumber\": \"Q/100/1002/2018/01509\",\n" + 
                    "            \"validationFlag\": \"success\",\n" + 
                    "            \"validation\": [\n" + 
                    "                {\n" + 
                    "                    \"validationName\": \"EngineNumberCheck\",\n" + 
                    "                    \"fieldName\": \"engineNo\",\n" + 
                    "                    \"Status\": \"pass\",\n" + 
                    "                    \"failedReason\": \"\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"validationName\": \"ChassisNumberCheck\",\n" + 
                    "                    \"fieldName\": \"chassisNo\",\n" + 
                    "                    \"Status\": \"pass\",\n" + 
                    "                    \"failedReason\": \"\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"validationName\": \"RegistrationNumberCheck\",\n" + 
                    "                    \"fieldName\": \"registrationNo\",\n" + 
                    "                    \"Status\": \"pass\",\n" + 
                    "                    \"failedReason\": \"\"\n" + 
                    "                }\n" + 
                    "            ],\n" + 
                    "            \"premiumSplitup\": [\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Excess Protection (+)\",\n" + 
                    "                    \"value\": \"250\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Loss Of Use (+)\",\n" + 
                    "                    \"value\": \"250\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Political Violence, Terrorism And Sabotage (+)\",\n" + 
                    "                    \"value\": \"250\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Own Damage (+)\",\n" + 
                    "                    \"value\": \"3500\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Minimum Premium Adjustment Loading (+)\",\n" + 
                    "                    \"value\": \"10750\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Aa Fee Deduction - D - P (-)\",\n" + 
                    "                    \"value\": \"3000\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Total Premium\",\n" + 
                    "                    \"value\": \"12000\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Variable Access Fee\",\n" + 
                    "                    \"value\": \"300\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Marketing Fee\",\n" + 
                    "                    \"value\": \"300\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Sem Recovery Fee\",\n" + 
                    "                    \"value\": \"900\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Aa Fee (+)\",\n" + 
                    "                    \"value\": \"3000\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Policy Holders Compensation Fund (+)\",\n" + 
                    "                    \"value\": \"60\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Training Levy (+)\",\n" + 
                    "                    \"value\": \"24\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Insurance Premium Levy\",\n" + 
                    "                    \"value\": \"120\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Stamp Duty (+)\",\n" + 
                    "                    \"value\": \"40\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Sub Total\",\n" + 
                    "                    \"value\": \"4744\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Total Amount\",\n" + 
                    "                    \"value\": \"16744\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Broker Summary\",\n" + 
                    "                    \"value\": \"1200\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"description\": \"Total Commission\",\n" + 
                    "                    \"value\": \"1200\"\n" + 
                    "                }\n" + 
                    "            ]\n" + 
                    "        }\n" + 
                    "    }\n" + 
                    "}";
        }
        else if(requestType.equals(RequestType.UPDATE))
        {
            json = "{\n" + 
                    "    \"responseType\": \"S\",\n" + 
                    "    \"responseValue\": {\n" + 
                    "        \"policy\": {\n" + 
                    "            \"message\": \"Quotation Update Successfully\"\n" + 
                    "        }\n" + 
                    "    }\n" + 
                    "}";
        }
        else if(requestType.equals(RequestType.SUBMISSION))
        {
            json = "{\n" + 
                    "    \"responseType\": \"S\",\n" + 
                    "    \"responseValue\": {\n" + 
                    "        \"policy\": {\n" + 
                    "            \"policyNumber\": \"P/100/1002/2018/00669\",\n" + 
                    "            \"status\": \"Success\",\n" + 
                    "            \"premium\": \"426939\",\n" + 
                    "            \"cover\": [\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3196\",\n" + 
                    "                    \"coverPremium\": 25000,\n" + 
                    "                    \"coverName\": \"Loss of Use\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3101\",\n" + 
                    "                    \"coverPremium\": 350000,\n" + 
                    "                    \"coverName\": \"Own Damage\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3178\",\n" + 
                    "                    \"coverPremium\": 0,\n" + 
                    "                    \"coverName\": \"Third Party Property Damage\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3176\",\n" + 
                    "                    \"coverPremium\": 0,\n" + 
                    "                    \"coverName\": \"Third party Bodily injury\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3181\",\n" + 
                    "                    \"coverPremium\": 0,\n" + 
                    "                    \"coverName\": \"Wind Screen\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3182\",\n" + 
                    "                    \"coverPremium\": 0,\n" + 
                    "                    \"coverName\": \"Radio/Cassette\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3338\",\n" + 
                    "                    \"coverPremium\": 25000,\n" + 
                    "                    \"coverName\": \"Political violence, terrorism and sabotage\"\n" + 
                    "                },\n" + 
                    "                {\n" + 
                    "                    \"coverCode\": \"3333\",\n" + 
                    "                    \"coverPremium\": 25000,\n" + 
                    "                    \"coverName\": \"Excess protection\"\n" + 
                    "                }\n" + 
                    "            ]\n" + 
                    "        }\n" + 
                    "    }\n" + 
                    "}";
        }
        return CSLJsonUtils.parseJson(json, SanlamPolicyResponseWrapper.class);
        
    }
    class ProcessorImpl implements PaymentProcessor{

        @Override
        public void preProcess() {
        }

        @Override
        public PaymentResponse executePayment() {
            return new PaymentResponse(PaymentStatus.Success, null, null);
        }

        @Override
        public void processSuccess() {            
        }

        @Override
        public void processFailure() {
            // TODO Auto-generated method stub
            
        }
        
    }
    @Getter
    @Setter
    class PaymentProcessorFactoryImpl implements PaymentProcessorFactory{

        @Override
        public PaymentProcessor createPaymentProcessor(BancaApplication bancaApplicationRequest) {
            return paymentProcessor;
        }
        
    }
}
