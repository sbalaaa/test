package com.sc.obs.sanlam.application.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.MailingAddress;
import com.sc.obs.sanlam.application.mapper.HomeApplicationMapper.HomeApplicationCustomerDetailsReqMapper;
import com.sc.obs.sanlam.application.mapper.HomeApplicationMapper.HomeApplicationCustomerDetailsResMapper;
import com.sc.obs.sanlam.application.mapper.HomeApplicationMapper.HomeApplicationSubmissionReqMapper;
import com.sc.obs.sanlam.application.mapper.HomeApplicationMapper.HomeApplicationSubmissionResMapper;
import com.sc.obs.sanlam.application.model.HomeApplicationDetail;
import com.sc.obs.sanlam.application.model.HomePolicyRisk;
import com.sc.obs.sanlam.application.model.isp.HomePolicy;
import com.sc.obs.sanlam.application.model.isp.HomePolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.HomePolicyWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;

public class HomeApplicationMapperTest {

    @InjectMocks
    private HomeApplicationMapper mapper;

    private HomeApplicationCustomerDetailsReqMapper custDetailsReqMapper;
    
    private HomeApplicationCustomerDetailsResMapper custDetailsResMapper;

    private HomeApplicationSubmissionReqMapper submissionReqMapper;

    private HomeApplicationSubmissionResMapper submissionResMapper;
    
    private BancaApplication req;

    private List<String> sectionListToMap;


    
    @Before
    public void init() {
	    sectionListToMap = new ArrayList<>();
	    MockitoAnnotations.initMocks(this);
	    custDetailsReqMapper = new HomeApplicationCustomerDetailsReqMapper();
	    custDetailsResMapper = new HomeApplicationCustomerDetailsResMapper();
	    submissionReqMapper  = new HomeApplicationSubmissionReqMapper();
	    submissionResMapper = new HomeApplicationSubmissionResMapper();
	    mapper.setCustDetailsReqMapper(custDetailsReqMapper);
	    mapper.setCustDetailsResMapper(custDetailsResMapper);
	    mapper.setSubmissionReqMapper(submissionReqMapper);
	    mapper.setSubmissionResMapper(submissionResMapper);
    }

 
    @Test
    public void updateRequestMappedSuccessfully() {
        sectionListToMap.add("update");
        
    	req = generateBancaRequest(RequestType.UPDATE);
        HomeApplicationDetail homeAppDetails = (HomeApplicationDetail) req.getBancaApplicationDetail();
        assertNotNull(homeAppDetails);
        
        HomePolicy homePolicy = mapper.map(req, sectionListToMap);
        HomePolicyWrapper homePolicyWrap = new HomePolicyWrapper(homePolicy);
        assertNotNull(homePolicy);
        assertNotNull(homePolicyWrap);
        
        String[] actualBancaDetail ={req.getCountry(),req.getQuotationNumber()};
        String[] expectedBancaDetail ={homePolicyWrap.getPolicy().getCountry(),homePolicyWrap.getPolicy().getQuotationNumber()};
        assertArrayEquals(expectedBancaDetail,actualBancaDetail);
        
        String[] actualHomeAppDetail ={homeAppDetails.getReferrerId(),homeAppDetails.getNextInstallmentDate(),homeAppDetails.getAutoRenewal(),homeAppDetails.getPaymentMethod()};
        String[] expectedHomeAppDetail ={homePolicyWrap.getPolicy().getReferrerPWId(),homePolicyWrap.getPolicy().getNextInstallmentDate(),homePolicyWrap.getPolicy().getAutoRenewal(),homePolicyWrap.getPolicy().getPaymentMethod()};
        assertArrayEquals(expectedHomeAppDetail,actualHomeAppDetail);
        
        String[] actualHomeRiskDetail ={homeAppDetails.getRisks().get(0).getRiskClass(),homeAppDetails.getRisks().get(0).getRiskLocation(),homeAppDetails.getRisks().get(0).getCity(),homeAppDetails.getRisks().get(0).getDescriptionOfBuilding(),homeAppDetails.getRisks().get(0).getLocOfBuilding()};
        String[] expectedHomeRiskDetail ={ homePolicyWrap.getPolicy().getRisk().get(0).getRiskClass(), homePolicyWrap.getPolicy().getRisk().get(0).getRiskLocation(), homePolicyWrap.getPolicy().getRisk().get(0).getCity(), homePolicyWrap.getPolicy().getRisk().get(0).getDescriptionOfBuilding(), homePolicyWrap.getPolicy().getRisk().get(0).getLocOfBuilding()};
        assertArrayEquals(expectedHomeAppDetail,actualHomeAppDetail);

     }
    
    @Test
    public void updateResponseMappedSuccessfully() {
    	HomePolicyResponseWrapper sanlamResponse = generateSanlamResponse(RequestType.UPDATE);
        sectionListToMap.clear();
        sectionListToMap.add("update");
        req = generateBancaRequest(RequestType.UPDATE);
        
        BancaApplication request = mapper.map(req,sanlamResponse, sectionListToMap);
        HomeApplicationDetail home = (HomeApplicationDetail) request.getBancaApplicationDetail();
        assertNotNull(request);
        assertNotNull(home);
        
        assertEquals(sanlamResponse.getResponseType(), home.getResponseStatus());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getMessage(), home.getResponseStatusDescription());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPolicyNumber(), request.getPolicyNumber());
     }
    
    @Test
    public void submissionRequestMappedSuccessfully() {
        sectionListToMap.add("submission");
        
        req = generateBancaRequest(RequestType.SUBMISSION);
        HomeApplicationDetail homeAppDetails = (HomeApplicationDetail) req.getBancaApplicationDetail();
        assertNotNull(homeAppDetails);

        HomePolicy homePolicy = mapper.map(req, sectionListToMap);
        HomePolicyWrapper homePolicyWrap = new HomePolicyWrapper(homePolicy);
        assertNotNull(homePolicy);
        assertNotNull(homePolicyWrap);
        
        String[] actualBancaDetail ={req.getCountry(),req.getQuotationNumber()};
        String[] expectedBancaDetail ={homePolicyWrap.getPolicy().getCountry(),homePolicyWrap.getPolicy().getQuotationNumber()};
        assertArrayEquals(expectedBancaDetail,actualBancaDetail);
        
        String[] actualHomeAppDetail ={homeAppDetails.getPaymentType(),homeAppDetails.getPaymentDate(),homeAppDetails.getPaymentReferenceNo(),homeAppDetails.getCreditedToAccount(),String.valueOf(homeAppDetails.getAmount())};
        String[] expectedHomeAppDetail ={homePolicyWrap.getPolicy().getPayment().get(0).getPaymentType(),homePolicyWrap.getPolicy().getPayment().get(0).getPaymentDate(),homePolicyWrap.getPolicy().getPayment().get(0).getPaymentReferenceNo(),homePolicyWrap.getPolicy().getPayment().get(0).getAccountNo(),homePolicyWrap.getPolicy().getPayment().get(0).getPaidAmount()};
        assertArrayEquals(expectedHomeAppDetail,actualHomeAppDetail);
     }
    
    @Test
    public void submissionResponseMappedSuccessfully() {
    	HomePolicyResponseWrapper sanlamResponse = generateSanlamResponse(RequestType.SUBMISSION);
        sectionListToMap.clear();
        sectionListToMap.add("submission");
        
        req = generateBancaRequest(RequestType.SUBMISSION);
        BancaApplication request = mapper.map(req,sanlamResponse, sectionListToMap);
        HomeApplicationDetail home = (HomeApplicationDetail) request.getBancaApplicationDetail();
        assertNotNull(request);
        assertNotNull(home);
        
        assertEquals(sanlamResponse.getResponseType(), home.getResponseStatus());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPolicyNumber(), request.getPolicyNumber());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPolicyNumber(), home.getPolicyDetails().getPolicyNumber());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPremium(), home.getPolicyDetails().getPremium());
        assertNotNull(home.getPolicyDetails().getPolicyCovers());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverCode(),home.getPolicyDetails().getPolicyCovers().get(0).getCoverCode());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverName(),home.getPolicyDetails().getPolicyCovers().get(0).getCoverName());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverPremium(),home.getPolicyDetails().getPolicyCovers().get(0).getCoverPremium());
     }
    
    private enum RequestType {
        VALIDATION, UPDATE, SUBMISSION;
    }

    @Configuration
    @ComponentScan(basePackages = { "com.sc.obs.sanlam.application.mapper" })
    public static class AppConfig {
    }

   private BancaApplication generateBancaRequest(RequestType requestType) {
        req = new BancaApplication();
        HomeApplicationDetail appDetails = new HomeApplicationDetail();
        if (requestType.equals(RequestType.UPDATE)){
            req.setCountry("KE");
            req.setQuotationNumber("Q/100/1002/2018/00123");
            appDetails.setReferrerId("d");
            appDetails.setDealReferrerName("SCB");
            appDetails.setNextInstallmentDate("27-Sep-2018");
            appDetails.setAutoRenewal("y");
            appDetails.setPaymentMethod("05");
           
            HomePolicyRisk homePolicyRisk = new HomePolicyRisk();
            homePolicyRisk.setRiskLocation("LOC1");
            homePolicyRisk.setCity("CITY1");
            homePolicyRisk.setDescriptionOfBuilding("DES1");
            homePolicyRisk.setLocOfBuilding("LOCBLD1");
            List <HomePolicyRisk> homePolicyRiskList = new ArrayList<>();
            homePolicyRiskList.add(homePolicyRisk);
            appDetails.setRisks(homePolicyRiskList);
            req.setBancaApplicationDetail(appDetails);  
        } else if (requestType.equals(RequestType.SUBMISSION)) {
            req.setCountry("KE");
            req.setQuotationNumber("Q/100/1002/2018/00123");
            appDetails.setPaymentType("05");
            appDetails.setPaymentDate("27-Sep-2018");
            appDetails.setPaymentReferenceNo("65432");
            appDetails.setCreditedToAccount("0000000056");
            appDetails.setAmount(new BigDecimal(3098));     
        }
        req.setBancaApplicationDetail(appDetails);
        return req;
    }
    
   
    
    private HomePolicyResponseWrapper generateSanlamResponse(RequestType requestType)
    {
    	HomePolicyResponseWrapper res;
        String response = null ;
        if(requestType.equals(RequestType.UPDATE)) {
            response = "{\n" + 
                    "   \"responseType\":\"S\",\n" + 
                    "   \"responseValue\":{\n" + 
                    "      \"policy\":{\n" + 
                    "         \"message\":\"Quotation Updated Successfully\",\n" +
                    "         \"PolicyNo\":\"P01\"" + 
                    "      }\n" + 
                    "   }\n" + 
                    "}";
        } else if(requestType.equals(RequestType.SUBMISSION)) {
            response = "{\n" + 
                    "   \"responseType\":\"S\",\n" + 
                    "   \"responseValue\":{\n" + 
                    "      \"policy\":{\n" + 
                    "         \"policyNumber\":\"Q/100/1002/2018/00123\",\n" + 
                    "         \"status\":\"success\",\n" + 
                    "         \"premium\":3098.35,\n" + 
                    "         \"cover\":[\n" + 
                    "            {\n" + 
                    "               \"coverCode\":\"3181\",\n" + 
                    "               \"coverPremium\":15000,\n" + 
                    "               \"coverName\":\"Political\"\n" + 
                    "            },\n" + 
                    "            {\n" + 
                    "               \"coverCode\":\"3182\",\n" + 
                    "               \"coverPremium\":25000,\n" + 
                    "               \"coverName\":\"Theft\"\n" + 
                    "            },\n" + 
                    "            {\n" + 
                    "               \"coverCode\":\"3338\",\n" + 
                    "               \"coverPremium\":22500,\n" + 
                    "               \"coverName\":\"Terrorism and sabotage\"\n" + 
                    "            }\n" + 
                    "         ]\n" + 
                    "      }\n" + 
                    "   }\n" + 
                    "}";
        }  
        res = CSLJsonUtils.parseJson(response, HomePolicyResponseWrapper.class);
        return res;
    }
}
