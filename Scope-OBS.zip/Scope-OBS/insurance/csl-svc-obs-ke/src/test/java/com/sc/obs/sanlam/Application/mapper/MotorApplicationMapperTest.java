package com.sc.obs.sanlam.application.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.MailingAddress;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationCustomerDetailsReqMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationCustomerDetailsResMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationSubmissionReqMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationSubmissionResMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationValidationReqMapper;
import com.sc.obs.sanlam.application.mapper.MotorApplicationMapper.MotorApplicationValidationResMapper;
import com.sc.obs.sanlam.application.model.MotorApplicationDetail;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicy;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamValidationResponse;
import com.sc.obs.sanlam.quote.PremiumSplitup;

public class MotorApplicationMapperTest {

    @InjectMocks
    private MotorApplicationMapper mapper;

    private MotorApplicationValidationReqMapper validationReqMapper;
    
    private MotorApplicationValidationResMapper validationResMapper;

    private MotorApplicationCustomerDetailsReqMapper custDetailsReqMapper;
    
    private MotorApplicationCustomerDetailsResMapper custDetailsResMapper;

    private MotorApplicationSubmissionReqMapper submissionReqMapper;

    private MotorApplicationSubmissionResMapper submissionResMapper;
    
    private BancaApplication req;

    private MotorApplicationDetail appDetails;

    private List<String> sectionListToMap;


    
    @Before
    public void init() {
        sectionListToMap = new ArrayList<>();
        MockitoAnnotations.initMocks(this);
        validationReqMapper = new MotorApplicationValidationReqMapper();
        validationResMapper = new MotorApplicationValidationResMapper();
        custDetailsReqMapper = new MotorApplicationCustomerDetailsReqMapper();
        custDetailsResMapper = new MotorApplicationCustomerDetailsResMapper();
        submissionReqMapper  = new MotorApplicationSubmissionReqMapper();
        submissionResMapper = new MotorApplicationSubmissionResMapper();
        mapper.setCustDetailsReqMapper(custDetailsReqMapper);
        mapper.setSubmissionReqMapper(submissionReqMapper);
        mapper.setValidationReqMapper(validationReqMapper);
        mapper.setValidationResMapper(validationResMapper);
        mapper.setCustDetailsResMapper(custDetailsResMapper);
        mapper.setSubmissionResMapper(submissionResMapper);
    }

    @Test
    public void validationRequestMappedSuccessfully() {
        req = generateBancaRequest(RequestType.VALIDATION);
        sectionListToMap.add("validation");
        sectionListToMap.add("update");
        SanlamPolicy request = mapper.map(req, sectionListToMap);
        SanlamPolicyWrapper validationReq = new SanlamPolicyWrapper(request);
        String sanlamValidationRequest = CSLJsonUtils.toPrettyJson(validationReq);
        assertEquals(getSanlamValidationRequest(), sanlamValidationRequest);
     }
    
    @Test
    public void validationResponseMappedSuccessfully() {
        SanlamPolicy response = generateValidationResponse();
        SanlamPolicyResponseWrapper validationReq = new SanlamPolicyResponseWrapper();
        validationReq.setResponseType("S");
        SanlamPolicyWrapper responseVal = new SanlamPolicyWrapper(response);
        validationReq.setResponseValue(responseVal);
        
        sectionListToMap.clear();
        sectionListToMap.add("validation");
        req = generateBancaRequest(RequestType.VALIDATION);
        BancaApplication applicationsValidationRes = mapper.map(req,validationReq, sectionListToMap);
        MotorApplicationDetail motorDetails = (MotorApplicationDetail)applicationsValidationRes.getBancaApplicationDetail();
        assertEquals(validationReq.getResponseType(),motorDetails.getResponseStatus() );
        assertEquals(response.getQuotationNumber(), applicationsValidationRes.getQuotationNumber());
        assertEquals(response.getValidationFlag(), motorDetails.getValidationFlag());
        assertEquals(response.getValidation().get(0).getFailedReason(), motorDetails.getValidation().get(0).getFailedReason());
        assertEquals(response.getValidation().get(0).getFieldName(), motorDetails.getValidation().get(0).getFieldName());
        assertEquals(response.getValidation().get(0).getStatus(), motorDetails.getValidation().get(0).getStatus());
        assertEquals(response.getValidation().get(0).getValidationName(), motorDetails.getValidation().get(0).getValidationName());
        assertEquals(response.getValidation().get(1).getFailedReason(), motorDetails.getValidation().get(1).getFailedReason());
        assertEquals(response.getValidation().get(1).getFieldName(), motorDetails.getValidation().get(1).getFieldName());
        assertEquals(response.getValidation().get(1).getStatus(), motorDetails.getValidation().get(1).getStatus());
        assertEquals(response.getValidation().get(1).getValidationName(), motorDetails.getValidation().get(1).getValidationName());
        assertEquals(response.getValidation().get(2).getFailedReason(), motorDetails.getValidation().get(2).getFailedReason());
        assertEquals(response.getValidation().get(2).getFieldName(), motorDetails.getValidation().get(2).getFieldName());
        assertEquals(response.getValidation().get(2).getStatus(), motorDetails.getValidation().get(2).getStatus());
        assertEquals(response.getValidation().get(2).getValidationName(), motorDetails.getValidation().get(2).getValidationName());
        assertEquals(response.getPremiumSplitup().get(0).getDescription(), motorDetails.getPremiumDetails().get(0).getDescription());
        assertEquals(response.getPremiumSplitup().get(0).getValue(), motorDetails.getPremiumDetails().get(0).getValue());
        assertEquals(response.getPremiumSplitup().get(1).getDescription(), motorDetails.getPremiumDetails().get(1).getDescription());
        assertEquals(response.getPremiumSplitup().get(1).getValue(), motorDetails.getPremiumDetails().get(1).getValue());
     }

    @Test
    public void updateRequestMappedSuccessfully() {
        req = generateBancaRequest(RequestType.UPDATE);
        //String updateReqJasonString = CSLJsonUtils.toJson(req);
        sectionListToMap.add("update");
        SanlamPolicy request = mapper.map(req, sectionListToMap);
        SanlamPolicyWrapper validationReq = new SanlamPolicyWrapper(request);
        String sanlamValidationRequest = CSLJsonUtils.toPrettyJson(validationReq);
        assertEquals(getSanlamUpdateRequest(), sanlamValidationRequest);
     }
    
    @Test
    public void updateResponseMappedSuccessfully() {
        SanlamPolicyResponseWrapper sanlamResponse = generateResponse(RequestType.UPDATE);
        sectionListToMap.clear();
        sectionListToMap.add("update");
        req = generateBancaRequest(RequestType.UPDATE);
        BancaApplication request = mapper.map(req,sanlamResponse, sectionListToMap);
        MotorApplicationDetail motor = (MotorApplicationDetail) request.getBancaApplicationDetail();
        assertNotNull(request);
        assertNotNull(motor);
        assertEquals(sanlamResponse.getResponseType(), motor.getResponseStatus());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getMessage(), motor.getResponseStatusDescription());
     }

    @Test
    public void submissionRequestMappedSuccessfully() {
        req = generateBancaRequest(RequestType.SUBMISSION);
        //String updateReqJasonString = CSLJsonUtils.toJson(req);
        sectionListToMap.add("submission");
        SanlamPolicy request = mapper.map(req, sectionListToMap);
        SanlamPolicyWrapper validationReq = new SanlamPolicyWrapper(request);
        String sanlamValidationRequest = CSLJsonUtils.toPrettyJson(validationReq);
        assertEquals(getSanlamSubmissionRequest(), sanlamValidationRequest);
     }
    
    @Test
    public void submissionResponseMappedSuccessfully() {
        SanlamPolicyResponseWrapper sanlamResponse = generateResponse(RequestType.SUBMISSION);
        sectionListToMap.clear();
        sectionListToMap.add("submission");
        req = generateBancaRequest(RequestType.SUBMISSION);
        BancaApplication request = mapper.map(req,sanlamResponse, sectionListToMap);
        MotorApplicationDetail motor = (MotorApplicationDetail) request.getBancaApplicationDetail();
        assertNotNull(request);
        assertNotNull(motor);
        assertEquals(sanlamResponse.getResponseType(), motor.getResponseStatus());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPolicyNumber(), request.getPolicyNumber());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPolicyNumber(), motor.getPolicyDetails().getPolicyNumber());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getPremium(), motor.getPolicyDetails().getPremium());
        assertNotNull(motor.getPolicyDetails().getPolicyCovers());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverCode(),motor.getPolicyDetails().getPolicyCovers().get(0).getCoverCode());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverName(),motor.getPolicyDetails().getPolicyCovers().get(0).getCoverName());
        assertEquals(sanlamResponse.getResponseValue().getPolicy().getCover().get(0).getCoverPremium(),motor.getPolicyDetails().getPolicyCovers().get(0).getCoverPremium());
     }
    
    private enum RequestType {
        VALIDATION, UPDATE, SUBMISSION;
    }

    @Configuration
    @ComponentScan(basePackages = { "com.sc.obs.sanlam.application.mapper" })
    public static class AppConfig {
    }

    private String getSanlamValidationRequest()
    {
    return "{\n" + 
            "  \"policy\" : {\n" + 
            "    \"country\" : \"KE\",\n" + 
            "    \"quotationNumber\" : \"Q/100/1002/2018/00460\",\n" + 
            "    \"engineNumber\" : \"243r9ur\",\n" + 
            "    \"chassisNumber\" : \"e3hh8ew\",\n" + 
            "    \"registrationNumber\" : \"1l21n3l\",\n" + 
            "    \"model\" : \"9992\",\n" + 
            "    \"usageType\" : \"001\",\n" + 
            "    \"bodyType\" : \"001\",\n" + 
            "    \"cylinder\" : \"001\",\n" + 
            "    \"colour\" : \"001\"\n" + 
            "  }\n" + 
            "}";
    }
    
    private String getSanlamUpdateRequest()
    {
    return "{\n" + 
            "  \"policy\" : {\n" + 
            "    \"country\" : \"KE\",\n" + 
            "    \"quotationNumber\" : \"Q/100/1002/2018/00460\",\n" + 
            "    \"dealReferrer\" : \"raja\",\n" + 
            "    \"referrerPWId\" : \"d\",\n" + 
            "    \"autoRenewal\" : \"d\",\n" + 
            "    \"paymentMethod\" : \"05\",\n" + 
            "    \"personalDetails\" : {\n" + 
            "      \"identificationNumber\" : \"5757999757\",\n" + 
            "      \"identityType\" : \"1\",\n" + 
            "      \"phoneNumber\" : \"9003387371\",\n" + 
            "      \"emailId\" : \"rajaguru.p@3i-infotech.com\",\n" + 
            "      \"firstName\" : \"raja\",\n" + 
            "      \"middleName\" : \"\",\n" + 
            "      \"lastName\" : \"guru\",\n" + 
            "      \"businessSector\" : \"02\",\n" + 
            "      \"gender\" : \"1\",\n" + 
            "      \"jobtitle\" : \"008\",\n" + 
            "      \"address\" : {\n" + 
            "        \"address1\" : \"1\",\n" + 
            "        \"address2\" : \"xyz\",\n" + 
            "        \"state\" : \"Kenya\",\n" + 
            "        \"postalCode\" : \"11112223\"\n" + 
            "      }\n" + 
            "    }\n" + 
            "  }\n" + 
            "}";
    }
    
    private String getSanlamSubmissionRequest()
    {
        return "{\n" + 
                "  \"policy\" : {\n" + 
                "    \"country\" : \"KE\",\n" + 
                "    \"quotationNumber\" : \"Q/100/1002/2018/00460\",\n" + 
                "    \"payment\" : [ {\n" + 
                "      \"paymentType\" : \"01\",\n" + 
                "      \"paymentDate\" : \"10-10-2018\",\n" + 
                "      \"paymentReferenceNo\" : \"afedasf\",\n" + 
                "      \"accountNo\" : \"123456\",\n" + 
                "      \"paidAmount\" : \"2300\"\n" + 
                "    } ]\n" + 
                "  }\n" + 
                "}";
    }
    private BancaApplication generateBancaRequest(RequestType requestType) {
        req = new BancaApplication();
        appDetails = new MotorApplicationDetail();

        if (requestType.equals(RequestType.VALIDATION)) {
            req.setCountry("KE");
            appDetails.setVehicleModel("9992");
            appDetails.setVehicleUsageType("001");
            appDetails.setVehicleType("001");
            appDetails.setVehicleCylinderCode("001");
            appDetails.setColourCode("001");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setRegistrationNumber("1l21n3l");
            appDetails.setEngineNumber("243r9ur");
            appDetails.setChassisNumber("e3hh8ew");
        }else if (requestType.equals(RequestType.UPDATE))
        {
            req.setCountry("KE");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setReferrerId("d");
            appDetails.setDealReferrerName("raja");
            appDetails.setNextInstallmentDate("02-Aug-2018");
            appDetails.setAutoRenewal("d");
            appDetails.setPaymentMethod("05");
            appDetails.setIdentificationNumber("5757999757");
            appDetails.setIdentityType("1");
            appDetails.setPhoneNumber("9003387371");
            appDetails.setEmailId("rajaguru.p@3i-infotech.com");
            appDetails.setFirstName("raja");
            appDetails.setMiddleName("");
            appDetails.setLastName("guru");
            appDetails.setBusinessSector("02");
            appDetails.setJobTitle("008");
            appDetails.setGender("1");
            List<MailingAddress> addresses = new ArrayList<>();
            MailingAddress address = new MailingAddress();
            address.setAddressLine1("1");
            address.setAddressLine2("xyz");
            address.setState("Kenya");
            address.setPostalCode("11112223");
            addresses.add(address);
            appDetails.setMailingAddress(addresses);
        }
        else if (requestType.equals(RequestType.SUBMISSION))
        {
            req.setCountry("KE");
            req.setQuotationNumber("Q/100/1002/2018/00460");
            appDetails.setPaymentType("01");
            appDetails.setPaymentDate("10-10-2018");
            appDetails.setPaymentReferenceNo("afedasf");
            appDetails.setCreditedToAccount("123456");
            appDetails.setAmount(new BigDecimal(2300));     
            
        }
        req.setBancaApplicationDetail(appDetails);
        return req;
    }
    
    private SanlamPolicy generateValidationResponse()
    {
        SanlamPolicy validationRes = new SanlamPolicy();
        List<SanlamValidationResponse> validation  = new ArrayList<>();
        SanlamValidationResponse vRes;
        List<PremiumSplitup> premiumSplitup = new ArrayList<>();
        PremiumSplitup split;
        
        split = new PremiumSplitup();
        split.setDescription("Third Party Bodily Injury (+)");
        split.setValue("892.86");
        premiumSplitup.add(split);
        
        split = new PremiumSplitup();
        split.setDescription("Total Premium");
        split.setValue("892.86");
        premiumSplitup.add(split);
        
        vRes = new SanlamValidationResponse();
        vRes.setFailedReason("");
        vRes.setFieldName("engineNo");
        vRes.setStatus("pass");
        vRes.setValidationName("EngineNumberCheck");
        validation.add(vRes);
        
        vRes = new SanlamValidationResponse();
        vRes.setFailedReason("");
        vRes.setFieldName("chassisNo");
        vRes.setStatus("pass");
        vRes.setValidationName("ChassisNumberCheck");
        validation.add(vRes);
        
        vRes = new SanlamValidationResponse();
        vRes.setFailedReason("");
        vRes.setFieldName("registrationNo");
        vRes.setStatus("pass");
        vRes.setValidationName("RegistrationNumberCheck");
        validation.add(vRes);
        
        validationRes.setQuotationNumber("Q/100/1002/2018/00460");
        validationRes.setValidationFlag("success");
        
        validationRes.setValidation(validation);
        validationRes.setPremiumSplitup(premiumSplitup);
        
        return validationRes;
    }
    
    private SanlamPolicyResponseWrapper generateResponse(RequestType requestType)
    {
        SanlamPolicyResponseWrapper res;
        String response = null ;
        if(requestType.equals(RequestType.UPDATE))
        {
            response = getSanlamUpdateResponseJson();
        }
        else if(requestType.equals(RequestType.SUBMISSION))
        {
            response = getSanlamSubmissionResponseJson();
        }
             
        res = CSLJsonUtils.parseJson(response, SanlamPolicyResponseWrapper.class);
        return res;
    }
    private String getSanlamUpdateResponseJson()
    {
        return "{\n" + 
                "   \"responseType\":\"S\",\n" + 
                "   \"responseValue\":{\n" + 
                "      \"policy\":{\n" + 
                "         \"message\":\"Quotation Updated Successfully\"\n" + 
                "      }\n" + 
                "   }\n" + 
                "}";
        
    }
    
    private String getSanlamSubmissionResponseJson()
    {
        return "{\n" + 
                "   \"responseType\":\"S\",\n" + 
                "   \"responseValue\":{\n" + 
                "      \"policy\":{\n" + 
                "         \"policyNumber\":\"Q/100/1002/2018/01240\",\n" + 
                "         \"status\":\"success\",\n" + 
                "         \"premium\":15094.35,\n" + 
                "         \"cover\":[\n" + 
                "            {\n" + 
                "               \"coverCode\":\"3181\",\n" + 
                "               \"coverPremium\":5000,\n" + 
                "               \"coverName\":\"Wind Screen\"\n" + 
                "            },\n" + 
                "            {\n" + 
                "               \"coverCode\":\"3182\",\n" + 
                "               \"coverPremium\":5000,\n" + 
                "               \"coverName\":\"Radio/Cassette\"\n" + 
                "            },\n" + 
                "            {\n" + 
                "               \"coverCode\":\"3338\",\n" + 
                "               \"coverPremium\":500,\n" + 
                "               \"coverName\":\"Political violence, terrorism and sabotage\"\n" + 
                "            }\n" + 
                "         ]\n" + 
                "      }\n" + 
                "   }\n" + 
                "}";
        
    }
}
