package com.sc.obs.sanlam;

import static com.github.tomakehurst.wiremock.client.WireMock.aMultipart;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.netflix.hystrix.Hystrix;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.obs.ObsKEApplication;
import com.sc.obs.config.ApplicationError;
import com.sc.obs.config.ObsKEConstants;
import com.sc.obs.config.mapper.SanlamMotorQuoteResMapper;
import com.sc.obs.quotation.Quotation;
import com.sc.obs.sanlam.motorlov.service.impl.DataloaderServiceImpl;
import com.sc.obs.sanlam.motorlov.util.JunitHelperTest;
import com.sc.obs.sanlam.quote.SanlamMotorQuotationService;
import com.sc.obs.sanlam.quote.SanlamMotorQuote;
import com.sc.obs.sanlam.quote.SanlamMotorQuoteRespWrapper;
import com.sc.obs.upload.model.SanlamMotorDocumentResponseWrapper;
import com.sc.obs.upload.service.DocUploadService;

/**
 * Created by 1536544 on 7/12/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = ObsKEApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class SanlamAPIWireMockTest {

    @ClassRule
    public static WireMockRule wireMockRule = new WireMockRule(8089);

    @Autowired
    private SanlamMotorQuotationService quoteAdapter;

    @Autowired
    private SanlamMotorQuoteResMapper quoteRespMapper;

    @Autowired
    private DataloaderServiceImpl dataloaderServiceImpl;
    
    @Autowired
    private WebApplicationContext webApplicationContext;

    @BeforeClass
    public static void beforeClass(){
        Hystrix.reset();
    }
    
    @Autowired
    private DocUploadService docUploadService;

    @Test
    public void getSanlamQuoteTest()throws Exception{
        String url = "/PortalSCBMobility/quote";
        String mockResp = "{\"responseType\": \"S\",\"responseValue\": {\"quote\": {\"quotationNumber\": \"Q/100/1002/2018/00837\", \"totalPremium\": \"15,094.00\",\"currencyCode\": \"KES\",\"totalBasicCoverPremium\": 8000,\"totalRiderCoverPremium\": 500,\"totalSumAssured\": 200000,\"noOfDays\": 365,\"toDate\": \"15-APR-19\",\"risk\": [{\"riskIndex\": \"1\",\"cover\": [{\"coverCode\": \"3196\",\"coverName\": \"Loss of Use\",\"sumInsured\": 81000,\"noofDays\": 0,\"coverPremium\": 500,\"sumInsuredEditable\": \"no\",\"noOfDaysEditable\": \"no\",\"sumInsuredDisplayble\": \"no\",\"mandatoryCover\": \"yes\",\"typeOfCover\": \"BASIC\"}]}]}}}";
        stubFor(post(urlPathMatching(url))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json;charset=UTF-8")
                        .withBody(mockResp)));
        Quotation quotationRequest = new Quotation();
        ObjectMapper mapper =  new ObjectMapper();

        String quoreRequestJson = "{\"type\" : \"sanlam-motor-quote\",\"policyType\":\"staff\",\"policyDuration\":\"annual\",\"mode\":\"ADD\",\"lobCode\":\"10\",\"productCode\":\"1002\",\"fromDate\":\"03-Apr-2018 12:30\",\"paymentMethod\":\"05\",\"totalPremium\":\"13098.50\",\"toDate\":\"10-JAN-2019 12:00\",\"noOfDays\":\"10\",\"currencyCode\":\"KES\",\"totalBasicCoverPremium\":8000,\"totalRiderCoverPremium\":500,\"totalSumAssured\":200000,\"installments\" : [{					\"installmentName\" : \"1 Installment ( 30%)\",\"premium\" : \"3998.50\"},{\"installmentName\" : \"2 Installment ( 70%)\",\"premium\" : \"9100.00\"}],\"premiumSplitups\" : [{\"description\" : \"Excess Protection (+)\",\"value\" : 10000},{\"description\" : \"Training Levy (+) \",\"value\" : 200}],\"risks\" :  [{	\"riskIndex\":\"1\",\"make\":\"002\",\"typeOfCover\":\"01\",\"mfgYear\":\"2018\",\"vehicleValue\":\"200000.00\",\"vehicleCategory\":\"001\",\"typeOfVehicle\":\"\",\"cover\" : [{\"coverCode\": \"3101\",\"coverSumInsured\":\"200000\",\"noOfDays\": \"0\",\"coverSelected\":\"yes\"						}]}]					}";
        SanlamMotorQuote request = mapper.readValue(quoreRequestJson, SanlamMotorQuote.class);
        quotationRequest.setCountry("KE");
        quotationRequest.setProductType("MOTOR");
        quotationRequest.setQuotationId("Q/100/1002/2018/00837");
        quotationRequest.setDetail(request);
        Quotation response = quoteAdapter.execute(quotationRequest);
        SanlamMotorQuoteRespWrapper respWrapper = mapper.readValue(mockResp, SanlamMotorQuoteRespWrapper.class);

        //Assert.assertEquals(quotationRequest.getQuotationId(), response.getQuotationId() );
        Assert.assertEquals("Q/100/1002/2018/00837", response.getQuotationId() );
        Assert.assertEquals(quoteRespMapper.map(respWrapper.getResponseValue().getQuote(), SanlamMotorQuote.class), (SanlamMotorQuote)response.getDetail());

    }

    @Test
    public void getSanlamMotorLOVForKETest()throws Exception {
        String url = "/PortalSCBMobility/motorlovmaster";
        String mockResp = new JunitHelperTest().getMockJson("json/Sanlam_Mock_Response_KE.json");
        stubFor(get(urlPathMatching(url))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json;charset=UTF-8")
                        .withBody(mockResp)));
        assertThat(dataloaderServiceImpl.loadLovMasters("KE",ObsKEConstants.TRUE));
    }
    @Test
    public void getSanlamMotorLOvForAllCountry()throws Exception {
        String url = "/PortalSCBMobility/motorlovmaster";
        String mockResp = new JunitHelperTest().getMockJson("json/Sanlam_Mock_Response_ALL.json");
        stubFor(get(urlPathMatching(url))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json;charset=UTF-8")
                        .withBody(mockResp)));
        assertThat(dataloaderServiceImpl.loadLovMasters("KE",ObsKEConstants.TRUE));
    }
    @Test(expected = TechnicalException.class)
    public void getSanlamMotorLovForFailureCase()throws Exception {
        String url = "/PortalSCBMobility/motorlovmaster";
        String mockResp = new JunitHelperTest().getMockJson("json/Sanlam_Mock_Response_InvalidCountry.json");
        stubFor(get(urlPathMatching(url))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json;charset=UTF-8")
                        .withBody(mockResp)));
        assertThat(dataloaderServiceImpl.loadLovMasters("KE",ObsKEConstants.TRUE));
    }
    
    @Test
    public void testErrorCodes(){
    	ApplicationError testError = new ApplicationError("test","test","test");
    	assertNotNull(testError);
    	assertNotNull(testError.getCode());
    	assertNotNull(testError.getTitle());
    	assertNotNull(testError.getDescription());
    }
    
    @Test
	public void testDocUpload() throws Exception{ 
	    String url = "/PortalSCBMobility/upload";
	    String mockResp = new JunitHelperTest().getMockJson("json/sanlam_upload_response.json");
	    stubFor(post(urlPathMatching(url))
	    		  .withMultipartRequestBody(
	    				  	aMultipart()
	    				  		.withName("file[0].fileContent")
	    				  		.withHeader("Content-Type", matching("text/plain"))
	    				  )
	            .willReturn(aResponse()
	                    .withStatus(200)
	                    .withHeader("Content-Type", "application/json;charset=UTF-8")
	                    .withBody(mockResp)));
	   
	    MockMultipartFile firstFile = new MockMultipartFile("file[0].fileContent", "filename.txt", "text/plain", "some xml".getBytes());
       
        MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
        mockMvc.perform(MockMvcRequestBuilders.fileUpload("/docupload")
                        .file(firstFile)
                        .param("quotationId", "4")
                        .param("uploadState", "upload"))
                    .andExpect(status().is(200));
        mockMvc.perform(MockMvcRequestBuilders.fileUpload("/docupload")
                .file(firstFile)
                .param("quotationId", "4")
                .param("uploadState", "delete")
                .param("file[0].fileId", "1"))
            .andExpect(status().is(200));
	    ObjectMapper objectMapper = new ObjectMapper();
	    SanlamMotorDocumentResponseWrapper data = objectMapper.readValue(SanlamAPIWireMockTest.class.getClassLoader().getResourceAsStream("json/sanlam_upload_response.json"), SanlamMotorDocumentResponseWrapper.class);
	    assertNotNull(data);
    }
    
    @Test(expected=TechnicalException.class)
    public void getSanlamQuoteTimeoutTest()throws Exception{
        String url = "/PortalSCBMobility/quote";
        String mockResp = "{\"responseType\": \"S\",\"responseValue\": {\"quote\": {\"quotationNumber\": \"Q/100/1002/2018/00837\", \"totalPremium\": \"15,094.00\",\"currencyCode\": \"KES\",\"totalBasicCoverPremium\": 8000,\"totalRiderCoverPremium\": 500,\"totalSumAssured\": 200000,\"noOfDays\": 365,\"toDate\": \"15-APR-19\",\"risk\": [{\"riskIndex\": \"1\",\"cover\": [{\"coverCode\": \"3196\",\"coverName\": \"Loss of Use\",\"sumInsured\": 81000,\"noofDays\": 0,\"coverPremium\": 500,\"sumInsuredEditable\": \"no\",\"noOfDaysEditable\": \"no\",\"sumInsuredDisplayble\": \"no\",\"mandatoryCover\": \"yes\",\"typeOfCover\": \"BASIC\"}]}]}}}";
        stubFor(post(urlPathMatching(url))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withFixedDelay(30000)
                        .withHeader("Content-Type", "application/json;charset=UTF-8")
                        .withBody(mockResp)));
        Quotation quotationRequest = new Quotation();
        ObjectMapper mapper =  new ObjectMapper();

        String quoreRequestJson = "{\"type\" : \"sanlam-motor-quote\",\"policyType\":\"staff\",\"policyDuration\":\"annual\",\"mode\":\"ADD\",\"lobCode\":\"10\",\"productCode\":\"1002\",\"fromDate\":\"03-Apr-2018 12:30\",\"paymentMethod\":\"05\",\"totalPremium\":\"13098.50\",\"toDate\":\"10-JAN-2019 12:00\",\"noOfDays\":\"10\",\"currencyCode\":\"KES\",\"totalBasicCoverPremium\":8000,\"totalRiderCoverPremium\":500,\"totalSumAssured\":200000,\"installments\" : [{					\"installmentName\" : \"1 Installment ( 30%)\",\"premium\" : \"3998.50\"},{\"installmentName\" : \"2 Installment ( 70%)\",\"premium\" : \"9100.00\"}],\"premiumSplitups\" : [{\"description\" : \"Excess Protection (+)\",\"value\" : 10000},{\"description\" : \"Training Levy (+) \",\"value\" : 200}],\"risks\" :  [{	\"riskIndex\":\"1\",\"make\":\"002\",\"typeOfCover\":\"01\",\"mfgYear\":\"2018\",\"vehicleValue\":\"200000.00\",\"vehicleCategory\":\"001\",\"typeOfVehicle\":\"\",\"cover\" : [{\"coverCode\": \"3101\",\"coverSumInsured\":\"200000\",\"noOfDays\": \"0\",\"coverSelected\":\"yes\"						}]}]					}";
        SanlamMotorQuote request = mapper.readValue(quoreRequestJson, SanlamMotorQuote.class);
        quotationRequest.setCountry("KE");
        quotationRequest.setProductType("MOTOR");
        quotationRequest.setQuotationId("Q/100/1002/2018/00837");
        quotationRequest.setDetail(request);
        Quotation response = quoteAdapter.execute(quotationRequest);
        SanlamMotorQuoteRespWrapper respWrapper = mapper.readValue(mockResp, SanlamMotorQuoteRespWrapper.class);

        //Assert.assertEquals(quotationRequest.getQuotationId(), response.getQuotationId() );
        Assert.assertEquals("Q/100/1002/2018/00837", response.getQuotationId() );
        Assert.assertEquals(quoteRespMapper.map(respWrapper.getResponseValue().getQuote(), SanlamMotorQuote.class), (SanlamMotorQuote)response.getDetail());

    }
}
