package com.sc.obs.sanlam.motorlov.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

import com.sc.obs.data.entity.Staging;

/**
 * Created by 1536544 on 6/26/2018.
 */
public class StagingTest {

    @Test
    public void test_getter_setters_of_stage_object(){
        Staging staging = new Staging();
        staging.setId(1L);
        staging.setCountry("KE");
        staging.setNameOfProduct("VehicleMake");
        staging.setNameOfChildProduct("ADMIRAL:child");
        staging.setKey("ADMIRAL");
        staging.setValue("001");
        staging.setModelKey("303");
        staging.setModelValue("PICKUP");
        assertThat(staging.getCountry()).isEqualTo("KE");
        assertThat(staging.getId()).isEqualTo(1L);
        assertThat(staging.getNameOfProduct()).isEqualTo("VehicleMake");
        assertThat(staging.getNameOfChildProduct()).isEqualTo("ADMIRAL:child");
        assertThat(staging.getKey()).isEqualTo("ADMIRAL");
        assertThat(staging.getValue()).isEqualTo("001");
        assertThat(staging.getModelKey()).isEqualTo("303");
        assertThat(staging.getModelValue()).isEqualTo("PICKUP");
        assertThat(staging.toString()).contains("PICKUP");


        Staging stagingwithargConstructor = new Staging("VehicleMake","KE","001","ADMIRAL","ADMIRAL:child","303","PICKUP");
        assertThat(stagingwithargConstructor.getCountry()).isEqualTo("KE");
        //assertThat(stagingwithargConstructor.getId()).isEqualTo(1);
        assertThat(stagingwithargConstructor.getNameOfProduct()).isEqualTo("VehicleMake");
        assertThat(stagingwithargConstructor.getNameOfChildProduct()).isEqualTo("ADMIRAL:child");
        assertThat(stagingwithargConstructor.getKey()).isEqualTo("001");
        assertThat(stagingwithargConstructor.getValue()).isEqualTo("ADMIRAL");
        assertThat(stagingwithargConstructor.getModelKey()).isEqualTo("303");
        assertThat(stagingwithargConstructor.getModelValue()).isEqualTo("PICKUP");
        assertThat(stagingwithargConstructor.toString()).contains("PICKUP");
    }
}
