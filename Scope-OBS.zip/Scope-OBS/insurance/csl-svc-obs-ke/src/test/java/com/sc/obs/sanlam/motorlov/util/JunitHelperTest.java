package com.sc.obs.sanlam.motorlov.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.cxf.helpers.IOUtils;


/**
 * Created by 1536544 on 6/29/2018.
 */
public class JunitHelperTest {
    public String getMockJson(String fileLoc) throws IOException {
        ClassLoader classLoader = this.getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(fileLoc);
        return IOUtils.toString(inputStream);

    }

   /* @Test
    public void compare_response_json() throws Exception{

        String reponseObject1 = getMockJson("json/Sanlam_Response_ALL.json");
        String reponseObject2 = getMockJson("json/Sanlam_Response_KE.json");

        assertThat(reponseObject1.equals(reponseObject2)).isTrue();
    }*/
}
