package com.sc.obs.sanlam.quote.home;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import com.sc.obs.sanlam.application.common.ApplicationErrorCode;
import com.sc.obs.sanlam.quote.home.model.HomeQuote;
import com.sc.obs.sanlam.quote.home.model.isp.HomeQuoteRespWrapper;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.obs.config.mapper.SanlamHomeQuoteReqMapper;
import com.sc.obs.config.mapper.SanlamHomeQuoteResMapper;
import com.sc.obs.quotation.Quotation;
import com.sc.obs.sanlam.adapter.SanlamAdapter;

public class HomeQuotationServiceTest {

	@Mock
	private HomeQuotationService homeServiceCall;

	@Mock
	private SanlamHomeQuoteReqMapper reqMapper;

	@Mock
	private SanlamHomeQuoteResMapper resMapper;

	@Mock
	HomeQuote homeQuote;

	@Mock
	private SanlamAdapter sanlamAdapter;

	/* Mock class Initialization */
	@Before
	public void initSetupMock() {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testHomeQuotationMockCreation() {
		assertNotNull(homeServiceCall);
	}

	@Test
	public void callValidateRequestService() throws Exception {
		String quoteRequest = getSanlamHomeRequest();
		ObjectMapper mapper = new ObjectMapper();
		Quotation request = new Quotation();
		HomeQuote quoteDetail = reqMapper.map(quoteRequest, HomeQuote.class);
		request.setCountry("KE");
		request.setProductType("Home");
		request.setQuotationId("Q/100/1002/2018/00837");
		request.setDetail(quoteDetail);
		when(homeServiceCall.validate(request)).thenReturn(true);
	}

	@Test
	public void validationResponseCallSanlamSuccessfully() throws Exception {
		String mockResp = "{\"responseType\":\"S\",    \"responseValue\":{       \"quote\":{          \"quotationNumber\":\"PT/HOME/KENYA/QUOTATION/0012345\",          \"totalPremium\":\"13098.50\",          \"toDate\":\"31-DEC-2018 12:00\",          \"noOfDays\":\"365\",          \"currencyCode\":\"KES\",          \"commission\":\"\",          \"vat\":\"20\",          \"message\":\"Home quote sampple\",          \"homeRisk\":[             {               \"section\":[                   {                      \"sectionCode\":\"\",                      \"riskID\":\"1\",                      \"sectionSelectedYN\":\"yes\",                      \"sectionPremium\":\"\",                      \"cover\":[                         {                            \"coverCode\":\"\",                            \"coverName\":\"\",                            \"sumInsured\":\"\",                            \"coverPremium\":\"\",                            \"sumInsuredDisplaybleYN\":\"\",                            \"mandatoryCoverYN\":\"\",                            \"sumInsuredEditableYN\":\"\",                            \"coverSelectedYN\":\"\",                            \"rate\":\"\"                         },                         {                            \"coverCode\":\"\",                            \"coverName\":\"\",                            \"sumInsured\":\"\",                            \"coverPremium\":\"\",                            \"sumInsuredDisplaybleYN\":\"\",                            \"mandatoryCoverYN\":\"\",                            \"sumInsuredEditableYN\":\"\",                            \"coverSelectedYN\":\"\",                            \"rate\":\"\"                         }                      ]                   }                ]             }          ],          \"benefits\":[{\"benefitID\":\"BENF001\",                \"description\":\"\",                \"value\":\"\"             },             {                \"benefitID\":\"BENF002\",                \"description\":\"\",                \"value\":\"\"             }          ]       }    } }";
		ObjectMapper mapper = new ObjectMapper();
		HomeQuoteRespWrapper quoteResponseWrapper = mapper.readValue(mockResp, HomeQuoteRespWrapper.class);
		when(sanlamAdapter.callSanlam(any(), any(), any(), any(), any(), any())).thenReturn(quoteResponseWrapper);	
		assertEquals(new BigDecimal("20"), quoteResponseWrapper.getResponseValue().getQuote().getVat());
		assertEquals("Home quote sampple", quoteResponseWrapper.getResponseValue().getQuote().getMessage());				
		assertEquals("KES", quoteResponseWrapper.getResponseValue().getQuote().getCurrencyCode());
		assertEquals("PT/HOME/KENYA/QUOTATION/0012345",
				quoteResponseWrapper.getResponseValue().getQuote().getQuotationNumber());	
		
		String sanlamValidationRequest = CSLJsonUtils.toPrettyJson(quoteResponseWrapper);
		assertNotNull(sanlamValidationRequest);	
				

	}

	@Test
	public void serviceCallfailed() throws Exception {
		try {
			when(sanlamAdapter.callSanlam(any(), any(), any(), any(), any(), any()))
					.thenThrow(new TechnicalException(ApplicationErrorCode.OBS_QUOTATION_FALURE, "exception"));
		} catch (Exception e) {
			assertEquals(e.getMessage(), ApplicationErrorCode.OBS_QUOTATION_FALURE);
		}

	}

	private String getSanlamHomeRequest() {
		return "{\"policyType\": \"client\",         \"type\": \"sanlam-home-quote\",         \"mode\": \"add\",         \"lobCode\": \"10\",         \"productCode\": \"1002\",         \"fromDate\": \"02-Jul-2018 00:00\",         \"paymentMethod\": \"07\",         \"risks\": [           {             \"buildings\":{                \"sectionCode\":\"200201\",                \"riskId\":\"1\",                \"riskClass\":\"001\",                \"riskLocation\":\"01\",                \"city\":\"CHN\",                \"descriptionOfBuilding\":\"hospital with 10 Floors - buildings\",                                \"smiInfo\":[                   {                      \"riskId\":\"\",                      \"sectionCode\":\"\",                      \"smiDescription\":\"\",                      \"smiValue\":\"\"                   }                ]             },             \"contents\":{                \"sectionCode\":\"200202\",                \"riskId\":\"1\",                \"riskClass\":\"001\",                \"riskLocation\":\"01\",                \"city\":\"CHN\",                \"descriptionOfBuilding\":\"hospital with 10 Floors - contents\",                                \"smiInfo\":[                   {                      \"riskId\":\"\",                      \"sectionCode\":\"\",                      \"smiDescription\":\"\",                      \"smiValue\":\"\"                   }                ]             },             \"personallegalliability\":{                \"sectionCode\":\"200203\",                \"riskId\":\"1\",                \"riskClass\":\"001\",                \"riskLocation\":\"01\",                \"city\":\"CHN\",                \"descriptionOfBuilding\":\"hospital with 10 Floors - personal\",                                \"smiInfo\":[                   {                      \"riskId\":\"\",                      \"sectionCode\":\"\",                      \"smiDescription\":\"\",                      \"smiValue\":\"\"                   }                ]             },             \"allrisks\":{                \"sectionCode\":\"200204\",                \"riskId\":\"1\",                \"riskClass\":\"001\",                \"riskLocation\":\"01\",                \"city\":\"CHN\",                \"descriptionOfBuilding\":\"hospital with 10 Floors -allrisks\",                                \"smiInfo\":[                   {                      \"riskId\":\"\",                      \"sectionCode\":\"\",                      \"smiDescription\":\"\",                      \"smiValue\":\"\"                   }                ]             },             \"golferscover\":{                \"sectionCode\":\"200205\",                \"riskId\":\"1\",                \"riskClass\":\"001\",                \"riskLocation\":\"01\",                \"city\":\"CHN\",                \"descriptionOfBuilding\":\"hospital with 10 Floors - golfs\",                                \"smiInfo\":[                   {                      \"riskId\":\"\",                      \"sectionCode\":\"\",                      \"smiDescription\":\"\",                      \"smiValue\":\"\"                   }                ]             }          }         ]       }";
	}
	private String getReponse(){
		String res= "{\n" +
				"  \"responseType\" : \"S\",\n" +
				"  \"responseValue\" : {\n" +
				"    \"quote\" : {\n" +
				"      \"quotationNumber\" : \"PT/HOME/KENYA/QUOTATION/0012345\",\n" +
				"      \"totalPremium\" : 13098.50,\n" +
				"      \"toDate\" : \"31-Dec-18\",\n" +
				"      \"noOfDays\" : 365,\n" +
				"      \"currencyCode\" : \"KES\",\n" +
				"      \"vat\" : 20,\n" +
				"      \"message\" : \"Home quote sampple\",\n" +
				"      \"risk\" : [ {\n" +				
				"        \"section\" : [ {\n" +
				"          \"sectionCode\" : \"\",\n" +
				"          \"sectionSelectedYN\" : \"yes\",\n" +
				"          \"riskID\" : "+1+",\n" +
				"          \"cover\" : [ {\n" +
				"            \"coverCode\" : \"\",\n" +
				"            \"coverName\" : \"\",\n" +
				"            \"sumInsuredDisplaybleYN\" : \"\",\n" +
				"            \"mandatoryCoverYN\" : \"\",\n" +
				"            \"sumInsuredEditableYN\" : \"\",\n" +
				"            \"coverSelectedYN\" : \"\"\n" +
				"          }, {\n" +
				"            \"coverCode\" : \"\",\n" +
				"            \"coverName\" : \"\",\n" +
				"            \"sumInsuredDisplaybleYN\" : \"\",\n" +
				"            \"mandatoryCoverYN\" : \"\",\n" +
				"            \"sumInsuredEditableYN\" : \"\",\n" +
				"            \"coverSelectedYN\" : \"\"\n" +
				"         } ]\n" +
				"        } ]\n" +
				"      } ],\n" +
				"      \"benefits\" : [ {\n" +				
				"        \"description\" : \"\",\n" +
				"        \"value\" : \"\"\n" +
				"        \"benefitID\" : \"BENF001\"\n" +
				"      }, {\n" +				
				"        \"description\" : \"\",\n" +
				"        \"value\" : \"\"\n" +
				"        \"benefitID\" : \"BENF002\"\n" +
				"      } ]\n" +
				"    }\n" +
				"  }\n" +
				"}";
		return res;
	}
}
