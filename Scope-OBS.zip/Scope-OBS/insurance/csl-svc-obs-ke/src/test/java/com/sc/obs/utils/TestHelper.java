package com.sc.obs.utils;

import com.google.common.collect.Lists;
import com.sc.corebanking.v6.account.Account;
import com.sc.corebanking.v6.account.AccountInfo;
import com.sc.corebanking.v6.account.DocTypeRefComDataTypeString;
import com.sc.corebanking.v6.account.GetAccountDetailsResPayload;
import com.sc.corebanking.v6.account.SubsidiaryAccountMasterRelationship;
import com.sc.corebanking.v6.transaction.PostTransactionRes;
import com.sc.corebanking.v6.transaction.PostTransactionResPayload;
import com.sc.corebanking.v6.transaction.Transaction;
import com.sc.corebanking.v6.transaction.TransactionInfo;
import com.sc.corebanking.v6.transaction.TransactionResponse;
import com.sc.corebanking.v6.ws.provider.account.GetAccountDetailsRes;
import com.sc.obs.application.BancaApplication;
import com.sc.obs.application.MailingAddress;
import com.sc.obs.data.entity.*;
import com.sc.obs.edmi.account.adapter.AccountValidationResponse;
import com.sc.obs.edmi.account.adapter.AccountValidationStatus;
import com.sc.obs.payment.PaymentResponse;
import com.sc.obs.payment.PaymentStatus;
import com.sc.obs.payment.casa.CasaPaymentDetail;
import com.sc.obs.sanlam.application.model.*;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicy;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyResponseWrapper;
import com.sc.obs.sanlam.application.model.isp.SanlamPolicyWrapper;
import com.sc.scbcorebankingtransaction.v6.ws.provider.transaction.PostTransactionResponse;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sc.obs.data.OrderTransaction.CHANNEL_MOBILE_CODE;
import static com.sc.obs.data.OrderTransaction.CHANNEL_MOBILE_NAME;
import static com.sc.obs.data.OrderTransactionStatus.PAYMENT_INITIATED;
import static com.sc.obs.sanlam.application.common.ApplicationErrorCode.OBS_FAILURE;

public class TestHelper {

    private TestHelper(){}

    public static PostTransactionResponse mockSuccessKEFundTransferResponse() {
        PostTransactionResponse postTransactionResponse = new PostTransactionResponse();
        PostTransactionRes postTransactionRes = new PostTransactionRes();
        PostTransactionResPayload postTransactionResPayload = new PostTransactionResPayload();
        Transaction transaction = new Transaction();
        TransactionInfo transactionInfo = new TransactionInfo();
        transactionInfo.setAccountFullName("Vince Hoang");

        TransactionResponse transactionResponse = new TransactionResponse();
        transactionResponse.setCode("10000");
        transactionResponse.setDescription("Request completed successfully");

        transactionInfo.setTransactionResponse(transactionResponse);

        transaction.setTransactionInfo(transactionInfo);
        postTransactionResPayload.setPostTransactionRes(transaction);
        postTransactionRes.setPostTransactionResPayload(postTransactionResPayload);
        postTransactionResponse.setPostTransactionResponse(postTransactionRes);
        return postTransactionResponse;
    }

    public static PaymentResponse mockSuccessPaymentResponse(){
        return new PaymentResponse(PaymentStatus.Success, null, "10000");
    }

    public static CasaPaymentDetail mockCasaPaymentDetail(){
        CasaPaymentDetail casaPaymentDetail = new CasaPaymentDetail();
        casaPaymentDetail.setTransactionAmount("1");
        casaPaymentDetail.setCountryCode("KE");

        return casaPaymentDetail;
    }
    
    public static GetAccountDetailsRes mockSuccessKEAccValidationResponse() {
       	GetAccountDetailsRes getAccountDetailsRes = new GetAccountDetailsRes();
       	GetAccountDetailsResPayload getAccountDetailsResPayload = new GetAccountDetailsResPayload();
       	Account account = new Account();
       	AccountInfo accountInfo = new AccountInfo();
       	SubsidiaryAccountMasterRelationship subsidiaryAccountMasterRelationship = new SubsidiaryAccountMasterRelationship();
       	DocTypeRefComDataTypeString cid = new DocTypeRefComDataTypeString();
       	cid.setValue("A876551");
       	subsidiaryAccountMasterRelationship.setHolderRelationshipNumber(cid);
       	accountInfo.getSubsidiaryAccountMasterRelationship().add(subsidiaryAccountMasterRelationship);
       	account.setAccountInfo(accountInfo);
       	getAccountDetailsResPayload.setGetAccountDetailsRes(account);
       	getAccountDetailsRes.setGetAccountDetailsResPayload(getAccountDetailsResPayload);
           return getAccountDetailsRes;
    }
    
    public static AccountValidationResponse mockSuccessAccValResponse(){
        return new AccountValidationResponse(AccountValidationStatus.Success, null, "10000");
    }

    public static BancaApplication mockBancaApplication(){
        BancaApplication application = new BancaApplication();
        application.setApplicationId("7");
        application.setCountry("KE");
        application.setQuotationNumber("Q/100/1002/2018/01509");

        MotorApplicationDetail motorDetails = new MotorApplicationDetail();
//        motorDetails.setTypeOfCover("Comprehensive");
        motorDetails.setFirstName("Vince");
        motorDetails.setLastName("Hoang");
        motorDetails.setTitle("Mr");
        motorDetails.setGender("01");
        motorDetails.setCurrentApplicationStage("02");
        motorDetails.setPhoneNumber("9003387371");
        motorDetails.setEmailId("vincehoang@email.com");
        motorDetails.setIdentificationNumber("5757999757");
        motorDetails.setIdentityType("1");
        motorDetails.setBusinessSector("02");
        motorDetails.setJobTitle("008");
        motorDetails.setNextInstallmentDate("01-10-2018");
        motorDetails.setProductCode("MOTOR");
        motorDetails.setVehicleModel("9992");
        motorDetails.setVehicleCylinderCode("001");
        motorDetails.setVehicleType("001");
        motorDetails.setVehicleUsageType("001");
        motorDetails.setColourCode("001");
        motorDetails.setRegistrationNumber("1l21n3l");
        motorDetails.setEngineNumber("243r9ur");
        motorDetails.setChassisNumber("e3hh8ew");
        motorDetails.setPaymentReferenceNo("Q/100/1002/2018/18496");
        motorDetails.setResponseStatus("S");

        Validation validation = new Validation();
        validation.setStatus("pass");
        validation.setValidationName("EngineNumberCheck");
        validation.setFieldName("engineNo");
        validation.setFailedReason("");

        PremiumDetails premiumDetails = new PremiumDetails();
        premiumDetails.setDescription("Excess Protection (+)");
        premiumDetails.setValue("250");

        PremiumDetails premiumDetails2 = new PremiumDetails();
        premiumDetails2.setDescription("Loss Of Use (+)");
        premiumDetails2.setValue("250");

        PremiumDetails premiumDetails3 = new PremiumDetails();
        premiumDetails3.setDescription("Own Damage (+)");
        premiumDetails3.setValue("250");

        PolicyDetails policyDetails = new PolicyDetails();
        policyDetails.setPolicyNumber("P/100/1002/2018/00669");
        policyDetails.setParentPolicyNumber("P/100/1002/2018/00669");
        policyDetails.setPremium(BigDecimal.valueOf(426939));

        PolicyCover cover1 = new PolicyCover();
        cover1.setCoverCode("3196");
        cover1.setCoverName("Loss of Use");
        cover1.setCoverPremium("25000");

        PolicyCover cover2 = new PolicyCover();
        cover2.setCoverCode("3101");
        cover2.setCoverName("Own Damage");
        cover2.setCoverPremium("350000");

        PolicyCover cover3 = new PolicyCover();
        cover3.setCoverCode("3178");
        cover3.setCoverName("Third Party Property Damage");
        cover3.setCoverPremium("0");

        policyDetails.setPolicyCovers(Lists.newArrayList(cover1, cover2, cover3));

        CasaPaymentDetail casaPaymentDetail = new CasaPaymentDetail();
        casaPaymentDetail.setCountryCode("KE");
        casaPaymentDetail.setPaymentType("CASA");
        casaPaymentDetail.setTransactionCurrencyCode("KES");
        casaPaymentDetail.setTransactionCurrency("KES");
        casaPaymentDetail.setTransactionAmount("1");
        casaPaymentDetail.setFromAccountNumber("0101800162600");

        MailingAddress address = new MailingAddress();
        address.setAddressLine1("1");
        address.setAddressLine2("xyz");
        address.setAddressLine3("abc");
        address.setState("Kenya");
        address.setPostalCode("11112223");

        motorDetails.setValidation(Lists.newArrayList(validation));
        motorDetails.setPremiumDetails(Lists.newArrayList(premiumDetails, premiumDetails2, premiumDetails3));
        motorDetails.setPolicyDetails(policyDetails);
        motorDetails.setMailingAddress(Lists.newArrayList(address));
        application.setBancaApplicationDetail(motorDetails);
        application.setPaymentDetail(casaPaymentDetail);

        return application;
    }

    public static Map<String, String> mockFieldsAndValues() {
        Map<String, String> map1 = new HashMap<>();
        map1.put("dealReferrer", "Digital Mobile Sales");
        map1.put("referrerPWId", "Digital Mobile Sales");
        map1.put("paymentMethod", "05");
        map1.put("autoRenewal", "");
        map1.put("title", "");
        map1.put("fromDate", "");

        return map1;
    }

    public static Map<String, String> mockApplicationWizardState() {
        Map<String, String> map1 = new HashMap<>();
        map1.put("01", "validation");
        map1.put("02", "update");
        map1.put("03", "submission");

        return map1;
    }

    public static AppProductMaster mockAppProductMaster() {
        AppProductMaster appProductMaster = new AppProductMaster();
        appProductMaster.setProductId(1L);
        appProductMaster.setProductCode("MOTOR");
        appProductMaster.setIspQuotationCd("Q/100/1002/2018/01509");
        appProductMaster.setApplicationDetails(new ApplicationDetails());

        return appProductMaster;
    }

    public static OrderProductPayment mockOrderProductPayment() {
        OrderProductPayment productPayment = new OrderProductPayment();
        productPayment.setTxnStatus(PAYMENT_INITIATED);
        productPayment.setTxnAmt(BigDecimal.ONE);

        return productPayment;
    }

    public static OrderMaster mockOrderMaster() {
        OrderMaster orderMaster = new OrderMaster();
        orderMaster.setOrderId(1L);

        return orderMaster;
    }

    public static AppProductMotor mockProductMotor() {
        AppProductMotor productMotor = new AppProductMotor();
        productMotor.setEngineNumber("243r9ur");
        productMotor.setChassisNumber("e3hh8ew");

        return productMotor;
    }

    public static OrderProductPaymentMap mockOrderProductMap() {
        OrderProductPaymentMap orderProductMap = new OrderProductPaymentMap();
        orderProductMap.setAppProductMaster(new AppProductMaster());
        orderProductMap.setOrderMaster(new OrderMaster());

        return orderProductMap;
    }

    public static AppRequesterDetails mockRequesterDetails() {
        AppRequesterDetails requesterDetails = new AppRequesterDetails();
        requesterDetails.setRequesterDetailsId(1L);

        return requesterDetails;
    }

    public static AppProductInsuredDetails mockInsuredDetails() {
        AppProductInsuredDetails insuredDetails = new AppProductInsuredDetails();
        insuredDetails.setFirstName("test");

        return insuredDetails;
    }

    public static AppProductPolicy mockPolicy() {
        AppProductPolicy policy = new AppProductPolicy();
        policy.setPolicyNo("P/100/1002/2018/00669");
        policy.setPolicyMasterNo("P/100/1002/2018/00669");

        return policy;
    }

    public static List<AppProductCoverDetails> mockCoverDetails() {
        AppProductCoverDetails coverDetails = new AppProductCoverDetails();
        coverDetails.setCoverPremium(BigDecimal.valueOf(350000));
        coverDetails.setCoverPremiumCurrency("KES");
        coverDetails.setCoverName("Loss of Use");
        coverDetails.setCoverCode("3196");

        return Lists.newArrayList(coverDetails);
    }

    public static List<AppProductPremiumDetails> mockPremiumDetails() {
        AppProductPremiumDetails premiumDetails = new AppProductPremiumDetails();
        premiumDetails.setPremiumDesc("Excess Protection (+)");
        premiumDetails.setPremiumValue(BigDecimal.valueOf(250));

        AppProductPremiumDetails premiumDetails1 = new AppProductPremiumDetails();
        premiumDetails1.setPremiumDesc("Loss Of Use (+)");
        premiumDetails1.setPremiumValue(BigDecimal.valueOf(250));

        return Lists.newArrayList(premiumDetails, premiumDetails1);
    }

    public static SanlamPolicyResponseWrapper mockPolicyResponseWrapper() {
        SanlamPolicyResponseWrapper policyResponseWrapper = new SanlamPolicyResponseWrapper();
        SanlamPolicy sanlamPolicy = new SanlamPolicy();
        SanlamPolicyWrapper policyWrapper = new SanlamPolicyWrapper(sanlamPolicy);
        policyWrapper.setErrorMessage("Sanlam API Fail");
        policyWrapper.setErrorCode(OBS_FAILURE.name());
        policyResponseWrapper.setResponseType("F");
        policyResponseWrapper.setResponseValue(policyWrapper);
        return policyResponseWrapper;
    }

    public static ApplicationDetails mockApplicationDetails() {
        ApplicationDetails applicationDetails = new ApplicationDetails();
        applicationDetails.setApplicationId(1L);
        applicationDetails.setRelId("04A785671");
        applicationDetails.setChannelName(CHANNEL_MOBILE_NAME);
        applicationDetails.setChannelCd(CHANNEL_MOBILE_CODE);

        return applicationDetails;
    }

    public static AppProductMailingAddressDetails mockMaillingDetails() {
        AppProductMailingAddressDetails mailingAddressDetails = new AppProductMailingAddressDetails();
        mailingAddressDetails.setAddressHolderType("Requester");
        mailingAddressDetails.setAddressHolderId(1L);
        mailingAddressDetails.setAddress1("address 1");

        return mailingAddressDetails;
    }
}
