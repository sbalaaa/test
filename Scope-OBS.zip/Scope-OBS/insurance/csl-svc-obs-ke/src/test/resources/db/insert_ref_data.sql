INSERT INTO OBS_CONFIG_MSTR (screen_code, field_code, product_code, country_code, channel_code,is_deleted, created_by, created_date)
VALUES ('get-quote', 'make', 'MOTOR', 'KE', 'mobile',false,'test',current_date);
INSERT INTO OBS_CONFIG_MSTR (screen_code, field_code, product_code, country_code, channel_code,is_deleted, created_by, created_date)
VALUES ('get-quote', 'model', 'MOTOR', 'KE', 'mobile',false,'test',current_date);

INSERT INTO OBS_REF_DATA (config_mstr_id, field_desc, field_val, field_val_label, language_code, is_deleted, created_by, created_date)
VALUES (1, 'Make ref data', '100', 'Ford', 'en',false,'test',current_date);
INSERT INTO OBS_REF_DATA (config_mstr_id, field_desc, field_val, field_val_label, language_code, is_deleted, created_by, created_date)
VALUES (2, 'Model ref data', '101', 'Ford Model 1', 'en',false,'test',current_date);
INSERT INTO OBS_REF_DATA (config_mstr_id, field_desc, field_val, field_val_label, language_code, is_deleted, created_by, created_date)
VALUES (2, 'Model ref data', '102', 'Ford Model 2', 'en',false,'test',current_date);

INSERT INTO OBS_REF_MAPPING (ref_pid, ref_cid, is_deleted, created_by, created_date)
VALUES (1, 2, false,'test',current_date);
INSERT INTO OBS_REF_MAPPING (ref_pid, ref_cid, is_deleted, created_by, created_date)
VALUES (1, 3, false,'test',current_date);