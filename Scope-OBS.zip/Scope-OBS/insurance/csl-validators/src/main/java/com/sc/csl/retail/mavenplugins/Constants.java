package com.sc.csl.retail.mavenplugins;

public class Constants {
	public static final String	CSL_PREFIX						= "csl-";
	public static final String	CSL_SVC_PREFIX					= "csl-svc";
	public static final String	CSL_LIB_PREFIX					= "csl-lib";
	public static final String	CSL_FEATURE_BASE				= "csl-base-features";
	public static final String	CSL_GROUP_ID					= "com.sc.csl.retail";
	
	public static final String	ADC_PREFIX						= "adc-";
	public static final String	ADC_SVC_PREFIX					= "adc-svc";
	public static final String	ADC_LIB_PREFIX					= "adc-lib";

	//added for new csl location
	public static final String	RDC_CSL_GROUP_ID					= "com.sc.rdc.csl";

	// TODO: The following Group id constants to be removed - this has been
	// added for temporarily,
	// till the legacy code is cleaned up
	public static final String	CSL_GROUP1_ID					= "com.sc.csl.retail.core.base";
	public static final String	CSL_GROUP2_ID					= "com.sc.csl.retail.core";
	public static final String	CSL_GROUP3_ID					= "com.sc.csl.retail.core.log4sc";

	public static final String	BASE_POM						= "csl-base-pom";
	public static final String	CSL_LIB_BASE					= "csl-lib-base";
	public static final String	SNAPSHOT_SUFFIX					= "-SNAPSHOT";
	public static final String	DEV_BRANCH_VERSION					= "0.0.0";

	public static final String	PROJECT_VERSION_PLACE_HOLDER	= "${project.version}";
	public static final String	DEFAULT_SERVICE_START_LEVEL		= "${service.start-level}";
	public static final String	DEFAULT_LIB_START_LEVEL			= "${lib.start-level}";
	public static final String	DEFAULT_DATASOURCE_START_LEVEL	= "${datasource.start-level}";

	public static final String	FEATURE_NAMESPACE				= "http://karaf.apache.org/xmlns/features/v1.0.0";
	public static final String	PERSISTENCE_NAMESPACE			= "http://java.sun.com/xml/ns/persistence";
	public static final String	POM_NAMESPACE					= "http://maven.apache.org/POM/4.0.0";
	public static final int		MIN_START_SERVICE_LEVEL			= 80;
	public static final int		MAX_START_SERVICE_LEVEL			= 110;
}
