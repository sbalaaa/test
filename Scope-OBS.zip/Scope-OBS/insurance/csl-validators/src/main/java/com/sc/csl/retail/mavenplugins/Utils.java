package com.sc.csl.retail.mavenplugins;

import static com.sc.csl.retail.mavenplugins.Constants.*;
import static org.apache.commons.lang3.StringUtils.endsWith;
import static org.apache.commons.lang3.StringUtils.startsWith;

public class Utils {
    public static boolean isCslService(String artifactId) {
        return artifactId.startsWith(CSL_SVC_PREFIX);
    }

    public static boolean isCslLibrary(String groupId, String artifactId) {
        return artifactId.startsWith(CSL_LIB_PREFIX)
        		|| artifactId.startsWith(ADC_LIB_PREFIX)
                || CSL_GROUP_ID.equals(groupId)
                || CSL_GROUP1_ID.equals(groupId)
                || CSL_GROUP2_ID.equals(groupId)
                || CSL_GROUP3_ID.equals(groupId);
    }

    public static boolean isSnapshot(String version) {
        return endsWith(version, SNAPSHOT_SUFFIX);
    }

    public static boolean isDevelopBranch(String version) {
        return startsWith(version, DEV_BRANCH_VERSION);
    }

    public static String getBundleVersion(String bundleUrl) {
        int firstIndex = bundleUrl.indexOf('/') + 1;
        String versionString = bundleUrl.substring(bundleUrl.indexOf('/', firstIndex) + 1);

        if(versionString.contains("/")) {
            return versionString.substring(0, versionString.indexOf('/'));
        }
        return versionString;
    }

    public static String getBundleName(String bundleUrl) {
        int firstIndex = bundleUrl.indexOf('/') + 1;
        return bundleUrl.substring(firstIndex, bundleUrl.indexOf('/', firstIndex));
    }

    public static String getBundleGroup(String bundleUrl) {
        int start = bundleUrl.lastIndexOf(':') + 1;
        int end = bundleUrl.indexOf('/');

        return bundleUrl.substring(start, end);
    }
}
