package com.sc.csl.retail.mavenplugins.checkstyle;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import org.apache.commons.lang3.StringUtils;

import static com.puppycrawl.tools.checkstyle.api.TokenTypes.DOT;
import static com.puppycrawl.tools.checkstyle.api.TokenTypes.IDENT;

public class AsyncCheck extends BaseCheck {
    private static String ASYNC = "Async";
    private static String[] allowedSuffixes = {"Async"};

    @Override
    public void visitToken(DetailAST ast) {
        if (isAnnotation(ast)) {
            DetailAST dotToken = ast.findFirstToken(DOT);
            String annotationType;

            if(dotToken != null) {
                annotationType = dotToken.findFirstToken(IDENT).getText();
            } else {
                annotationType = ast.findFirstToken(IDENT).getText();
            }

            if(ASYNC.equals(annotationType)) {
                if(!StringUtils.endsWithAny(currentMethodName, allowedSuffixes)) {
                    logError(ast, "Method name should end with Async, if annotated with @Async");
                    return;
                }
            }
        }
        else if(isClass(ast)) {
            DetailAST clazz = ast.findFirstToken(IDENT);
            currentClassName = clazz.getText();
        }
        else if(isMethod(ast)) {
            DetailAST clazz = ast.findFirstToken(IDENT);
            currentMethodName = clazz.getText();
        }
    }
}
