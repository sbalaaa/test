package com.sc.csl.retail.mavenplugins.checkstyle;

import com.puppycrawl.tools.checkstyle.api.AbstractCheck;
import com.puppycrawl.tools.checkstyle.api.DetailAST;

import static com.puppycrawl.tools.checkstyle.api.TokenTypes.*;

public abstract class BaseCheck extends AbstractCheck {
    protected String currentClassName;
    protected String currentMethodName;

    @Override
    public int[] getDefaultTokens() {
        return new int[] {ANNOTATION, CLASS_DEF, INTERFACE_DEF, METHOD_DEF};
    }

    @Override
    public void beginTree(DetailAST rootAST) {
        super.beginTree(rootAST);
        currentClassName = null;
        currentMethodName = null;
    }

    protected void logError(DetailAST ast, String message) {
        String prefix = (currentMethodName == null) ? "" : currentMethodName + " - ";
        log(ast.getLineNo(),  prefix + message);
    }

    protected String propertyValue(DetailAST propertyAST) {
        DetailAST exprAST = propertyAST.findFirstToken(EXPR);
        DetailAST valueAST = exprAST.findFirstToken(IDENT);

        if(valueAST == null) {
            DetailAST dot = exprAST.findFirstToken(DOT);
            valueAST = dot.getLastChild();
        }
        return valueAST.getText();
    }

    protected boolean isMethod(DetailAST ast) {
        return ast.getType() == METHOD_DEF;
    }

    protected boolean isClass(DetailAST ast) {
        int type = ast.getType();
        return type == CLASS_DEF || type == INTERFACE_DEF;
    }

    protected boolean isAnnotation(DetailAST ast) {
        return ast.getType() == ANNOTATION;
    }
}
