package com.sc.csl.retail.mavenplugins.checkstyle;

import com.puppycrawl.tools.checkstyle.api.DetailAST;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

import static com.puppycrawl.tools.checkstyle.api.TokenTypes.*;

public class TransactionCheck extends BaseCheck {
    private static String TRANSACTIONAL = "Transactional";
    private static String REQ_NEW_METHOD_SUFFIX = "AndCommit";
    private static String[] allowedSuffixes = {"Controller", "Service", "Processor", "Repository", "Relationship", "Resource"};

    @Override
    public void visitToken(DetailAST ast) {
        if (isAnnotation(ast)) {
            DetailAST dotToken = ast.findFirstToken(DOT);
            String annotationType;

            if(dotToken != null) {
                annotationType = dotToken.findFirstToken(IDENT).getText();
            } else {
                annotationType = ast.findFirstToken(IDENT).getText();
            }

            if(TRANSACTIONAL.equals(annotationType)) {
                if(!StringUtils.endsWithAny(currentClassName, allowedSuffixes)) {
                    logError(ast, "@Transactional allowed only in the following type of classes :" + Arrays.asList(allowedSuffixes));
                    return;
                }

                DetailAST propertyAST = ast.findFirstToken(ANNOTATION_MEMBER_VALUE_PAIR);

                while(propertyAST != null) {
                    if(propertyAST.getType() == ANNOTATION_MEMBER_VALUE_PAIR) {
                        verifyTransactionProperty(propertyAST);
                    }
                    propertyAST = propertyAST.getNextSibling();
                }
            }
        }
        else if(isClass(ast)) {
            DetailAST clazz = ast.findFirstToken(IDENT);
            currentClassName = clazz.getText();
        }
        else if(isMethod(ast)) {
            DetailAST clazz = ast.findFirstToken(IDENT);
            currentMethodName = clazz.getText();
        }
    }

    private void verifyTransactionProperty(DetailAST propertyAST) {
        String propertyName = propertyAST.findFirstToken(IDENT).getText();

        if(propertyName == null) {
            return;
        }

        if(propertyName.equals("isolation")) {
            logError(propertyAST, "Please do not specify isolation level for Transaction");
        }
        else if(propertyName.equals("propagation")) {
            String value = propertyValue(propertyAST);
            if(value.equals("REQUIRES_NEW")) {
                if(currentMethodName == null) {
                    logError(propertyAST, "@Transactional(REQUIRES_NEW) not allowed at class level");
                } else if(!currentMethodName.endsWith(REQ_NEW_METHOD_SUFFIX)) {
                    String errorMsg = "@Transactional(REQUIRES_NEW) allowed only for methods that end with suffix `" + REQ_NEW_METHOD_SUFFIX + "`";
                    logError(propertyAST, errorMsg);
                }
            } else if(!value.equals("REQUIRED")) {
                logError(propertyAST, "Only REQUIRES_NEW and REQUIRED are supported. Please contact Foundation team for more details.");
            }
        }
    }
}
