package com.sc.csl.retail.mavenplugins.model;

import lombok.Data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "aspectLibrary")
@Data
@XmlAccessorType(XmlAccessType.FIELD)
public class AspectLibrary {
    @XmlElement(name = "groupId")
    String groupId;

    @XmlElement(name = "artifactId")
    String artifactId;
}
