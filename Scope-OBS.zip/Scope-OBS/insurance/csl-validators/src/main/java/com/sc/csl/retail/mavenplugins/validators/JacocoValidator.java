package com.sc.csl.retail.mavenplugins.validators;

import edu.emory.mathcs.backport.java.util.Collections;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugin.logging.Log;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;

import java.io.File;
import java.util.List;
import java.util.Optional;

@Mojo(name = "validate-jacoco")
public class JacocoValidator extends AbstractMojo {
    @Parameter(defaultValue = "${project}", readonly = true, required = true)
    protected MavenProject project;
    private Log log = getLog();

    @Parameter(property = "validate-jacoco.skipCheck", defaultValue = "false")
    private Boolean skipCheck;

    @Parameter(property = "validate-jacoco.jacocoExcludedArtifacts")
    private List<String> jacocoExcludedArtifacts;

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        log.info("---------------------");
        log.info("Validation type : jacoco.exec validation");
        log.info("Description : Verify the jacoco.exec file exists");
        String artifactId = project.getArtifactId();
        String groupId = project.getGroupId();
        List<String> excluded = Optional.of(jacocoExcludedArtifacts).orElse(Collections.emptyList());

        if (skipCheck || excluded.contains(artifactId)) {
            log.info(String.format("Skipping jacoco.exec validation for: %s:%s", groupId, artifactId));
            return;
        }

        File jacocoExecFile = new File(project.getBasedir().getAbsolutePath() + "/target/jacoco.exec");
        if(!jacocoExecFile.exists()) {
            throw new MojoFailureException("jacoco.exec doesn't exist, improve code coverage to successfully create jacoco.exec");
        }

        log.info("Validation : pass");
    }
}
