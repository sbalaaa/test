package com.sc.csl.retail.mavenplugins.validators;

import com.sc.csl.retail.mavenplugins.Constants;
import com.sc.csl.retail.mavenplugins.model.AspectLibrary;
import com.sc.csl.retail.mavenplugins.model.Instructions;
import org.apache.commons.lang3.StringUtils;
import org.apache.maven.model.*;
import org.apache.maven.model.io.xpp3.MavenXpp3Reader;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugin.logging.Log;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.project.MavenProject;
import org.codehaus.plexus.util.xml.Xpp3Dom;
import org.codehaus.plexus.util.xml.pull.XmlPullParserException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.*;
import java.util.stream.Collectors;

import static com.sc.csl.retail.mavenplugins.Constants.*;
import static com.sc.csl.retail.mavenplugins.Utils.*;
import static org.apache.commons.lang3.StringUtils.*;

@Mojo(name = "validate-pom")
public class PomValidator extends AbstractMojo {
	@Parameter(defaultValue = "${project}", readonly = true, required = true)
	private MavenProject project;
	private Log log = getLog();
	private Model pomModel;

	private List<String> restrictedPlugins = Arrays.asList(
		"csl-pom-validator",
		"maven-checkstyle-plugin",
		"maven-surefire-plugin",
		"jacoco-maven-plugin"
	);

	@Parameter(property="validate-pom.overridableDependencies")
	private List<String> overridableDependencies;

	@Parameter(property="validate-pom.ignoreDependencies")
	private Map<String, String> ignoreDependencies;

	@Parameter(property="validate-pom.ignorePlugins")
	private Map<String, String> ignorePlugins;

	@Override
	public void execute() throws MojoFailureException {
		String artifactId = project.getArtifactId();
		if (artifactId.equals(BASE_POM)) {
			log.info("Skipping POM validation for base pom");
			return;
		}
		log.info("Validating pom file for artifact : " + artifactId);
		log.info("");

		try {
			File file = new File(project.getBasedir().getAbsolutePath() + "/pom.xml");
			MavenXpp3Reader pomReader = new MavenXpp3Reader();
			pomModel = pomReader.read(new FileReader(file));
		} catch (XmlPullParserException | IOException e) {
			throw new MojoFailureException("Error reading pom.xml", e);
		}

		validateName();
		validateSnapshotDependency();
		validateDependency();
		validatePlugin();
		validateProperties();
	}

	private void validatePluginConfig() throws MojoFailureException {
		String currentArtifactId = project.getArtifactId();
		if (currentArtifactId.equals(CSL_LIB_BASE)) {
			log.info("Skipping Plugin validation for : " + CSL_LIB_BASE);
			return;
		}


		log.info("---------------------");
		log.info("Validation type : Validation bundle plugin");
		log.info("Description : Checks to verify bundle plugin configuration");

		Build build = pomModel.getBuild();
		if (build == null)
			return;
		List<Plugin> plugins = build.getPlugins();
		if (plugins == null)
			return;

		for (Plugin plugin : plugins) {
			String artifactId = plugin.getArtifactId();

			if (restrictedPlugins.contains(artifactId)) {
				throw new MojoFailureException("You are not allowed to override the plugin : " + artifactId + ". Please remove it from pom.xml");
			}

			if (artifactId.equals("maven-bundle-plugin")) {
				validateMavenBundlePlugin(plugin);
			}
		}

		List<Plugin> pluginList = plugins.stream().filter(p -> p.getArtifactId().equals("aspectj-maven-plugin")).collect(Collectors.toList());
		if(pluginList.isEmpty()) {
			throw new MojoFailureException("Please add csl-lib-base and csl-lib-cache as aspectLibraries in aspectj-maven-plugin configuration");
		}
		validateAspectjPlugin(pluginList.get(0));
	}

	private void validateAspectjPlugin(Plugin plugin) throws MojoFailureException {
       	Xpp3Dom configuration  = (Xpp3Dom) plugin.getConfiguration();
       	String errorMessage = "Please add csl-lib-base and csl-lib-cache as aspectLibraries in aspectj-maven-plugin configuration.";
		if (configuration == null) {
			throw new MojoFailureException(errorMessage);
		}

		Xpp3Dom aspectLibrariesDom = configuration.getChild("aspectLibraries");
		if (aspectLibrariesDom == null) {
			throw new MojoFailureException(errorMessage);
		}

		Xpp3Dom[] aspectLibraryDomList = aspectLibrariesDom.getChildren("aspectLibrary");
		if (aspectLibraryDomList == null || aspectLibraryDomList.length < 2) {
			throw new MojoFailureException(errorMessage);
		}

		boolean isLibBaseConfigured = false;
		boolean isLibCacheConfigured = false;

		for (Xpp3Dom aspectLibraryDom : aspectLibraryDomList) {
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(AspectLibrary.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				AspectLibrary aspectLibrary = (AspectLibrary) unmarshaller.unmarshal(new StringReader(aspectLibraryDom.toString()));
				String aspectLibraryGroupId = aspectLibrary.getGroupId();
				String aspectLibraryArtifactId = aspectLibrary.getArtifactId();

				if (aspectLibraryGroupId.equals(RDC_CSL_GROUP_ID) && aspectLibraryArtifactId.equals("csl-lib-base")) {
					isLibBaseConfigured = true;
				}
				if (aspectLibraryGroupId.equals(RDC_CSL_GROUP_ID) && aspectLibraryArtifactId.equals("csl-lib-cache") ) {
					isLibCacheConfigured = true;
				}
			}
			catch (JAXBException e) {
				throw new MojoFailureException(e.toString());
			}
		}

		if (!isLibBaseConfigured) {
			throw new MojoFailureException(errorMessage);
		}
		if ( !isLibCacheConfigured) {
			throw new MojoFailureException(errorMessage);
		}
   }

	private void validateMavenBundlePlugin(Plugin plugin) throws MojoFailureException {
		List<PluginExecution> executions = plugin.getExecutions();
		if (executions == null)
			return;
		String artifactId = pomModel.getArtifactId();
		String expectedDataSourceBundleSymbolicName = artifactId.replace("svc", "datasource");
		String expectedDataSourceBundleName = expectedDataSourceBundleSymbolicName.toUpperCase();

		for (PluginExecution pluginExecution : executions) {
			Xpp3Dom configuration = (Xpp3Dom) pluginExecution.getConfiguration();
			Xpp3Dom instructionsDom = configuration.getChild("instructions");
			String id = pluginExecution.getId();
			List<String> goals = pluginExecution.getGoals();

			if (goals.size() != 1 || !goals.containsAll(Arrays.asList("bundle"))) {
				throw new MojoFailureException("maven-bundle-plugin should only have the goal `bundle`");
			}

			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(Instructions.class);
				Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				Instructions instructions = (Instructions) unmarshaller.unmarshal(new StringReader(instructionsDom.toString()));
				String bundleName = instructions.getBundleName();
				String bundleSymbolicName = instructions.getBundleSymbolicName();

				if (id.equals("generate-datasource-bundle")) {
					if (!expectedDataSourceBundleName.equals(bundleName)) {
						throw new MojoFailureException("Datasource bundle name should be : " + expectedDataSourceBundleName);
					}
					if (!expectedDataSourceBundleSymbolicName.equals(bundleSymbolicName)) {
						throw new MojoFailureException("Datasource symbolic bundle name should be : " + expectedDataSourceBundleSymbolicName);
					}
					if (instructionsDom.getChildCount() > 2) {
						throw new MojoFailureException("Do not specify any additional instructions for datasource bundle other than name and symbolic name.");
					}
				} else if (id.equals("generate-bundle")) {
					if (bundleName != null || bundleSymbolicName != null) {
						throw new MojoFailureException("Do not provide bundle name and symbolic name instructions. It will be inherited from base-pom.");
					}
				} else {
					throw new MojoFailureException("Only 'generate-bundle' and 'generate-datasource-bundle' executions are allowed in maven-bundle-plugin");
				}
			} catch (JAXBException e) {
				throw new MojoFailureException(e.toString());
			}

		}
	}

	private void validateProperties() throws MojoFailureException {
		log.info("---------------------");
		log.info("Validation type : Property validation");
		log.info("Description : Start-Level property should only be defined in base-pom");
		String bundleStartLevel = pomModel.getArtifactId() + ".start-level";

		Properties properties = pomModel.getProperties();
		for (Object keyObject : properties.keySet()) {
			String key = keyObject.toString();
			String value = properties.getProperty(key);

			if (key.equals(bundleStartLevel)) {

				checkValueOfStartLevel(value, properties);

			}
		}
	}

	private void checkValueOfStartLevel(String value, Properties properties) throws MojoFailureException {

		if (value == null) {
			throw new MojoFailureException(
					"Please specify bundle start level based on base pom or your own number greater than 80.[ the start level is null ]  ]");
		}

		if (Constants.DEFAULT_SERVICE_START_LEVEL.equals(value) || Constants.DEFAULT_DATASOURCE_START_LEVEL.equals(value))
			return;

		if (StringUtils.isNumeric(value)) {
			int startLevel = new Integer(value);
			if (startLevel <= Constants.MIN_START_SERVICE_LEVEL || startLevel > Constants.MAX_START_SERVICE_LEVEL) {
				throw new MojoFailureException("Please specify bundle start level based on base pom or your own number greater than ["
						+ Constants.MIN_START_SERVICE_LEVEL + "] less than [" + Constants.MAX_START_SERVICE_LEVEL + "]");
			}
		} else {
			String derivedValue = value.substring(value.indexOf('{') + 1, value.indexOf('}'));
			checkValueOfStartLevel(properties.getProperty(derivedValue), properties);
		}

	}

	private void validateName() throws MojoFailureException {
		log.info("---------------------");
		log.info("Validation type : ID and name validation");
		log.info("Description : Artifact id and group id should follow convention");

		MavenProject parentProject = project.getParent();
		String artifactId = project.getArtifactId();
		String name = project.getName();
		String parentName = parentProject.getName();

		String description = project.getDescription();
		String parentDescription = parentProject.getDescription();

		log.info("Artifact ID : " + artifactId + ", Name : " + name);

		if (isEmpty(name) || name.equals(parentName)) {
			throw new MojoFailureException("Please provide proper name for the module");
		}

		if (isEmpty(description) || description.equals(parentDescription)) {
			throw new MojoFailureException("Please provide proper description for the module");
		}

		log.info("Validation : pass");
	}

	private void validateSnapshotDependency() throws MojoFailureException {
		String version = project.getVersion();
		log.info("---------------------");
		log.info("Validation type : SNAPSHOT Dependency validation");
		log.info("Description : Cannot use SNAPSHOT version for CSL-Libraries");

		if (isSnapshot(version) || isDevelopBranch(version)) {
			log.info("Skipping SNAPSHOT dependency validation. Since the module itself is SNAPSHOT/DEVELOP build : " + version);
			return;
		}

		List<Dependency> dependencies = project.getDependencies();
		for (Dependency dependency : dependencies) {
			String depGroupId = dependency.getGroupId();
			String depArtifactId = dependency.getArtifactId();
			String depArtifactVersion = dependency.getVersion();

			if (isCslLibrary(depGroupId, depArtifactId)) {
				if (depArtifactVersion.endsWith("-SNAPSHOT")) {
					String errorMessage = "Error : Cannot use SNAPSHOT version for " + depGroupId + ":" + depArtifactId + ". Use release version.";
					throw new MojoFailureException(errorMessage);
				}
			}
		}

		log.info("Validation : pass");
	}
	
	private boolean ignoreValidation(String groupId, String artifactId, Map<String, String> ignoreList) {
		String artifactsStr = ignoreList.get(project.getArtifactId());

		if(isBlank(artifactsStr)) {
			return false;
		}

		String artifacts[] = artifactsStr.split(",");
		for (String artifact : artifacts) {
			String values[] = artifact.split(":");
			String gId = trim(values[0]);
			String aId = trim(values[1]);

			if (gId.equalsIgnoreCase(groupId) &&
				aId.equalsIgnoreCase(artifactId)) {
				return true;
			}
		}
		return false;
	}
	
	private void validateDependency() throws MojoFailureException {
		log.info("---------------------");
		log.info("Validation type : Dependency validation");
		log.info("Description : Dependency versions should not be explicitly specified in modules");

		List<Dependency> dependencies = project.getDependencies();
		Properties properties = project.getProperties();
		Map<String, String> parentDependencyMap = constructParentDependencyMap();

		for (Dependency dependency : dependencies) {
			String groupId = dependency.getGroupId();
			String artifactId = dependency.getArtifactId();
			String artifactVersion = dependency.getVersion();
			String parentVersion = parentDependencyMap.get(artifactId);
			String artifactStr = groupId + " : " + artifactId + " : " + artifactVersion;

			if (isCslService(artifactId)) {
				throw new MojoFailureException(artifactStr + " : CSL-Service cannot be added as dependency.");
			}

			if (isCslLibrary(groupId, artifactId)) {
				String propertyName = artifactId + ".version";
				String versionProperty = properties.getProperty(propertyName);

				if (versionProperty == null || !artifactVersion.equals(versionProperty)) {
					throw new MojoFailureException(
							"CSL-Libraries version should be defined as a property and used for dependency definition. Please define and use the property <"
									+ propertyName + ">");
				}
				log.info(artifactStr + " : Skipping version check for CSL-Library.");
				continue;
			}

			if (ignoreValidation(groupId, artifactId, ignoreDependencies)) {
				log.info(artifactStr + " - skipping dependency validation, as it is ignored in base-pom");
				continue;
			}

			if (parentVersion == null) {
				String errorMessage = artifactStr + " not available in the base pom. Please contact the CSL-CORE team to add it in base pom";
				throw new MojoFailureException(errorMessage);
			}

			boolean overridableDependency = isOverridableDependency(groupId, artifactId);
			if (!artifactVersion.equals(parentVersion) && !overridableDependency) {
				String errorMessage = artifactStr + " not supported : Do not specify version for 3rd party dependencies, version should be inherited from base pom";
				throw new MojoFailureException(errorMessage);
			}
			if(overridableDependency) {
				log.warn("Version being overridden for " + artifactStr + ", Version in parent : " + parentVersion);
			}

			log.info(artifactStr + " - \u2713");
		}

		log.info("Validation : pass");
	}

	private boolean isOverridableDependency(String groupId, String artifactId) {
		return overridableDependencies.stream()
				.anyMatch(str -> ( groupId + ":" + artifactId ).equals(trim(str)));
	}

	private void validatePlugin() throws MojoFailureException {
		log.info("---------------------");
		log.info("Validation type : Plugin validation");
		log.info("Description : Plugin version and some config should not be explicitly specified in modules");

		List<Plugin> buildPlugins = project.getBuildPlugins();
		Map<String, String> parentPluginMap = constructParentPluginMap();

		for (Plugin plugin : buildPlugins) {
			String groupId = plugin.getGroupId();
			String artifactId = plugin.getArtifactId();
			String artifactVersion = plugin.getVersion();
			String parentVersion = parentPluginMap.get(artifactId);

			if (ignoreValidation(groupId, artifactId, ignorePlugins)) {
				log.info(groupId + " : " + artifactId + " : " + artifactVersion + " - skipping plugin validation, as it is ignored in base-pom");
				continue;
			}

			if (parentVersion == null) {
				String errorMessage = "Plugin : " + groupId + ":" + artifactId
						+ " not available in the base pom. Please contact the CSL-CORE team to add it in base pom";
				throw new MojoFailureException(errorMessage);
			}

			if (!artifactVersion.equals(parentVersion)) {
				log.error("Plugin : " + groupId + ":" + artifactId + " has a different version : " + artifactVersion
						+ ", It should inherit from base-pom as : " + parentVersion);
				throw new MojoFailureException("Do not specify version for the plugin " + artifactId + ", version should inherit from base pom");
			}

			log.info(groupId + " : " + artifactId + " : " + artifactVersion + " - \u2713");
		}

		validatePluginConfig();
		log.info("Validation : pass");
	}

	private Map<String, String> constructParentDependencyMap() {
		MavenProject parent = project.getParent();
		List<Dependency> parentDependencies = parent.getDependencies();
		DependencyManagement dependencyManagement = parent.getDependencyManagement();
		List<Dependency> depsFromDependencyManagement = dependencyManagement.getDependencies();

		Map<String, String> parentDependencyMap = new HashMap<String, String>();
		Collections.reverse(depsFromDependencyManagement);

		for (Dependency dependency : depsFromDependencyManagement) {
			parentDependencyMap.put(dependency.getArtifactId(), dependency.getVersion());
		}

		for (Dependency dependency : parentDependencies) {
			parentDependencyMap.put(dependency.getArtifactId(), dependency.getVersion());
		}

		return parentDependencyMap;
	}

	private Map<String, String> constructParentPluginMap() {
		MavenProject parent = project.getParent();
		List<Plugin> buildPlugins = parent.getBuildPlugins();
		PluginManagement parentPluginManagement = parent.getPluginManagement();
		Map<String, String> parentPluginMap = new HashMap<String, String>();

		for (Plugin plugin : parentPluginManagement.getPlugins()) {
			parentPluginMap.put(plugin.getArtifactId(), plugin.getVersion());
		}

		for (Plugin plugin : buildPlugins) {
			parentPluginMap.put(plugin.getArtifactId(), plugin.getVersion());
		}

		return parentPluginMap;
	}
}
