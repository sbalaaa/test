drop DATABASE dpu01obs_bw;

