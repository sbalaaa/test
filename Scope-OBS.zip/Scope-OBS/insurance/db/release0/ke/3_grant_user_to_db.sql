set role "svc.bancatrvl.001";
select current_user;

CREATE SCHEMA obs AUTHORIZATION "svc.bancatrvl.001";

GRANT CONNECT ON DATABASE dpu01obs_ke  TO "svc.bancatrvlapp.002";
GRANT CONNECT ON DATABASE dpu01obs_ke  TO "svc.bancatrvlro.003";

--Give svc.bancatrvlapp.002 user access in the schema obs
GRANT USAGE ON  SCHEMA obs TO "svc.bancatrvlapp.002";
GRANT SELECT,INSERT,UPDATE,DELETE ON  ALL TABLES IN SCHEMA obs TO "svc.bancatrvlapp.002";
GRANT SELECT,UPDATE ON  ALL SEQUENCES IN SCHEMA obs TO "svc.bancatrvlapp.002";
ALTER DEFAULT PRIVILEGES IN SCHEMA obs GRANT SELECT,INSERT,UPDATE,DELETE ON TABLES TO "svc.bancatrvlapp.002";
ALTER DEFAULT PRIVILEGES IN SCHEMA obs GRANT SELECT,UPDATE ON SEQUENCES TO "svc.bancatrvlapp.002";


--Give svc.bancatrvlro.003 user access in the schema obs
GRANT CONNECT ON DATABASE dpu01obs_ke  TO "svc.bancatrvlro.003";
GRANT USAGE ON  SCHEMA obs TO "svc.bancatrvlro.003";
GRANT SELECT ON  ALL TABLES IN SCHEMA obs TO "svc.bancatrvlro.003";
GRANT SELECT ON  ALL SEQUENCES IN SCHEMA obs TO "svc.bancatrvlro.003";
ALTER DEFAULT PRIVILEGES IN SCHEMA obs GRANT SELECT ON TABLES TO "svc.bancatrvlro.003";
