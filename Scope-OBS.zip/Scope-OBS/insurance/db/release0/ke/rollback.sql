drop DATABASE dpu01obs_ke;

