ALTER ROLE "svc.bancatrvl.001" IN DATABASE dpu01obs_sg SET search_path TO obs,"$user",public;
ALTER ROLE "svc.bancatrvlapp.002" IN DATABASE dpu01obs_sg SET search_path TO obs,"$user",public;
ALTER ROLE "svc.bancatrvlro.003" IN DATABASE dpu01obs_sg SET search_path TO obs,"$user",public;
