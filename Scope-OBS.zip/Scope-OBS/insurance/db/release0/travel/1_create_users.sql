--Create users in postgres (same name as the LDAP user)
create user "svc.bancatrvl.001" with NOSUPERUSER NOCREATEDB NOCREATEROLE  NOINHERIT LOGIN NOREPLICATION NOBYPASSRLS;
create user "svc.bancatrvlapp.002" with NOSUPERUSER NOCREATEDB NOCREATEROLE  NOINHERIT LOGIN NOREPLICATION NOBYPASSRLS;
create user "svc.bancatrvlro.003" with NOSUPERUSER NOCREATEDB NOCREATEROLE  NOINHERIT LOGIN NOREPLICATION NOBYPASSRLS;

--grant "svc.bancatrvl.001" to devadmin ;
--grant "svc.bancatrvlapp.002" to devadmin ;
--grant "svc.bancatrvlro.003" to devadmin ;
