drop DATABASE dpu01obs;

drop user "svc.bancatrvl.001";
drop user "svc.bancatrvlapp.002";
drop user "svc.bancatrvlro.003";
