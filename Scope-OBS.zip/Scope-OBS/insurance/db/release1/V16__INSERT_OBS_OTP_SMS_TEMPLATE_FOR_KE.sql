INSERT INTO obs_otp_message_template(type, action_name, country, language, title, template, updated_timestamp, created_timestamp, datetime_format)
	VALUES ('SMS','TRANSACTION_OTP','KE','en',null,'Dear Client, {otp} is your One-Time password. It will expire after 240 seconds. For any assistance, kindly contact our 24/7 phone banking numbers',null,CURRENT_TIMESTAMP,null);
commit;