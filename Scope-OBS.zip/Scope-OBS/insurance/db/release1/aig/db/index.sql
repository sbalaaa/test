set role "svc.bancatrvl.001";
select current_user;
SET search_path = obs;


\set ON_ERROR_STOP on

\echo "************************************************************************************************************************************************"
\echo "Running obs pre-check......"
\echo "************************************************************************************************************************************************"
\i obs/checks/pre_deploy_checks.sql

\echo "************************************************************************************************************************************************"
\echo "Running obs deployment......"
\echo "************************************************************************************************************************************************"

\i obs/global/V1__OBS_COMMON_CONFIG_SCHEMA.sql
\i obs/global/V2__OBS_COMMON_ALTER_EXISTING_TABLES.sql
\i obs/global/V3__OBS_COMMON_ALTER_EXISTING_DATA_TYPES.sql
\i obs/global/V4__OBS_COMMON_ORDER_PRDT_MAILLING_ADDR_SCHEMA.sql
\i obs/global/V5__OBS_COMMON_ORDER_PRDT_COVER_DTLS_SCHEMA.sql
\i obs/global/V6__OBS_COMMON_ORDER_PRDT_MOTOR_SCHEMA.sql
\i obs/global/V7__OBS_COMMON_CONSENT_MASTER_SCHEMA.sql
\i obs/global/V8__OBS_COMMON_XREF_TABLES_SCHEMA.sql
\i obs/global/V9__OBS_COMMON_ORDER_PRDT_CPE_SCHEMA.sql
\i obs/global/V10__OBS_COMMON_ORDER_DOCUMENT_DTLS_SCHEMA.sql
\i obs/global/V11__OBS_ORDER_PREMIUM_DETAILS.sql
\i obs/global/V12__OBS_OTP_SMS_TEMPLATE_SCHEMA.sql
\i obs/global/V13__INSERT_OBS_OTP_SMS_TEMPLATE_FOR_KE.sql
\i obs/global/V14__OBS_CONFIG_STAGING_DATA_SCHEMA.sql
\i obs/global/V15__OBS_STAGING_DATALOADER_FUNCTION_SCRIPT.sql
\i obs/global/V16__OBS_COMMON_AUDIT_LOG_DTLS_TABLE_CREATE.sql
\i obs/global/V17__OBS_COMMON_CONFIG_TITLE_GENDER_COUNTRY_LOV.sql
\i obs/global/V18__OBS_COMMON_CREATE_FUNCTION_MOTOR_REPORT.sql
\i obs/global/V19__OBS_MIGRATION_FOR_MOTOR_RELEASE.sql
\i obs/global/V20__UPDATE_SEQUENCE_TRAVEL_TABLES.sql

\echo "************************************************************************************************************************************************"
\echo "Running obs post-check......"
\echo "************************************************************************************************************************************************"
\i obs/checks/post_deploy_checks.sql

\echo "************************************************************************************************************************************************"
\echo "completed obs deployment......"
\echo "************************************************************************************************************************************************"
