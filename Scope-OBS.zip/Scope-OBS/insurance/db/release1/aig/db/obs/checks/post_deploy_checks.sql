-- list Tables and Views Count
\echo "list Tables and Views Count......"
SELECT  table_catalog as dbname, table_schema, table_type, COUNT(table_name)
FROM 	information_schema.tables
 WHERE 	table_schema IN ('obs')
GROUP BY
		table_catalog, table_schema, table_type
ORDER BY
		table_catalog, table_schema, table_type; 
-- list constraints and count constraint columns
\echo "list constraints and count constraint columns......"
SELECT 	tc.table_schema,
		tc.table_name,
	    tc.constraint_name,
    	COUNT(kcu.column_name) AS COUNT_column_name
FROM 	information_schema.table_constraints AS tc
JOIN 	information_schema.key_column_usage AS kcu
ON 		tc.constraint_name = kcu.constraint_name
 WHERE 	tc.table_schema IN ('obs')
GROUP BY
		tc.table_schema,
		tc.table_name,
	    tc.constraint_name
ORDER BY
		tc.table_schema,
		tc.table_name,
	    tc.constraint_name; 
-- list Functions Count
\echo "list Functions Count......"
SELECT  routine_catalog, routine_schema, routine_type, COUNT(routine_name)
FROM 	information_schema.routines
WHERE 	specific_schema IN ('obs')
GROUP BY
		routine_catalog, routine_schema, routine_type
ORDER BY
		routine_catalog, routine_schema, routine_type; 
		
\echo "post----data count......"				
select 'obs_ref_config',count(*) from obs_ref_config;
select 'obs_app_requester_dtls',count(*) from obs_app_requester_dtls;
select 'obs_app_prdt_travel',count(*) from obs_app_prdt_travel;
select 'obs_order_prdt_payment_map',count(*) from obs_order_prdt_payment_map;
select 'obs_app_prdt_policy',count(*) from obs_app_prdt_policy;
select 'obs_ref_data',count(*) from obs_ref_data;
select 'obs_config_master',count(*) from obs_config_master;
select 'obs_ref_mapping',count(*) from obs_ref_mapping;
select 'obs_order_prdt_payment',count(*) from obs_order_prdt_payment;
select 'obs_app_prdt_insured_dtls',count(*) from obs_app_prdt_insured_dtls;
select 'obs_app_prdt_mailling_addr_dtls',count(*) from obs_app_prdt_mailling_addr_dtls;
select 'obs_app_prdt_motor',count(*) from obs_app_prdt_motor;
select 'obs_app_prdt_cover_dtls',count(*) from obs_app_prdt_cover_dtls;
select 'obs_xref',count(*) from obs_xref;
select 'obs_error_sp_mapping',count(*) from obs_error_sp_mapping;
select 'obs_consent_master',count(*) from obs_consent_master;
select 'obs_error_canonical_desc',count(*) from obs_error_canonical_desc;
select 'obs_serviceretry_config',count(*) from obs_serviceretry_config;
select 'obs_otp_message_template',count(*) from obs_otp_message_template;
select 'obs_app_prdt_cpe',count(*) from obs_app_prdt_cpe;
select 'obs_app_document_dtls',count(*) from obs_app_document_dtls;
select 'obs_app_prdt_premium_dtls',count(*) from obs_app_prdt_premium_dtls;
select 'obs_config_staging',count(*) from obs_config_staging;
select 'obs_audit_log_dtls',count(*) from obs_audit_log_dtls;
select 'obs_application_dtls',count(*) from obs_application_dtls;
select 'obs_app_prdt_master',count(*) from obs_app_prdt_master;
select 'obs_order_master',count(*) from obs_order_master;


SELECT 'obs_app_prdt_policy',nextval(pg_get_serial_sequence('obs_app_prdt_policy','prdt_policy_id')), max(prdt_policy_id) FROM obs_app_prdt_policy;
SELECT 'obs_order_master',nextval(pg_get_serial_sequence('obs_order_master','order_id')), max(order_id) FROM obs_order_master;
SELECT 'obs_application_dtls',nextval(pg_get_serial_sequence('obs_application_dtls','application_id')), max(application_id) FROM obs_application_dtls;
SELECT 'obs_order_prdt_payment',nextval(pg_get_serial_sequence('obs_order_prdt_payment','order_prdt_payment_id')), max(order_prdt_payment_id) FROM obs_order_prdt_payment;
SELECT 'obs_app_requester_dtls',nextval(pg_get_serial_sequence('obs_app_requester_dtls','requester_dtls_id')), max(requester_dtls_id) FROM obs_app_requester_dtls;
SELECT 'obs_app_prdt_insured_dtls',nextval(pg_get_serial_sequence('obs_app_prdt_insured_dtls','insured_dtls_id')), max(insured_dtls_id) FROM obs_app_prdt_insured_dtls;
SELECT 'obs_order_prdt_payment_map',nextval(pg_get_serial_sequence('obs_order_prdt_payment_map','order_prdt_map_id')), max(order_prdt_map_id) FROM obs_order_prdt_payment_map;
SELECT 'obs_app_prdt_travel',nextval(pg_get_serial_sequence('obs_app_prdt_travel','prdt_travel_id')), max(prdt_travel_id) FROM obs_app_prdt_travel;