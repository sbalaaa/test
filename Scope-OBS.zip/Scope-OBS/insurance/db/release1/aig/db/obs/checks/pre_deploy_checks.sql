-- list Tables and Views Count
\echo "list Tables and Views Count......"
SELECT  table_catalog as dbname, table_schema, table_type, COUNT(table_name)
FROM 	information_schema.tables
 WHERE 	table_schema IN ('obs')
GROUP BY
		table_catalog, table_schema, table_type
ORDER BY
		table_catalog, table_schema, table_type; 
-- list constraints and count constraint columns
\echo "list constraints and count constraint columns......"
SELECT 	tc.table_schema,
		tc.table_name,
	    tc.constraint_name,
    	COUNT(kcu.column_name) AS COUNT_column_name
FROM 	information_schema.table_constraints AS tc
JOIN 	information_schema.key_column_usage AS kcu
ON 		tc.constraint_name = kcu.constraint_name
 WHERE 	tc.table_schema IN ('obs')
GROUP BY
		tc.table_schema,
		tc.table_name,
	    tc.constraint_name
ORDER BY
		tc.table_schema,
		tc.table_name,
	    tc.constraint_name; 

\echo "pre----data count......"		
select 'obs_order_requester_dtls',count(*) from obs_order_requester_dtls;
select 'obs_ref_config',count(*) from obs_ref_config;
select 'obs_order_prdt_travel',count(*) from obs_order_prdt_travel;
select 'obs_order_master',count(*) from obs_order_master;
select 'obs_prdt_order_map',count(*) from obs_prdt_order_map;
select 'obs_prdt_insured_dtls',count(*) from obs_prdt_insured_dtls;
select 'obs_order_prdt_payment',count(*) from obs_order_prdt_payment;
select 'obs_prdt_policy',count(*) from obs_prdt_policy;
