INSERT INTO obs_otp_message_template(type, action_name, country, language, title, template, updated_timestamp, created_timestamp, datetime_format)
	VALUES ('SMS','TRANSACTION_OTP','KE','en',null,'Dear Client, the OTP to confirm your Motor Insurance request is {otp}. Please call us on 254203293900 if you have not initiated this request',null,CURRENT_TIMESTAMP,null);
commit;