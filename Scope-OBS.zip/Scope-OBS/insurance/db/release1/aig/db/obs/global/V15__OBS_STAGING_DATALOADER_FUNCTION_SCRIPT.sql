CREATE OR REPLACE FUNCTION create_delete_into_obs_config_mstr(varchar,varchar,varchar,varchar) RETURNS integer AS $$
DECLARE
    countryCode ALIAS FOR $1;
	screenCode ALIAS FOR $2;
	productCode ALIAS FOR $3;
	channelCode ALIAS FOR $4;
	inst RECORD;
	upd RECORD;
BEGIN
	delete  from obs_config_staging where name_of_product like 'dummy%';
	For inst IN (
		(select distinct name_of_product from obs_config_staging where country =countryCode
		union
		select distinct name_of_child_product from obs_config_staging where country =countryCode and name_of_child_product is not null )
		EXCEPT
		select field_code from obs_config_master where country_code = countryCode and screen_code=screenCode and product_code=productCode and channel_code=channelCode AND created_by='SANLAM')
	LOOP
		INSERT INTO obs_config_master(
		screen_code, field_code, product_code, country_code, channel_code, is_deleted, created_by, created_timestamp, updated_by, updated_timestamp)
		VALUES (screenCode, inst.name_of_product, productCode, countryCode, channelCode, false, 'SANLAM', CURRENT_TIMESTAMP, 'SANLAM', CURRENT_TIMESTAMP);
	END LOOP;

	For upd IN (
		select field_code from obs_config_master where country_code =countryCode and screen_code=screenCode and product_code=productCode and channel_code=channelCode AND created_by='SANLAM'
		EXCEPT
		(select distinct name_of_product from obs_config_staging where country =countryCode
		union
		select distinct name_of_child_product from obs_config_staging where country =countryCode and name_of_child_product is not null ) )
	LOOP
		update obs_config_master set is_deleted='true', updated_by='SANLAM',updated_timestamp= CURRENT_TIMESTAMP where country_code =countryCode and screen_code=screenCode and product_code=productCode and channel_code=channelCode AND field_code=upd.field_code AND created_by='SANLAM';
	END LOOP;
return 1;	
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION insert_into_obs_ref_data(varchar,varchar,varchar,varchar,varchar) RETURNS integer AS $$
DECLARE
    countryCode ALIAS FOR $1;
	screenCode ALIAS FOR $2;
	productCode ALIAS FOR $3;
	channelCode ALIAS FOR $4;
	fieldDesc ALIAS FOR $5;
	selt RECORD;
	inst RECORD;
	upd RECORD;
	cselt RECORD;
	cinst RECORD;
	cupd RECORD;
BEGIN
	For selt IN ( select config_mstr_id,field_code from obs_config_master where country_code = countryCode and screen_code=screenCode and product_code=productCode and channel_code=channelCode AND created_by='SANLAM' and field_code IN(select distinct name_of_product from obs_config_staging where country=countryCode))
	LOOP
		For inst IN ( 
			select distinct key,value from obs_config_staging where name_of_product=selt.field_code and country=countryCode
			except
			select field_val,field_val_label from obs_ref_data where  config_mstr_id =selt.config_mstr_id AND created_by='SANLAM')
			LOOP
				INSERT INTO obs_ref_data(config_mstr_id, field_desc, field_val, field_val_label, language_code, is_deleted, created_by, created_timestamp, updated_by, updated_timestamp)
				VALUES (selt.config_mstr_id,fieldDesc , inst.key, inst.value,  'en', 'false', 'SANLAM',CURRENT_TIMESTAMP, 'SANLAM',CURRENT_TIMESTAMP );
			END LOOP;
		For upd IN ( 
			select field_val,field_val_label from obs_ref_data where  config_mstr_id =selt.config_mstr_id AND created_by='SANLAM'
			except
			select distinct key,value from obs_config_staging where name_of_product=selt.field_code and country=countryCode)
			LOOP
				update obs_ref_data set is_deleted='true', updated_by='SANLAM',updated_timestamp= CURRENT_TIMESTAMP where config_mstr_id =selt.config_mstr_id and field_val=upd.field_val and field_val_label=upd.field_val_label AND created_by='SANLAM';
			END LOOP;	
	END LOOP;

	For cselt IN ( select config_mstr_id,field_code from obs_config_master where country_code = countryCode and screen_code=screenCode and product_code=productCode and channel_code=channelCode AND created_by='SANLAM' and field_code IN(select distinct name_of_child_product from obs_config_staging where country=countryCode))
	LOOP
		For cinst IN ( 
			select distinct model_key,model_value from obs_config_staging where name_of_child_product=cselt.field_code and country=countryCode AND model_key is not null AND model_value is not null 
			except
			select field_val,field_val_label from obs_ref_data where  config_mstr_id =cselt.config_mstr_id AND created_by='SANLAM' )
			LOOP
				INSERT INTO obs_ref_data(config_mstr_id, field_desc, field_val, field_val_label, language_code, is_deleted, created_by, created_timestamp, updated_by, updated_timestamp)
				VALUES (cselt.config_mstr_id,fieldDesc , cinst.model_key, cinst.model_value,  'en', 'false', 'SANLAM',CURRENT_TIMESTAMP, 'SANLAM',CURRENT_TIMESTAMP );
			END LOOP;
		For cupd IN ( 
			select field_val,field_val_label from obs_ref_data where  config_mstr_id =cselt.config_mstr_id AND created_by='SANLAM'
			except
			select distinct model_key,model_value from obs_config_staging where name_of_child_product=cselt.field_code AND country=countryCode AND model_key is not null AND model_value is not null )
			LOOP
				update obs_ref_data set is_deleted='true', updated_by='SANLAM',updated_timestamp= CURRENT_TIMESTAMP where config_mstr_id =selt.config_mstr_id and field_val=cupd.field_val and field_val_label=cupd.field_val_label AND created_by='SANLAM';
			END LOOP;	
	END LOOP;	
return 1;	
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION insert_into_obs_ref_mapping(integer,integer) RETURNS integer AS $$
DECLARE
    parent_id ALIAS FOR $1;
	child_id ALIAS FOR $2;
BEGIN
		IF NOT EXISTS (SELECT 1 FROM obs_ref_mapping WHERE ref_pid = parent_id and ref_cid = child_id)	THEN 
			INSERT INTO obs_ref_mapping(	ref_pid,ref_cid, is_deleted, created_by, created_timestamp, updated_by, updated_timestamp)
			VALUES (parent_id,child_id,'false', 'SANLAM',CURRENT_TIMESTAMP, 'SANLAM',CURRENT_TIMESTAMP);
		END IF;
return 1;		
END;
$$ LANGUAGE plpgsql; 

CREATE OR REPLACE FUNCTION find_pid_and_cid(varchar) RETURNS integer AS $$
DECLARE
    cntry  ALIAS FOR $1;
	selt RECORD;
	selt_obs_ref_data_pid RECORD;
	selt_obs_ref_data_cid RECORD;
BEGIN
		For selt IN (select field_code,config_mstr_id From obs_config_master where country_code =cntry AND created_by='SANLAM' AND field_code IN (select distinct name_of_product from obs_config_staging where country=cntry and model_key is not null))
			LOOP
				For selt_obs_ref_data_pid IN (select  ref_data_id,config_mstr_id , field_val,field_val_label from obs_ref_data where config_mstr_id=selt.config_mstr_id AND created_by='SANLAM' AND   ((field_val,field_val_label) IN(select distinct key,value from obs_config_staging where name_of_product= selt.field_code AND country=cntry AND model_key is not null )))
					LOOP
						For selt_obs_ref_data_cid IN (select  ref_data_id,config_mstr_id , field_val,field_val_label from obs_ref_data where  config_mstr_id in (select config_mstr_id from obs_config_master where country_code=cntry AND created_by='SANLAM') AND ( (field_val,field_val_label) IN(select model_key,model_value   from obs_config_staging where country=cntry AND key=selt_obs_ref_data_pid.field_val AND value=selt_obs_ref_data_pid.field_val_label and model_key is not null ) ))
							LOOP
							PERFORM insert_into_obs_ref_mapping(selt_obs_ref_data_pid.ref_data_id,selt_obs_ref_data_cid.ref_data_id);
							END LOOP;
					END LOOP;
			END LOOP;
return 1;			
END;
$$ LANGUAGE plpgsql;


CREATE OR REPLACE FUNCTION dataSync_Between_Staging_To_OBS_tables(varchar,varchar,varchar,varchar) RETURNS integer AS $$
DECLARE
	screen_code ALIAS FOR $1;
	product_code ALIAS FOR $2;
	channel_code ALIAS FOR $3;
	field_desc ALIAS FOR $4;
	selt RECORD;
BEGIN
	delete  from obs_config_staging where name_of_product like 'dummy%';
	For selt IN ( select distinct country from obs_config_staging) 
		LOOP
			PERFORM create_delete_into_obs_config_mstr(selt.country,screen_code,product_code,channel_code);
			PERFORM insert_into_obs_ref_data(selt.country,screen_code,product_code,channel_code,field_desc);
			PERFORM find_pid_and_cid(selt.country);
		END LOOP;
return 1;		
END;
$$ LANGUAGE plpgsql; 