CREATE TABLE obs_audit_log_dtls
(
    customer_name VARCHAR(512),
    customer_id VARCHAR(100),
    customer_segment VARCHAR(100),
    language_cd VARCHAR(20),
    channel_cd VARCHAR(20),
    location VARCHAR(100),
    app_name VARCHAR(256),
    device_id VARCHAR(100),
    channel_name VARCHAR(100),
    cntry_cd VARCHAR(20),
    created_by VARCHAR(100) NOT NULL,
    created_timestamp TIMESTAMPTZ(0) NOT NULL,
    updated_by VARCHAR(100),
    updated_timestamp TIMESTAMPTZ(0) NOT NULL,
    network_carrier VARCHAR(100),
    consent_id bigint,
    id BIGSERIAL PRIMARY KEY,
    user_id VARCHAR(50),
    consent_timestamp TIMESTAMPTZ(0) NOT NULL,
    policy_no VARCHAR(100),
	FOREIGN KEY (consent_id) REFERENCES obs_consent_master(consent_id)
);