create or replace function extract_premium_details(bigint, varchar) returns decimal as $$
declare
	result_value decimal;
begin

	select premium_value
	into result_value
	from obs_order_prdt_premium_dtls
	where order_prdt_id = $1 and premium_desc = $2;

return result_value;
end;
$$ language plpgsql;