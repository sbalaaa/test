-- remove columns
alter table obs_order_master
drop column terms_accept_timestamp;

-- rename order_prdt_id to prdt_id
alter table obs_order_prdt_policy
rename column order_prdt_id to prdt_id;

alter table obs_order_prdt_master
rename column order_prdt_id to prdt_id;

alter table obs_order_prdt_insured_dtls
rename column order_prdt_id to prdt_id;

alter table obs_order_prdt_travel
rename column order_prdt_id to prdt_id;

alter table obs_order_prdt_map
rename column order_prdt_id to prdt_id;

-- rename and duplicate obs order master
alter table obs_order_master rename to obs_application_dtls;

create table obs_order_master as table obs_application_dtls;
-- drop columns in order after duplicate
alter table obs_order_master
drop column customer_id,
drop column cntry_cd,
drop column channel_cd;
-- update order master table
alter table obs_order_master
rename column order_id to application_id;
alter table obs_application_dtls
rename column order_id to application_id;

alter table obs_order_master
add constraint fk_application_id
foreign key(application_id)
references obs_application_dtls(application_id);

alter table obs_order_master
add column order_id BIGSERIAL primary key;
--------------------------------------------------------
alter table obs_application_dtls
drop column order_error_desc,
drop column order_status,
drop column order_amt,
drop column order_amt_curr;

alter table obs_application_dtls
add column channel_name varchar(100) default 'MobileBanking';

update obs_application_dtls
set channel_cd = 'IBNK';

alter table obs_application_dtls
rename customer_id to rel_id;

alter table obs_application_dtls
add column isp_application_cd varchar(512),
add column application_error_desc varchar(512),
add column application_status varchar(100) default 'Application Submitted';

alter table obs_order_prdt_master
add column application_id bigint;

alter table obs_order_prdt_master
add constraint fk_app_id
foreign key(application_id)
references obs_application_dtls(application_id);
--
update obs_application_dtls app
set application_error_desc = o.order_error_desc
from obs_order_master o
where o.application_id = app.application_id;

alter table obs_order_prdt_map
add column payment_id bigint;

alter table obs_order_prdt_map
add constraint fk_payment_id
foreign key(payment_id)
references obs_order_prdt_payment(order_prdt_payment_id);

-- drop foreign key to product master table
alter table obs_order_prdt_payment
drop constraint if exists obs_order_prdt_payment_order_prdt_id_fkey;

-- update payment id of map to point to payment table PK
update obs_order_prdt_map op_map
set payment_id = op_payment.order_prdt_payment_id
from obs_order_prdt_master op_master
inner join obs_order_prdt_payment op_payment on op_payment.order_prdt_id = op_master.prdt_id
where op_map.prdt_id = op_payment.order_prdt_id;

-- update order id of map to point to PK of new table obs_order_master
alter table obs_order_prdt_map
drop constraint if exists obs_prdt_order_map_order_id_fkey;

alter table obs_order_prdt_payment
drop column order_prdt_id;

alter table obs_order_prdt_payment
add column order_id bigint;

alter table obs_order_prdt_payment
add constraint fk_order_id
foreign key(order_id)
references obs_order_master(order_id);

update obs_order_prdt_payment pay
set order_id = ap_map.order_id
from obs_order_prdt_map ap_map
inner join obs_order_master o on o.order_id=ap_map.order_id
where ap_map.payment_id = pay.order_prdt_payment_id;
----------------------------------------------------------
alter table obs_order_prdt_master
add column isp_quotation_cd varchar(100),
add column isp_cd varchar(100),
add column isp_name varchar(100),
add column premium_amt decimal,
add column product_risk_cd varchar(100),
add column premium_amt_curr varchar(20),
add column total_sum_assured_amt decimal,
add column total_sum_assured_amt_curr varchar(20);

update obs_order_prdt_master op_master
set isp_quotation_cd = trvl.isp_quote_cd, isp_name = trvl.isp_provider_name,
premium_amt = trvl.premium_amt, premium_amt_curr =  trvl.premium_amt_curr
from obs_order_prdt_travel trvl
where op_master.prdt_id = trvl.prdt_id;

-- drop column in travel product
alter table obs_order_prdt_travel
drop column isp_quote_cd,
drop column isp_provider_name,
drop column premium_amt,
drop column premium_amt_curr;
-- update policy table auto renewal to false by default
update obs_order_prdt_policy
set auto_renewal = false;
------------------------------------------------------------
update obs_order_prdt_map op_map
set order_id = o_master.order_id
from obs_order_master o_master
inner join obs_application_dtls app on app.application_id = o_master.application_id
where op_map.order_id = app.application_id;

alter table obs_order_prdt_map
add constraint fk_order_id
foreign key(order_id)
references obs_order_master(order_id);

alter table obs_order_requester_dtls
rename column order_id to application_id;

alter table obs_order_requester_dtls
drop constraint if exists obs_order_requester_dtls_order_id_fkey;

alter table obs_order_requester_dtls
add constraint fk_app_id
foreign key(application_id)
references obs_application_dtls(application_id);

-- migrate data from requester table to mailling address table
insert into obs_app_prdt_mailling_addr_dtls
(address_holder_type, address_holder_id, city_name, postal_cd, address_1, address_2, address_3, address_type, created_by, created_timestamp, updated_by, updated_timestamp)
select 'REQUESTER', requester_dtls_id, city_name, postal_cd, address_1, address_2, address_3, 'RESIDENCE', created_by, created_timestamp, updated_by, updated_timestamp
from obs_order_requester_dtls;
-- rename existing tables
alter table obs_order_requester_dtls rename to obs_app_requester_dtls;
alter table obs_order_prdt_master rename to obs_app_prdt_master;
alter table obs_order_prdt_map rename to obs_order_prdt_payment_map;
alter table obs_order_prdt_insured_dtls rename to obs_app_prdt_insured_dtls;
alter table obs_order_prdt_travel rename to obs_app_prdt_travel;
alter table obs_order_prdt_policy rename to obs_app_prdt_policy;

-- requester remove address
alter table obs_app_requester_dtls drop column if exists address_1;
alter table obs_app_requester_dtls drop column if exists address_2;
alter table obs_app_requester_dtls drop column if exists address_3;
alter table obs_app_requester_dtls drop column if exists city_name;
alter table obs_app_requester_dtls drop column if exists state;
alter table obs_app_requester_dtls drop column if exists postal_cd;

