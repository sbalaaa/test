SELECT setval(pg_get_serial_sequence('obs_app_prdt_policy','prdt_policy_id'), max(prdt_policy_id)) FROM obs_app_prdt_policy;
SELECT setval(pg_get_serial_sequence('obs_order_master','order_id'), max(order_id)) FROM obs_order_master;
SELECT setval(pg_get_serial_sequence('obs_application_dtls','application_id'), max(application_id)) FROM obs_application_dtls;
SELECT setval(pg_get_serial_sequence('obs_order_prdt_payment','order_prdt_payment_id'), max(order_prdt_payment_id)) FROM obs_order_prdt_payment;
SELECT setval(pg_get_serial_sequence('obs_app_requester_dtls','requester_dtls_id'), max(requester_dtls_id)) FROM obs_app_requester_dtls;
SELECT setval(pg_get_serial_sequence('obs_app_prdt_insured_dtls','insured_dtls_id'), max(insured_dtls_id)) FROM obs_app_prdt_insured_dtls;
SELECT setval(pg_get_serial_sequence('obs_order_prdt_payment_map','order_prdt_map_id'), max(order_prdt_map_id)) FROM obs_order_prdt_payment_map;
SELECT setval(pg_get_serial_sequence('obs_app_prdt_travel','prdt_travel_id'), max(prdt_travel_id)) FROM obs_app_prdt_travel;
