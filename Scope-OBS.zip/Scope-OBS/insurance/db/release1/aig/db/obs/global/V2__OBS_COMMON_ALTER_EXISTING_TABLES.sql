﻿--migration current production data
alter table obs_order_prdt_travel rename to obs_order_prdt_master;

CREATE TABLE obs_order_prdt_travel AS
  TABLE obs_order_prdt_master;

ALTER TABLE obs_order_prdt_master
  ADD COLUMN PRODUCT_CD VARCHAR(20) NOT NULL DEFAULT 'TRAVEL';

ALTER TABLE obs_order_prdt_travel
  ADD FOREIGN KEY (order_prdt_id)
  REFERENCES obs_order_prdt_master(order_prdt_id);

ALTER TABLE obs_order_prdt_travel
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_travel
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_travel
  ADD COLUMN prdt_travel_id BIGSERIAL PRIMARY KEY;

ALTER TABLE obs_order_prdt_master
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_master
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

alter table obs_order_prdt_master
    drop column isp_quote_cd ,
    drop column isp_offer_cd,
    drop column isp_provider_name,
    drop column discount_cd,
    drop column is_resident,
    drop column trip_type,
    drop column plan_type,
    drop column origin_cntry_cd,
    drop column isp_dest_cd,
    drop column scb_dest_cd,
    drop column premium_curr_cd,
    drop column premium_amt,
    drop column start_date,
    drop column end_date,
    drop column language_cd,
    drop column cust_consent_isp_contact,
    drop column cust_consent_scb_contact,
    drop column cust_consent_isp_contact_date,
    drop column cust_consent_scb_contact_date;

-- update OBS_ORDER_MASTER schema
ALTER TABLE OBS_ORDER_MASTER
RENAME COLUMN order_currency_cd to order_amt_curr;

ALTER TABLE OBS_ORDER_MASTER
RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;

ALTER TABLE OBS_ORDER_MASTER
RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

ALTER TABLE OBS_ORDER_MASTER
RENAME COLUMN order_fail_desc  to order_error_desc;

-- update OBS_ORDER_PRDT_REQUESTER_DTLS schema

ALTER TABLE obs_order_requester_dtls
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_requester_dtls
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

alter table obs_order_requester_dtls
add column full_name varchar (300),
add column middle_name varchar (100),
add column business_sector varchar (100),
add column gender varchar (20),
add column job_title varchar (100),
add column state varchar (100),
add column phone_no varchar(100);

-- rename OBS_PRDT_POLICY and update its schema
alter table OBS_PRDT_POLICY rename to OBS_ORDER_PRDT_POLICY;

ALTER TABLE OBS_ORDER_PRDT_POLICY
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE OBS_ORDER_PRDT_POLICY
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

alter table OBS_ORDER_PRDT_POLICY
drop column prdt_id,
drop column policy_holder_id,
add column application_no varchar(100),
add column policy_master_no varchar(100),
add column status varchar(100),
add column expiry_date timestamptz(0),
add column duration varchar(20),
add column no_of_days integer;

-- rename OBS_PRDT_INSURED_DTLS and update its schema
alter table obs_prdt_insured_dtls rename to obs_order_prdt_insured_dtls;
ALTER TABLE obs_order_prdt_insured_dtls
  DROP COLUMN PRDT_ID;
ALTER TABLE obs_order_prdt_insured_dtls
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_insured_dtls
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

alter table obs_order_prdt_insured_dtls
add column insured_type varchar(100),
add column middle_name varchar(100),
add column full_name varchar(300),
add column mobile_no varchar(100),
add column license_no varchar(100),
add column nationality varchar(20),
add column gender varchar(20),
add column phone_no varchar(100);

-- rename OBS_PRDT_ORDER_MAP and update its schema
alter table obs_prdt_order_map rename to obs_order_prdt_map;

ALTER TABLE obs_order_prdt_map
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_map
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;

-- rename OBS_ORDER_PRDT_TRAVEL and update its schema
alter table obs_order_prdt_travel
rename column premium_curr_cd to premium_amt_curr;

-- update OBD_ORDER_PRDT_PAYMENT
ALTER TABLE obs_order_prdt_payment
  RENAME COLUMN TRAN_CURR_CD TO TRAN_AMT_CURR;
ALTER TABLE obs_order_prdt_payment
  RENAME COLUMN CREATED_DATE TO CREATED_TIMESTAMP;
ALTER TABLE obs_order_prdt_payment
  RENAME COLUMN UPDATED_DATE TO UPDATED_TIMESTAMP;