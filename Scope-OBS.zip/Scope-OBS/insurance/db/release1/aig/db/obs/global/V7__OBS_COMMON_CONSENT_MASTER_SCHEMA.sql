CREATE TABLE IF NOT EXISTS obs_consent_master
(
	consent_id BIGSERIAL PRIMARY KEY,
	product_risk_cd varchar(100),
    consent_code VARCHAR(50),
    short_description VARCHAR(100),
    description VARCHAR(2000),
    created_by VARCHAR(50),
    created_timestamp TIMESTAMPTZ(0) NOT NULL,
    updated_by VARCHAR(50),
    updated_timestamp TIMESTAMPTZ(0) NOT NULL,
    country_code VARCHAR(10),
    product_code VARCHAR(50)
);


insert into obs_consent_master(consent_code,short_description,description,country_code,product_code,created_by,created_timestamp,updated_by,updated_timestamp) values('1','SCIAL disclaimer','SCIAL disclaimer','KE','MOTOR','SYSTEM',current_timestamp,'SYSTEM',current_timestamp);
insert into obs_consent_master(consent_code,short_description,description,country_code,product_code,created_by,created_timestamp,updated_by,updated_timestamp) values('2','Customer acceptance','Customer acceptance','KE','MOTOR','SYSTEM',current_timestamp,'SYSTEM',current_timestamp);
insert into obs_consent_master(consent_code,short_description,description,country_code,product_code,created_by,created_timestamp,updated_by,updated_timestamp) values('3','Review disclaimer code','Review disclaimer code','KE','MOTOR','SYSTEM',current_timestamp,'SYSTEM',current_timestamp);
commit;