--
-- Usage: psql -U svc.bancatrvl.001 -d dpu01obs_hk -h HKLVDUSQL001.hk.standardchartered.com -p 6524 -f "V22_OBS_COMMON_PURGE_AND_LOAD_ELIGIBLE_CUSTOMER_RELIDS.sql -v csvfilepath="relIDs_CPE.csv" -v username="sukumar"
--

-- function to extract the product name from the given filename delimited after '_' (last occurence) of csv file
CREATE OR REPLACE FUNCTION getProductName(filepathname text)
    RETURNS text AS
$func$
    BEGIN
        RETURN(SELECT SUBSTRING(filepathname FROM '_([^_]+)\.csv$'));
    END
$func$ LANGUAGE plpgsql;

-- function to delete the entries for a certain productcode
CREATE OR REPLACE FUNCTION deleteEntries(tblname regclass, productCode text)
    RETURNS void AS
$func$
    BEGIN
        raise notice 'DELETING ENTRIES for: %', productCode;
        EXECUTE format('
            DELETE FROM %s
            where %I = $1
        ', tblname, 'product_code')
        USING productCode;
        RETURN;
    END
$func$ LANGUAGE plpgsql;

-- perform the procedure
CREATE OR REPLACE FUNCTION performPurgeProcedureForProductCode(tblname regclass, filepathname text)
    RETURNS void AS
$func$
    DECLARE
        prodCode text;
    BEGIN
        prodCode := getProductName(filepathname);
        raise notice 'product_code Value: %', prodCode;
        IF prodCode IS NOT NULL THEN
            PERFORM deleteEntries(tblname, prodCode);
        ELSE
            RAISE EXCEPTION 'PRODUCT CODE NOT FOUND';
        END IF;
    END;
$func$ LANGUAGE plpgsql;

-- create audit table
CREATE OR REPLACE FUNCTION createAuditTable()
    RETURNS void AS
$func$
	BEGIN
		EXECUTE format('
			CREATE TABLE IF NOT EXISTS obs_relid_eligibility_audit
			(
				id SERIAL PRIMARY KEY,
				processed_file_name VARCHAR(100) NOT NULL,
				processed_time TIMESTAMPTZ(0) NOT NULL,
				processed_by VARCHAR(100) NOT NULL,
				status VARCHAR(100) NOT NULL
			)
		');
		RETURN;
	END;
$func$ LANGUAGE plpgsql;

-- insert the entry into audit table
CREATE OR REPLACE FUNCTION insertAuditTable(tblname regclass, filepathname text, processedTime timestamptz, created_by text, status text)
    RETURNS void AS
$func$
	BEGIN
		EXECUTE format('
			INSERT INTO %s
			(processed_file_name, processed_time, processed_by, status)
			VALUES
			($1, $2, $3, $4)
		', tblname)
		USING filepathname, processedTime, created_by, status;
		RETURN;
	END;
$func$ LANGUAGE plpgsql;

-- update the last entry in the audit table
CREATE OR REPLACE FUNCTION updateAuditTable(tblname regclass, status text)
    RETURNS void AS
$func$
	BEGIN
		EXECUTE format('
			UPDATE %s
			SET "status" = $1
			WHERE
				id = (SELECT max(id) FROM %s)
		', tblname, tblname)
		USING status;
		RETURN;
	END;
$func$ LANGUAGE plpgsql;


-- main
SELECT createAuditTable();
SELECT insertAuditTable('obs_relid_eligibility_audit', :'csvfilepath', now(), :'username', 'FAILED');
BEGIN;

	-- Temporary table for the purpose of loading the rel ids from the CSV file
	CREATE TEMPORARY TABLE t (customer_rel_id text);

	-- Bulk copy operations from CSV file to the temporary table
	\t
	\o tmp_copy_command.txt
	select format(
		$$\copy t from %L WITH (FORMAT CSV)$$
		, :'csvfilepath'
	);
	\o
	\i tmp_copy_command.txt

	-- Delete the first record having the header as 'customer_rel_id'
	DELETE FROM t
	WHERE "customer_rel_id" IN (SELECT "customer_rel_id" FROM t LIMIT 1);

	SET timezone = 'Asia/Hong_Kong';

    -- Execute the purge procedures for the given product code
	SELECT performPurgeProcedureForProductCode('OBS_ELIGIBLE_PRODUCTS', :'csvfilepath');

	-- Copy from temporary table to the original table
	INSERT INTO OBS_ELIGIBLE_PRODUCTS("customer_rel_id", "product_code", "created_by", "created_timestamp", "updated_by", "updated_timestamp")
	SELECT customer_rel_id, 'CPE', :'username', now(), :'username', now() FROM t;

	-- Drop the temporary table t
	DROP TABLE t;
	SELECT updateAuditTable('obs_relid_eligibility_audit', 'SUCCESS');

COMMIT;
