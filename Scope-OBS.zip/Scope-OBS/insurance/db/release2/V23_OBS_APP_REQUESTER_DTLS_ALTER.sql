alter table obs_app_requester_dtls
add column REL_MGR_CD VARCHAR(50),
add column REL_BR_CD VARCHAR(50),
add column CUST_SEG_CD VARCHAR(50);