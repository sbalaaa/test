package com.sc.obs.application;

import com.sc.obs.code.ObsErrorCode;
import lombok.Getter;

/**
 * Class to cater the exceptions for Applications Model until database exception handling is implemented
 * @author akshaymhatre
 *
 */
public enum ApplicationErrorCode implements ObsErrorCode {

    APPLICATION_CONNECTIVITY_ERROR("OBS_APPLICATION_001",
            "Application connectivity error",
            "There was an error when connecting to ISP's Application API."),

    APPLICATION_DATA_VALIDATION_ERROR("OBS_APPLICATION_002",
            "Application Data validation error",
            "There was a data validation error in Application payload."),

    APPLICATION_SUBMISSION_FAILURE("OBS_APPLICATION_003",
            "Application Data submission failure",
            "There was a failure when data was submitted to ISP's Application API."),
    
    APPLICATION_PAYMENT_FAILURE("OBS_APPLICATION_004",
            "Application payment failure",
            "There was a failure doing payment to core system."),
    
    APPLICATION_PROCESSING_FAILURE("OBS_APPLICATION_005",
            "Application processing failure",
            "There was a failure while processing the Application."),
	
	SMS_OTP_HDR_READ_FAILURE("OBS_SMS_OTP_HDR_READ FAILURE",
			"SEND SMS OTP FALIED", 
			"Send SMS OTP Failed, error while reading otp header"),
	FETCH_CUST_MOBILE_FAILURE("OBS_FETCH_CUST_MOBILE_FAILURE", 
			"FETCH CUST MOBILE NUMBER FALIED", 
			"Send SMS OTP Failed, error while fetching customer mobile number."),
	SMS_OTP_FAILURE("OBS_SMS_OTP_FAILURE", 
			"FETCH CUST MOBILE NUMBER FALIED", 
			"Send SMS OTP Failed, error while fetching customer mobile number."),
	FETCH_OTP_SMS_TEMPLATE_FAILURE("OBS_FETCH_OTP_SMS_TEMPLATE_FAILURE", 
			"FETCH OTP SMS TEMPLATE FALIED", 
			"Error while fetching the SMP OTP Template.");


    @Getter
    private final String code;

    @Getter
    private final String title;

    @Getter
    private final String description;

    ApplicationErrorCode(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

}
