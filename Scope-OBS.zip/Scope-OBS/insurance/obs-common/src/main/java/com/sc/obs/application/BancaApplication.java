package com.sc.obs.application;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.obs.payment.PaymentDetail;
import io.crnk.core.resource.annotations.JsonApiId;
import io.crnk.core.resource.annotations.JsonApiResource;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@JsonApiResource(type = "banca-applications")
public class BancaApplication {
    
    @JsonApiId
    private String id;

    @JsonProperty("quote-id")
    private String quotationNumber;

    @JsonProperty("application-id")
    private String applicationId;

    @JsonProperty("policy-number")
    private String policyNumber;

    @NotNull
    private String country;
    
    @Valid
    @JsonProperty("application-detail")
    private BancaApplicationDetail bancaApplicationDetail;

    @Valid
    @JsonProperty("payment-detail")
    private PaymentDetail paymentDetail;  
}
