package com.sc.obs.application;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;


@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "productCode" ,visible = true)
@Getter
@Setter
public abstract class BancaApplicationDetail {

    @NonNull
    @JsonProperty("productCode")
    private String productCode;

    @JsonProperty("documents")
    private List<Documents> documents;

    @JsonProperty("first-name")
    private String firstName;
    
    @JsonProperty("middle-name")
    private String middleName;
    
    @JsonProperty("last-name")
    private String lastName;
    
    @JsonProperty("email-id")
    private String emailId;
    
    @JsonDeserialize(using = LocalDateDeserializer.class)  
    @JsonSerialize(using = LocalDateSerializer.class)  
    @JsonProperty("birth-date")
    private LocalDate dateOfBirth;
    
    @JsonProperty("gender")
    private String gender;
    
    @JsonProperty("phone-number")
    private String phoneNumber;

    @JsonProperty("segment-code")
    private String segmentCode;

    @JsonProperty("mailing-address")
    private     List<MailingAddress> mailingAddress;
}
