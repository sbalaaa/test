package com.sc.obs.application;

public interface BancaApplicationProcessor {

    BancaApplication submitBancaApplication(BancaApplication bancaApplication);

}
