package com.sc.obs.application;

import com.sc.obs.registry.CountryProductTypeRegistry;
import org.springframework.stereotype.Component;

@Component
public class BancaApplicationProcessorRegistry extends CountryProductTypeRegistry<BancaApplicationProcessor> {
}
