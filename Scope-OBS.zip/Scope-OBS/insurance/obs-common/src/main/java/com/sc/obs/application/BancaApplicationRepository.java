package com.sc.obs.application;

import io.crnk.core.queryspec.QuerySpec;
import io.crnk.core.repository.ResourceRepositoryBase;
import io.crnk.core.resource.list.ResourceList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BancaApplicationRepository extends ResourceRepositoryBase<BancaApplication, String> {

    @Autowired
    private BancaApplicationProcessorRegistry applicationProcessorFactoryRegistry;

    public BancaApplicationRepository() {
        super(BancaApplication.class);
    }

    @Override
    public ResourceList<BancaApplication> findAll(QuerySpec querySpec) {
        throw new UnsupportedOperationException("to be implemented");
    }

    @Override
    public BancaApplication save(BancaApplication bancaApplication) {
        String country = bancaApplication.getCountry();
        String productCode = bancaApplication.getBancaApplicationDetail().getProductCode();
        return applicationProcessorFactoryRegistry.get(country, productCode).submitBancaApplication(bancaApplication);
    }

}
