package com.sc.obs.application;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Documents {
    @JsonProperty("document-type")
    private String documentType;
    @JsonProperty("document-number")
    private String documentNumber;
    @JsonProperty("document-name")
    private String documentName;
    @JsonProperty("document-description")
    private String documentDescription;
    @JsonProperty("document-status")
    private String documentStatus;
    @JsonProperty("document-data")
    private String documentData;
    @JsonProperty("document-extension")
    private String documentExtension;
}
