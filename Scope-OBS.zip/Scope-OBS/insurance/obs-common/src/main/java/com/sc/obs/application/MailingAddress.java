package com.sc.obs.application;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MailingAddress {
    @JsonProperty("address-type")
    private String addressType; //Residency/ office etc
    @JsonProperty("address-line1")
    private String addressLine1;
    @JsonProperty("address-line2")
    private String addressLine2;
    @JsonProperty("address-line3")
    private String addressLine3;
    @JsonProperty("state")
    private String state;
    @JsonProperty("city-name")
    private String cityName;
    @JsonProperty("postal-code")
    private String postalCode;
    @JsonProperty("country-code")
    private String countryCode;
    @JsonProperty("country-name")
    private String countryName;
}
