package com.sc.obs.auth.otp;

import com.sc.obs.data.entity.ObsJpaBaseEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "OBS_OTP_MESSAGE_TEMPLATE")
public class OtpMessageTemplate extends ObsJpaBaseEntity{
	
    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "ACTION_NAME")
    private String actionName;

    @Column(name = "COUNTRY")
    private String countryCode;

    @Column(name = "LANGUAGE")
    private String language;
    
    @Column(name = "TITLE")
    private String title;

    @Column(name = "TEMPLATE")
    private String template;
    
    @Column(name = "DATETIME_FORMAT")
    private String dateTimeFormat;
}
