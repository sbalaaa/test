package com.fusesource.camel.exercises.aggregator;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AggregatorApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(AggregatorApplication.class, args);
		
	}
}
