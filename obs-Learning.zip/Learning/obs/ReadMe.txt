1. common
2. cls-svc-obs-ke ---> test not covered.
3. 

