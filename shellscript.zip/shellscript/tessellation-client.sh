#!/bin/bash
# this is the launcher for a standalone execution
USER_HOME=/home/ubuntu
SOURCE_DIR=${USER_HOME}/bala/blockchain/tessellation
CLIENT_DIR=${USER_HOME}/bala/blockchain/executables
CORE_FILE=${SOURCE_DIR}/modules/core/target/scala-2.13/tessellation-core-assembly-0.6.0-SNAPSHOT.jar
KEYTOOL_FILE=${SOURCE_DIR}/modules/keytool/target/scala-2.13/tessellation-keytool-assembly-0.6.0-SNAPSHOT.jar
TOKEN=${SOURCE_DIR}/examples/l0-token/target/scala-2.13/l0-token-assembly-0.1.0-SNAPSHOT.jar
PUBLISHER=${SOURCE_DIR}/examples/simple-snapshot-publisher/target/scala-2.13/simple-snapshot-publisher-assembly-0.1.0.jar
GENESIS_FILE=${USER_HOME}/bala/blockchain/genesis.csv
cd ${SOURCE_DIR}
export GITHUB_TOKEN=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
CUR_DIR=$PWD
echo ============================================
echo RUNNING sbt assembly INSIDE $CUR_DIR
echo ============================================
sbt assembly
echo ============================================
echo RUNNING sbt "shared/publishM2;kernel/publishM2" INSIDE $CUR_DIR
echo ============================================
sbt "shared/publishM2;kernel/publishM2"
#export CL_KEYSTORE=./key.p12
#export CL_KEYALIAS=walletalias
#export CL_PASSWORD=welcome123
export CL_KEYSTORE=./key.p12 CL_KEYALIAS=walletalias CL_PASSWORD=welcome123
cd ${SOURCE_DIR}\examples\l0-token
CUR_DIR=$PWD
echo ============================================
echo RUNNING sbt assembly INSIDE $CUR_DIR\examples\l0-token
echo ============================================
sbt assembly
cd ${SOURCE_DIR}\examples\simple-snapshot-publisher
CUR_DIR=$PWD
echo ============================================
echo RUNNING sbt assembly INSIDE $CUR_DIR\examples\simple-snapshot-publisher
echo ============================================
sbt assembly
echo ============================================
echo COPYING JARS FROM ${SOURCE_DIR}\modules AND example to ${CLIENT_DIR}
echo ============================================
cp ${CORE_FILE} ${CLIENT_DIR}
cp ${KEYTOOL_FILE} ${CLIENT_DIR}
cp ${TOKEN} ${CLIENT_DIR}
cp ${PUBLISHER} ${CLIENT_DIR}
echo ============================================
echo RENAMING JARS INSIDE ${CLIENT_DIR}
echo ============================================
cd ${CLIENT_DIR}
mv tessellation-core-assembly-0.6.0-SNAPSHOT.jar core.jar
mv l0-token-assembly-0.1.0-SNAPSHOT.jar channel.jar
mv simple-snapshot-publisher-assembly-0.1.0.jar publisher.jar
echo ============================================
echo COPYING Genesis file FROM $GENESIS_FILE to $CLIENT_DIR
echo ============================================
cp ${GENESIS_FILE} {CLIENT_DIR}
echo ============================================
echo GENERATING KEY FILE key.p12
echo ============================================
java -jar tessellation-keytool-assembly-0.6.0-SNAPSHOT.jar generate
echo ============================================
echo LOAD A CHANNEL
echo ============================================
java "-Xms1024M" "-Xmx3G" "-Xss256K" -cp core.jar:publisher.jar org.tessellation.Main run-genesis ./genesis.csv --ip 13.40.184.226 --public-port 9000 --p2p-port 9001 --cli-port 9002 -e testnet
