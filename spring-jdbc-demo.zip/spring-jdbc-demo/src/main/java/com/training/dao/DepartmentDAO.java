package com.training.dao;

import java.util.List;

import com.training.entity.Department;

public interface DepartmentDAO {

	public List<Department> listAllDepartments();
	public Department selectDepartmentById(int departmentId);
	public Department selectDepartmentByName(String departmentName);
	public void insertDepartment(Department department);
	public void updateDepartment(Department department);
	public void deleteDepartment(int departmentId);
}
