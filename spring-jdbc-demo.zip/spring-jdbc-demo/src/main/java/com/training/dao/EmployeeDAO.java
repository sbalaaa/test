package com.training.dao;

import java.util.List;

import com.training.entity.Employee;

public interface EmployeeDAO {

	public List<Employee> listAllEmployees();
	public Employee selectEmployeeById(int employeeId);
	public List<Employee> getEmployeesByDepartment(int departmentId);
	public void insertEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
}
