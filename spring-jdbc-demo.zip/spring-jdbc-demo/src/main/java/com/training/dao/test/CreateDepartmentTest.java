package com.training.dao.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.ApplicationConfig;
import com.training.dao.DepartmentDAO;
import com.training.entity.Department;

public class CreateDepartmentTest {

	public static void main(String[] args) {
		
		System.out.println("Spring Containers Started by loading Java Configuration ApplicationConfig");
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		DepartmentDAO dao = (DepartmentDAO) context.getBean("departmentDAOImpl");
		System.out.println("\n \n");
		
		System.out.println("Insert a Department");
		Department department = new Department("Maths","ADMIN");
		dao.insertDepartment(department);
		
		System.out.println("\n \n");
		((ConfigurableApplicationContext)context).close();
		System.out.println("Spring Containers Closed");
	}

}
