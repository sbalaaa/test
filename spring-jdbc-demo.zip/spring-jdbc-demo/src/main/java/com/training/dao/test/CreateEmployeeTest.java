package com.training.dao.test;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.ApplicationConfig;
import com.training.dao.EmployeeDAO;
import com.training.entity.Department;
import com.training.entity.Employee;

public class CreateEmployeeTest {

	public static void main(String[] args) {
		
		System.out.println("Spring Containers Started by loading Java Configuration ApplicationConfig");
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		EmployeeDAO dao = (EmployeeDAO) context.getBean("employeeDAOImpl");
		System.out.println("\n \n");
		
		System.out.println("Insert a Employee");
		Employee employee = getEmployee();
		dao.insertEmployee(employee);
		
		System.out.println("\n \n");
		((ConfigurableApplicationContext)context).close();
		System.out.println("Spring Containers Closed");
	}
	
	
	private static Employee getEmployee() {
		
		Employee employee = new Employee();
		employee.setFirstName("David");
		employee.setLastName("Charless");
		employee.setGender("M");
		employee.setAge(30);
		employee.setEmail("sample@gmail.com");
		employee.setPhoneNumber("123-4563");
		employee.setHireDate(new Date());
		employee.setSalary(1000.00);
		
		Department department = new Department();
		department.setDepartmentId(12);
		employee.setDepartmentId(department);
		
		return employee;
	}

}
