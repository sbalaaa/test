package com.training.dao.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.ApplicationConfig;
import com.training.dao.EmployeeDAO;

public class DeleteEmployeeTest {

	public static void main(String[] args) {
		System.out.println("Spring Containers Started by loading Java Configuration ApplicationConfig");	
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		EmployeeDAO dao = (EmployeeDAO) context.getBean("employeeDAOImpl");
		System.out.println("\n \n");
		
		dao.deleteEmployee(6);
		System.out.println("Delete the employee by ID");
		
		System.out.println("\n \n");
		((ConfigurableApplicationContext)context).close();
		System.out.println("Spring Containers Closed");
	}
	
	
	

}
