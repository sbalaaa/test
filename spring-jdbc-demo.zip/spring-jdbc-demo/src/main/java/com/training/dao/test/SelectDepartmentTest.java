package com.training.dao.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.ApplicationConfig;
import com.training.dao.DepartmentDAO;
import com.training.entity.Department;

public class SelectDepartmentTest {

	public static void main(String[] args) {
		System.out.println("Spring Containers Started by loading Java Configuration ApplicationConfig");
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		DepartmentDAO dao = (DepartmentDAO) context.getBean("departmentDAOImpl");
		System.out.println("\n \n");
		
		List<Department> departments = dao.listAllDepartments();
		
		for(Department department:departments){
			System.out.println(department);
		}
		
		System.out.println("\n \n");
		System.out.println("Select Single Record by Id");
		Department department = dao.selectDepartmentById(3);
		System.out.println(department);
		
		System.out.println("\n \n");
		((ConfigurableApplicationContext)context).close();
		System.out.println("Spring Containers Closed");

	}

}
