package com.training.dao.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.training.config.ApplicationConfig;
import com.training.dao.EmployeeDAO;
import com.training.entity.Employee;

public class SelectEmployeeTest {

	public static void main(String[] args) {
		
		System.out.println("Spring Containers Started by loading Java Configuration ApplicationConfig");	
		ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		EmployeeDAO dao = (EmployeeDAO) context.getBean("employeeDAOImpl");
		System.out.println("\n \n");
		
		List<Employee> employees = dao.listAllEmployees();
		
		for( Employee e : employees ) {
			System.out.println(e);
		}
		
		System.out.println("\n \n");
		System.out.println("Select Single Employee Record by Id");
		Employee e = dao.selectEmployeeById(1);
		System.out.println(e);
		
		System.out.println("\n \n");
		((ConfigurableApplicationContext)context).close();
		System.out.println("Spring Containers Closed");
	}
	
	
	

}
