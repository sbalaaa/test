package com.training.entity;

public class Department {

	private int departmentId;
	private String departmentName;
	private String createdBy;

	public Department(){
	}
	
	public Department(int departmentId){
		this.departmentId = departmentId;
	}
	
	public Department(int departmentId, String departmentName){
		this.departmentId = departmentId;
		this.departmentName = departmentName;
	}
	
	public Department(int departmentId, String departmentName, String createdBy){
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.createdBy = createdBy;
	}
	
	public Department(String departmentName, String createdBy){
		this.departmentName = departmentName;
		this.createdBy = createdBy;
	}
	
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "Department [departmentId=" + departmentId + ", departmentName=" + departmentName + ", createdBy="
				+ createdBy + "]";
	}
	
}
	
	

